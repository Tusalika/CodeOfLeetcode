create TYPE          "TYPE_CHECKGROUPNO_1"                                          is object
(part_name varchar2(255));
/

