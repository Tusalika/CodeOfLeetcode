create TYPE          "TYPE_CHECKGROUPNO_2"                                          is table of dmpdb2.type_checkgroupno_1;
/

