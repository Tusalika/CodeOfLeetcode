create TYPE          "TYPE_DOPRINT_1"                                          is object
( Part_Name varchar2(255),
  Presswork_ID varchar2(255),
  Print_To NUMBER,
  Unitage NUMBER, 
  DescriptionC varchar2(255),
  DescriptionE varchar2(255),
  WO_Parts_ID varchar2(255) 
);
/

