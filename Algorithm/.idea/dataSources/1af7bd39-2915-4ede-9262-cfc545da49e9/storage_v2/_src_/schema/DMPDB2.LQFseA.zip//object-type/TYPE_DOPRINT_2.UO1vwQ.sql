create TYPE          "TYPE_DOPRINT_2"                                          is table of dmpdb2.type_DoPrint_1;
/

