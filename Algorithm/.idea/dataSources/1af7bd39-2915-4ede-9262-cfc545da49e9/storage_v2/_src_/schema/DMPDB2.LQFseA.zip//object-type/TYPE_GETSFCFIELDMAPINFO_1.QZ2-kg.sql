create TYPE          "TYPE_GETSFCFIELDMAPINFO_1"                                          is object
(Field_Name VARCHAR2(255), 
 Mapped_Name  VARCHAR2(255), 
 TitleC VARCHAR2(255),  
 TitleE VARCHAR2(255), 
 Key_02 VARCHAR2(255),  
 Width NUMBER,  
 Is_Visible NUMBER, 
 Is_Fill_By_System  NUMBER, 
 Is_Fix_value NUMBER, 
 Is_Read_Only NUMBER,  
 Is_Not_Null NUMBER,  
 Default_Value VARCHAR2(255),  
 Range_Value VARCHAR2(255), 
 Foreign_Key VARCHAR2(255),  
 Is_Public NUMBER     
);
/

