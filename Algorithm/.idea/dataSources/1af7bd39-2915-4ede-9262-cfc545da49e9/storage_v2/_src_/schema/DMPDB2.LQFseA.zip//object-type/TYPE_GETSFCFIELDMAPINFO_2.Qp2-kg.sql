create TYPE          "TYPE_GETSFCFIELDMAPINFO_2"                                          is table of dmpdb2.TYPE_GETSFCFIELDMAPINFO_1;
/

