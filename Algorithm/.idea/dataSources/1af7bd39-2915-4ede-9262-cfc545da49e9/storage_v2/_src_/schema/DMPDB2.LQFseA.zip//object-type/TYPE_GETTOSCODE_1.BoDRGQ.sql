create TYPE          "TYPE_GETTOSCODE_1"                                          is object
(To_Station_Code varchar2(255));
/

