create TYPE          "TYPE_GETTOSCODE_2"                                          is table of dmpdb2.type_GetToSCode_1;
/

