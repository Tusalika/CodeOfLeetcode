create TYPE          "TYPE_LIKELOTPARTNO_1"                                          is object
(WO_Parts_ID NUMBER,
  Part_Name varchar2(255),
  EEE_Code varchar2(255),
  Cust_Part_No varchar2(255),
  Part_No varchar2(255),
  Begin_Time Date,
  In_Grp_Flag varchar2(255),
  Out_Grp_Flag varchar2(255),
  Unitage NUMBER,
  Scan_Type varchar2(255),
  Part_Type varchar2(255),
  Station_Code varchar2(255)
);
/

