create TYPE          "TYPE_LIKELOTPARTNO_2"                                          is table of dmpdb2.type_LikeLotPartNo_1;
/

