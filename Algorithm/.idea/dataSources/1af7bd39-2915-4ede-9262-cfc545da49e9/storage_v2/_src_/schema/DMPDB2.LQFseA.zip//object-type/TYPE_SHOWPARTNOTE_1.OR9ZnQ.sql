create TYPE          "TYPE_SHOWPARTNOTE_1"                                          is object
( Part_Name varchar2(255),
  Cust_Part_No varchar2(255),
  Part_Desc varchar2(255),
  Image_01 BLOB,
  Image_02 BLOB
);
/

