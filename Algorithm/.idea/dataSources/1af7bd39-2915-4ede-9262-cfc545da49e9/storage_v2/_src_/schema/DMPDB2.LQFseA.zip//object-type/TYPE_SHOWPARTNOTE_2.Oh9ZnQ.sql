create TYPE          "TYPE_SHOWPARTNOTE_2"                                          is table of dmpdb2.type_ShowPartNote_1;
/

