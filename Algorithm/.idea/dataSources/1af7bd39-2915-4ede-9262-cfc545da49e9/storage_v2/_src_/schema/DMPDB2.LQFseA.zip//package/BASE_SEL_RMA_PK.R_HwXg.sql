create PACKAGE        Base_Sel_Rma_Pk
AS
   TYPE CURSORTYPE IS REF CURSOR;
   PROCEDURE GET_MENU_INFO_T (
      V_ROLE_ID   IN       VARCHAR2,
      RES         OUT      VARCHAR2,
      P_CURSOR    OUT      Base_Sel_Rma_Pk.CURSORTYPE
   );


END Base_Sel_Rma_Pk;
/

