create PACKAGE BODY        Base_Sel_Rma_Pk AS                                                                                                                                                                                                                                          

PROCEDURE GET_Menu_Info_T(
                            v_role_id IN VARCHAR2,
                            RES OUT VARCHAR2,
                          P_CURSOR OUT Base_Sel_Rma_Pk.CURSORTYPE )
AS 

   BEGIN
   
   
    open p_cursor for
            
     SELECT  a.id,A.MODULE_NAME,A.MODULE_LEVEL,A.PARENT_MODULE_ID,A.MODULE_URL,A.MODULE_ORDER,
     A.IS_MAIN,A.DEL_fLAG
    FROM DMPDB2.C_SYS_WEB_MODULE_T A     
    WHERE A.DEL_FLAG=0
    ORDER BY A.id,A.module_order;
            
        
     

 RES :='OK!';
           EXCEPTION
             WHEN OTHERS THEN
               RES := ' Exception Error.';

END GET_Menu_Info_T;

END Base_Sel_Rma_Pk;
/

