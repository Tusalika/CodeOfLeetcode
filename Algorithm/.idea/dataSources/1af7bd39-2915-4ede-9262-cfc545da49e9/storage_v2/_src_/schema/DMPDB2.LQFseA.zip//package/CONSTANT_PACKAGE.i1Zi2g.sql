create PACKAGE        constant_package
IS
   g_commodity_id    CONSTANT PLS_INTEGER  := 33;
   --g_lock_flag_none   CONSTANT VARCHAR2 (2) := '*0';
   g_lock_flag_wip   CONSTANT VARCHAR2 (2) := '*1';
--g_lock_flag_fg     CONSTANT VARCHAR2 (2) := '*2';
END constant_package;

/

