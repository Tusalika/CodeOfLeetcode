create PACKAGE        FATP_MAINTAIN_DATA_PK
AS
   /******************************************************************************
      NAME:       FATP_MAINTAIN_DATA_SP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        2014/7/16      F3455247       1. Created this package.
   ******************************************************************************/

   TYPE CURSORTYPE IS REF CURSOR;

   PROCEDURE ROOT_CAUSE_LIST (
      V_SEARCH   IN     VARCHAR2,
      V_TYPE     IN     VARCHAR2,
      V_PAGE     IN     NUMBER,
      V_COUNT       OUT NUMBER,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE);

   PROCEDURE ROOT_CAUSE_MODIFY (RES                  OUT VARCHAR2,
                             V_TYPE            IN     VARCHAR2,
                             V_COMMODITY_ID    IN     VARCHAR2,
                             V_USER_ID         IN     VARCHAR2,
                             V_ROOT_CAUSE_ID   IN     VARCHAR2,
                             V_CODE            IN     VARCHAR2,
                             V_DESCC           IN     VARCHAR2,
                             V_DESCE           IN     VARCHAR2,
                             V_PROPERTY_01     IN     VARCHAR2,
                             V_PROPERTY_02     IN     VARCHAR2,
                             V_PROPERTY_03     IN     VARCHAR2,
                             V_PROPERTY_04     IN     VARCHAR2,
                             V_PROPERTY_05     IN     VARCHAR2,
                             V_PROPERTY_06     IN     VARCHAR2,
                             V_PROPERTY_07     IN     VARCHAR2,
                             V_PROPERTY_08     IN     VARCHAR2,
                             V_PROPERTY_09     IN     VARCHAR2,
                             V_PROPERTY_10     IN     VARCHAR2,
                             V_PROPERTY_11     IN     VARCHAR2,
                             V_PROPERTY_12     IN     VARCHAR2,
                             V_PROPERTY_13     IN     VARCHAR2,
                             V_PROPERTY_14     IN     VARCHAR2,
                             V_PROPERTY_15     IN     VARCHAR2,
                             V_PROPERTY_16     IN     VARCHAR2);
                             
                                 


   PROCEDURE ROOT_CAUSE_DELETE (RES                  OUT VARCHAR2,
                                V_ROOT_CAUSE_ID   IN     VARCHAR2,
                                V_USER_ID         IN     NUMBER);
                                
   PROCEDURE GETSTATION  (
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE
   );              
        
    PROCEDURE GETSYMPTOMINFO  (
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE
   );    
   
   ------------------------------------------------
   
    PROCEDURE COMPONENT_POSITION_LIST (
      V_SEARCH   IN     VARCHAR2,
      V_TYPE     IN     VARCHAR2,
      V_PAGE     IN     NUMBER,
      V_COUNT       OUT NUMBER,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE);

   PROCEDURE COMPONENT_POSITION_MODIFY (RES                 OUT VARCHAR2,
                                        V_TYPE           IN     VARCHAR2,
                                        V_COMMODITY_ID   IN     VARCHAR2,
                                        V_USER_ID        IN     VARCHAR2,
                                        V_ID             IN     VARCHAR2,
                                        V_CATEGORY_KEY   IN     VARCHAR2,
                                        V_COMPONENT      IN     VARCHAR2,
                                        V_POSITION       IN     VARCHAR2,
                                        V_ROOT           IN     VARCHAR2,
                                        V_RESON_TYPE     IN     VARCHAR2,
                                        V_RISK_STATION   IN     VARCHAR2,
                                        V_KEY_POSITION   IN     VARCHAR2,
                                        V_ACTION         IN     VARCHAR2,
                                        V_VENDOR         IN     VARCHAR2,
                                        V_REMARK         IN     VARCHAR2  );

   PROCEDURE COMPONENT_POSITION_DELETE (RES                  OUT VARCHAR2,
                                V_ID   IN     VARCHAR2,
                                V_USER_ID         IN     NUMBER);
                                
    PROCEDURE WIP_DETAILS_LIST (
      V_SEARCH   IN     VARCHAR2,
      V_TYPE     IN     VARCHAR2,
      V_PAGE     IN     NUMBER,
      V_COUNT       OUT NUMBER,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE);

   PROCEDURE WIP_DETAILS_MODIFY (RES                 OUT VARCHAR2,
                                        V_TYPE           IN     VARCHAR2,
                                        V_CATEGORY_KEY   IN     VARCHAR2,
                                        V_USER_ID        IN     VARCHAR2,
                                        V_WIPNO             IN     VARCHAR2,
                                        V_TEST_STATION   IN     VARCHAR2,
                                        V_SYMPTOM      IN     VARCHAR2,
                                        V_SYMPTOM_DESC       IN     VARCHAR2,
                                        V_SYMPTOM_PDCA           IN     VARCHAR2,
                                        V_FAIL_VALUE     IN     VARCHAR2,
                                        V_PASS_VALUE   IN     VARCHAR2,
                                        V_COMPONENT   IN     VARCHAR2,
                                        V_POSITION         IN     VARCHAR2,
                                        V_ROOT         IN     VARCHAR2,
                                        V_REMARK         IN     VARCHAR2,
                                        V_COMPONENT_SERIAL_NO IN     VARCHAR2,
                                        V_COMPONENT_VENDOR IN     VARCHAR2,
                                        V_ASY_LINE IN     VARCHAR2,
                                        V_ASY_STATION IN     VARCHAR2,
                                        V_ASY_TIME   IN     VARCHAR2,
                                        V_RC_CATEGORY   IN  VARCHAR2,
                                         V_ID                    IN     VARCHAR2);

   PROCEDURE WIP_DETAILS_DELETE (RES                  OUT VARCHAR2,
                                V_ID   IN     VARCHAR2,
                                V_USER_ID         IN     NUMBER);      
                                
                                                         
                                
                                
     PROCEDURE WIP_GET_FAILURESTATUS
    (
    V_SN    IN  VARCHAR2, 
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE
    );                                                          

    
 
 

   PROCEDURE GETCATEGORYKEY  (
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE
   );
   
    PROCEDURE GETCOMPONENT  (
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE,
   V_MODEL IN   VARCHAR2
   );
   
    PROCEDURE GETPOSITION  (
    V_COMPONENT    IN  VARCHAR2,
    V_MODEL IN   VARCHAR2,
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE
   );
   
   PROCEDURE GETROOT  (
    V_COMPONENT    IN  VARCHAR2,
     V_MODEL IN   VARCHAR2,
    V_POSITION      IN VARCHAR2,
   P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE
   );            
END FATP_MAINTAIN_DATA_PK;

/

