create PACKAGE BODY        FATP_MAINTAIN_DATA_PK
AS
   /******************************************************************************
      NAME:       FATP_MAINTAIN_DATA_SP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        2014/7/16      F3455247       1. Created this package.
   ******************************************************************************/


   PROCEDURE ROOT_CAUSE_LIST (
      V_SEARCH   IN     VARCHAR2,
      V_TYPE     IN     VARCHAR2,
      V_PAGE     IN     NUMBER,
      V_COUNT       OUT NUMBER,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
      VV_COUNT   NUMBER;
      V_BEGIN    NUMBER;
      V_END      NUMBER;
   BEGIN
      IF V_TYPE = 'SEARCH'
      THEN
         V_BEGIN := (V_PAGE - 1) * 15;                           --pagesite:15
         V_END := V_PAGE * 15;

         OPEN P_CURSOR FOR
            SELECT CODE,
                   DESCRIPTIONC,
                   DESCRIPTIONE,
                   PROPERTY_01,
                   PROPERTY_02,
                   PROPERTY_03,
                   PROPERTY_04,
                   PROPERTY_05,
                   PROPERTY_06,
                   PROPERTY_07,
                   PROPERTY_08,
                   PROPERTY_09,
                   PROPERTY_10,
                   PROPERTY_11,
                   PROPERTY_12,
                   PROPERTY_13,
                   PROPERTY_14,
                   PROPERTY_15,
                   PROPERTY_16,
                   SYMPTOM_CODE,
                   SYMPTOM_ID,
                   ID,
                   COMMODITY_ID
              FROM (  SELECT ROWNUM AS RW,
                             A.CODE,
                             A.DESCRIPTIONC,
                             A.DESCRIPTIONE,
                             A.PROPERTY_01,
                             A.PROPERTY_02,
                             A.PROPERTY_03,
                             A.PROPERTY_04,
                             A.PROPERTY_05,
                             A.PROPERTY_06,
                             A.PROPERTY_07,
                             A.PROPERTY_08,
                             A.PROPERTY_09,
                             DECODE (A.PROPERTY_10,
                                     'F', '功能',
                                     'C', '外觀',
                                     '')
                                AS PROPERTY_10,
                             A.PROPERTY_11,
                             A.PROPERTY_12,
                             A.PROPERTY_13,
                             A.PROPERTY_14,
                             A.PROPERTY_15,
                             A.PROPERTY_16,
                             B.CODE AS SYMPTOM_CODE,
                             B.ID AS SYMPTOM_ID,
                             A.ID,
                             A.COMMODITY_ID
                        FROM DMPDB2.ROOT_CAUSE A, DMPDB2.SYMPTOM B
                       WHERE     A.CODE LIKE NVL (V_SEARCH, A.CODE) || '%'
                             AND A.DEL_FLAG = 0
                             AND A.PROPERTY_02 = B.ID
                    ORDER BY A.EDIT_DATE DESC)
             WHERE RW > V_BEGIN AND RW <= V_END;

           SELECT COUNT (0)
             INTO VV_COUNT
             FROM DMPDB2.ROOT_CAUSE A, DMPDB2.SYMPTOM B
            WHERE     A.CODE LIKE NVL (V_SEARCH, A.CODE) || '%'
                  AND A.DEL_FLAG = 0
                  AND A.PROPERTY_02 = B.ID
         ORDER BY A.CODE;

         V_COUNT := VV_COUNT;
      ELSIF V_TYPE = 'EXPORT'
      THEN
         OPEN P_CURSOR FOR
              SELECT A.CODE,
                     A.DESCRIPTIONC,
                     A.DESCRIPTIONE,
                     A.PROPERTY_01,
                     A.PROPERTY_02,
                     A.PROPERTY_03,
                     A.PROPERTY_04,
                     A.PROPERTY_05,
                     A.PROPERTY_06,
                     A.PROPERTY_07,
                     A.PROPERTY_08,
                     A.PROPERTY_09,
                     A.PROPERTY_10,
                     A.PROPERTY_11,
                     A.PROPERTY_12,
                     A.PROPERTY_13,
                     A.PROPERTY_14,
                     A.PROPERTY_15,
                     A.PROPERTY_16,
                     B.CODE AS SYMPTOM_CODE,
                     B.ID AS SYMPTOM_ID,
                     A.ID,
                     A.COMMODITY_ID
                FROM DMPDB2.ROOT_CAUSE A, DMPDB2.SYMPTOM B
               WHERE     A.CODE LIKE NVL (V_SEARCH, A.CODE) || '%'
                     AND A.DEL_FLAG = 0
                     AND A.PROPERTY_02 = B.ID
            ORDER BY A.CODE;
      ELSE
         OPEN P_CURSOR FOR
              SELECT A.CODE,
                     A.DESCRIPTIONC,
                     A.DESCRIPTIONE,
                     A.PROPERTY_01,
                     A.PROPERTY_02,
                     A.PROPERTY_03,
                     A.PROPERTY_04,
                     A.PROPERTY_05,
                     A.PROPERTY_06,
                     A.PROPERTY_07,
                     A.PROPERTY_08,
                     A.PROPERTY_09,
                     A.PROPERTY_10,
                     A.PROPERTY_11,
                     A.PROPERTY_12,
                     A.PROPERTY_13,
                     A.PROPERTY_14,
                     A.PROPERTY_15,
                     A.PROPERTY_16,
                     B.CODE AS SYMPTOM_CODE,
                     B.ID AS SYMPTOM_ID,
                     A.ID,
                     A.COMMODITY_ID
                FROM DMPDB2.ROOT_CAUSE A, DMPDB2.SYMPTOM B
               WHERE     A.ID = NVL (V_SEARCH, A.ID)
                     AND A.DEL_FLAG = 0
                     AND A.PROPERTY_02 = B.ID
            ORDER BY A.CODE DESC;
      END IF;
   END ROOT_CAUSE_LIST;

   PROCEDURE ROOT_CAUSE_MODIFY (RES                  OUT VARCHAR2,
                                V_TYPE            IN     VARCHAR2,
                                V_COMMODITY_ID    IN     VARCHAR2,
                                V_USER_ID         IN     VARCHAR2,
                                V_ROOT_CAUSE_ID   IN     VARCHAR2,
                                V_CODE            IN     VARCHAR2,
                                V_DESCC           IN     VARCHAR2,
                                V_DESCE           IN     VARCHAR2,
                                V_PROPERTY_01     IN     VARCHAR2,
                                V_PROPERTY_02     IN     VARCHAR2,
                                V_PROPERTY_03     IN     VARCHAR2,
                                V_PROPERTY_04     IN     VARCHAR2,
                                V_PROPERTY_05     IN     VARCHAR2,
                                V_PROPERTY_06     IN     VARCHAR2,
                                V_PROPERTY_07     IN     VARCHAR2,
                                V_PROPERTY_08     IN     VARCHAR2,
                                V_PROPERTY_09     IN     VARCHAR2,
                                V_PROPERTY_10     IN     VARCHAR2,
                                V_PROPERTY_11     IN     VARCHAR2,
                                V_PROPERTY_12     IN     VARCHAR2,
                                V_PROPERTY_13     IN     VARCHAR2,
                                V_PROPERTY_14     IN     VARCHAR2,
                                V_PROPERTY_15     IN     VARCHAR2,
                                V_PROPERTY_16     IN     VARCHAR2)
   IS
      V_COUNT   NUMBER;
   BEGIN
      IF V_TYPE = 'ADD'
      THEN 
         SELECT COUNT (0)
           INTO V_COUNT
           FROM DMPDB2.ROOT_CAUSE
          WHERE     DEL_FLAG = 0
                AND CODE = V_CODE
                AND DESCRIPTIONC = V_DESCC
                AND PROPERTY_07 = V_PROPERTY_07;

         IF V_COUNT > 0
         THEN
            RES := '你維護的信息已經存在!';
         ELSE
            INSERT INTO DMPDB2.ROOT_CAUSE (ID,
                                           COMMODITY_ID,
                                           CODE,
                                           DESCRIPTIONC,
                                           DESCRIPTIONE,
                                           ADD_BY,
                                           ADD_DATE,
                                           EDIT_BY,
                                           EDIT_DATE,
                                           DEL_FLAG,
                                           PROPERTY_01,
                                           PROPERTY_02,
                                           PROPERTY_03,
                                           PROPERTY_04,
                                           PROPERTY_05,
                                           PROPERTY_06,
                                           PROPERTY_07,
                                           PROPERTY_08,
                                           PROPERTY_09,
                                           PROPERTY_10,
                                           PROPERTY_11,
                                           PROPERTY_12,
                                           PROPERTY_13,
                                           PROPERTY_14,
                                           PROPERTY_15,
                                           PROPERTY_16)
                 VALUES (
                           (SELECT NVL (MAX (ID), 0) + 1
                              FROM DMPDB2.ROOT_CAUSE),
                           '33',
                           V_CODE,
                           V_DESCC,
                           V_DESCE,
                           V_USER_ID,
                           SYSDATE,
                           V_USER_ID,
                           SYSDATE,
                           0,
                           V_PROPERTY_01,
                           V_PROPERTY_02,
                           V_PROPERTY_03,
                           V_PROPERTY_04,
                           V_PROPERTY_05,
                           V_PROPERTY_06,
                           V_PROPERTY_07,
                           V_PROPERTY_08,
                           V_PROPERTY_09,
                           V_PROPERTY_10,
                           V_PROPERTY_11,
                           V_PROPERTY_12,
                           V_PROPERTY_13,
                           V_PROPERTY_14,
                           V_PROPERTY_15,
                           V_PROPERTY_16);
         END IF;
      ELSIF V_TYPE = 'EDIT'
      THEN 
            UPDATE DMPDB2.ROOT_CAUSE
               SET DESCRIPTIONC = V_DESCC,
                   DESCRIPTIONE = V_DESCE,
                   EDIT_BY = V_USER_ID,
                   EDIT_DATE = SYSDATE,
                   PROPERTY_01 = V_PROPERTY_01,
                   PROPERTY_02 = V_PROPERTY_02,
                   PROPERTY_03 = V_PROPERTY_03,
                   PROPERTY_04 = V_PROPERTY_04,
                   PROPERTY_05 = V_PROPERTY_05,
                   PROPERTY_06 = V_PROPERTY_06,
                   PROPERTY_07 = V_PROPERTY_07,
                   PROPERTY_08 = V_PROPERTY_08,
                   PROPERTY_09 = V_PROPERTY_09,
                   PROPERTY_10 = V_PROPERTY_10,
                   PROPERTY_11 = V_PROPERTY_11,
                   PROPERTY_12 = V_PROPERTY_12,
                   PROPERTY_13 = V_PROPERTY_13,
                   PROPERTY_14 = V_PROPERTY_14,
                   PROPERTY_15 = V_PROPERTY_15,
                   PROPERTY_16 = V_PROPERTY_16
             WHERE ID = V_ROOT_CAUSE_ID; 
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         RES := SQLERRM;
   END ROOT_CAUSE_MODIFY;

   PROCEDURE ROOT_CAUSE_DELETE (RES                  OUT VARCHAR2,
                                V_ROOT_CAUSE_ID   IN     VARCHAR2,
                                V_USER_ID         IN     NUMBER)
   IS
   BEGIN
      UPDATE DMPDB2.ROOT_CAUSE
         SET DEL_FLAG = 1, EDIT_BY = V_USER_ID, EDIT_DATE = SYSDATE
       WHERE ID = V_ROOT_CAUSE_ID;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         RES := SQLERRM ();
   END ROOT_CAUSE_DELETE;

   PROCEDURE GETSTATION (P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
   BEGIN
      OPEN P_CURSOR FOR
           SELECT ID,
                  CODE,
                  NAMEC,
                  NAMEE,
                  CODE || '<>' || NAMEC AS NAME
             FROM DMPDB2.STATION
            WHERE DEL_FLAG = 0
         ORDER BY CODE;
   END GETSTATION;

   PROCEDURE GETSYMPTOMINFO (P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
   BEGIN
      OPEN P_CURSOR FOR
           SELECT ID,
                  COMMODITY_ID,
                  CODE,
                  NAMEC,
                  NAMEE,
                  CODE || '<>' || NAMEC AS TEXT
             FROM DMPDB2.SYMPTOM
            WHERE DEL_FLAG = 0
         ORDER BY CODE;
   END GETSYMPTOMINFO;

   PROCEDURE COMPONENT_POSITION_LIST (
      V_SEARCH   IN     VARCHAR2,
      V_TYPE     IN     VARCHAR2,
      V_PAGE     IN     NUMBER,
      V_COUNT       OUT NUMBER,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
      VV_COUNT   NUMBER;
      V_BEGIN    NUMBER;
      V_END      NUMBER;
   BEGIN
      IF V_TYPE = 'SEARCH'
      THEN
         V_BEGIN := (V_PAGE - 1) * 15;                           --pagesite:15
         V_END := V_PAGE * 15;

         OPEN P_CURSOR FOR
            SELECT *
              FROM (SELECT A.*, ROWNUM AS RW
                      FROM DMPDB2.FA_COMPONENT_POSITION A
                     WHERE (A.CATEGORY_KEY LIKE
                               NVL (V_SEARCH, A.CATEGORY_KEY) || '%'
                            OR A.COMPONENT LIKE
                                  NVL (V_SEARCH, A.COMPONENT) || '%'
                            OR A.POSITION LIKE
                                  NVL (V_SEARCH, A.POSITION) || '%'
                            OR A.ROOT LIKE NVL (V_SEARCH, A.ROOT) || '%')
                           AND DEL_FLAG = 0)
             WHERE RW BETWEEN V_BEGIN AND V_END;


           SELECT COUNT (0)
             INTO VV_COUNT
             FROM DMPDB2.FA_COMPONENT_POSITION A
            WHERE (   A.CATEGORY_KEY LIKE NVL (V_SEARCH, A.CATEGORY_KEY) || '%'
                   OR A.COMPONENT LIKE NVL (V_SEARCH, A.COMPONENT) || '%'
                   OR A.POSITION LIKE NVL (V_SEARCH, A.POSITION) || '%'
                   OR A.ROOT LIKE NVL (V_SEARCH, A.ROOT) || '%')
                  AND A.DEL_FLAG = 0
         ORDER BY A.COMPONENT;

         V_COUNT := VV_COUNT;
      ELSE
         OPEN P_CURSOR FOR
            SELECT *
              FROM DMPDB2.FA_COMPONENT_POSITION
             WHERE ID = V_SEARCH AND DEL_FLAG = 0;
      END IF;
   END COMPONENT_POSITION_LIST;

   PROCEDURE COMPONENT_POSITION_MODIFY (RES                 OUT VARCHAR2,
                                        V_TYPE           IN     VARCHAR2,
                                        V_COMMODITY_ID   IN     VARCHAR2,
                                        V_USER_ID        IN     VARCHAR2,
                                        V_ID             IN     VARCHAR2,
                                        V_CATEGORY_KEY   IN     VARCHAR2,
                                        V_COMPONENT      IN     VARCHAR2,
                                        V_POSITION       IN     VARCHAR2,
                                        V_ROOT           IN     VARCHAR2,
                                        V_RESON_TYPE     IN     VARCHAR2,
                                        V_RISK_STATION   IN     VARCHAR2,
                                        V_KEY_POSITION   IN     VARCHAR2,
                                        V_ACTION         IN     VARCHAR2,
                                        V_VENDOR         IN     VARCHAR2,
                                        V_REMARK         IN     VARCHAR2)
   IS
      V_COUNT   NUMBER;
   BEGIN
      --        SELECT COUNT(0) INTO V_COUNT FROM DMPDB2.FA_COMPONENT_POSITION
      --        WHERE DEL_FLAG=0
      --        ;
      IF V_TYPE = 'ADD'
      THEN
         INSERT INTO DMPDB2.FA_COMPONENT_POSITION (CATEGORY_KEY,
                                                   COMPONENT,
                                                   POSITION,
                                                   ROOT,
                                                   RESON_TYPE,
                                                   RISK_STATION,
                                                   KEY_POSITION,
                                                   ACTION,
                                                   VENDOR,
                                                   REMARK,
                                                   ADD_BY,
                                                   ADD_DATE,
                                                   EDIT_BY,
                                                   EDIT_DATE)
              VALUES (V_CATEGORY_KEY,
                      V_COMPONENT,
                      V_POSITION,
                      V_ROOT,
                      V_RESON_TYPE,
                      V_RISK_STATION,
                      V_KEY_POSITION,
                      V_ACTION,
                      V_VENDOR,
                      V_REMARK,
                      V_USER_ID,
                      SYSDATE,
                      V_USER_ID,
                      SYSDATE);
      ELSE
         UPDATE DMPDB2.FA_COMPONENT_POSITION
            SET COMPONENT = V_COMPONENT,
                POSITION = V_POSITION,
                ROOT = V_ROOT,
                RESON_TYPE = V_RESON_TYPE,
                RISK_STATION = V_RISK_STATION,
                KEY_POSITION = V_KEY_POSITION,
                ACTION = V_ACTION,
                VENDOR = V_VENDOR,
                REMARK = V_REMARK,
                EDIT_BY = V_USER_ID,
                EDIT_DATE = SYSDATE
          WHERE ID = V_ID;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         RES := SQLERRM;
   END COMPONENT_POSITION_MODIFY;

   PROCEDURE COMPONENT_POSITION_DELETE (RES            OUT VARCHAR2,
                                        V_ID        IN     VARCHAR2,
                                        V_USER_ID   IN     NUMBER)
   IS
   BEGIN
      UPDATE DMPDB2.FA_COMPONENT_POSITION
         SET DEL_FLAG = 1, EDIT_BY = V_USER_ID, EDIT_DATE = SYSDATE
       WHERE ID = V_ID;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         RES := SQLERRM;
   END COMPONENT_POSITION_DELETE;

   PROCEDURE WIP_DETAILS_LIST (
      V_SEARCH   IN     VARCHAR2,
      V_TYPE     IN     VARCHAR2,
      V_PAGE     IN     NUMBER,
      V_COUNT       OUT NUMBER,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
      VV_COUNT   NUMBER;
      V_BEGIN    NUMBER;
      V_END      NUMBER;
   BEGIN
      IF V_TYPE = 'SEARCH'
      THEN
         V_BEGIN := (V_PAGE - 1) * 15;                           --pagesite:15
         V_END := V_PAGE * 15;

         OPEN P_CURSOR FOR
            SELECT RW,
                   ID,
                   CATEGORY_KEY,
                   WIPNO,
                   TEST_STATION,
                   SYMPTOM,
                   SYMPTOM_DESC,
                   SYMPTOM_PDCA,
                   FAIL_VALUE,
                   PASS_VALUE,
                   COMPONENT,
                   POSITION,
                   ROOT,
                   REMARK,
                   COMPONENT_SERIAL_NO,
                   COMPONENT_VENDOR,
                   ASY_LINE,
                   ASY_STATION,
                   ASY_TIME
              FROM (  SELECT ROWNUM RW,
                             ID,
                             CATEGORY_KEY,
                             WIPNO,
                             TEST_STATION,
                             SYMPTOM,
                             SYMPTOM_DESC,
                             SYMPTOM_PDCA,
                             FAIL_VALUE,
                             PASS_VALUE,
                             COMPONENT,
                             POSITION,
                             ROOT,
                             REMARK,
                             COMPONENT_SERIAL_NO,
                             COMPONENT_VENDOR,
                             ASY_LINE,
                             ASY_STATION,
                             ASY_TIME
                        FROM DMPDB2.FA_WIP_DETAILS
                       WHERE (CATEGORY_KEY LIKE
                                 NVL (V_SEARCH, CATEGORY_KEY) || '%'
                              OR WIPNO LIKE NVL (V_SEARCH, WIPNO) || '%'
                              OR TEST_STATION LIKE
                                    NVL (V_SEARCH, TEST_STATION) || '%'
                              OR SYMPTOM LIKE NVL (V_SEARCH, SYMPTOM) || '%')
                             AND DEL_FLAG = 0
                    ORDER BY EDIT_DATE DESC)
             WHERE RW > V_BEGIN AND RW <= V_END;

         SELECT COUNT (0)
           INTO VV_COUNT
           FROM DMPDB2.FA_WIP_DETAILS
          WHERE (   CATEGORY_KEY LIKE NVL (V_SEARCH, CATEGORY_KEY) || '%'
                 OR WIPNO LIKE NVL (V_SEARCH, WIPNO) || '%'
                 OR TEST_STATION LIKE NVL (V_SEARCH, TEST_STATION) || '%'
                 OR SYMPTOM LIKE NVL (V_SEARCH, SYMPTOM) || '%')
                AND DEL_FLAG = 0;

         V_COUNT := VV_COUNT;
      ELSE
         OPEN P_CURSOR FOR
            SELECT ID,
                   CATEGORY_KEY,
                   WIPNO,
                   TEST_STATION,
                   SYMPTOM,
                   SYMPTOM_DESC,
                   SYMPTOM_PDCA,
                   FAIL_VALUE,
                   PASS_VALUE,
                   COMPONENT,
                   POSITION,
                   ROOT,
                   REMARK,
                   COMPONENT_SERIAL_NO,
                   COMPONENT_VENDOR,
                   ASY_LINE,
                   ASY_STATION,
                   ASY_TIME,
                   PROPERTY_01
              FROM DMPDB2.FA_WIP_DETAILS
             WHERE DEL_FLAG = 0 AND ID = V_SEARCH;
      END IF;
   END WIP_DETAILS_LIST;

   PROCEDURE WIP_DETAILS_MODIFY (RES                        OUT VARCHAR2,
                                 V_TYPE                  IN     VARCHAR2,
                                 V_CATEGORY_KEY          IN     VARCHAR2,
                                 V_USER_ID               IN     VARCHAR2,
                                 V_WIPNO                 IN     VARCHAR2,
                                 V_TEST_STATION          IN     VARCHAR2,
                                 V_SYMPTOM               IN     VARCHAR2,
                                 V_SYMPTOM_DESC          IN     VARCHAR2,
                                 V_SYMPTOM_PDCA          IN     VARCHAR2,
                                 V_FAIL_VALUE            IN     VARCHAR2,
                                 V_PASS_VALUE            IN     VARCHAR2,
                                 V_COMPONENT             IN     VARCHAR2,
                                 V_POSITION              IN     VARCHAR2,
                                 V_ROOT                  IN     VARCHAR2,
                                 V_REMARK                IN     VARCHAR2,
                                 V_COMPONENT_SERIAL_NO   IN     VARCHAR2,
                                 V_COMPONENT_VENDOR      IN     VARCHAR2,
                                 V_ASY_LINE              IN     VARCHAR2,
                                 V_ASY_STATION           IN     VARCHAR2,
                                 V_ASY_TIME              IN     VARCHAR2,
                                 V_RC_CATEGORY           IN     VARCHAR2,
                                 V_ID                    IN     VARCHAR2)
   IS
   BEGIN
      IF V_TYPE = 'ADD'
      THEN
         INSERT INTO DMPDB2.FA_WIP_DETAILS (CATEGORY_KEY,
                                            WIPNO,
                                            TEST_STATION,
                                            SYMPTOM,
                                            SYMPTOM_DESC,
                                            SYMPTOM_PDCA,
                                            FAIL_VALUE,
                                            PASS_VALUE,
                                            COMPONENT,
                                            POSITION,
                                            ROOT,
                                            REMARK,
                                            COMPONENT_SERIAL_NO,
                                            COMPONENT_VENDOR,
                                            ASY_LINE,
                                            ASY_STATION,
                                            ASY_TIME,
                                            PROPERTY_01,
                                            ADD_BY,
                                            ADD_DATE,
                                            EDIT_BY,
                                            EDIT_DATE,
                                            DEL_FLAG)
              VALUES (V_CATEGORY_KEY,
                      V_WIPNO,
                      V_TEST_STATION,
                      V_SYMPTOM,
                      V_SYMPTOM_DESC,
                      V_SYMPTOM_PDCA,
                      V_FAIL_VALUE,
                      V_PASS_VALUE,
                      V_COMPONENT,
                      V_POSITION,
                      V_ROOT,
                      V_REMARK,
                      V_COMPONENT_SERIAL_NO,
                      V_COMPONENT_VENDOR,
                      V_ASY_LINE,
                      V_ASY_STATION,
                      V_ASY_TIME,
                      V_RC_CATEGORY,
                      V_USER_ID,
                      SYSDATE,
                      V_USER_ID,
                      SYSDATE,
                      0);
      ELSE
         UPDATE DMPDB2.FA_WIP_DETAILS
            SET PASS_VALUE = V_PASS_VALUE,
                PROPERTY_01 = V_RC_CATEGORY,
                COMPONENT = V_COMPONENT,
                POSITION = V_POSITION,
                ROOT = V_ROOT,
                REMARK = V_REMARK,
                COMPONENT_SERIAL_NO = V_COMPONENT_SERIAL_NO,
                COMPONENT_VENDOR = V_COMPONENT_VENDOR,
                ASY_LINE = V_ASY_LINE,
                ASY_STATION = V_ASY_STATION,
                ASY_TIME = V_ASY_TIME,
                EDIT_BY = V_USER_ID,
                EDIT_DATE = SYSDATE
          WHERE ID = V_ID;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         RES := SQLERRM;
   END WIP_DETAILS_MODIFY;

   PROCEDURE WIP_DETAILS_DELETE (RES            OUT VARCHAR2,
                                 V_ID        IN     VARCHAR2,
                                 V_USER_ID   IN     NUMBER)
   IS
   BEGIN
      UPDATE DMPDB2.FA_WIP_DETAILS
         SET DEL_FLAG = 1, EDIT_BY = V_USER_ID, EDIT_DATE = SYSDATE
       WHERE ID = V_ID;
   END WIP_DETAILS_DELETE;



   PROCEDURE WIP_GET_FAILURESTATUS (
      V_SN       IN     VARCHAR2,
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
   BEGIN
      OPEN P_CURSOR FOR
         SELECT 'TEST_STATION' AS TEST_STATION,
                'SYMPTOM' AS SYMPTOM,
                'SYMPTOM_DESC' AS SYMPTOM_DESC,
                'SYMPTOM_PDCA' AS SYMPTOM_PDCA,
                'FAIL_VALUE' AS FAIL_VALUE
           FROM DUAL;
   END WIP_GET_FAILURESTATUS;



   PROCEDURE GETCATEGORYKEY (P_CURSOR OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
   BEGIN
      OPEN P_CURSOR FOR
           SELECT ID,
                  COMMODITY_ID,
                  CATEGORY_KEY,
                  PROCESS_CODE
             FROM DMPDB2.CATEGORY
            WHERE DEL_FLAG = 0
         ORDER BY CATEGORY_KEY;
   END GETCATEGORYKEY;

   PROCEDURE GETCOMPONENT (
      P_CURSOR      OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE,
      V_MODEL    IN     VARCHAR2)
   IS
   BEGIN
      OPEN P_CURSOR FOR
           SELECT ID, COMPONENT
             FROM DMPDB2.FA_COMPONENT_POSITION
            WHERE DEL_FLAG = 0 AND CATEGORY_KEY = V_MODEL
         ORDER BY COMPONENT;
   END GETCOMPONENT;

   PROCEDURE GETPOSITION (
      V_COMPONENT   IN     VARCHAR2,
      V_MODEL       IN     VARCHAR2,
      P_CURSOR         OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
   BEGIN
      OPEN P_CURSOR FOR
           SELECT ID, POSITION
             FROM DMPDB2.FA_COMPONENT_POSITION
            WHERE     DEL_FLAG = 0
                  AND COMPONENT = V_COMPONENT
                  AND CATEGORY_KEY = V_MODEL
         ORDER BY POSITION;
   END GETPOSITION;

   PROCEDURE GETROOT (V_COMPONENT   IN     VARCHAR2,
                      V_MODEL       IN     VARCHAR2,
                      V_POSITION    IN     VARCHAR2,
                      P_CURSOR         OUT FATP_MAINTAIN_DATA_PK.CURSORTYPE)
   IS
   BEGIN
      OPEN P_CURSOR FOR
           SELECT ID, ROOT
             FROM DMPDB2.FA_COMPONENT_POSITION
            WHERE     DEL_FLAG = 0
                  AND COMPONENT = V_COMPONENT
                  AND POSITION = V_POSITION
                  AND CATEGORY_KEY = V_MODEL
         ORDER BY POSITION;
   END GETROOT;
END FATP_MAINTAIN_DATA_PK;
/

