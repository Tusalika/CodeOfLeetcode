create PACKAGE        FATP_MAINTAIN_DATA_SP AS
/******************************************************************************
   NAME:       FATP_MAINTAIN_DATA_SP
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/7/16      F3455247       1. Created this package.
******************************************************************************/

  TYPE CURSORTYPE IS REF CURSOR;
  
  PROCEDURE ROOT_CAUSE_LIST(V_SEARCH IN VARCHAR2,
  V_TYPE IN VARCHAR2);

END FATP_MAINTAIN_DATA_SP;

/

