create PACKAGE BODY        FATP_MAINTAIN_DATA_SP AS
/******************************************************************************
   NAME:       FATP_MAINTAIN_DATA_SP
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/7/16      F3455247       1. Created this package.
   Package 創建時名字寫錯了，此Packing廢棄不用
******************************************************************************/

  TYPE CURSORTYPE IS REF CURSOR;
  
  PROCEDURE ROOT_CAUSE_LIST(V_SEARCH IN VARCHAR2,
  V_TYPE IN VARCHAR2)
  IS
  V_COUNT NUMBER;
  BEGIN
    SELECT COUNT(0) INTO V_COUNT FROM DMPDB2.ROOT_CAUSE;
  END ROOT_CAUSE_LIST;

END FATP_MAINTAIN_DATA_SP;
/

