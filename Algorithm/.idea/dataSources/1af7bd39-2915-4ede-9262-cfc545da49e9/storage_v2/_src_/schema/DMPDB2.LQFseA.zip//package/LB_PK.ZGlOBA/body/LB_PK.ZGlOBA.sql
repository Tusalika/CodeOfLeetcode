create package body        lb_pk as
  --create by SIDC-ERPII --King/Pan 20111201-----------------------
  procedure p_main(p_stage    varchar2,
                   p_user     varchar2,
                   p_flow     varchar2,
                   p_project  varchar2,
                   p_floor    varchar2,
                   p_to_floor varchar2,
                   p_snal_sn  varchar2,
                   p_enal_sn  varchar2,
                   p_cur      out cur_type) is
  begin
    --藍標掃描/盤點----------------
    /*    if p_user = 'TEST' then*/
    p_scan(p_stage,
           p_user,
           p_flow,
           p_project,
           p_floor,
           p_to_floor,
           p_snal_sn,
           p_enal_sn);
    /*    else
      g_msg := '系統升級中，請稍後再試。。。';
      g_ok  := 'N';
    end if;*/
  
    open p_cur for
      select g_msg, g_ok from dual;
  end;

  --藍標領/退料掃描、盤點--------------------------------------------
  procedure p_scan(p_stage    varchar2,
                   p_user     varchar2,
                   p_flow     varchar2,
                   p_project  varchar2,
                   p_floor    varchar2,
                   p_to_floor varchar2,
                   p_snal_sn  varchar2,
                   p_enal_sn  varchar2) is
  
    v_scan_sn   varchar2(30);
    v_ecan_sn   varchar2(30);
    v_nal_cn    integer; --NAL總數
    v_nal_ok_cn integer; --成功掃描NAL數
    v_bef_cn    integer; --由於前站沒有掃描，失敗NAL數
    v_sef_cn    integer; --由於本站已掃描，失敗NAL數
    v_used_cn   integer; --由于其他流程已使用, 失敗NAL數
    v_reced_cn  integer; --由于無領料記錄, 退料/盤點失敗nal數
    v_reted_cn  integer; --由于已退料,失敗盤點數
    v_united_cn integer; --由于良品/不良品已盤點,失敗盤點數
    v_cont      integer; --轉樓層的時候用
  begin
    v_nal_cn    := 0;
    v_nal_ok_cn := 0;
    v_bef_cn    := 0;
    v_sef_cn    := 0;
    v_used_cn   := 0;
    v_reced_cn  := 0;
    v_reted_cn  := 0;
    v_united_cn := 0;
    --add by Tom at 2012-4-6 116856068370540
    --根據OPM提供資料將  機種與藍標前五位綁定
    case p_project
      when 'N94-A1431' then
        begin
          if substr(p_snal_sn, 1, 5) <> '11685' then
            begin
              g_msg := '機種N94-A1431的藍標前五位不為11685,請檢查!';
              g_ok  := 'N';
              RETURN;
            end;
          end if;
        end;
      when 'N94-A1387' then
        begin
          if substr(p_snal_sn, 1, 5) <> '12047' then
            begin
              g_msg := '機種N94-1387的藍標前五位不為12047,請檢查!';
              g_ok  := 'N';
              RETURN;
            end;
          end if;
        end;
      when 'N88A' then
        begin
          if substr(p_snal_sn, 1, 5) <> '11489' then
            begin
              g_msg := '機種N88A的藍標前五位不為11489,請檢查!';
              g_ok  := 'N';
              RETURN;
            end;
          end if;
        end;
      when 'N90A' then
        begin
          if substr(p_snal_sn, 1, 5) <> '11471' then
            begin
              g_msg := '機種N90A的藍標前五位不為11471,請檢查!';
              g_ok  := 'N';
              RETURN;
            end;
          end if;
        end;
      else
        null;
    end case;
    --end add
  
    if p_flow = 'F004' or p_flow = 'F005' then
      --藍標盤點, 查詢最大盤點期別------------------
      select max(check_id) into g_max_check_id from lb_check;
      if nvl(g_max_check_id, '-') <> to_char(sysdate, 'yyyymmdd') then
        g_msg := '本日沒有盤點期別，不能盤點，請先建立盤點期別!!';
        g_ok  := 'N';
        return;
      end if;
    else
      --藍標掃描, 基本數據檢測與初始化------------------
      p_data_exam(p_flow, p_stage);
      if g_ok = 'N' then
        return;
      else
        p_data_stage(p_flow, p_stage);
      end if;
    end if;
  
    --START藍標領料、退料、盤點-------------------------------------
    --始終SN------------
    v_scan_sn := p_snal_sn;
    v_ecan_sn := p_enal_sn;
  
    v_nal_cn := (v_ecan_sn - v_scan_sn) / 10 + 1;
    if v_nal_cn > 30001 then
      g_msg := '本次掃描藍標' || v_nal_cn || '個批量過大,單次掃描批量<=30001個,請分批掃描！！';
      return;
    end if;
  
    --反掃描作業------------------------------
    if p_project = '@001' then
      --掃描藍標的流程
      select max(nvl(flow_id, 0))
        into g_lb_flow
        from lb_scan
       where nal_sn = p_snal_sn
         and stage_id = p_stage;
      --END ADD   
    
      --掃描藍標的下一個工站 add by Tom AT 2012-3-15    
      select max(nvl(stage_id, 0))
        INTO g_lb_next_stage_id
        from lb_flow_dtl
       where flow_id = g_lb_flow
         and flow_item in (select nvl(flow_item, 0) + 1
                             from lb_flow_dtl
                            where flow_id = g_lb_flow
                              and stage_id = p_stage);
    
      if nvl(g_lb_next_stage_id, '-') = '-' then
        --modify By Tom at 2012-3-15
        g_msg := '您不能進行反掃描作業，因為藍標的下一站沒有掃描工站！';
        return;
      end if;
      /*--add at 2012-3-15 匹配掃描帳號的流程和掃描藍標的流程
      if p_flow <> g_lb_flow then
        g_msg := '您不能進行反掃描作業，因為藍標的掃描流程和您的帳號不匹配！';
        return;
      end if;*/ --由於藍標只有走正常領料和非正常領料中的一個所以去掉
    
      update lb_scan
         set is_acti = 'N'
       where nal_sn >= p_snal_sn
         and nal_sn <= p_enal_sn
         and flow_id = g_lb_flow
         and stage_id = g_lb_next_stage_id --modify by Tom at 2012-3-15
         and is_acti = 'Y';
      v_used_cn := sql%rowcount;
      g_msg     := '本次返掃描藍標' || v_nal_cn || '個，成功返掃描' || v_used_cn || '個！';
      if v_nal_cn > v_used_cn then
        g_msg := g_msg || '失敗掃描原因可能是下一工站沒有掃描。';
      end if;
      return;
    end if;
  
    --轉樓層掃描作業------------------------------
    if p_project = '@002' then
      if p_stage <> 'S003' then
        g_msg := '只有S003工站具有轉樓層掃描藍標權限！';
        return;
      end if;
      --add by Tom at 2012-3-12  如果藍標在下一工站被掃描過的話，則不能進行轉樓層  
      -- 掃描藍標的流程
      select max(nvl(flow_id, 0))
        into g_lb_flow
        from lb_scan
       where nal_sn = p_snal_sn
         and stage_id = p_stage;
    
      --掃描藍標的下一個工站 add by Tom AT 2012-3-15    
      select max(nvl(stage_id, 0))
        INTO g_lb_next_stage_id
        from lb_flow_dtl
       where flow_id = g_lb_flow
         and flow_item in (select nvl(flow_item, 0) + 1
                             from lb_flow_dtl
                            where flow_id = g_lb_flow
                              and stage_id = p_stage);
      select count(1)
        into v_cont
        from lb_scan
       where nal_sn >= p_snal_sn
         and nal_sn <= p_enal_sn
            --and flow_id = p_flow     delete by Tom at 2012-3-14
         and stage_id = g_lb_next_stage_id
         and is_acti = 'Y';
    
      if v_cont >= 1 then
        g_msg := '本次轉樓層掃描藍標在下一工站' || g_next_stage_id ||
                 '已掃描，請對下一工站反掃描后再進行轉樓層的操作！';
        return;
      end if;
      -- end add 
      update lb_scan
         set TO_FLOOR_ID = p_to_floor
       where nal_sn >= p_snal_sn
         and nal_sn <= p_enal_sn
         and flow_id = g_lb_flow
         and stage_id = p_stage
            --and user_id = p_user  --delete by tom at 2012-3-12  【誰掃描的藍標，誰進行轉樓層】或者
         and is_acti = 'Y';
      v_used_cn := sql%rowcount;
      g_msg     := '本次轉樓層掃描藍標' || v_nal_cn || '個，成功轉樓層掃描' || v_used_cn || '個！';
      if v_nal_cn > v_used_cn then
        g_msg := g_msg || '失敗掃描原因可能是【當前工站沒有掃描記錄】。';
      end if;
      return;
    end if;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  
    --開始掃描藍標,從最小至最大---------
    while v_scan_sn <= v_ecan_sn loop
      --紀錄掃描結果-------------------------
      insert into lb_t_scan
        (scan_no, nal_sn, user_id, prod_sn, proj_id, floor_id)
      values
        (lb_scan_seq.nextval,
         v_scan_sn,
         p_user,
         'Y',
         g_bef_stage_id,
         p_stage);
      --掃描下一藍標--------------
      v_scan_sn := v_scan_sn + 10;
    end loop;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  
    --~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~----------
    --F001正常\F002非正常領料\F003退料\F004~F005盤點 其他流程掃描狀況判斷-------------
    --正常領料----------------------
    if p_flow = 'F001' then
      --正常領料第一個工站，檢查非正常領料的所用工站的掃描紀錄，如果有則不通過-----
      if p_stage = 'S001' then
        delete from lb_t_scan
         where user_id = p_user
           and nal_sn in (select nal_sn
                            from lb_scan
                           where flow_id = 'F002'
                             and is_acti = 'Y');
        v_used_cn := sql%rowcount;
      else
        --正常領料非第一個工站，檢查非正常領料的非第一個工站的掃描紀錄，如果有則不通過---        
        delete from lb_t_scan
         where user_id = p_user
           and nal_sn in (select nal_sn
                            from lb_scan
                           where stage_id <> 'S001'
                             and flow_id = 'F002'
                             and is_acti = 'Y');
        v_used_cn := sql%rowcount;
      end if;
    
      --非正常領料-----------------------
    elsif p_flow = 'F002' then
      --非正常領料第一個工站，檢查正常領料的所用工站的掃描紀錄，如果有則不通過-------------------
      if p_stage = 'S001' then
        delete from lb_t_scan
         where user_id = p_user
           and nal_sn in (select nal_sn
                            from lb_scan
                           where flow_id = 'F001'
                             and is_acti = 'Y');
        v_used_cn := sql%rowcount;
      else
        --非正常領料的非第一個工站，檢查正常領料的非第一個工站的掃描紀錄，如果有則不通過------------------        
        delete from lb_t_scan
         where user_id = p_user
           and nal_sn in (select nal_sn
                            from lb_scan
                           where stage_id <> 'S001'
                             and flow_id = 'F001'
                             and is_acti = 'Y');
        v_used_cn := sql%rowcount;
      end if;
    
      --不良退料-----------------------------
    elsif p_flow = 'F003' then
      --ADD by Tom at 2012/2/3  --是否有領料記錄，沒有則不通過---------  --    
      v_reced_cn := 0;
      delete lb_t_scan
       where nal_sn in (select t1.nal_sn
                          from lb_t_scan t1
                          left join lb_scan t2
                            on t1.nal_sn = t2.nal_sn
                         where t2.stage_id = 'S001'
                           and t2.is_acti = 'Y'
                           and t2.flow_id = 'F001'
                           and t2.nal_sn is null);
      v_reced_cn := sql%rowcount;
      if v_reced_cn < v_nal_cn then
        delete lb_t_scan
         where nal_sn in (select t1.nal_sn
                            from lb_t_scan t1
                            left join lb_scan_end t2
                              on t1.nal_sn = t2.nal_sn
                           where t2.stage_id = 'S001'
                             and t2.is_acti = 'Y'
                             and t2.flow_id = 'F001'
                             and t2.nal_sn is null);
        v_reced_cn := v_reced_cn + sql%rowcount;
      end if;
    
      /*     --是否有 Link SFC 記錄，有則不通過-----    
      if v_reced_cn < v_nal_cn then
        v_united_cn := 0;
        \*        delete from lb_t_scan
         where nal_sn in (select t1.nal_sn
                            from lb_t_scan t1
                            left join lb_scan t2
                              on t1.nal_sn = t2.nal_sn
                           where t2.is_acti = 'Y'
                             and is_SFC = 'Y'
                             and t2.stage_id = 'S001'
                             and t2.flow_id = 'F001'
                             and t2.nal_sn is not null);
        v_united_cn := sql%rowcount;*\
        delete from lb_t_scan
         where nal_sn in (select t1.nal_sn
                            from lb_t_scan t1
                            left join lb_scan_end t2
                              on t1.nal_sn = t2.nal_sn
                           where t2.is_acti = 'Y'
                             and is_SFC = 'Y'
                             and t2.stage_id = 'S001'
                             and t2.flow_id = 'F001'
                             and t2.nal_sn is not null);
        v_united_cn := v_united_cn + sql%rowcount;
      end if;*/
      --盤點狀況:分良品盤點，不良品盤點-----------
    elsif p_flow = 'F004' or p_flow = 'F005' then
      --非當前流程是否有記錄，有則不通過---
      delete from lb_t_scan
       where nal_sn in (select t1.nal_sn
                          from lb_t_scan t1
                          left join lb_check_dtl t2
                            on t1.nal_sn = t2.nal_sn
                           and t2.check_id = g_max_check_id
                         where t2.nal_sn is not null);
      v_used_cn := sql%rowcount;
      insert into lb_check_dtl
        (check_id,
         NAL_SN,
         FLOW_ID,
         PROJ_ID,
         FLOOR_ID,
         SCAN_TIME,
         STAGE_ID,
         USER_ID)
        select g_max_check_id,
               nal_sn,
               p_flow,
               p_project,
               p_floor,
               sysdate,
               p_stage,
               p_user
          from lb_t_scan
         where user_id = p_user
           and prod_sn = 'Y';
      v_nal_ok_cn := sql%rowcount;
    
      g_msg := '本次盤點藍標 ' || v_nal_cn || ' 個 , 成功盤點 ' || v_nal_ok_cn || ' 個';
      if v_used_cn > 0 then
        g_msg := g_msg || ',其中在本期已經盤點過' || v_used_cn || '個';
      end if;
      return;
    end if;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  
    --當前是否已經被掃描，有則不通過----
    delete from lb_t_scan
     where user_id = p_user
       and nal_sn in (select nal_sn
                        from lb_scan
                       where stage_id = p_stage
                         and is_acti = 'Y');
    v_sef_cn := sql%rowcount;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  
    --前一工站是否有掃描記錄,沒有則不通過---------
    if g_bef_item > 0 then
      delete lb_t_scan
       where user_id = p_user
         and nal_sn in (select t1.nal_sn
                          from lb_t_scan t1
                          left join Lb_scan t2
                            on t1.nal_sn = t2.nal_sn
                           and t1.proj_id = t2.stage_id --lb_log.proj_id已定義為前一工站掃描本站
                           and t2.is_acti = 'Y'
                         where t2.nal_sn is null
                           and t1.user_id = P_USER);
      v_bef_cn := sql%rowcount;
    end if;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  
    insert into lb_scan
      (SCAN_NO,
       FLOW_ID,
       FLOW_ITEM,
       PROJ_ID,
       FLOOR_ID,
       TO_FLOOR_ID,
       NAL_SN,
       SCAN_TIME,
       STAGE_ID,
       USER_ID,
       IS_ACTI,
       PROD_SN)
      select scan_no,
             p_flow,
             g_curr_item,
             p_project,
             p_floor,
             p_to_floor,
             nal_sn,
             sysdate,
             p_stage,
             p_user,
             'Y',
             CASE substr(nal_sn, 1, 5) --add by Tom at 2012-3-1
               WHEN '11685' THEN
                'LT-A1431' --聯通藍標前五位為11685
               WHEN '12047' THEN
                'DX-A1387' --電信藍標前五位為12047
               ELSE
                NULL
             END TAB
        from lb_t_scan
       where user_id = p_user
         and prod_sn = 'Y';
    v_nal_ok_cn := sql%rowcount;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  
    --單個掃描提示--------------------------------------------
    if v_nal_cn = 1 then
      v_scan_sn := v_scan_sn - 10;
      if v_nal_ok_cn > 0 then
        g_msg := '成功掃描藍標:' || v_scan_sn;
      elsif v_used_cn > 0 then
        if p_flow = 'F001' then
          g_msg := '藍標:' || v_scan_sn || '已被非正常領料!';
        elsif p_flow = 'F002' then
          g_msg := '藍標:' || v_scan_sn || '已被正常領料!';
        elsif p_flow = 'F004' then
          g_msg := '藍標:' || v_scan_sn || '在本期別已做不良品盤點!';
        elsif p_flow = 'F005' then
          g_msg := '藍標:' || v_scan_sn || '在本期別已做良品盤點!';
        end if;
      elsif v_reced_cn > 0 then
        g_msg := '藍標:' || v_scan_sn || '無領料記錄!';
      elsif v_reted_cn > 0 then
        g_msg := '藍標:' || v_scan_sn || '已退不良!';
      elsif v_united_cn = v_nal_cn then
        --modifyed by Tom at 2012-3-21
        g_msg := '藍標:' || v_scan_sn || '已Link Unit SN!';
      elsif v_sef_cn > 0 then
        if p_flow >= 'F004' then
          g_msg := '藍標:' || v_scan_sn || '在本期別已被盤點!';
        else
          g_msg := '藍標:' || v_scan_sn || '在當前工站已被掃描!';
        end if;
      elsif v_bef_cn > 0 then
        g_msg := '藍標:' || v_scan_sn || '前一工站' || g_bef_stage_name ||
                 '沒有掃描!';
      end if;
    
      --批量掃描提示--------------------------------------------      
    else
      g_msg := '本次掃描藍標 ' || v_nal_cn || ' 個 , 成功掃描 ' || v_nal_ok_cn || ' 個';
      if v_sef_cn > 0 then
        if p_flow >= 'F004' then
          g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                   '在本期別已被盤點 ' || v_sef_cn || ' 個';
        else
          g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                   '在當前工站已被掃描 ' || v_sef_cn || ' 個';
        end if;
      end if;
    
      if v_bef_cn > 0 then
        g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                 '因前工站' || g_bef_stage_name || '未掃描, 導致失敗 ' || v_bef_cn || ' 個';
      end if;
    
      if v_used_cn > 0 then
        if p_flow = 'F001' then
          g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                   '因已非正常領料, 導致失敗 ' || v_used_cn || ' 個';
        elsif p_flow = 'F002' then
          g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                   '因已正常領料, 導致失敗 ' || v_used_cn || ' 個';
        elsif p_flow = 'F004' then
          g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                   '因本期別已做不良品盤點, 導致失敗 ' || v_used_cn || ' 個';
        elsif p_flow = 'F005' then
          g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                   '因本期別已做良品盤點, 導致失敗 ' || v_used_cn || ' 個';
        end if;
      end if;
    
      if v_united_cn > 0 then
        g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                 '因已Link Unit SN, 導致失敗 ' || v_united_cn || ' 個';
      end if;
    
      if v_reted_cn > 0 then
        g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                 '因已退不良, 導致失敗 ' || v_reted_cn || ' 個';
      end if;
    
      if v_reced_cn > 0 then
        g_msg := g_msg || chr(10) || chr(13) || chr(10) || chr(13) ||
                 '因無領料記錄, 導致失敗 ' || v_reced_cn || ' 個';
      end if;
    end if;
  
    --日誌-------------------------
    insert into lb_t_scan
      (scan_no, user_id, prod_sn, notes)
    values
      (lb_scan_seq.nextval,
       p_user,
       'N',
       'STAT:' || to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
  end;

  --數據檢測----------------------
  procedure p_data_exam(p_flow varchar2, p_stage varchar2) is
  begin
    g_ok := 'N';
    --檢測所執行流程是否為本工站所在流程---------
    for cur_check_flow in (select flow_id
                             from lb_flow_dtl
                            where stage_id = p_stage) loop
      if p_flow = cur_check_flow.flow_id then
        g_ok := 'Y';
        exit;
      end if;
    end loop;
  
    if g_ok = 'N' then
      g_msg := '工站未在掃描流程中!';
      return;
    end if;
  end;

  --工站信息----------------------------------------------
  procedure p_data_stage(p_flow varchar2, p_stage varchar2) is
  begin
    --本工站序號----------
    select nvl(max(flow_item), 0)
      into g_curr_item
      from lb_flow_dtl
     where flow_id = p_flow
       and stage_id = p_stage;
  
    --前工站序號----------  
    g_bef_item := g_curr_item - 1;
    if g_bef_item > 0 then
      --前工站ID----------
      select max(stage_id)
        into g_bef_stage_id
        from lb_flow_dtl
       where flow_id = p_flow
         and flow_item = g_bef_item;
    
      --前工站NAME----------
      select max(stage_name)
        into g_bef_stage_name
        from lb_stage
       where stage_id = g_bef_stage_id;
    end if;
  
    --下一工站序號
    g_next_item := g_curr_item + 1;
    select max(stage_id)
      into g_next_stage_id
      from lb_flow_dtl
     where flow_id = p_flow
       and flow_item = g_next_item;
  end;

  --掃描流程結束后，掃描紀錄轉移到表LB_SCAN_END------------------
  procedure p_scan_move is
  begin
    null;
    -----------------------------------------------------------------
    insert into dmpdb2.lb_scan_end
      (SCAN_NO,
       FLOW_ID,
       FLOW_ITEM,
       PROJ_ID,
       FLOOR_ID,
       PROD_SN,
       NAL_SN,
       SCAN_TIME,
       STAGE_ID,
       USER_ID,
       LINE_CODE,
       IS_ACTI,
       NOTES,
       TO_FLOOR_ID,
       MOVE_TIME)
      select SCAN_NO,
             FLOW_ID,
             FLOW_ITEM,
             PROJ_ID,
             FLOOR_ID,
             PROD_SN,
             NAL_SN,
             SCAN_TIME,
             STAGE_ID,
             USER_ID,
             LINE_CODE,
             IS_ACTI,
             NOTES,
             TO_FLOOR_ID,
             sysdate
        from dmpdb2.lb_scan
       where nal_sn in (select nal_sn
                          from dmpdb2.lb_scan
                         where flow_id = 'F001'
                           and stage_id = 'S001'
                           and is_sfc = 'Y');
    --刪除10日前的結束流程的藍標----------------------------                           
    delete from dmpdb2.lb_scan
     where nal_sn in (select nal_sn
                        from dmpdb2.lb_scan
                       where flow_id = 'F001'
                         and stage_id = 'S001'
                         and is_sfc = 'Y');
  end;
end lb_pk;
/

