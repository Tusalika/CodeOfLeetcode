create package        lb_pk_c_t as
  type cur_type is ref cursor;
  g_ok               varchar2(1);
  g_msg              varchar2(200);
  g_curr_item        varchar2(20);
  g_bef_item         varchar2(20);
  g_next_item        varchar2(20);
  g_bef_stage_id     varchar2(20);
  g_next_stage_id    varchar2(40);
  g_bef_stage_name   varchar2(40);
  g_max_check_id     varchar2(20);
  g_sef_cn           integer;
  g_bef_cn           integer;
  g_used_cn          integer;
  g_reced_cn         integer;
  g_reted_cn         integer;
  g_checked_cn       integer;
  g_united_cn        integer;
  g_lb_next_stage_id varchar2(40);
  g_lb_flow          varchar2(40);
  procedure p_main(p_stage    varchar2,
                   p_user     varchar2,
                   p_flow     varchar2,
                   p_project  varchar2,
                   p_floor    varchar2,
                   p_to_floor varchar2,
                   p_ailno    varchar2,
                   p_expire   varchar2,
                   p_snal_list  varchar2,
                   p_cur      out cur_type);

  procedure p_scan(p_stage    varchar2,
                   p_user     varchar2,
                   p_flow     varchar2,
                   p_project  varchar2,
                   p_floor    varchar2,
                   p_to_floor varchar2,
                   p_ailno    varchar2,
                   p_expire   varchar2,
                   p_snal_list  varchar2);

  procedure p_data_exam(p_flow varchar2, p_stage varchar2);

  procedure p_data_stage(p_flow varchar2, p_stage varchar2);


  procedure p_scan_move;
end lb_pk_c_t;
/

