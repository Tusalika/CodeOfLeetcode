create PACKAGE        lb_pk_d
AS
   TYPE cur_type IS REF CURSOR;

   g_ok                 VARCHAR2 (1);
   g_msg                VARCHAR2 (200);
   g_curr_item          VARCHAR2 (20);
   g_bef_item           VARCHAR2 (20);
   g_next_item          VARCHAR2 (20);
   g_bef_stage_id       VARCHAR2 (20);
   g_next_stage_id      VARCHAR2 (40);
   g_bef_stage_name     VARCHAR2 (40);
   g_max_check_id       VARCHAR2 (20);
   g_sef_cn             INTEGER;
   g_bef_cn             INTEGER;
   g_used_cn            INTEGER;
   g_reced_cn           INTEGER;
   g_reted_cn           INTEGER;
   g_checked_cn         INTEGER;
   g_united_cn          INTEGER;
   g_lb_next_stage_id   VARCHAR2 (40);
   g_lb_flow            VARCHAR2 (40);

   PROCEDURE p_main (
      p_stage             VARCHAR2,
      p_user              VARCHAR2,
      p_flow              VARCHAR2,
      p_project           VARCHAR2,
      p_floor             VARCHAR2,
      p_to_floor          VARCHAR2,
      p_ailno             VARCHAR2,
      p_expire            VARCHAR2,
      p_snal_list         VARCHAR2,
      p_cur         OUT   cur_type
   );

   PROCEDURE p_scan (
      p_stage       VARCHAR2,
      p_user        VARCHAR2,
      p_flow        VARCHAR2,
      p_project     VARCHAR2,
      p_floor       VARCHAR2,
      p_to_floor    VARCHAR2,
      p_ailno       VARCHAR2,
      p_expire      VARCHAR2,
      p_snal_list   VARCHAR2
   );

   PROCEDURE p_data_exam (p_flow VARCHAR2, p_stage VARCHAR2);

   PROCEDURE p_data_stage (p_flow VARCHAR2, p_stage VARCHAR2);

   PROCEDURE p_scan_move;
END lb_pk_d;

/

