create PACKAGE BODY        lb_pk_d_t
AS
   --create by SIDC-ERPII --King/Pan 20111201-----------------------
   PROCEDURE p_main (
      p_stage             VARCHAR2,
      p_user              VARCHAR2,
      p_flow              VARCHAR2,
      p_project           VARCHAR2,
      p_floor             VARCHAR2,
      p_to_floor          VARCHAR2,
      p_ailno             VARCHAR2,
      p_expire            VARCHAR2,
      p_snal_list         VARCHAR2,
      p_cur         OUT   cur_type
   )
   IS
   BEGIN
      --藍標掃描/盤點----------------
      /*    if p_user = 'TEST' then*/
      p_scan (p_stage,
              p_user,
              p_flow,
              p_project,
              p_floor,
              p_to_floor,
              p_ailno,
              p_expire,
              p_snal_list
             );

      /*    else
        g_msg := '系統升級中，請稍後再試。。。';
        g_ok  := 'N';
      end if;*/
      OPEN p_cur FOR
         SELECT g_msg, g_ok
           FROM DUAL;
   END;

   --藍標領/退料掃描、盤點--------------------------------------------
   PROCEDURE p_scan (
      p_stage       VARCHAR2,
      p_user        VARCHAR2,
      p_flow        VARCHAR2,
      p_project     VARCHAR2,
      p_floor       VARCHAR2,
      p_to_floor    VARCHAR2,
      p_ailno       VARCHAR2,
      p_expire      VARCHAR2,
      p_snal_list   VARCHAR2
   )
   IS
      v_scan_sn       VARCHAR2 (50);
      --v_ecan_sn   varchar2(30);
      v_ail_no        VARCHAR2 (15);
      v_expire        DATE;
      v_nal_pos       INTEGER;                             --二維碼中藍標位置
      v_nal_count     INTEGER;                           --二維碼中藍標的取值
      v_nal_cn        INTEGER;                                      --NAL總數
      v_nal_ok_cn     INTEGER;                                --成功掃描NAL數
      v_bef_cn        INTEGER;                  --由於前站沒有掃描，失敗NAL數
      v_sef_cn        INTEGER;                    --由於本站已掃描，失敗NAL數
      v_used_cn       INTEGER;                --由于其他流程已使用, 失敗NAL數
      v_reced_cn      INTEGER;           --由于無領料記錄, 退料/盤點失敗nal數
      v_reted_cn      INTEGER;                        --由于已退料,失敗盤點數
      v_united_cn     INTEGER;             --由于良品/不良品已盤點,失敗盤點數
      v_cont          INTEGER;                               --轉樓層的時候用
      v_recount       INTEGER;                         --判斷是否到了組裝工站
      v_overdue       INTEGER;                               --藍標過期標誌位
      v_floor_cn      INTEGER; --判斷S003和S004的樓層是否與前一工站的樓層一致
      v_floor         VARCHAR2 (30);               --S003和S004前一工站的樓層
      --v_mixed     integer; --判斷掃描的藍標中是否有混合的正常發料和非正常發料
      v_t_target      INTEGER;
      v_in_target     INTEGER;
      v_left_target   INTEGER;
      v_eeee_count    INTEGER;
      v_id            INTEGER;
   BEGIN
      v_ail_no := p_ailno;
      v_expire := TO_DATE (p_expire, 'yyyy/mm/dd');
      v_nal_cn := 0;
      v_nal_ok_cn := 0;
      v_bef_cn := 0;
      v_sef_cn := 0;
      v_used_cn := 0;
      v_reced_cn := 0;
      v_reted_cn := 0;
      v_united_cn := 0;
      v_recount := 0;
      v_floor_cn := 0;
      --v_mixed     := 0;
      v_overdue := 0;
      v_nal_count := 0;
      v_nal_pos := 0;
      v_id := 0;

      --add by Tom at 2012-4-6 116856068370540
      --根據OPM提供資料將  機種與藍標前五位綁定
      IF LENGTH (RTRIM (p_snal_list)) = 0
      THEN
         BEGIN
            g_msg := '傳入的二維碼為空,請檢查!';
            g_ok := 'N';
            RETURN;
         END;
      END IF;

      v_nal_pos := INSTR (p_snal_list, ',', 1, 1);

      IF v_nal_pos = 0
      THEN
         IF LENGTH (RTRIM (p_snal_list)) = 15
         THEN
            v_scan_sn := SUBSTR (p_snal_list, 1, 15);

            IF p_stage = 'S001' AND p_project <> '@001'
               AND p_project <> '@002'
            THEN
               SELECT target_qty, input_qty, left_qty
                 INTO v_t_target, v_in_target, v_left_target
                 FROM lb_ail
                WHERE ail_no = p_ailno;

               IF v_in_target + 1 > v_t_target
               THEN
                  g_msg :=
                        '本次掃描藍標數會超過OPM維護的AIL管控數,請核實維護數量'
                     || v_t_target;
                  g_ok := 'N';
                  RETURN;
               ELSE
                  UPDATE lb_ail
                     SET input_qty = v_in_target + 1,
                         left_qty = v_left_target - 1
                   WHERE ail_no = p_ailno;
               END IF;
            END IF;
         ELSE
            g_msg := '傳入的二維碼格式錯誤,請檢查!';
            g_ok := 'N';
            RETURN;
         END IF;
      ELSE
         v_scan_sn := SUBSTR (p_snal_list, 1, v_nal_pos - 1);

         IF p_stage = 'S001' AND p_project <> '@001' AND p_project <> '@002'
         THEN
            LOOP
               v_nal_count := v_nal_count + 1;
               v_nal_pos := INSTR (p_snal_list, ',', 1, v_nal_count);
               EXIT WHEN v_nal_pos = 0;
            END LOOP;

            SELECT target_qty, input_qty, left_qty
              INTO v_t_target, v_in_target, v_left_target
              FROM lb_ail
             WHERE ail_no = p_ailno;

            IF v_in_target + v_nal_count > v_t_target
            THEN
               g_msg :=
                     '本次掃描藍標數會超過OPM維護的AIL管控數,請核實維護數量'
                  || v_t_target;
               g_ok := 'N';
               RETURN;
            ELSE
               UPDATE lb_ail
                  SET input_qty = v_in_target + v_nal_count,
                      left_qty = v_left_target - v_nal_count
                WHERE ail_no = p_ailno;
            END IF;
         END IF;
      END IF;

      v_nal_count := 0;
      v_nal_pos := 0;

      IF p_project <> '@001' AND p_project <> '@002'
      THEN
         SELECT COUNT (1)
           INTO v_eeee_count
           FROM lb_code
          WHERE model_number = p_project
            AND eeee_code = SUBSTR (v_scan_sn, 1, 6);

         IF v_eeee_count < 1
         THEN
            g_msg := '藍標SN前6位沒有跟' || p_project || '綁定';
            RETURN;
         END IF;
      END IF;

      IF p_flow = 'F004' OR p_flow = 'F005'
      THEN
         --藍標盤點, 查詢最大盤點期別------------------
         SELECT MAX (check_id)
           INTO g_max_check_id
           FROM lb_check;

         IF NVL (g_max_check_id, '-') <> TO_CHAR (SYSDATE, 'yyyymmdd')
         THEN
            g_msg := '本日沒有盤點期別，不能盤點，請先建立盤點期別!!';
            g_ok := 'N';
            RETURN;
         END IF;
      ELSE
         --藍標掃描, 基本數據檢測與初始化------------------
         p_data_exam (p_flow, p_stage);

         IF g_ok = 'N'
         THEN
            RETURN;
         ELSE
            p_data_stage (p_flow, p_stage);
         END IF;
      END IF;

      --START藍標領料、退料、盤點-------------------------------------
      --始終SN------------

      --v_scan_sn := p_snal_sn;
      --v_ecan_sn := p_enal_sn;

      /*
      v_nal_cn := (v_ecan_sn - v_scan_sn) / 10 + 1;
      if v_nal_cn > 30001 then
        g_msg := '本次掃描藍標' || v_nal_cn || '個批量過大,單次掃描批量<=30001個,請分批掃描！！';
        return;
      end if;
      */
      v_nal_cn := (LENGTH (RTRIM (p_snal_list)) + 1) / 16;

      --反掃描作業------------------------------
      IF p_project = '@001'
      THEN
         --掃描藍標的流程
         LOOP
            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   COUNT (1)
              --檢查是否組裝到SFC工站。change by kunli 12-6 2012
            INTO   v_recount
              FROM lb_scan
             WHERE nal_sn = v_scan_sn
               AND stage_id = 'S004'
               AND is_acti = 'Y'
               AND (is_sfc = 'Y' OR is_sfc = 'S');

            IF v_recount >= 1
            THEN
               g_msg := '本次掃描藍標中存在已組裝到SFC工站，請檢查';
               RETURN;
            END IF;

            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   MAX (NVL (flow_id, 0))
              INTO g_lb_flow
              FROM lb_scan
             WHERE nal_sn = v_scan_sn AND stage_id = p_stage;

            --END ADD

            --掃描藍標的下一個工站 add by Tom AT 2012-3-15
            SELECT MAX (NVL (stage_id, 0))
              INTO g_lb_next_stage_id
              FROM lb_flow_dtl
             WHERE flow_id = g_lb_flow
               AND flow_item IN (
                              SELECT NVL (flow_item, 0) + 1
                                FROM lb_flow_dtl
                               WHERE flow_id = g_lb_flow
                                     AND stage_id = p_stage);

            IF NVL (g_lb_next_stage_id, '-') = '-'
            THEN
               --modify By Tom at 2012-3-15
               g_msg :=
                       '您不能進行反掃描作業，因為藍標的下一站沒有掃描工站！';
               RETURN;
            END IF;

            /*--add at 2012-3-15 匹配掃描帳號的流程和掃描藍標的流程
            if p_flow <> g_lb_flow then
              g_msg := '您不能進行反掃描作業，因為藍標的掃描流程和您的帳號不匹配！';
              return;
            end if;*/ --由於藍標只有走正常領料和非正常領料中的一個所以去掉

            --?了配合web抓取數據修改反掃描邏輯  add by kunli
            UPDATE /*+index(lb_scan LB_SCAN_UNIQUE)*/lb_scan
               SET out_time =
                      TO_DATE ('1900-01-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss')
             WHERE nal_sn = v_scan_sn AND stage_id = p_stage AND is_acti = 'Y';

             /*
            update lb_scan  因為反掃描之后會有重復數據。把原有的更改is_acti改為刪除資料。
               set is_acti = 'N', out_time = sysdate
             where nal_sn >= p_snal_sn
               and nal_sn <= p_enal_sn
               and stage_id >= g_lb_next_stage_id --modify by Tom at 2012-3-15
               and is_acti = 'Y';
               */
            DELETE      /*+index(lb_scan LB_SCAN_UNIQUE)*/FROM lb_scan
                  WHERE nal_sn = v_scan_sn AND stage_id >= g_lb_next_stage_id;

            --modify by Tom at 2012-3-15

            --and is_acti = 'Y'; 基本上不管IS_ACTI為什?都要刪除。
            v_used_cn := v_used_cn + 1;
            v_nal_count := v_nal_count + 1;
            v_nal_pos := INSTR (p_snal_list, ',', 1, v_nal_count);
            v_scan_sn := SUBSTR (p_snal_list, v_nal_pos + 1, 15);
            EXIT WHEN v_nal_pos = 0;
         END LOOP;

         --v_used_cn := sql%rowcount;
         g_msg := '本次成功返掃描' || v_nal_cn || '個！';

         IF v_nal_cn > v_used_cn
         THEN
            g_msg := g_msg || '失敗掃描原因可能是下一工站沒有掃描。';
         END IF;

         RETURN;
      END IF;

      --轉樓層掃描作業------------------------------
      IF p_project = '@002'
      THEN
         IF p_stage <> 'S003'
         THEN
            g_msg := '只有S003工站具有轉樓層掃描藍標權限！';
            RETURN;
         END IF;

         --add by Tom at 2012-3-12  如果藍標在下一工站被掃描過的話，則不能進行轉樓層
         -- 掃描藍標的流程
         LOOP
            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   MAX (NVL (flow_id, 0))
              INTO g_lb_flow
              FROM lb_scan
             WHERE nal_sn = v_scan_sn AND stage_id = p_stage;

            --掃描藍標的下一個工站 add by Tom AT 2012-3-15
            SELECT MAX (NVL (stage_id, 0))
              INTO g_lb_next_stage_id
              FROM lb_flow_dtl
             WHERE flow_id = g_lb_flow
               AND flow_item IN (
                              SELECT NVL (flow_item, 0) + 1
                                FROM lb_flow_dtl
                               WHERE flow_id = g_lb_flow
                                     AND stage_id = p_stage);

            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   COUNT (1)
              INTO v_cont
              FROM lb_scan
             WHERE nal_sn = v_scan_sn
               --and flow_id = p_flow     delete by Tom at 2012-3-14
               AND stage_id = g_lb_next_stage_id
               AND is_acti = 'Y';

            IF v_cont >= 1
            THEN
               g_msg :=
                     '本次轉樓層掃描藍標在下一工站'
                  || g_next_stage_id
                  || '已掃描，請對下一工站反掃描后再進行轉樓層的操作！';
               RETURN;
            END IF;

            -- end add
            UPDATE lb_scan
               SET to_floor_id = p_to_floor
             WHERE nal_sn = v_scan_sn
               AND flow_id = g_lb_flow
               AND stage_id = p_stage
               --and user_id = p_user  --delete by tom at 2012-3-12  【誰掃描的藍標，誰進行轉樓層】或者
               AND is_acti = 'Y';

            --v_used_cn := v_used_cn + 1;
            UPDATE lb_scan
               SET to_floor_id = p_to_floor
             WHERE nal_sn = v_scan_sn
               AND flow_id = g_lb_flow
               AND stage_id = p_stage
               --and user_id = p_user  --delete by tom at 2012-3-12  【誰掃描的藍標，誰進行轉樓層】或者
               AND is_acti = 'Y';

            v_used_cn := v_used_cn + 1;
            v_nal_count := v_nal_count + 1;
            v_nal_pos := INSTR (p_snal_list, ',', 1, v_nal_count);
            v_scan_sn := SUBSTR (p_snal_list, v_nal_pos + 1, 15);
            EXIT WHEN v_nal_pos = 0;
         END LOOP;

         --v_used_cn := sql%rowcount;
         g_msg :=
               '本次轉樓層掃描藍標'
            || v_nal_cn
            || '個，成功轉樓層掃描'
            || v_used_cn
            || '個！';

         IF v_nal_cn > v_used_cn
         THEN
            g_msg := g_msg || '失敗掃描原因可能是【當前工站沒有掃描記錄】。';
         END IF;

         RETURN;
      END IF;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );

      --開始掃描藍標,從最小至最大---------
      IF p_stage <> 'S001'
      THEN
         SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                ail_no, expire_date
           INTO v_ail_no, v_expire
           FROM lb_scan
          WHERE nal_sn = v_scan_sn AND stage_id = 'S001';
      END IF;

      LOOP
         --紀錄掃描結果-------------------------
         SELECT lb_scan_seq.NEXTVAL into v_id FROM DUAL;
         
         INSERT INTO lb_scan
                     (scan_no, flow_id, flow_item, proj_id,
                      floor_id, to_floor_id, nal_sn, scan_time, stage_id,
                      user_id, ail_no, expire_date, is_acti, id
                     )
              VALUES (v_id, p_flow, g_curr_item, p_project,
                      p_floor, p_to_floor, v_scan_sn, SYSDATE, p_stage,
                      p_user, v_ail_no, v_expire, 'Y', v_id
                     );

         --掃描下一藍標--------------
         v_nal_count := v_nal_count + 1;
         v_nal_pos := INSTR (p_snal_list, ',', 1, v_nal_count);
         v_scan_sn := SUBSTR (p_snal_list, v_nal_pos + 1, 15);
         v_nal_ok_cn := v_nal_ok_cn + 1;
         EXIT WHEN v_nal_pos = 0;
      END LOOP;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );

      --目前ZZ要做樓層管控，S003和S004必須和前一工站的to_floor_id一致。
      IF p_flow = 'F001'
      THEN
         IF p_stage = 'S003'
         THEN
            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   COUNT (DISTINCT to_floor_id)
              INTO v_floor_cn
              FROM lb_scan
             WHERE nal_sn = v_scan_sn AND stage_id = 'S002' AND is_acti = 'Y';

            IF v_floor_cn > 1
            THEN
               g_msg := 'S003的掃入樓層必須與S002的樓層一致！';
               RETURN;
            ELSIF v_floor_cn = 0
            THEN
               g_msg :=
                   '此批藍標S002並且IS_ACTI為Y的to_floor_id 沒有值！請檢查！';
               RETURN;
            ELSE
               SELECT          /*+index(lb_scan LB_SCAN_UNIQUE)*/
                      DISTINCT to_floor_id
                          INTO v_floor
                          FROM lb_scan
                         WHERE nal_sn = v_scan_sn
                           AND stage_id = 'S002'
                           AND is_acti = 'Y';

               IF v_floor <> p_to_floor
               THEN
                  g_msg := 'S003的掃入樓層必須與S002的樓層一致！';
                  RETURN;
               END IF;
            END IF;
         END IF;

         IF p_stage = 'S004'
         THEN
            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   COUNT (DISTINCT to_floor_id)
              INTO v_floor_cn
              FROM lb_scan
             WHERE nal_sn = v_scan_sn AND stage_id = 'S003' AND is_acti = 'Y';

            IF v_floor_cn > 1
            THEN
               g_msg := 'S004的掃入樓層必須與S003的樓層一致！';
               RETURN;
            ELSIF v_floor_cn = 0
            THEN
               g_msg :=
                   '此批藍標S002並且IS_ACTI為Y的to_floor_id 沒有值！請檢查！';
               RETURN;
            ELSE
               SELECT          /*+index(lb_scan LB_SCAN_UNIQUE)*/
                      DISTINCT to_floor_id
                          INTO v_floor
                          FROM lb_scan
                         WHERE nal_sn = v_scan_sn
                           AND stage_id = 'S003'
                           AND is_acti = 'Y';

               IF v_floor <> p_to_floor
               THEN
                  g_msg := 'S004的掃入樓層必須與S003的樓層一致！';
                  RETURN;
               END IF;
            END IF;
         END IF;
      END IF;

      IF p_flow = 'F002'
      THEN
         IF p_stage = 'S004'
         THEN
            SELECT /*+index(lb_scan LB_SCAN_UNIQUE)*/
                   COUNT (DISTINCT to_floor_id)
              INTO v_floor_cn
              FROM lb_scan
             WHERE nal_sn = v_scan_sn AND stage_id = 'S003' AND is_acti = 'Y';

            IF v_floor_cn > 1
            THEN
               g_msg := 'S004的掃入樓層必須與S003的樓層一致！';
               RETURN;
            ELSIF v_floor_cn = 0
            THEN
               g_msg :=
                   '此批藍標S002並且IS_ACTI為Y的to_floor_id 沒有值！請檢查！';
               RETURN;
            ELSE
               SELECT          /*+index(lb_scan LB_SCAN_UNIQUE)*/
                      DISTINCT to_floor_id
                          INTO v_floor
                          FROM lb_scan
                         WHERE nal_sn = v_scan_sn
                           AND stage_id = 'S003'
                           AND is_acti = 'Y';

               IF v_floor <> p_to_floor
               THEN
                  g_msg := 'S004的掃入樓層必須與S003的樓層一致！';
                  RETURN;
               END IF;
            END IF;
         END IF;
      END IF;

--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~----------
--F001正常\F002非正常領料\F003退料\F004~F005盤點 其他流程掃描狀況判斷-------------
--正常領料----------------------
 /*
if p_flow = 'F001' then
  --正常領料第一個工站，檢查非正常領料的所用工站的掃描紀錄，如果有則不通過-----
  if p_stage = 'S001' then
    delete from lb_t_scan
     where user_id = p_user
       and nal_sn in (select nal_sn
                        from lb_scan
                       where flow_id = 'F002'
                         and is_acti = 'Y');
    v_used_cn := sql%rowcount;
  else
    --正常領料非第一個工站，檢查非正常領料的非第一個工站的掃描紀錄，如果有則不通過---
    delete from lb_t_scan
     where user_id = p_user
       and nal_sn in (select nal_sn
                        from lb_scan
                       where stage_id <> 'S001'
                         and flow_id = 'F002'
                         and is_acti = 'Y');
    v_used_cn := sql%rowcount;
  end if;

  --非正常領料-----------------------
elsif p_flow = 'F002' then
  --非正常領料第一個工站，檢查正常領料的所用工站的掃描紀錄，如果有則不通過-------------------
  if p_stage = 'S001' then
    delete from lb_t_scan
     where user_id = p_user
       and nal_sn in (select nal_sn
                        from lb_scan
                       where flow_id = 'F001'
                         and is_acti = 'Y');
    v_used_cn := sql%rowcount;
  else
    --非正常領料的非第一個工站，檢查正常領料的非第一個工站的掃描紀錄，如果有則不通過------------------
    delete from lb_t_scan
     where user_id = p_user
       and nal_sn in (select nal_sn
                        from lb_scan
                       where stage_id <> 'S001'
                         and flow_id = 'F001'
                         and is_acti = 'Y');
    v_used_cn := sql%rowcount;
  end if;

  --不良退料-----------------------------

elsif p_flow = 'F003' then
  --ADD by Tom at 2012/2/3  --是否有領料記錄，沒有則不通過---------  --
  v_reced_cn := 0;
  delete lb_t_scan
   where nal_sn in (select t1.nal_sn
                      from lb_t_scan t1
                      left join lb_scan t2
                        on t1.nal_sn = t2.nal_sn
                     where t2.stage_id = 'S001'
                       and t2.is_acti = 'Y'
                       and t2.flow_id = 'F001'
                       and t2.nal_sn is null);
  v_reced_cn := sql%rowcount;
  if v_reced_cn < v_nal_cn then
    delete lb_t_scan
     where nal_sn in (select t1.nal_sn
                        from lb_t_scan t1
                        left join lb_scan_end t2
                          on t1.nal_sn = t2.nal_sn
                       where t2.stage_id = 'S001'
                         and t2.is_acti = 'Y'
                         and t2.flow_id = 'F001'
                         and t2.nal_sn is null);
    v_reced_cn := v_reced_cn + sql%rowcount;

  end if;

  */

      --盤點狀況:分良品盤點，不良品盤點-----------
      IF p_flow = 'F004' OR p_flow = 'F005'
      THEN
         --非當前流程是否有記錄，有則不通過---
         DELETE FROM lb_t_scan
               WHERE nal_sn IN (SELECT t1.nal_sn
                                  FROM lb_t_scan t1 LEFT JOIN lb_check_dtl t2
                                       ON t1.nal_sn = t2.nal_sn
                                     AND t2.check_id = g_max_check_id
                                 WHERE t2.nal_sn IS NOT NULL);

         v_used_cn := SQL%ROWCOUNT;

         INSERT INTO lb_check_dtl
                     (check_id, nal_sn, flow_id, proj_id, floor_id, scan_time,
                      stage_id, user_id)
            SELECT g_max_check_id, nal_sn, p_flow, p_project, p_floor,
                   SYSDATE, p_stage, p_user
              FROM lb_t_scan
             WHERE user_id = p_user AND prod_sn = 'Y';

         v_nal_ok_cn := SQL%ROWCOUNT;
         g_msg :=
               '本次盤點藍標 '
            || v_nal_cn
            || ' 個 , 成功盤點 '
            || v_nal_ok_cn
            || ' 個';

         IF v_used_cn > 0
         THEN
            g_msg := g_msg || ',其中在本期已經盤點過' || v_used_cn || '個';
         END IF;

         RETURN;
      END IF;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );

      --當前是否已經被掃描，有則不通過----
      /*
      if p_flow <> 'F003' then
        delete from lb_t_scan
         where user_id = p_user
           and nal_sn in (select nal_sn
                            from lb_scan
                           where stage_id = p_stage
                             and is_acti = 'Y');
        v_sef_cn := sql%rowcount;
      end if;
      */
      IF (p_flow = 'F004') OR (p_flow = 'F005')
      THEN                            --因為F001和F002的防呆暫時拿到代碼中去了
         DELETE FROM lb_t_scan
               WHERE user_id = p_user
                 AND nal_sn IN (SELECT nal_sn
                                  FROM lb_scan
                                 WHERE stage_id = p_stage AND is_acti = 'Y');

         v_sef_cn := SQL%ROWCOUNT;
      END IF;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );

      --前一工站是否有掃描記錄,沒有則不通過------
      --if p_flow <> 'F003' then
      IF (p_flow = 'F004') OR (p_flow = 'F005')
      THEN                         ---  因為F001和F002的防呆暫時拿到代碼中去了
         IF g_bef_item > 1
         THEN
            DELETE      lb_t_scan
                  WHERE user_id = p_user
                    AND nal_sn IN (
                               SELECT t1.nal_sn
                                 FROM lb_t_scan t1 LEFT JOIN lb_scan t2
                                      ON t1.nal_sn = t2.nal_sn
                                    AND t1.proj_id = t2.stage_id
                                    --lb_log.proj_id已定義為前一工站掃描本站
                                    AND t2.is_acti = 'Y'
                                WHERE t2.nal_sn IS NULL
                                      AND t1.user_id = p_user);

            v_bef_cn := SQL%ROWCOUNT;
         END IF;
      END IF;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );

      /*
      if p_stage = 'S003' then
         select count(distinct flow_id)
         into v_mixed
         from lb_scan
         where nal_sn >= p_snal_sn
               and nal_sn <= p_enal_sn
               and stage_id = 'S001'
               and is_acti = 'Y';
      end if;

      if v_mixed > 1 then
         g_msg := '批量掃入的藍標中有混合領料的情況，請區別！';
         return;
      end if;
      */

      --增加AIL管控
      /*
      INSERT INTO lb_scan
                  (scan_no, flow_id, flow_item, proj_id, floor_id,
                   to_floor_id, nal_sn, scan_time, stage_id, user_id, ail_no,
                   expire_date, is_acti, prod_sn)
         SELECT scan_no, p_flow, g_curr_item, p_project, p_floor, p_to_floor,
                nal_sn, SYSDATE, p_stage, p_user, ail_no, expire_date, 'Y',
                CASE SUBSTR (nal_sn, 1, 5)       --add by Tom at 2012-3-1
                   WHEN '11685'
                      THEN 'LT-A1431'             --聯通藍標前五位為11685
                   WHEN '12047'
                      THEN 'DX-A1387'             --電信藍標前五位為12047
                   ELSE NULL
                END tab
           FROM lb_t_scan
          WHERE user_id = p_user AND prod_sn = 'Y';

      v_nal_ok_cn := SQL%ROWCOUNT;
      */
      IF g_bef_item > 0
      THEN
         /*
           update lb_scan
             set out_time = sysdate
            where nal_sn in (select nal_sn
                              from lb_t_scan
                               where user_id = p_user
                                 and prod_sn = 'Y')
              and flow_id = p_flow
              and flow_item = g_bef_item;
          */
         v_nal_count := 0;

         LOOP
            UPDATE /*+  INDEX(lb_scan  LB_SCAN_UNIQUE)*/lb_scan
               SET out_time = SYSDATE
             WHERE nal_sn = v_scan_sn AND stage_id = g_bef_stage_id;

            v_nal_count := v_nal_count + 1;
            v_nal_pos := INSTR (p_snal_list, ',', 1, v_nal_count);
            v_scan_sn := SUBSTR (p_snal_list, v_nal_pos + 1, 15);
            EXIT WHEN v_nal_pos = 0;
         END LOOP;
      END IF;

      IF p_stage = 'S001'
      THEN
         SELECT /*+ index(a LB_SCAN_AIL_NO)*/
                MAX (NVL (is_overdue, 0))
           INTO v_overdue
           FROM lb_scan
          WHERE ail_no = p_ailno AND ROWNUM = 1;
      ELSE
         SELECT /*+  INDEX(lb_scan  LB_SCAN_UNIQUE)*/
                MAX (NVL (is_overdue, 0))
           INTO v_overdue
           FROM lb_scan
          WHERE nal_sn = v_scan_sn AND stage_id = 'S001';
      END IF;

      v_nal_count := 0;

      LOOP
         UPDATE /*+  INDEX(lb_scan  LB_SCAN_UNIQUE)*/lb_scan
            SET is_overdue = v_overdue
          WHERE nal_sn = v_scan_sn AND stage_id = p_stage;

         v_nal_count := v_nal_count + 1;
         v_nal_pos := INSTR (p_snal_list, ',', 1, v_nal_count);
         v_scan_sn := SUBSTR (p_snal_list, v_nal_pos + 1, 15);
         EXIT WHEN v_nal_pos = 0;
      END LOOP;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );

      --單個掃描提示--------------------------------------------
      IF v_nal_cn = 1
      THEN
         --v_scan_sn := v_scan_sn - 10;
         IF v_nal_ok_cn > 0
         THEN
            g_msg := '成功掃描藍標:' || v_scan_sn;
         ELSIF v_used_cn > 0
         THEN
            IF p_flow = 'F001'
            THEN
               g_msg := '藍標:' || v_scan_sn || '已被非正常領料!';
            ELSIF p_flow = 'F002'
            THEN
               g_msg := '藍標:' || v_scan_sn || '已被正常領料!';
            ELSIF p_flow = 'F004'
            THEN
               g_msg := '藍標:' || v_scan_sn || '在本期別已做不良品盤點!';
            ELSIF p_flow = 'F005'
            THEN
               g_msg := '藍標:' || v_scan_sn || '在本期別已做良品盤點!';
            END IF;
         ELSIF v_reced_cn > 0
         THEN
            g_msg := '藍標:' || v_scan_sn || '無領料記錄!';
         ELSIF v_reted_cn > 0
         THEN
            g_msg := '藍標:' || v_scan_sn || '已退不良!';
         ELSIF v_united_cn = v_nal_cn
         THEN
            --modifyed by Tom at 2012-3-21
            g_msg := '藍標:' || v_scan_sn || '已Link Unit SN!';
         ELSIF v_sef_cn > 0
         THEN
            IF p_flow >= 'F004'
            THEN
               g_msg := '藍標:' || v_scan_sn || '在本期別已被盤點!';
            ELSE
               g_msg := '藍標:' || v_scan_sn || '在當前工站已被掃描!';
            END IF;
         ELSIF v_bef_cn > 0
         THEN
            g_msg :=
                  '藍標:'
               || v_scan_sn
               || '前一工站'
               || g_bef_stage_name
               || '沒有掃描!';
         END IF;
      --批量掃描提示--------------------------------------------
      ELSE
         g_msg :=
               '本次掃描藍標 '
            || v_nal_cn
            || ' 個 , 成功掃描 '
            || v_nal_ok_cn
            || ' 個';

         IF v_sef_cn > 0
         THEN
            IF p_flow >= 'F004'
            THEN
               g_msg :=
                     g_msg
                  || CHR (10)
                  || CHR (13)
                  || CHR (10)
                  || CHR (13)
                  || '在本期別已被盤點 '
                  || v_sef_cn
                  || ' 個';
            ELSE
               g_msg :=
                     g_msg
                  || CHR (10)
                  || CHR (13)
                  || CHR (10)
                  || CHR (13)
                  || '在當前工站已被掃描 '
                  || v_sef_cn
                  || ' 個';
            END IF;
         END IF;

         IF v_bef_cn > 0
         THEN
            g_msg :=
                  g_msg
               || CHR (10)
               || CHR (13)
               || CHR (10)
               || CHR (13)
               || '因前工站'
               || g_bef_stage_name
               || '未掃描, 導致失敗 '
               || v_bef_cn
               || ' 個';
         END IF;

         IF v_used_cn > 0
         THEN
            IF p_flow = 'F001'
            THEN
               g_msg :=
                     g_msg
                  || CHR (10)
                  || CHR (13)
                  || CHR (10)
                  || CHR (13)
                  || '因已非正常領料, 導致失敗 '
                  || v_used_cn
                  || ' 個';
            ELSIF p_flow = 'F002'
            THEN
               g_msg :=
                     g_msg
                  || CHR (10)
                  || CHR (13)
                  || CHR (10)
                  || CHR (13)
                  || '因已正常領料, 導致失敗 '
                  || v_used_cn
                  || ' 個';
            ELSIF p_flow = 'F004'
            THEN
               g_msg :=
                     g_msg
                  || CHR (10)
                  || CHR (13)
                  || CHR (10)
                  || CHR (13)
                  || '因本期別已做不良品盤點, 導致失敗 '
                  || v_used_cn
                  || ' 個';
            ELSIF p_flow = 'F005'
            THEN
               g_msg :=
                     g_msg
                  || CHR (10)
                  || CHR (13)
                  || CHR (10)
                  || CHR (13)
                  || '因本期別已做良品盤點, 導致失敗 '
                  || v_used_cn
                  || ' 個';
            END IF;
         END IF;

         IF v_united_cn > 0
         THEN
            g_msg :=
                  g_msg
               || CHR (10)
               || CHR (13)
               || CHR (10)
               || CHR (13)
               || '因已Link Unit SN, 導致失敗 '
               || v_united_cn
               || ' 個';
         END IF;

         IF v_reted_cn > 0
         THEN
            g_msg :=
                  g_msg
               || CHR (10)
               || CHR (13)
               || CHR (10)
               || CHR (13)
               || '因已退不良, 導致失敗 '
               || v_reted_cn
               || ' 個';
         END IF;

         IF v_reced_cn > 0
         THEN
            g_msg :=
                  g_msg
               || CHR (10)
               || CHR (13)
               || CHR (10)
               || CHR (13)
               || '因無領料記錄, 導致失敗 '
               || v_reced_cn
               || ' 個';
         END IF;
      END IF;

--日誌-------------------------
      INSERT INTO lb_t_scan
                  (scan_no, user_id, prod_sn,
                   notes
                  )
           VALUES (lb_scan_seq.NEXTVAL, p_user, 'N',
                   'STAT:' || TO_CHAR (SYSDATE, 'yyyy/mm/dd hh24:mi:ss')
                  );
   END;

   --數據檢測----------------------
   PROCEDURE p_data_exam (p_flow VARCHAR2, p_stage VARCHAR2)
   IS
   BEGIN
      g_ok := 'N';

      --檢測所執行流程是否為本工站所在流程---------
      FOR cur_check_flow IN (SELECT flow_id
                               FROM lb_flow_dtl
                              WHERE stage_id = p_stage)
      LOOP
         IF p_flow = cur_check_flow.flow_id
         THEN
            g_ok := 'Y';
            EXIT;
         END IF;
      END LOOP;

      IF g_ok = 'N'
      THEN
         g_msg := '工站未在掃描流程中!';
         RETURN;
      END IF;
   END;

--工站信息----------------------------------------------
   PROCEDURE p_data_stage (p_flow VARCHAR2, p_stage VARCHAR2)
   IS
   BEGIN
      --本工站序號----------
      SELECT NVL (MAX (flow_item), 0)
        INTO g_curr_item
        FROM lb_flow_dtl
       WHERE flow_id = p_flow AND stage_id = p_stage;

      --前工站序號----------
      g_bef_item := g_curr_item - 1;

      IF g_bef_item > 0
      THEN
         --前工站ID----------
         SELECT MAX (stage_id)
           INTO g_bef_stage_id
           FROM lb_flow_dtl
          WHERE flow_id = p_flow AND flow_item = g_bef_item;

         --前工站NAME----------
         SELECT MAX (stage_name)
           INTO g_bef_stage_name
           FROM lb_stage
          WHERE stage_id = g_bef_stage_id;
      END IF;

      --下一工站序號
      g_next_item := g_curr_item + 1;

      SELECT MAX (stage_id)
        INTO g_next_stage_id
        FROM lb_flow_dtl
       WHERE flow_id = p_flow AND flow_item = g_next_item;
   END;

   --掃描流程結束后，掃描紀錄轉移到表LB_SCAN_END------------------
   PROCEDURE p_scan_move
   IS
   BEGIN
      NULL;

-----------------------------------------------------------------
      INSERT INTO dmpdb2.lb_scan_end
                  (scan_no, flow_id, flow_item, proj_id, floor_id, prod_sn,
                   nal_sn, scan_time, stage_id, user_id, line_code, is_acti,
                   notes, to_floor_id, move_time)
         SELECT scan_no, flow_id, flow_item, proj_id, floor_id, prod_sn,
                nal_sn, scan_time, stage_id, user_id, line_code, is_acti,
                notes, to_floor_id, SYSDATE
           FROM dmpdb2.lb_scan
          WHERE nal_sn IN (
                   SELECT nal_sn
                     FROM dmpdb2.lb_scan
                    WHERE flow_id = 'F001'
                      AND stage_id = 'S001'
                      AND is_sfc = 'Y');

      --刪除10日前的結束流程的藍標----------------------------
      DELETE FROM dmpdb2.lb_scan
            WHERE nal_sn IN (
                     SELECT nal_sn
                       FROM dmpdb2.lb_scan
                      WHERE flow_id = 'F001'
                        AND stage_id = 'S001'
                        AND is_sfc = 'Y');
   END;
END lb_pk_d_t;
/

