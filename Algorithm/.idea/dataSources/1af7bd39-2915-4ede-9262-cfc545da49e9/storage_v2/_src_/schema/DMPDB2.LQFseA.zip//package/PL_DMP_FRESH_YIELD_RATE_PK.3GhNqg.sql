create PACKAGE        PL_DMP_FRESH_YIELD_RATE_PK
AS
   TYPE CURSORTYPE IS REF CURSOR;

   PROCEDURE DMP_FRESH_YIELD_SP (
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_START_TIME     IN       VARCHAR2,
      V_END_TIME       IN       VARCHAR2,
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_plant_CODE      IN       VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      PL_DMP_FRESH_YIELD_RATE_PK.CURSORTYPE
   );  

   PROCEDURE DMP_DEFECT_DETAIL_SP (
      V_START_DATE     IN        VARCHAR2,
      V_END_DATE       IN        VARCHAR2,
      V_PRODUCT_NAME   IN        VARCHAR2,
      V_PRODUCT_SKU    IN        VARCHAR2,
      V_MODULE_NAME    IN        VARCHAR2,
      V_LINE_NAME      IN        VARCHAR2,     
      V_WO_NUMBER      IN        VARCHAR2,
      V_STATION_CODE   IN        VARCHAR2,
      V_Repair_times   IN        NUMBER,     
      V_type_CODE      IN        VARCHAR2,
      V_DATA_TYPE      IN        VARCHAR2,
      RES              OUT       VARCHAR2,
      P_CURSOR         OUT       pl_Dmp_Fresh_Yield_Rate_Pk.CURSORTYPE
   );

END PL_DMP_FRESH_YIELD_RATE_PK;

/

