create PACKAGE BODY        Pl_Dmp_Fresh_Yield_Rate_Pk AS
/* creadte by Jerry Zhang For Fresh Rate 20071204 */

   PROCEDURE DMP_Fresh_YIELD_SP (
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_START_TIME     IN       VARCHAR2,
      V_END_TIME       IN       VARCHAR2,
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_plant_CODE     IN       VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      Pl_Dmp_Fresh_Yield_Rate_Pk.CURSORTYPE
   )

   AS
       V_PRODUCT        VARCHAR2(30);
       V_SKU            VARCHAR2(30);
       V_MODULE         VARCHAR2(10);
       V_LINE           VARCHAR2(10);
       V_DATATYPE       VARCHAR2(1);
       V_type           VARCHAR2(1);
       
   BEGIN
          IF V_DATA_TYPE='' OR V_DATA_TYPE IS NULL THEN
          V_DATATYPE:='R';
       ELSE
          V_DATATYPE:=V_DATA_TYPE;
       END IF;

          IF V_MODULE_NAME='' OR V_MODULE_NAME IS NULL THEN
          V_MODULE:='';
       ELSE
          V_MODULE:=V_MODULE_NAME;
       END IF;

       IF V_LINE_NAME='' OR V_LINE_NAME IS NULL THEN
          V_LINE:='';
       ELSE
          V_LINE:=V_LINE_NAME;
       END IF;

       IF V_PRODUCT_NAME='' OR V_PRODUCT_NAME IS NULL THEN
          V_PRODUCT:='';
       ELSE
          V_PRODUCT:=V_PRODUCT_NAME;
       END IF;

       IF V_PRODUCT_SKU ='' OR V_PRODUCT_SKU  IS NULL THEN
          V_SKU:='';
       ELSE
          V_SKU:=V_PRODUCT_SKU ;
       END IF;       
    

        IF V_DATATYPE = 'R' THEN

            OPEN P_CURSOR FOR

            SELECT A.NAMEE,
            A.STATION_ID,
            a.CODE,
            --nomal
            SUM(A.FRESHIQTY) AS FRESH_INPUT_QTY,
            SUM(A.FRESHPQTY) AS FRESH_PASS_QTY,          
            DECODE(SUM(FRESHIQTY),0,0,ROUND(SUM(A.FRESHPQTY)/SUM(FRESHIQTY)*100,2)) AS FRESH_YIELD,
            SUM(A.FIRSTIQTY) AS FIRST_INPUT_QTY,
            SUM(A.FIRSTPQTY) AS FIRST_PASS_QTY,          
            DECODE(SUM(FIRSTIQTY),0,0,ROUND(SUM(A.FIRSTPQTY)/SUM(FIRSTIQTY)*100,2)) AS FIRST_YIELD,
            SUM(A.SECONDIQTY) AS SECOND_INPUT_QTY,
            SUM(A.SECONDPQTY) AS SECOND_PASS_QTY,           
            DECODE(SUM(SECONDIQTY),0,0,ROUND(SUM(A.SECONDPQTY)/SUM(SECONDIQTY)*100,2)) AS SECOND_YIELD,
            SUM(A.THIRDIQTY) AS THIRD_INPUT_QTY,
            SUM(A.THIRDPQTY) AS THIRD_PASS_QTY,            
            DECODE(SUM(THIRDIQTY),0,0,ROUND(SUM(A.THIRDPQTY)/SUM(THIRDIQTY)*100,2)) AS THIRD_YIELD,
            SUM(A.OTTIQTY) AS OTT_INPUT_QTY,
            SUM(A.OTTPQTY) AS OTT_PASS_QTY,            
            DECODE(SUM(OTTIQTY),0,0,ROUND(SUM(A.OTTPQTY)/SUM(OTTIQTY)*100,2)) AS OTT_YIELD,
            --cr
             SUM(A.msr_FRESHIQTY) AS msr_FRESH_INPUT_QTY,
            SUM(A.msr_FRESHPQTY) AS msr_FRESH_PASS_QTY,          
            DECODE(SUM(msr_FRESHIQTY),0,0,ROUND(SUM(A.msr_FRESHPQTY)/SUM(msr_FRESHIQTY)*100,2)) AS msr_FRESH_YIELD,
            SUM(A.msr_FIRSTIQTY) AS msr_FIRST_INPUT_QTY,
            SUM(A.msr_FIRSTPQTY) AS msr_FIRST_PASS_QTY,          
            DECODE(SUM(msr_FIRSTIQTY),0,0,ROUND(SUM(A.msr_FIRSTPQTY)/SUM(msr_FIRSTIQTY)*100,2)) AS msr_FIRST_YIELD,
            SUM(A.msr_SECONDIQTY) AS msr_SECOND_INPUT_QTY,
            SUM(A.msr_SECONDPQTY) AS msr_SECOND_PASS_QTY,           
            DECODE(SUM(msr_SECONDIQTY),0,0,ROUND(SUM(A.msr_SECONDPQTY)/SUM(msr_SECONDIQTY)*100,2)) AS msr_SECOND_YIELD,
            SUM(A.msr_THIRDIQTY) AS msr_THIRD_INPUT_QTY,
            SUM(A.msr_THIRDPQTY) AS msr_THIRD_PASS_QTY,            
            DECODE(SUM(msr_THIRDIQTY),0,0,ROUND(SUM(A.msr_THIRDPQTY)/SUM(msr_THIRDIQTY)*100,2)) AS msr_THIRD_YIELD,
             SUM(A.msr_OTTIQTY) AS msr_OTT_INPUT_QTY,
            SUM(A.msr_OTTPQTY) AS msr_OTT_PASS_QTY,            
            DECODE(SUM(msr_OTTIQTY),0,0,ROUND(SUM(A.msr_OTTPQTY)/SUM(msr_OTTIQTY)*100,2)) AS msr_OTT_YIELD,
            --ttl
            SUM(A.ttl_FRESHIQTY) AS ttl_FRESH_INPUT_QTY,
            SUM(A.ttl_FRESHPQTY) AS ttl_FRESH_PASS_QTY,          
            DECODE(SUM(ttl_FRESHIQTY),0,0,ROUND(SUM(A.ttl_FRESHPQTY)/SUM(ttl_FRESHIQTY)*100,2)) AS ttl_FRESH_YIELD,
            SUM(A.ttl_FIRSTIQTY) AS ttl_FIRST_INPUT_QTY,
            SUM(A.ttl_FIRSTPQTY) AS ttl_FIRST_PASS_QTY,          
            DECODE(SUM(ttl_FIRSTIQTY),0,0,ROUND(SUM(A.ttl_FIRSTPQTY)/SUM(ttl_FIRSTIQTY)*100,2)) AS ttl_FIRST_YIELD,
            SUM(A.ttl_SECONDIQTY) AS ttl_SECOND_INPUT_QTY,
            SUM(A.ttl_SECONDPQTY) AS ttl_SECOND_PASS_QTY,           
            DECODE(SUM(ttl_SECONDIQTY),0,0,ROUND(SUM(A.ttl_SECONDPQTY)/SUM(ttl_SECONDIQTY)*100,2)) AS ttl_SECOND_YIELD,
            SUM(A.ttl_THIRDIQTY) AS ttl_THIRD_INPUT_QTY,
            SUM(A.ttl_THIRDPQTY) AS ttl_THIRD_PASS_QTY,            
            DECODE(SUM(ttl_THIRDIQTY),0,0,ROUND(SUM(A.ttl_THIRDPQTY)/SUM(ttl_THIRDIQTY)*100,2)) AS ttl_THIRD_YIELD,
            SUM(A.ttl_OTTIQTY) AS ttl_OTT_INPUT_QTY,
            SUM(A.ttl_OTTPQTY) AS ttl_OTT_PASS_QTY,            
            DECODE(SUM(ttl_OTTIQTY),0,0,ROUND(SUM(A.ttl_OTTPQTY)/SUM(ttl_OTTIQTY)*100,2)) AS ttl_OTT_YIELD
            FROM
            (
                SELECT /*+ordered*/ TO_DATE((CASE WHEN (REPORT_DATE <> WORK_DATE AND TIME_SLOT = '23:30') THEN TO_CHAR(WORK_DATE,'YYYY/MM/DD')||' '||'00:00'
                       ELSE TO_CHAR(WORK_DATE,'YYYY/MM/DD')||' '||TIME_SLOT END),'YYYY/MM/DD HH24:MI:SS') AS WORK_TIME,
                A.LINE_ID,
                A.STATION_ID,
                D.NAMEE,
                d.CODE,
                A.WO_ID,
                A.FRESH_PASS_QTY AS FreshPQTY,             
                A.FRESH_PASS_QTY+ A.FRESH_FAIL_QTY AS FreshIqty,
                
                A.msr_FRESH_PASS_QTY AS msr_FreshPQTY,              
                A.msr_FRESH_PASS_QTY+ A.msr_FRESH_FAIL_QTY AS msr_FreshIqty,
                
                A.FRESH_PASS_QTY+A.msr_FRESH_PASS_QTY AS ttl_FreshPQTY,              
                A.FRESH_PASS_QTY+a.fresh_fail_qty+A.msr_FRESH_PASS_QTY+ A.msr_FRESH_FAIL_QTY AS ttl_FreshIqty,
                
                A.FIRST_REPAIR_PASS_QTY AS FirstPQTY,              
                A.FIRST_REPAIR_PASS_QTY+A.FIRST_REPAIR_FAIL_QTY AS FirstIqty,
                A.msr_FIRST_REPAIR_PASS_QTY AS msr_FirstPQTY,               
                A.msr_FIRST_REPAIR_PASS_QTY+A.msr_FIRST_REPAIR_FAIL_QTY AS msr_FirstIqty,
                A.FIRST_REPAIR_PASS_QTY+A.msr_FIRST_REPAIR_PASS_QTY AS ttl_FIRSTPQTY,
                A.FIRST_REPAIR_PASS_QTY+a.FIRST_REPAIR_fail_qty+A.msr_FIRST_REPAIR_PASS_QTY+ A.msr_FIRST_REPAIR_FAIL_QTY AS ttl_FIRSTIqty,
                
                A.SECOND_REPAIR_PASS_QTY AS SecondPQTY,               
                A.SECOND_REPAIR_PASS_QTY+A.SECOND_REPAIR_Fail_QTY AS SecondIqty,
                A.msr_SECOND_REPAIR_PASS_QTY AS msr_SecondPQTY,               
                A.msr_SECOND_REPAIR_PASS_QTY+A.msr_SECOND_REPAIR_Fail_QTY AS msr_SecondIqty,
                A.SECOND_REPAIR_PASS_QTY+A.msr_SECOND_REPAIR_PASS_QTY AS ttl_SECONDPQTY,
                A.SECOND_REPAIR_PASS_QTY+a.SECOND_REPAIR_fail_qty+A.msr_SECOND_REPAIR_PASS_QTY+ A.msr_SECOND_REPAIR_FAIL_QTY AS ttl_SECONDIqty,
                
                A.THIRD_REPAIR_PASS_QTY AS ThirdPQty,               
                A.THIRD_REPAIR_PASS_QTY+A.THIRD_REPAIR_Fail_QTY AS ThirdIqty,
                A.msr_THIRD_REPAIR_PASS_QTY AS msr_ThirdPQty,            
                A.msr_THIRD_REPAIR_PASS_QTY+A.msr_THIRD_REPAIR_Fail_QTY AS msr_ThirdIqty,
                A.THIRD_REPAIR_PASS_QTY+A.msr_THIRD_REPAIR_PASS_QTY AS ttl_THIRDPQTY,
                A.THIRD_REPAIR_PASS_QTY+a.THIRD_REPAIR_fail_qty+A.msr_THIRD_REPAIR_PASS_QTY+ A.MSR_THIRD_REPAIR_FAIL_QTY AS ttl_THIRDIqty,
                
                A.OTT_REPAIR_PASS_QTY AS OTTPQty,               
                A.OTT_REPAIR_PASS_QTY+A.OTT_REPAIR_Fail_QTY AS OTTIqty,
                A.msr_OTT_REPAIR_PASS_QTY AS msr_OTTPQty,            
                A.msr_OTT_REPAIR_PASS_QTY+A.msr_OTT_REPAIR_Fail_QTY AS msr_OTTIqty,
                A.OTT_REPAIR_PASS_QTY+A.msr_OTT_REPAIR_PASS_QTY AS ttl_OTTPQTY,
                A.OTT_REPAIR_PASS_QTY+a.OTT_REPAIR_fail_qty+A.msr_OTT_REPAIR_PASS_QTY+ A.MSR_OTT_REPAIR_FAIL_QTY AS ttl_OTTIqty
                FROM DMPDB2.A_TEST_RESULT_FRESH A,
                     DMPDB2.R_WO B,
                     DMPDB2.LINE C,
                     DMPDB2.STATION D
                WHERE  A.LINE_ID = C.ID
                AND A.WO_ID= B.ID
                AND A.STATION_ID = D.ID               
                AND C.PARENT_LINE_CODE LIKE '%'||V_LINE
                AND C.GROUP_FLAG LIKE '%'||V_MODULE
                AND B.CUST_PART_NO LIKE '%'||V_SKU
                AND D.TYPE IN ('TO','TP')
                --AND B.PLANT_CODE LIKE V_PLANT_CODE||'%'
                AND B.NO LIKE V_WO_NO||'%'
                AND A.CATEGORY_KEY = V_PRODUCT
                AND A.WORK_DATE>=TO_DATE(V_START_DATE,'YYYY/MM/DD')
                AND A.WORK_DATE<=TO_DATE(V_END_DATE,'YYYY/MM/DD')                
            ) A
            WHERE A.WORK_TIME>=TO_DATE(V_START_DATE||' '||V_START_TIME,'YYYY/MM/DD HH24:MI:SS')
            AND A.WORK_TIME< TO_DATE(V_END_DATE||' '||V_END_TIME,'YYYY/MM/DD HH24:MI:SS')
            GROUP BY A.NAMEE ,A.STATION_ID,a.CODE
            ORDER BY A.STATION_ID;          
    END IF;

   END DMP_Fresh_YIELD_SP;
   
   PROCEDURE DMP_DEFECT_DETAIL_SP (
      V_START_DATE     IN        VARCHAR2,
      V_END_DATE       IN        VARCHAR2,
      V_PRODUCT_NAME   IN        VARCHAR2,
      V_PRODUCT_SKU    IN        VARCHAR2,
      V_MODULE_NAME    IN        VARCHAR2,
      V_LINE_NAME      IN        VARCHAR2,    
      V_WO_NUMBER      IN        VARCHAR2,
      V_STATION_CODE   IN        VARCHAR2,
      V_Repair_times   IN        NUMBER,     
      V_type_CODE      IN        VARCHAR2,
      V_DATA_TYPE      IN        VARCHAR2,
      RES              OUT       VARCHAR2,
      P_CURSOR         OUT       Pl_Dmp_Fresh_Yield_Rate_Pk.CURSORTYPE
   )
   AS

      V_START           VARCHAR2(30);
      V_END             VARCHAR2(30);
      V_PRODUCT         VARCHAR2(20);
      V_SKU             VARCHAR2(20);
      V_MODULE          VARCHAR2(20);
      V_LINE            VARCHAR2(20);    
      V_WO              VARCHAR2(30);
      V_STATION         VARCHAR2(30);     
      V_DATATYPE        VARCHAR2(1);
      V_type            VARCHAR2(1);
      V_repairtimes     NUMBER;

   BEGIN
   
       V_WO := V_WO_NUMBER;

       IF V_DATA_TYPE='' OR V_DATA_TYPE IS NULL THEN
          V_DATATYPE:='R';
       ELSE
          V_DATATYPE:=V_DATA_TYPE;
       END IF;

       IF V_START_DATE='' OR V_START_DATE IS NULL THEN
          V_START := '';--TO_CHAR(SYSDATE,'yyyymmdd')||' 07:30:00';
       ELSE
          V_START:=V_START_DATE;
       END IF;

       IF V_END_DATE='' OR V_END_DATE IS NULL THEN
          V_END := '';--TO_CHAR(SYSDATE+1,'yyyymmdd')||' 07:30:00';
       ELSE
          V_END:=V_END_DATE;
       END IF;

       IF V_PRODUCT_NAME='' OR V_PRODUCT_NAME ='ALL' OR V_PRODUCT_NAME IS NULL  THEN
         V_PRODUCT:='';
       ELSE
         V_PRODUCT:=V_PRODUCT_NAME;
       END IF;

       IF V_PRODUCT_SKU='' OR V_PRODUCT_NAME ='ALL' OR V_PRODUCT_SKU IS NULL  THEN
         V_SKU:='';
       ELSE
         V_SKU:=V_PRODUCT_SKU;
       END IF;

       IF V_MODULE_NAME='' OR V_MODULE_NAME ='ALL' OR V_MODULE_NAME IS NULL THEN
         V_MODULE:='';
       ELSE
         V_MODULE:=V_MODULE_NAME;
       END IF;

       IF V_LINE_NAME='' OR V_LINE_NAME ='ALL' OR V_LINE_NAME IS NULL  THEN
         V_LINE:='';
       ELSE
         V_LINE:=V_LINE_NAME;
       END IF;

       IF V_STATION_CODE IS NULL  THEN
         V_STATION:='';
       ELSE
         V_STATION:=V_STATION_CODE;
       END IF;
       
       IF V_type_code ='' OR V_type_code IS NULL THEN
        V_type :='';
        ELSE IF UPPER(V_type_code) = 'N' THEN
        V_type := '0';
        ELSE
        V_type := '1';
        END IF;        
        END IF;
        
         V_repairtimes := TO_NUMBER(V_repair_times)+1;

       IF V_STATION IS NOT NULL THEN
       
       IF V_repairtimes <=4 THEN

        OPEN P_CURSOR FOR

        /*
         SELECT /*+ all_rows */
        /*D.NO AS SN,
        D.WO_NO,
        D.CUST_PART_NO,
        TO_CHAR(A.TEST_TIME,'YYYY-MM-DD HH24:MI:SS')AS TEST_TIME,
        C.NAMEE AS TEST_STATION,
        L.NAMEE AS TEST_LINE,
        H.NAMEE AS TEST_ITEM,
        F.NAMEE AS FAIL_SYMPTOM,
        I.NAMEE AS ACTUAL_SYMPTOM,
        TO_CHAR(A.REPAIR_TIME,'YYYY-MM-DD HH24:MI:SS')AS REPAIR_TIME,
        j.OLD_SERIAL_NO,
        J.NEW_SERIAL_NO,
        M.EMPLOYEE_ID AS REPAIRER,
        K.NAMEE AS REPAIR_ACTION,
        TO_CHAR(A.CHECK_IN_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_IN_TIME,
        TO_CHAR(A.CHECK_OUT_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_OUT_TIME,
        FLOOR(24*60*(NVL(A.CHECK_OUT_TIME,SYSDATE)-NVL(A.CHECK_IN_TIME,SYSDATE)))AS DIFFMIN
        FROM        
        DMPDB2.R_WIP D,
        DMPDB2.R_REPAIR A,
        DMP2WEB.SFC_PRODUCT E,
        DMPDB2.SYMPTOM F,
        DMPDB2.SYMPTOM I,
        DMPDB2.TEST_ITEM H,
        DMPDB2.R_REPAIR_DETAIL J,
        DMPDB2.REPAIR_ACTION K,
        DMPDB2.APP_USER M,
        DMPDB2.R_WO N,
        DMPDB2.STATION C,
        DMPDB2.LINE L
        WHERE J.REPAIR_ACTION_ID=K.ID(+)
        AND A.ID=J.REPAIR_ID(+)
        AND A.SYMPTOM_ID2=I.ID(+)
        AND A.TEST_ITEM_ID=H.ID(+)
        AND A.SYMPTOM_ID1=F.ID
        AND d.PRODUCT_ID = E.ID
        AND A.WIP_ID=D.ID
        AND A.TEST_LINE_ID=L.ID
        AND A.TEST_STATION_ID=C.ID
        AND A.REPAIR_BY=M.ID(+)
        AND D.WO_NO=N.NO
        AND A.DEL_FLAG=0       
        AND C.ID = V_STATION
        AND L.GROUP_FLAG LIKE '%'||V_MODULE 
        AND L.PARENT_LINE_CODE LIKE '%'||V_LINE
        AND E.CATEGORY_KEY = V_PRODUCT
        --AND N.plant_code LIKE V_PLANT_CODE||'%'
        AND N.is_msr LIKE '%'||V_type
        AND n.no LIKE v_wo||'%'
        AND A.repair_times = V_repairtimes
        AND A.TEST_TIME>=TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
        AND A.TEST_TIME<=TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
        ORDER BY A.TEST_TIME
        */
        
        SELECT /*+ all_rows */D.NO AS SN,
        D.WO_NO,
        D.CUST_PART_NO,
        TO_CHAR(A.TEST_TIME,'YYYY-MM-DD HH24:MI:SS')AS TEST_TIME,
        C.NAMEE AS TEST_STATION,
        L.NAMEE AS TEST_LINE,
        H.NAMEE AS TEST_ITEM,
        F.NAMEE AS FAIL_SYMPTOM,
        I.NAMEE AS ACTUAL_SYMPTOM,
        TO_CHAR(A.REPAIR_TIME,'YYYY-MM-DD HH24:MI:SS')AS REPAIR_TIME,
        j.OLD_SERIAL_NO,
        J.NEW_SERIAL_NO,
        M.EMPLOYEE_ID AS REPAIRER,
        K.NAMEE AS REPAIR_ACTION,
        TO_CHAR(A.CHECK_IN_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_IN_TIME,
        TO_CHAR(A.CHECK_OUT_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_OUT_TIME,
        FLOOR(24*60*(NVL(A.CHECK_OUT_TIME,SYSDATE)-NVL(A.CHECK_IN_TIME,SYSDATE)))AS DIFFMIN
        FROM dmpdb2.R_REPAIR a,
             DMPDB2.R_WIP d,
             dmpdb2.R_REPAIR_DETAIL J,
             dmpdb2.R_WO N,
             dmpdb2.REPAIR_ACTION K,
             dmpdb2.APP_USER M,
             dmpdb2.SYMPTOM F,
             dmpdb2.SYMPTOM I,
             dmpdb2.TEST_ITEM H,
             dmpdb2.STATION C,
             dmpdb2.LINE L
        WHERE a.wip_id=d.id
        AND A.TEST_STATION_ID = C.ID
        AND A.TEST_LINE_ID = L.ID
        AND D.WO_NO = N.NO
        AND A.ID = J.REPAIR_ID(+)
        AND A.TEST_ITEM_ID = H.ID(+)
        AND A.SYMPTOM_ID1 = F.ID(+)
        AND A.SYMPTOM_ID2 = I.ID(+)
        AND J.REPAIR_ACTION_ID = K.ID(+)
        AND A.REPAIR_BY=M.ID(+)
        AND A.DEL_FLAG=0
        --AND d.DEL_FLAG=0 --MODIFY BY QIUCHEN 2008/7/6
        AND C.ID = V_STATION
        AND L.GROUP_FLAG LIKE '%'||V_MODULE 
        AND L.PARENT_LINE_CODE LIKE '%'||V_LINE
        AND N.CATEGORY_KEY = V_PRODUCT
        --AND N.plant_code LIKE V_PLANT_CODE||'%'
        AND N.is_msr LIKE '%'||V_type
        AND n.no LIKE v_wo||'%'
        AND A.repair_times = V_repairtimes
        AND A.TEST_TIME>=TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
        AND A.TEST_TIME<=TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
        ORDER BY A.TEST_TIME;
        
        ELSE
        
        OPEN p_cursor FOR
        
        SELECT /*+ all_rows */D.NO AS SN,
        D.WO_NO,
        D.CUST_PART_NO,
        TO_CHAR(A.TEST_TIME,'YYYY-MM-DD HH24:MI:SS')AS TEST_TIME,
        C.NAMEE AS TEST_STATION,
        L.NAMEE AS TEST_LINE,
        H.NAMEE AS TEST_ITEM,
        F.NAMEE AS FAIL_SYMPTOM,
        I.NAMEE AS ACTUAL_SYMPTOM,
        TO_CHAR(A.REPAIR_TIME,'YYYY-MM-DD HH24:MI:SS')AS REPAIR_TIME,
        j.OLD_SERIAL_NO,
        J.NEW_SERIAL_NO,
        M.EMPLOYEE_ID AS REPAIRER,
        K.NAMEE AS REPAIR_ACTION,
        TO_CHAR(A.CHECK_IN_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_IN_TIME,
        TO_CHAR(A.CHECK_OUT_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_OUT_TIME,
        FLOOR(24*60*(NVL(A.CHECK_OUT_TIME,SYSDATE)-NVL(A.CHECK_IN_TIME,SYSDATE)))AS DIFFMIN
        FROM        
        DMPDB2.R_WIP D,
        DMPDB2.R_REPAIR A,
        DMP2WEB.SFC_PRODUCT E,
        DMPDB2.SYMPTOM F,
        DMPDB2.SYMPTOM I,
        DMPDB2.TEST_ITEM H,
        DMPDB2.R_REPAIR_DETAIL J,
        DMPDB2.REPAIR_ACTION K,
        DMPDB2.APP_USER M,
        DMPDB2.R_WO N,
        DMPDB2.STATION C,
        DMPDB2.LINE L
        WHERE J.REPAIR_ACTION_ID=K.ID(+)
        AND A.ID=J.REPAIR_ID(+)
        AND A.SYMPTOM_ID2=I.ID(+)
        AND A.TEST_ITEM_ID=H.ID(+)
        AND A.SYMPTOM_ID1=F.ID
        AND d.PRODUCT_ID = E.ID
        AND A.WIP_ID=D.ID
        AND A.TEST_LINE_ID=L.ID
        AND A.TEST_STATION_ID=C.ID
        AND A.REPAIR_BY=M.ID(+)
        AND D.WO_NO=N.NO
        AND A.DEL_FLAG=0       
        AND C.ID= V_STATION
        AND L.GROUP_FLAG LIKE '%'||V_MODULE 
        AND L.PARENT_LINE_CODE LIKE '%'||V_LINE
        AND E.CATEGORY_KEY = V_PRODUCT
        --AND N.plant_code LIKE V_PLANT_CODE||'%'
        AND N.is_msr LIKE '%'||V_type
        AND n.no LIKE v_wo||'%'
        AND A.repair_times >= V_repairtimes
        AND A.TEST_TIME>=TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
        AND A.TEST_TIME<=TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
        ORDER BY A.TEST_TIME;
        
        END IF;
        
        ELSE
        
        IF V_repairtimes <=4 THEN

        OPEN P_CURSOR FOR

        SELECT /*+ all_rows */D.NO AS SN,
        D.WO_NO,
        D.CUST_PART_NO,
        TO_CHAR(A.TEST_TIME,'YYYY-MM-DD HH24:MI:SS')AS TEST_TIME,
        C.NAMEE AS TEST_STATION,
        L.NAMEE AS TEST_LINE,
        H.NAMEE AS TEST_ITEM,
        F.NAMEE AS FAIL_SYMPTOM,
        I.NAMEE AS ACTUAL_SYMPTOM,
        TO_CHAR(A.REPAIR_TIME,'YYYY-MM-DD HH24:MI:SS')AS REPAIR_TIME,
        j.OLD_SERIAL_NO,
        J.NEW_SERIAL_NO,
        M.EMPLOYEE_ID AS REPAIRER,
        K.NAMEE AS REPAIR_ACTION,
        TO_CHAR(A.CHECK_IN_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_IN_TIME,
        TO_CHAR(A.CHECK_OUT_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_OUT_TIME,
        FLOOR(24*60*(NVL(A.CHECK_OUT_TIME,SYSDATE)-NVL(A.CHECK_IN_TIME,SYSDATE)))AS DIFFMIN
        FROM        
        DMPDB2.R_WIP D,
        DMPDB2.R_REPAIR A,
        DMP2WEB.SFC_PRODUCT E,
        DMPDB2.SYMPTOM F,
        DMPDB2.SYMPTOM I,
        DMPDB2.TEST_ITEM H,
        DMPDB2.R_REPAIR_DETAIL J,
        DMPDB2.REPAIR_ACTION K,
        DMPDB2.APP_USER M,
        DMPDB2.R_WO N,
        DMPDB2.STATION C,
        DMPDB2.LINE L
        WHERE J.REPAIR_ACTION_ID=K.ID(+)
        AND A.ID=J.REPAIR_ID(+)
        AND A.SYMPTOM_ID2=I.ID(+)
        AND A.TEST_ITEM_ID=H.ID(+)
        AND A.SYMPTOM_ID1=F.ID
        AND d.PRODUCT_ID = E.ID
        AND A.WIP_ID=D.ID
        AND A.TEST_LINE_ID=L.ID
        AND A.TEST_STATION_ID=C.ID
        AND A.REPAIR_BY=M.ID(+)
        AND D.WO_NO=N.NO
        AND A.DEL_FLAG=0       
        AND C.ID IN (80,81,83,84,85)
        AND L.GROUP_FLAG LIKE '%'||V_MODULE 
        AND L.PARENT_LINE_CODE LIKE '%'||V_LINE
        AND E.CATEGORY_KEY = V_PRODUCT
        --AND N.plant_code LIKE V_PLANT_CODE||'%'
        AND N.is_msr LIKE '%'||V_type
        AND n.no LIKE v_wo||'%'
        AND A.repair_times = V_repairtimes
        AND A.TEST_TIME>=TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
        AND A.TEST_TIME<=TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
        ORDER BY A.TEST_TIME;
        
        ELSE
        
        OPEN p_cursor FOR
        
        SELECT /*+ all_rows */D.NO AS SN,
        D.WO_NO,
        D.CUST_PART_NO,
        TO_CHAR(A.TEST_TIME,'YYYY-MM-DD HH24:MI:SS')AS TEST_TIME,
        C.NAMEE AS TEST_STATION,
        L.NAMEE AS TEST_LINE,
        H.NAMEE AS TEST_ITEM,
        F.NAMEE AS FAIL_SYMPTOM,
        I.NAMEE AS ACTUAL_SYMPTOM,
        TO_CHAR(A.REPAIR_TIME,'YYYY-MM-DD HH24:MI:SS')AS REPAIR_TIME,
        j.OLD_SERIAL_NO,
        J.NEW_SERIAL_NO,
        M.EMPLOYEE_ID AS REPAIRER,
        K.NAMEE AS REPAIR_ACTION,
        TO_CHAR(A.CHECK_IN_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_IN_TIME,
        TO_CHAR(A.CHECK_OUT_TIME,'YYYY-MM-DD HH24:MI:SS')AS CHECK_OUT_TIME,
        FLOOR(24*60*(NVL(A.CHECK_OUT_TIME,SYSDATE)-NVL(A.CHECK_IN_TIME,SYSDATE)))AS DIFFMIN
        FROM        
        DMPDB2.R_WIP D,
        DMPDB2.R_REPAIR A,
        DMP2WEB.SFC_PRODUCT E,
        DMPDB2.SYMPTOM F,
        DMPDB2.SYMPTOM I,
        DMPDB2.TEST_ITEM H,
        DMPDB2.R_REPAIR_DETAIL J,
        DMPDB2.REPAIR_ACTION K,
        DMPDB2.APP_USER M,
        DMPDB2.R_WO N,
        DMPDB2.STATION C,
        DMPDB2.LINE L
        WHERE J.REPAIR_ACTION_ID=K.ID(+)
        AND A.ID=J.REPAIR_ID(+)
        AND A.SYMPTOM_ID2=I.ID(+)
        AND A.TEST_ITEM_ID=H.ID(+)
        AND A.SYMPTOM_ID1=F.ID
        AND d.PRODUCT_ID = E.ID
        AND A.WIP_ID=D.ID
        AND A.TEST_LINE_ID=L.ID
        AND A.TEST_STATION_ID=C.ID
        AND A.REPAIR_BY=M.ID(+)
        AND D.WO_NO=N.NO
        AND A.DEL_FLAG=0       
        AND C.ID IN (80,81,83,84,85)
        AND L.GROUP_FLAG LIKE '%'||V_MODULE 
        AND L.PARENT_LINE_CODE LIKE '%'||V_LINE
        AND E.CATEGORY_KEY = V_PRODUCT
        --AND N.plant_code LIKE V_PLANT_CODE||'%'
        AND N.is_msr LIKE '%'||V_type
        AND n.no LIKE v_wo||'%'
        AND A.repair_times >= V_repairtimes
        AND A.TEST_TIME>=TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
        AND A.TEST_TIME<=TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
        ORDER BY A.TEST_TIME;
        
        END IF;

      END IF;

   END DMP_DEFECT_DETAIL_SP;

END Pl_Dmp_Fresh_Yield_Rate_Pk;
/

