create PACKAGE        PL_Dmp_Rrt_Inspection_Daily_Pk
AS
   TYPE CURSORTYPE IS REF CURSOR;

   PROCEDURE DMP_RRT_INSPECTION_DAILY_SP (
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_QUERY_TYPE       IN        VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      V_PLANT_CODE       IN        VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      PL_Dmp_Rrt_Inspection_Daily_Pk.CURSORTYPE
   );

   PROCEDURE DMP_RRT_INSPECTION_FC_QTYPE_SP (
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_QUERY_TYPE       IN        VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      V_PLANT_CODE       IN        VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      PL_Dmp_Rrt_Inspection_Daily_Pk.CURSORTYPE
   );


   PROCEDURE DMP_RRT_DEFECT_DETAIL_QTYPE_SP (
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_STATION_CODE   IN       VARCHAR2,
      V_SYMPTOM_TYPE   IN       VARCHAR2,
      V_WO_FLAG        IN       VARCHAR2,
      V_QUERY_TYPE       IN        VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      V_PLANT_CODE       IN        VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      PL_Dmp_Rrt_Inspection_Daily_Pk.CURSORTYPE
   );
END PL_Dmp_Rrt_Inspection_Daily_Pk;

/

