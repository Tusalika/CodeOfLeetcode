create PACKAGE BODY        Pl_Dmp_Rrt_Inspection_Daily_Pk
AS
/*
 VERSION : 1.1.0.3 PL_Dmp_Rrt_Inspection_Daily_Pk
 CREATED BY WINLY DANG 2006/06/07
 1. THIS SP USE A_TEST_RESULT, PLS CHECK TIME'S PROCESS
 2. PARAMETERS IS OK
 ADD BY JOYBEE 20060622
 ADD DMP_RRT_DEFECT_DETAIL_SP ,BECAUSE THE REPAIR SP IS VERY SLOWLY
 UPDATE BY JOYBEE 20060623
 DISTINGUISH 'FIRST' ,'MULTI' through is_MSR flag
 UPDATED BY WINLY DANG [2006/06/28]
 1. ADD DATA_TYPE
*/

/** Update by: Joybee
    Update Date : 20060915 
    Update Content : 'N36' has no 'CA' station,so replace 'GC' with it 
                      DMP_RRT_INSPECTION_SP add 'GC' station,beacause M26 needs 'CA' station, then keep 'CA' station as original ,
                      and 'CA' &'GC' station can't exist with the same model,
**/


   PROCEDURE DMP_RRT_INSPECTION_DAILY_SP (
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_MODULE_NAME       IN        VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_WO_NO           IN       VARCHAR2,
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_QUERY_TYPE       IN        VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      V_PLANT_CODE       IN        VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      Pl_Dmp_Rrt_Inspection_Daily_Pk.CURSORTYPE
   )
   AS
      V_QUERYTYPE    VARCHAR2 (10);
      V_PRODUCT     VARCHAR2 (30);
      V_SKU         VARCHAR2 (30);
      V_MODULE      VARCHAR2 (10);
      V_LINE        VARCHAR2 (10);
      V_START       VARCHAR2 (30);
      V_END         VARCHAR2 (30);
      V_WO        VARCHAR2 (20);
      V_DATATYPE  VARCHAR2(1);
/****************** SP _MONITOR *************/
    V_SP_START    DATE;
    V_SP_END      DATE;
    V_SP_RPT      VARCHAR2 (50);
    V_CODE_NAME   VARCHAR2 (50);
    V_CREATE_BY   VARCHAR2 (10);
    V_CREATE_DT   VARCHAR2 (10);
/*******************END ********************/
    BEGIN
/****************** SP _MONITOR *************/
    V_SP_START := SYSDATE;
    V_SP_RPT := 'RRT INSPECTION REPORT';
    V_CODE_NAME := 'Q22/RRTINSPECTIONREPORTDMP.ASPX';
    V_CREATE_BY := 'CHILY';
    V_CREATE_DT := '20051212';

/*********************END *********************/
      IF V_START_DATE = '' OR V_START_DATE IS NULL THEN
         V_START := TO_CHAR (SYSDATE, 'YYYYMMDD HH24:MI:SS');
      ELSE
         V_START :=TO_CHAR (TO_DATE (V_START_DATE, 'YYYY/MM/DD HH24:MI:SS'), 'YYYYMMDD HH24:MI:SS');
      END IF;

      IF V_END_DATE = '' OR V_END_DATE IS NULL THEN
         V_END := TO_CHAR (SYSDATE, 'YYYYMMDD HH24:MI:SS');
      ELSE
         V_END := TO_CHAR (TO_DATE (V_END_DATE, 'YYYY/MM/DD HH24:MI:SS'), 'YYYYMMDD HH24:MI:SS');
      END IF;

      IF V_QUERY_TYPE = 'ALL' OR V_QUERY_TYPE = '' OR V_QUERY_TYPE IS NULL THEN
         V_QUERYTYPE := '';
      ELSE
         V_QUERYTYPE := V_QUERY_TYPE;
      END IF;

      IF V_PRODUCT_NAME = 'ALL' OR V_PRODUCT_NAME = '' THEN
         V_PRODUCT := '';
      ELSE
         V_PRODUCT := V_PRODUCT_NAME;
      END IF;

      IF V_PRODUCT_SKU = 'ALL' OR V_PRODUCT_SKU = '' THEN
         V_SKU := '';
      ELSE
         V_SKU := V_PRODUCT_SKU;
      END IF;

      IF V_MODULE_NAME = 'ALL' OR V_MODULE_NAME = '' THEN
         V_MODULE := '';
      ELSE
         V_MODULE := V_MODULE_NAME;
      END IF;

      IF V_LINE_NAME = 'ALL' OR V_LINE_NAME = '' THEN
         V_LINE := '';
      ELSE
         V_LINE := V_LINE_NAME;
      END IF;

      IF V_WO_NO = 'ALL' OR V_WO_NO = '' THEN
         V_WO := '' ;
      ELSE
         V_WO := V_WO_NO;
      END IF;

      IF V_DATA_TYPE='' OR V_DATA_TYPE IS NULL THEN
       V_DATATYPE:='R';
      ELSE
       V_DATATYPE:=V_DATA_TYPE;
      END IF;

      IF V_DATATYPE = 'R' THEN


        OPEN P_CURSOR FOR

          SELECT TO_CHAR(A.REPORT_DATE,'YYYYMMDD') AS REPORT_DATE,
        A.STATION_NAME,A.STATION_CODE,A.WO_FLAG,
        SUM(A.PASSQTY)AS PASSQTY,SUM(A.FAILQTY)AS FAILQTY,SUM(A.INSPECTQTY)AS INSPECTQTY
        FROM
        (
            SELECT /*+ ORDERED USE_HASH(D A)*/TO_DATE((CASE WHEN (A.REPORT_DATE <> WORK_DATE AND TIME_SLOT = '23:30') THEN TO_CHAR(WORK_DATE,'YYYY/MM/DD')||' '||'00:00'
            ELSE TO_CHAR(WORK_DATE,'YYYY/MM/DD')||' '||TIME_SLOT END),'YYYY/MM/DD HH24:MI:SS') AS WORK_TIME,
            A.REPORT_DATE,
            E.NAMEE AS STATION_NAME,
            (CASE WHEN E.CODE='GC' THEN 'CA' ELSE E.CODE END) AS STATION_CODE,
            D.IS_MSR AS WO_FLAG,
            (NVL (A.FIRST_PASS_QTY, 0) ) AS PASSQTY,
            (NVL (A.FIRST_FAIL_QTY, 0))AS FAILQTY,
            (NVL (A.FIRST_PASS_QTY, 0)
              +NVL (A.FIRST_FAIL_QTY, 0)
              +NVL (MSR_FIRST_PASS_QTY, 0)
              +NVL (MSR_FIRST_FAIL_QTY, 0)
             ) AS INSPECTQTY
            FROM            
            DMPDB2.R_WO D,
            DMPDB2.A_TEST_RESULT A,
            DMPDB2.LINE C,
            DMPDB2.STATION E
            WHERE
            /*
            a.line_id||'' = c.ID||''
           AND a.wo_id||'' = d.ID||''
           AND a.station_id||'' = e.ID||''
           AND d.del_flag = 0
           AND d.cust_part_no LIKE  '%'
           AND d.cust_part_no LIKE  '%'
           AND d.NO||'' LIKE  '%'
           AND c.group_flag LIKE '%'
           AND c.parent_line_code LIKE '%'-- || :b4
           AND e.code || '' IN ('CM', 'OQ', 'PK', 'CA', 'GC')
           AND a.category_key = 'N36'
           AND a.work_date >= TO_DATE(TO_CHAR(TO_DATE(:b2, 'YYYY/MM/DD HH24:MI:SS'), 'YYYYMMDD'), 'YYYY/MM/DD')
           AND a.work_date <= TO_DATE(TO_CHAR(TO_DATE(:b1, 'YYYY/MM/DD HH24:MI:SS'), 'YYYYMMDD'), 'YYYY/MM/DD')
            */
            A.LINE_ID= C.ID
            AND A.WO_ID= D.ID
            AND A.STATION_ID= E.ID
            AND D.DEL_FLAG = 0
            AND D.PLANT_CODE LIKE V_PLANT_CODE||'%'
            AND D.CUST_PART_NO LIKE V_QUERYTYPE||'%'
            AND D.CUST_PART_NO LIKE V_SKU||'%'
            AND D.NO||'' LIKE V_WO||'%'
            AND C.GROUP_FLAG LIKE '%'||V_MODULE
            AND C.PARENT_LINE_CODE LIKE '%'||V_LINE
            AND E.CODE||'' IN ('CM','OQ','PK','CA','GC')
            AND A.CATEGORY_KEY = V_PRODUCT
            AND A.WORK_DATE >= TO_DATE(TO_CHAR(TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD'),'YYYY/MM/DD')
            AND A.WORK_DATE <= TO_DATE(TO_CHAR(TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD'),'YYYY/MM/DD')
        ) A
        WHERE A.WORK_TIME >= TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
        AND A.WORK_TIME < TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
        GROUP BY TO_CHAR(A.REPORT_DATE,'YYYYMMDD'),A.STATION_NAME,A.STATION_CODE,A.WO_FLAG ;


    END IF;

       RES :='OK'||V_START||V_END;
/********************SP _Monitor *************/
    V_SP_END :=SYSDATE;

    /*INSERT INTO R_SP_MONITOR_T(SP_NAME,RPT_NAME,RPT_BU,SP_START_TIME,SP_END_TIME,SP_STATUS,SP_DESC,CODE_NAME,CREATE_BY,CREATE_DATE)
    VALUES('DMP_RRT_INSPECTION_DAILY_SP',V_SP_RPT,'DMP',V_SP_start,V_SP_END,'SUCCESS','RRT INSPECTION REPORT', V_CODE_NAME,V_CREATE_BY,V_CREATE_DT);
    COMMIT; */
/********************END*************/
    EXCEPTION
    WHEN OTHERS THEN
    RES := ' EXCEPTION ERROR.';
/********************SP _Monitor *************/
    V_SP_END :=SYSDATE;

    /*INSERT INTO R_SP_MONITOR_T(SP_NAME,RPT_NAME,RPT_BU,SP_START_TIME,SP_END_TIME,SP_STATUS,SP_DESC,CODE_NAME,CREATE_BY,CREATE_DATE)
    VALUES('DMP_RRT_INSPECTION_DAILY_SP',V_SP_RPT,'DMP',V_SP_start,V_SP_END,'FAIL','RRT INSPECTION REPORT', V_CODE_NAME,V_CREATE_BY,V_CREATE_DT);

    COMMIT;*/
/********************END*************/
   END DMP_RRT_INSPECTION_DAILY_SP;

   PROCEDURE DMP_RRT_INSPECTION_FC_QTYPE_SP (
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_QUERY_TYPE       IN        VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      V_PLANT_CODE       IN        VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      Pl_Dmp_Rrt_Inspection_Daily_Pk.CURSORTYPE
   )
 AS
          V_QUERYTYPE    VARCHAR2 (10);
       V_PRODUCT        VARCHAR2(30);
       V_SKU              VARCHAR2(30);
       V_MODULE        VARCHAR2(10);
       V_LINE          VARCHAR2(10);
       V_START            VARCHAR2(30);
       V_END              VARCHAR2(30);
       V_WO                  VARCHAR2(20);
       V_DATATYPE  VARCHAR2(1);
/****************** SP _MONITOR *************/
  V_SP_START         DATE;
  V_SP_END           DATE;
  V_SP_RPT             VARCHAR2(50);
  V_CODE_NAME         VARCHAR2(50);
  V_CREATE_BY         VARCHAR2(10);
  V_CREATE_DT         VARCHAR2(10);

/*******************END ********************/

  BEGIN
/****************** SP _MONITOR *************/
  V_SP_START:=SYSDATE;
  V_SP_RPT:='RRT INSPECTION REPORT';
  V_CODE_NAME:='Q22/RRTINSPECTIONREPORTDMP.ASPX';
  V_CREATE_BY:='CHILY';
  V_CREATE_DT:='20051212';

/*********************END *********************/
/*
            IF V_START_DATE = '' OR V_START_DATE IS NULL THEN
                 V_START:=TO_CHAR(SYSDATE-6,'YYYYMMDD');
            ELSE
                 V_START:=TO_CHAR(TO_DATE(V_START_DATE,'YYYY/MM/DD'),'YYYYMMDD');
            END IF;

            IF V_END_DATE = '' OR V_END_DATE IS NULL THEN
                 V_END:=TO_CHAR(SYSDATE+1,'YYYYMMDD');
            ELSE
                 V_END:=TO_CHAR(TO_DATE(V_END_DATE,'YYYY/MM/DD')+1,'YYYYMMDD');
            END IF;
            */

     IF V_QUERY_TYPE = 'ALL' OR V_QUERY_TYPE = '' OR V_QUERY_TYPE IS NULL THEN
        V_QUERYTYPE := '';
     ELSE
        V_QUERYTYPE := V_QUERY_TYPE;
     END IF;

    IF V_START_DATE = '' OR V_START_DATE IS NULL THEN
         V_START:=TO_CHAR(SYSDATE-6,'YYYYMMDD')||' 07:30:00';
    ELSIF LENGTH(V_START_DATE) <= 11 THEN
         V_START:=TO_CHAR(TO_DATE(V_START_DATE,'YYYY/MM/DD'),'YYYYMMDD')||' 07:30:00';
    ELSE
         V_START:=TO_CHAR(TO_DATE(V_START_DATE,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD HH24:MI:SS');
    END IF;

          IF V_END_DATE = '' OR V_END_DATE IS NULL THEN
         V_END:=TO_CHAR(SYSDATE+1,'YYYYMMDD')||' 07:30:00';
    ELSIF LENGTH(V_END_DATE) <= 11 THEN
         V_END:=TO_CHAR(TO_DATE(V_END_DATE,'YYYY/MM/DD')+1,'YYYYMMDD')||' 07:30:00';
    ELSE
         V_END:=TO_CHAR(TO_DATE(V_END_DATE,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD HH24:MI:SS');
    END IF;


    IF V_PRODUCT_SKU ='ALL' OR V_PRODUCT_SKU ='' THEN
                V_SKU:='';
    ELSE
          V_SKU:=V_PRODUCT_SKU ;
       END IF;

    IF V_PRODUCT_NAME='ALL' OR V_PRODUCT_NAME='' THEN
         V_PRODUCT:='';
    ELSE
         V_PRODUCT:=V_PRODUCT_NAME;
    END IF;

    IF V_MODULE_NAME ='ALL' OR V_MODULE_NAME ='' THEN
                V_MODULE:='';
    ELSE
          V_MODULE:= V_MODULE_NAME ;
       END IF;

    IF V_LINE_NAME='ALL' OR V_LINE_NAME='' THEN
         V_LINE:='';
    ELSE
         V_LINE:=V_LINE_NAME;
    END IF;

    IF V_WO_NO='ALL' OR V_WO_NO='' THEN
               V_WO:='';
    ELSE
         V_WO:=V_WO_NO;
       END IF;

    IF V_DATA_TYPE='' OR V_DATA_TYPE IS NULL THEN
       V_DATATYPE:='R';
    ELSE
       V_DATATYPE:=V_DATA_TYPE;
    END IF;

    IF V_DATATYPE = 'R' THEN

        OPEN P_CURSOR FOR

          SELECT /*+ ORDERED*/ TEST_DATE,STATUS,wo_flag,COUNT(NO) AS FAILQTY
            FROM
            (
                SELECT DECODE(GREATEST(TO_CHAR(B.TEST_TIME,'HH24:MI:SS'),'07:30:00'),'07:30:00',
                       TO_CHAR(B.TEST_TIME-1,'YYYYMMDD'),TO_CHAR(B.TEST_TIME,'YYYYMMDD') )AS TEST_DATE,
                       A.NO,D.is_msr AS wo_flag,
                       (CASE WHEN E.CODE LIKE 'F%' THEN 'F' ELSE 'C' END) AS STATUS
                FROM DMPDB2.R_REPAIR B,
                     DMPDB2.R_WIP A,
                     DMPDB2.R_WO D,
                     DMPDB2.SYMPTOM E,
                     DMPDB2.LINE F,
                     DMPDB2.STATION G
                WHERE A.ID = B.WIP_ID
                AND B.TEST_LINE_ID = F.ID
                AND B.TEST_STATION_ID=G.ID
                AND B.SYMPTOM_ID1 = E.ID
                AND A.WO_ID = D.ID
                --AND A.DEL_FLAG = 0
                AND D.DEL_FLAG = 0
                AND D.PLANT_CODE LIKE V_PLANT_CODE||'%'
                AND D.CUST_PART_NO LIKE V_QUERYTYPE||'%'
                AND F.GROUP_FLAG LIKE '%'||V_MODULE
                AND F.PARENT_LINE_CODE LIKE '%'||V_LINE --L1
                AND D.CATEGORY_KEY = V_PRODUCT
                AND D.CUST_PART_NO LIKE V_SKU||'%'
                AND D.NO LIKE V_WO||'%'
                AND G.CODE = 'OQ' --ID:14 --'OQC'
                AND B.TEST_TIME >= TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS')
                AND B.TEST_TIME <= TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS')
            )
            GROUP BY TEST_DATE,STATUS,wo_flag    ;
        END IF;



     RES :='OK'||V_START||V_END;
/********************SP _MONITOR *************/
        V_SP_END :=SYSDATE;

       /* INSERT INTO R_SP_MONITOR_T(SP_NAME,RPT_NAME,RPT_BU,SP_START_TIME,SP_END_TIME,SP_STATUS,SP_DESC,CODE_NAME,CREATE_BY,CREATE_DATE)
        VALUES('DPM_RRT_INSPECTION_FC_SP',V_SP_RPT,'DMP',V_SP_START,V_SP_END,'SUCCESS','RRT INSPECTION REPORT', V_CODE_NAME,V_CREATE_BY,V_CREATE_DT);

        COMMIT;*/
/********************END*************/
        EXCEPTION
          WHEN OTHERS THEN
             RES := ' EXCEPTION ERROR.';
/********************SP _MONITOR *************/

        V_SP_END :=SYSDATE;

     /*   INSERT INTO R_SP_MONITOR_T(SP_NAME,RPT_NAME,RPT_BU,SP_START_TIME,SP_END_TIME,SP_STATUS,SP_DESC,CODE_NAME,CREATE_BY,CREATE_DATE)
        VALUES('DMP_RRT_INSPECTION_FC_SP',V_SP_RPT,'DMP',V_SP_START,V_SP_END,'FAIL','RRT INSPECTION REPORT', V_CODE_NAME,V_CREATE_BY,V_CREATE_DT);

        COMMIT;*/
/********************END*************/
   END DMP_RRT_INSPECTION_FC_QTYPE_SP;

   PROCEDURE DMP_RRT_DEFECT_DETAIL_QTYPE_SP (
      V_MODULE_NAME    IN       VARCHAR2,
      V_LINE_NAME      IN       VARCHAR2,
      V_PRODUCT_NAME   IN       VARCHAR2,
      V_PRODUCT_SKU    IN       VARCHAR2,
      V_WO_NO          IN       VARCHAR2,
      V_START_DATE     IN       VARCHAR2,
      V_END_DATE       IN       VARCHAR2,
      V_STATION_CODE   IN       VARCHAR2,
      V_SYMPTOM_TYPE   IN       VARCHAR2,
      V_WO_FLAG        IN       VARCHAR2,
      V_QUERY_TYPE       IN        VARCHAR2,
      V_DATA_TYPE      IN       VARCHAR2,
      V_PLANT_CODE       IN        VARCHAR2,
      RES              OUT      VARCHAR2,
      P_CURSOR         OUT      Pl_Dmp_Rrt_Inspection_Daily_Pk.CURSORTYPE
   )

AS

         V_QUERYTYPE       VARCHAR(10);
           V_PRODUCT        VARCHAR2(30);
           V_SKU              VARCHAR2(50);
           V_MODULE        VARCHAR2(10);
           V_LINE          VARCHAR2(10);
           V_START            VARCHAR2(30);
           V_END              VARCHAR2(30);
           V_WO                  VARCHAR2(20);
           V_DATATYPE  VARCHAR2(1);

    /****************** SP _MONITOR *************/
      V_SP_START         DATE;
      V_SP_END           DATE;
      V_SP_RPT             VARCHAR2(50);
      V_CODE_NAME         VARCHAR2(50);
      V_CREATE_BY         VARCHAR2(10);
      V_CREATE_DT         VARCHAR2(10);

    /*******************END ********************/

      BEGIN
    /****************** SP _MONITOR *************/
      V_SP_START:=SYSDATE;
      V_SP_RPT:='RRT INSPECTION REPORT_1';
      V_CODE_NAME:='Q22/INSPECTIONDETAILDMP.ASPX';
      V_CREATE_BY:='JOYBEE';
      V_CREATE_DT:='20060622';

    /*********************END *********************/

     IF V_QUERY_TYPE = 'ALL' OR V_QUERY_TYPE = '' OR V_QUERY_TYPE IS NULL THEN
        V_QUERYTYPE := '';
     ELSE
        V_QUERYTYPE := V_QUERY_TYPE;
     END IF;

    IF V_START_DATE = '' OR V_START_DATE IS NULL THEN
         V_START:=TO_CHAR(SYSDATE-6,'YYYYMMDD')||' 07:30:00';
    ELSIF LENGTH(V_START_DATE) <= 11 THEN
         V_START:=TO_CHAR(TO_DATE(V_START_DATE,'YYYY/MM/DD'),'YYYYMMDD')||' 07:30:00';
    ELSE
         V_START:=TO_CHAR(TO_DATE(V_START_DATE,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD HH24:MI:SS');
    END IF;

          IF V_END_DATE = '' OR V_END_DATE IS NULL THEN
         V_END:=TO_CHAR(SYSDATE+1,'YYYYMMDD')||' 07:30:00';
    ELSIF LENGTH(V_END_DATE) <= 11 THEN
         V_END:=TO_CHAR(TO_DATE(V_END_DATE,'YYYY/MM/DD')+1,'YYYYMMDD')||' 07:30:00';
    ELSE
         V_END:=TO_CHAR(TO_DATE(V_END_DATE,'YYYY/MM/DD HH24:MI:SS'),'YYYYMMDD HH24:MI:SS');
    END IF;
/*
    IF V_START_DATE = '' OR V_START_DATE IS NULL THEN
         V_START:=TO_CHAR(SYSDATE-2,'YYYYMMDD ');
    ELSE
         V_START:=TO_CHAR(TO_DATE(V_START_DATE,'YYYY/MM/DD'),'YYYYMMDD');
    END IF;

          IF V_END_DATE = '' OR V_END_DATE IS NULL THEN
         V_END:=TO_CHAR(SYSDATE+1,'YYYYMMDD ');
    ELSE
         V_END:=TO_CHAR(TO_DATE(V_END_DATE,'YYYY/MM/DD')+1,'YYYYMMDD');
    END IF;
*/
    IF V_PRODUCT_SKU ='ALL' OR V_PRODUCT_SKU ='' THEN
                V_SKU:='';
    ELSE
          V_SKU:=V_PRODUCT_SKU ;
       END IF;

    IF V_PRODUCT_NAME='ALL' OR V_PRODUCT_NAME='' THEN
         V_PRODUCT:='';
    ELSE
         V_PRODUCT:=V_PRODUCT_NAME;
    END IF;

    IF V_MODULE_NAME ='ALL' OR V_MODULE_NAME ='' THEN
                V_MODULE:='';
    ELSE
          V_MODULE:= V_MODULE_NAME ;
       END IF;

    IF V_LINE_NAME='ALL' OR V_LINE_NAME='' THEN
         V_LINE:='';
    ELSE
         V_LINE:=V_LINE_NAME;
    END IF;

    IF V_WO_NO='ALL' OR V_WO_NO='' THEN
               V_WO:='';
    ELSE
         V_WO:=V_WO_NO;
       END IF;

    IF V_DATA_TYPE='' OR V_DATA_TYPE IS NULL THEN
       V_DATATYPE:='R';
    ELSE
       V_DATATYPE:=V_DATA_TYPE;
    END IF;

    IF V_DATATYPE = 'R' THEN

    OPEN P_CURSOR FOR

            SELECT /*+ ordered*/ B.NO AS WIPNO,B.WO_NO,L.PLANT_CODE,I.CATEGORY_KEY,B.CUST_PART_NO,C.NAMEE AS TEST_LINE,J.NAMEE AS TEST_STATION,
            TO_CHAR(A.TEST_TIME,'YYYY/MM/DD HH24:MI:SS') AS TEST_TIME,E.NAMEC AS FAIL_SYMPTOM,E.NAMEC AS ACTUAL_SYMPTOM,
            TO_CHAR(A.REPAIR_TIME,'YYYY/MM/DD HH24:MI:SS') AS REPAIR_TIME,G.NAMEC AS REPAIR_ACTION,H.OLD_SERIAL_NO,H.NEW_SERIAL_NO,
            TO_CHAR(A.CHECK_IN_TIME,'YYYY/MM/DD HH24:MI:SS') AS CHECK_IN_TIME,TO_CHAR(A.CHECK_OUT_TIME,'YYYY/MM/DD HH24:MI:SS') AS CHECK_OUT_TIME,
            FLOOR(24*60*(NVL(A.CHECK_OUT_TIME, SYSDATE)-A.CHECK_IN_TIME)) AS DIFFTIME,K.EMPLOYEE_ID
            FROM dmpdb2.r_repair_detail h,
                 dmpdb2.symptom f,
                 dmpdb2.r_repair a,
                 dmpdb2.r_wip b,
                 dmpdb2.r_wo l,
                 dmpdb2.station j,
                 dmp2web.sfc_product i,
                 dmpdb2.symptom e,
                 dmpdb2.repair_action g,
                 dmpdb2.app_user k,
                 dmpdb2.line c
            WHERE A.WIP_ID=B.ID
             AND A.TEST_LINE_ID = C.ID
             AND A.SYMPTOM_ID1=E.ID
             AND A.SYMPTOM_ID2=F.ID(+)
             AND A.ID=H.REPAIR_ID(+)
             AND A.TEST_STATION_ID=J.ID
             AND A.REPAIR_BY=K.ID(+)
             AND B.PRODUCT_ID = I.ID
             AND B.WO_ID=L.ID
            -- AND L.PRODUCT_ID = M.ID
             AND H.REPAIR_ACTION_ID=G.ID(+)
             AND I.DEL_FLAG = 0
             AND A.DEL_FLAG=0
             --AND B.DEL_FLAG=0
             AND L.DEL_FLAG=0
             AND L.PLANT_CODE LIKE V_PLANT_CODE||'%'
             AND L.CUST_PART_NO LIKE V_QUERYTYPE||'%'
             AND L.IS_MSR=TO_NUMBER(V_WO_FLAG)
             AND E.CODE LIKE V_SYMPTOM_TYPE||'%' --'C'
             AND J.CODE LIKE '%'||V_STATION_CODE --'OQ'
             AND B.WO_NO LIKE '%'||V_WO
             AND C.PARENT_LINE_CODE LIKE '%'||V_LINE
             AND C.GROUP_FLAG LIKE '%'||V_MODULE
             AND B.CUST_PART_NO LIKE V_SKU||'%'
             AND I.CATEGORY_KEY = V_PRODUCT
             AND A.TEST_TIME>=TO_DATE(V_START,'YYYY/MM/DD HH24:MI:SS') --TO_DATE('20060613'||' 07:30:00','YYYY/MM/DD HH24:MI:SS')
             AND A.TEST_TIME<TO_DATE(V_END,'YYYY/MM/DD HH24:MI:SS') --TO_DATE('20060622'||' 07:30:00','YYYY/MM/DD HH24:MI:SS')
             ;

    END IF;

    RES :='OK';

          EXCEPTION
             WHEN OTHERS THEN
               RES := ' Exception Error.';

  END DMP_RRT_DEFECT_DETAIL_QTYPE_SP;
END Pl_Dmp_Rrt_Inspection_Daily_Pk;
/

