create PACKAGE        SFC_KOMODO_DATA_PK AS
/******************************************************************************
   NAME:       DMPDB2.SFC_KOMODO_DATA_PK
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2016/7/7      F3228786       1. Created this package.
******************************************************************************/
  TYPE CURSORTYPE IS REF CURSOR;
  
  PROCEDURE GetErrorList_SP(
    V_condition       IN VARCHAR2,
    V_DateFrom      IN VARCHAR2,
    V_DateTo          IN VARCHAR2,
    V_PageSize        IN     NUMBER,
    V_PageIndex       IN     NUMBER,
    V_Total        OUT   NUMBER,
    P_CURSOR   OUT   SFC_KOMODO_DATA_PK.CURSORTYPE
  );
  
  PROCEDURE SearchErrorList_SP(
    V_condition       IN VARCHAR2,
    V_DateFrom      IN VARCHAR2,
    V_DateTo          IN VARCHAR2,
    V_PageSize        IN     NUMBER,
    V_PageIndex       IN     NUMBER,
    V_Total        OUT   NUMBER,
    P_CURSOR   OUT   SFC_KOMODO_DATA_PK.CURSORTYPE
  );
  
  PROCEDURE Get_Data_GL_SP(
    P_CURSOR   OUT   SFC_KOMODO_DATA_PK.CURSORTYPE
  );

  PROCEDURE Get_Data_ZZ_SP(
    P_CURSOR   OUT   SFC_KOMODO_DATA_PK.CURSORTYPE
  );
  
  PROCEDURE Get_SummaryData_SP(
    V_DateFrom          IN VARCHAR2,
    V_DateTo          IN VARCHAR2,
    P_CURSOR   OUT   SFC_KOMODO_DATA_PK.CURSORTYPE
  );
END SFC_KOMODO_DATA_PK;

/

