create PACKAGE        Web_Login_Check_Pk

AS
   TYPE CURSORTYPE IS REF CURSOR;

   PROCEDURE WEB_CHECK_LOGIN_USER_SP (
      V_USER_NAME  IN    VARCHAR2,
      V_PASS_WORD       IN    VARCHAR2,
      RES            OUT   VARCHAR2,
      P_CURSOR       OUT   Web_Login_Check_Pk.CURSORTYPE
   );

PROCEDURE insert_login_info(
                          V_USER_NAME IN VARCHAR2,
                        V_IP IN VARCHAR2,
                        V_LOGIN_SUCCESS IN VARCHAR2,
                        V_LOGIN_DESC IN VARCHAR2,
                         RES OUT VARCHAR2);
   
END Web_Login_Check_Pk;
/

