create PACKAGE BODY        Web_Login_Check_Pk
AS


PROCEDURE WEB_CHECK_LOGIN_USER_SP(
                          V_USER_NAME IN VARCHAR2,
                          V_PASS_WORD IN VARCHAR2,
                         RES OUT VARCHAR2,
                         P_CURSOR OUT Web_Login_Check_Pk.CURSORTYPE)

AS
  BEGIN
       
      OPEN P_CURSOR FOR
                  SELECT ID,EMP_NO,EMP_NAME
                  FROM DMPDB2.WEB_SYS_USER_T
                WHERE EMP_NO =V_USER_NAME
--                AND USER_PASSWORD =V_PASS_WORD
                AND DEL_FLAG=0;
            
                   RES :='OK!';
                EXCEPTION
                 WHEN OTHERS THEN
                 RES := ' Exception Error.';

   END WEB_CHECK_LOGIN_USER_SP;
   
   
   



PROCEDURE insert_login_info(
                          V_USER_NAME IN VARCHAR2,
                        V_IP IN VARCHAR2,
                        V_LOGIN_SUCCESS IN VARCHAR2,
                        V_LOGIN_DESC IN VARCHAR2,
                         RES OUT VARCHAR2)
AS
v_id   NUMBER;
BEGIN
SELECT MAX(ID)+1 INTO v_id FROM dmpdb2.web_USER_LOGIN_INFO;

INSERT INTO dmpdb2.web_USER_LOGIN_INFO(id,emp_no,user_ip,login_time,login_success,login_desc)
VALUES(V_ID,V_USER_NAME,V_IP,SYSDATE,V_LOGIN_SUCCESS,V_LOGIN_DESC);
COMMIT;

res:='OK!';

EXCEPTION 
          WHEN OTHERS THEN
          res:='Exception Error.';
END insert_login_info;

END Web_Login_Check_Pk;
/

