create PACKAGE        wip_info_package
IS
   TYPE r_record IS RECORD (
      wip_id             r_wip.ID%TYPE,
      wip_no             r_wip.NO%TYPE,
      defect_flag        r_wip.defect_flag%TYPE,
      route_id           r_wip.route_id%TYPE,
      line_id            r_wip.line_id%TYPE, 
      route_history      r_wip.route_history%TYPE,
      finish_flag        r_wip.finish_flag%TYPE,
      lock_flag          r_wip.lock_flag%TYPE,
      pre_station_code   r_wip.pre_station_code%TYPE,
      wo_id              r_wo.ID%TYPE,
      is_msr             r_wo.is_msr%TYPE,
      is_allow_input     r_wo.is_allow_input%TYPE,
      close_flag         r_wo.close_flag%TYPE,
      category_key       product.category_key%TYPE,
      process_lock_id    r_wip.process_lock_id%TYPE
   );

   rec_wip_info   r_record;

   FUNCTION is_active_wip (
      p_cur_station_code   VARCHAR2,
      p_wip_no             VARCHAR2,
      p_commodity_id       PLS_INTEGER
   )
      RETURN VARCHAR2;

   FUNCTION is_route_correct (
      p_cur_station_code   VARCHAR2,
      p_defect_flag        PLS_INTEGER
   )
      RETURN VARCHAR2;

   FUNCTION get_should_to_station (
      p_cur_station_code   VARCHAR2,
      p_defect_flag        PLS_INTEGER
   )
      RETURN VARCHAR2;
END wip_info_package;

/

