create PACKAGE BODY        wip_info_package
IS
   FUNCTION get_station_type (cstation VARCHAR2)             --判斷工站的類型
      RETURN VARCHAR2
   IS
      ctype   VARCHAR2 (20);
   BEGIN
      SELECT TYPE
        INTO ctype
        FROM station
       WHERE del_flag = 0 AND code = cstation;

      RETURN ctype;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION is_out_repair (cstation VARCHAR2)           --判斷是否為維修出來站
      RETURN BOOLEAN
   IS
      to_station_num   PLS_INTEGER;
   BEGIN
      SELECT COUNT (a.to_station_code)
        INTO to_station_num
        FROM route_chart a, station b
       WHERE b.del_flag = 0
         AND a.from_station_code = cstation
         AND a.defect_flag = rec_wip_info.defect_flag
         AND SUBSTR (b.TYPE, 1, 1) = 'R'
         AND a.to_station_code = b.code
         AND a.route_id = rec_wip_info.route_id;

      RETURN to_station_num = 0;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN FALSE;
   END;
   

   FUNCTION get_station_namec (cstation VARCHAR2)           --取中工站的中文名
      RETURN VARCHAR2
   IS
      station_namec   VARCHAR2 (20);
   BEGIN
      SELECT namec
        INTO station_namec
        FROM station
       WHERE del_flag = 0 AND code = cstation;

      RETURN station_namec;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION is_repair_station (cstation VARCHAR2)         --判斷是否為測試工站
      RETURN BOOLEAN
   AS
   BEGIN
      RETURN SUBSTR (get_station_type (cstation), 1, 1) = 'R';
   END;

   FUNCTION is_in_route (p_cur_station_code VARCHAR2)
      RETURN BOOLEAN
   IS
      station_code   VARCHAR2 (20);
   BEGIN
      SELECT from_station_code
        INTO station_code
        FROM route_chart
       WHERE route_id = rec_wip_info.route_id
         AND from_station_code = p_cur_station_code
         AND ROWNUM = 1;

      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN FALSE;
   END;

   FUNCTION is_test_station (cstation VARCHAR2)           --判斷是否為測試工站
      RETURN BOOLEAN
   AS
   BEGIN
      RETURN SUBSTR (get_station_type (cstation), 1, 1) = 'T';
   END;
   
   FUNCTION is_first_test_station (
      irouteid             NUMBER,
      cwipprestationcode   VARCHAR2,
      ccurstationcode      VARCHAR2
   )
      RETURN BOOLEAN
   IS
      lgoon              BOOLEAN;
      lgoon2             BOOLEAN;
      lresult            BOOLEAN;
      ioptional          NUMBER;
      irecordcount       NUMBER;
      ctempstationcode   VARCHAR2 (30);
      ctostationcode     VARCHAR2 (30);
      cmessage           VARCHAR2 (200);

      CURSOR to_station_cursor_list
      IS
         SELECT   to_station_code, is_optional
             FROM route_chart
            WHERE from_station_code = ctempstationcode
                  AND route_id = irouteid
         ORDER BY is_optional;
   BEGIN
      lresult := FALSE;
      ioptional := NULL;
      lgoon := TRUE;
      lgoon2 := TRUE;
      ctempstationcode := cwipprestationcode;

      LOOP
         SELECT COUNT (*)
           INTO irecordcount
           FROM route_chart
          WHERE from_station_code = ctempstationcode
            AND route_id = irouteid
            AND is_optional = 0;

         IF irecordcount <= 0
         THEN
            lgoon2 := FALSE;
            lgoon := FALSE;
            lresult := FALSE;
            cmessage := '路徑有問題, 找不到主路徑了';
            EXIT;
         END IF;

         IF ctempstationcode = '  '
         THEN
           lgoon2 := FALSE;
           lgoon := FALSE;
           lresult := TRUE;
           EXIT;
         END IF;

         OPEN to_station_cursor_list;

         LOOP
            FETCH to_station_cursor_list
             INTO ctostationcode, ioptional;

            IF to_station_cursor_list%NOTFOUND
            THEN
               ioptional := NULL;
               lgoon2 := FALSE;
               --lGoon := false;
               lresult := FALSE;
               cmessage := '找不到任何符合條件的路徑了';

               IF is_test_station (ctempstationcode)
               THEN
                  lgoon := FALSE;
                  cmessage := '主路徑是測試站, 但不是當前站';
               END IF;
            ELSE
               lgoon2 := TRUE;

               IF ioptional = 0
               THEN
                  ctempstationcode := ctostationcode;
               END IF;

               IF is_test_station(ctostationcode) and  (ctostationcode = 'Q1') and (ccurstationcode <> 'Q1')
               THEN
                  lgoon2 := FALSE;
                  lgoon := FALSE;
                  --lresult := TRUE;
                  lresult := FALSE;
                  cmessage := 'Pre Burn 站不可以跳過';
                  EXIT;
               END IF;
               IF is_test_station(ctostationcode) THEN                                  
                  lgoon2 := FALSE;
                  lgoon := FALSE;
                  lresult := TRUE;
                  cmessage := '只要不跳過Pre Burn站就可以';                      
               END IF;              
                 
            END IF;

            EXIT WHEN NOT lgoon2;
         END LOOP;

         CLOSE to_station_cursor_list;

         EXIT WHEN NOT lgoon;
      END LOOP;

      RETURN lresult;
   END; 
   

   FUNCTION get_to_station_single (
      from_station    VARCHAR2,
      p_defect_flag   PLS_INTEGER
   )                                                           --唯一路徑的SQL
      RETURN VARCHAR2
   IS
      to_station   VARCHAR2 (20);
   BEGIN
      SELECT to_station_code
        INTO to_station
        FROM route_chart
       WHERE defect_flag = p_defect_flag
         AND from_station_code = from_station
         AND TRIM (ref_station_code) IS NULL
         AND is_optional = 0
         AND route_id = rec_wip_info.route_id;

      RETURN to_station;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION get_to_station_mul (
      from_station    VARCHAR2,
      cstation        VARCHAR2,
      p_defect_flag   PLS_INTEGER
   )
      --多條路徑的SQL
   RETURN VARCHAR2
   IS
      to_station   VARCHAR2 (20);
   BEGIN
      SELECT to_station_code
        INTO to_station
        FROM route_chart
       WHERE defect_flag = p_defect_flag
         AND from_station_code = from_station
         AND ref_station_code = cstation
         AND route_id = rec_wip_info.route_id;

      RETURN to_station;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION get_next_station (from_station VARCHAR2)        --取出工站的順序ID
      RETURN VARCHAR2
   IS
      next_station   VARCHAR2 (10);
   BEGIN
      SELECT to_station_code
        INTO next_station
        FROM route_chart
       WHERE from_station_code = from_station
         AND defect_flag = 0
         AND is_optional = 0
         AND route_id = rec_wip_info.route_id;

      RETURN next_station;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION get_test_station_num (from_station VARCHAR2, to_station VARCHAR2)
      --取出中間隔多少個測試工站
   RETURN PLS_INTEGER
   IS
      test_station_num   PLS_INTEGER;
      next_station       VARCHAR2 (10);
      pre_station        VARCHAR2 (10);
   BEGIN
      test_station_num := 0;
      next_station := get_next_station (from_station);

      WHILE next_station <> to_station
      LOOP
         IF is_test_station (next_station)
         THEN
            test_station_num := test_station_num + 1;
         END IF;

         --避免死循環
         EXIT WHEN test_station_num >= 1;
         pre_station := next_station;
         next_station := get_next_station (pre_station);
      END LOOP;

      RETURN test_station_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN -1;
   END;
   
   FUNCTION getline_ID(p_wip_no VARCHAR2)
     RETURN PLS_INTEGER
   IS 
     line_name VARCHAR2(10);
     lineid   PLS_INTEGER ;
     
   BEGIN
     SELECT CODE 
       INTO line_name
       FROM line 
     WHERE id in
   (SELECT line_id 
      FROM r_wip
     WHERE no = p_wip_no
       AND  del_flag =0 );
   IF Length(line_name) > 3 then 
     line_name := line_name || 'A';
   ELSE
     line_name := line_name || '-A';
   END IF ;
   
   SELECT id 
     INTO lineid
     FROM line
    WHERE CODE = line_name
      AND del_flag = 0 ;
            
   RETURN lineid;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;


   FUNCTION is_active_wip (
      p_cur_station_code   VARCHAR2,
      p_wip_no             VARCHAR2,
      p_commodity_id       PLS_INTEGER
   )
      RETURN VARCHAR2
   IS
   BEGIN
      SELECT   a.ID AS wip_id,
               a.NO AS wip_no,
               a.defect_flag,
               a.route_id,
               a.line_id,
               a.route_history,
               a.finish_flag,
               a.lock_flag,
               a.pre_station_code,
               b.ID AS wo_id,
               b.is_msr,
               b.is_allow_input,
               b.close_flag,
               c.category_key,
               a.process_lock_id
          INTO rec_wip_info
          FROM r_wip a, r_wo b, product c
         WHERE a.commodity_id = p_commodity_id
           AND a.del_flag = 0
           AND b.product_id = c.ID
           AND a.wo_id = b.ID
           AND a.NO = p_wip_no
      ORDER BY a.finish_flag;
      rec_wip_info.line_id := getline_ID(p_wip_no);
      IF    (rec_wip_info.is_allow_input IS NULL)
         OR (rec_wip_info.is_allow_input = 0)
      THEN
         RETURN '工單還沒有投入';
      --RETURN 'Workorder not allow input';
      END IF;

      IF NVL (rec_wip_info.close_flag, ' ') <> ' '
      THEN
         RETURN '工單已經結案';
      --RETURN 'Workorder has been closed';
      END IF;

      IF NVL (rec_wip_info.finish_flag, ' ') <> ' '
      THEN
         RETURN '產品已經產出，不屬於在制品';
      --RETURN 'Have been outputed. can not be wip';
      END IF;

      IF rec_wip_info.lock_flag = '*1'
      THEN
         RETURN '產品被扣住，不能再往下生產';
      --RETURN 'WIP locked, Please contact the locker';
      END IF;

      IF rec_wip_info.lock_flag = p_cur_station_code
      THEN
         RETURN '產品被扣在本工站，不能再往下生產';
      --RETURN 'WIP Lock at a station, Please contact QA';
      END IF;

      IF nvl(rec_wip_info.process_lock_id, -1) > 0
      THEN
         RETURN '產品在上一工站尚未組裝完成﹐不能再往下生產';
      --RETURN 'WIP Lock at a station, Please contact QA';
      END IF;

      RETURN 'OK';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN '無效的序號';
      WHEN TOO_MANY_ROWS
      THEN
         RETURN '存在重復的數據';
      WHEN OTHERS
      THEN
         RETURN '檢查序號時發生其它錯誤';
   END is_active_wip;

   FUNCTION is_route_correct (
      p_cur_station_code   VARCHAR2,
      p_defect_flag        PLS_INTEGER
   )
      --p_station_code 當前工站Code
   RETURN VARCHAR2
   IS
      lgoon                    BOOLEAN;
      lcanloop                 BOOLEAN;
      lgoon2                   BOOLEAN;
      length_history_station   PLS_INTEGER;
      test_station_num         PLS_INTEGER;
      sequence_id1             PLS_INTEGER;
      sequence_id2             PLS_INTEGER;
      --is_affect_action         PLS_INTEGER;
      to_station               VARCHAR2 (50);
      last_station             VARCHAR2 (50);
      to_station_two           VARCHAR2 (50);
      last_pre_station         VARCHAR2 (50);
      history_station          r_wip.route_history%TYPE;

      CURSOR to_station_cursor
      IS
         SELECT to_station_code
           FROM route_chart
          WHERE defect_flag = rec_wip_info.defect_flag
            AND from_station_code = rec_wip_info.pre_station_code
            AND is_optional = 1
            AND route_id = rec_wip_info.route_id;
   BEGIN
      lgoon := TRUE;
      lgoon2 := TRUE;
      to_station := '';
      lcanloop := TRUE;

      IF rec_wip_info.pre_station_code IS NULL
      THEN
         SELECT to_station_code
           INTO to_station
           FROM route_chart
          WHERE from_station_code = ' '
            AND TRIM (ref_station_code) IS NULL
            AND is_optional = 0
            AND route_id = rec_wip_info.route_id;

         IF to_station = p_cur_station_code
         THEN
            RETURN 'OK';
         ELSE
            IF to_station IS NOT NULL
            THEN
               to_station := get_station_namec (to_station);
               to_station := '應該去: <' || to_station || '>';
            --'The Station Not Found ';
            END IF;

            RETURN '路徑錯誤! ' || to_station;
         END IF;
      END IF;

--從維修出來且有參考工站的全部這里做了處理.默認路徑在后續會作處理.
      IF     (is_repair_station (rec_wip_info.pre_station_code))
         AND (is_out_repair (rec_wip_info.pre_station_code))
      THEN
         history_station := rec_wip_info.route_history;
         length_history_station := LENGTH (history_station);

         WHILE (length_history_station > 0) AND lcanloop
         LOOP
            last_station :=
                      SUBSTR (history_station, length_history_station - 2, 2);

            IF is_test_station (last_station)
            THEN
               last_pre_station :=
                      SUBSTR (history_station, length_history_station - 5, 2);

               IF     (NOT is_test_station (last_pre_station))
                  AND (NOT is_repair_station (last_pre_station))
               THEN
                  to_station :=
                     get_to_station_mul (rec_wip_info.pre_station_code,
                                         last_pre_station,
                                         rec_wip_info.defect_flag
                                        );

                  IF to_station IS NOT NULL
                  --等價于not adoQry.Eof
                  THEN
                     lgoon := FALSE;

                     IF to_station = p_cur_station_code
                     THEN
                        RETURN 'OK';
                     ELSE
                        IF to_station IS NOT NULL
                        THEN
                           to_station := get_station_namec (to_station);
                           to_station := '應該去: <' || to_station || '>';
                        END IF;

                        RETURN '路徑錯誤! ' || to_station;
                     END IF;
                  END IF;

                  lcanloop := FALSE;
               END IF;
            END IF;

            history_station :=
                       SUBSTR (history_station, 1, length_history_station - 3);
            length_history_station := LENGTH (history_station);
         END LOOP;
      END IF;

      IF lgoon                                                      --多條路徑
      THEN
         to_station :=
            get_to_station_single (rec_wip_info.pre_station_code,
                                   rec_wip_info.defect_flag
                                  );

         --唯一路徑的情況
         IF to_station = p_cur_station_code
         THEN
            RETURN 'OK';
         ELSE
            OPEN to_station_cursor;

            LOOP
               FETCH to_station_cursor
                INTO to_station_two;

               EXIT WHEN to_station_cursor%NOTFOUND;
               EXIT WHEN NOT lgoon2;

               IF to_station_two = p_cur_station_code
               THEN
                  lgoon2 := FALSE;
               END IF;
            END LOOP;

            CLOSE to_station_cursor;

            IF NOT lgoon2
            THEN
               RETURN 'OK';
            ELSE
               IF     (p_defect_flag = 1)                          --掃描Fail
                  AND (p_cur_station_code <> rec_wip_info.pre_station_code
                      )                               --不能連續在同一工站掃描
                  AND NOT is_repair_station (rec_wip_info.pre_station_code)
                  --防止從維修出來跨工站掃Fail﹐從維修出來都是已由上面做處理。
                  AND rec_wip_info.defect_flag <> 1           --不能連續掃Fail
                  AND is_in_route (p_cur_station_code)            --在其路由上
                  AND is_first_test_station
                         (rec_wip_info.route_id,
                          rec_wip_info.pre_station_code,
                          p_cur_station_code
                         )                   --掃描不良時必須是第一個測試工站
               THEN
                  RETURN 'OK';
               ELSE
                  IF to_station IS NOT NULL
                  THEN
                     to_station := get_station_namec (to_station);
                     to_station := '應該去: <' || to_station || '>';
                  END IF;

                  RETURN '路徑錯誤! ' || to_station;
               END IF;
            END IF;
         END IF;
      END IF;
   END;

   FUNCTION get_should_to_station (
      p_cur_station_code   VARCHAR2,
      p_defect_flag        PLS_INTEGER
   )
      RETURN VARCHAR2
   IS
      lgoon                    BOOLEAN;
      lcanloop                 BOOLEAN;
      length_history_station   PLS_INTEGER;
      to_station               VARCHAR2 (50);
      last_station             VARCHAR2 (50);
      last_pre_station         VARCHAR2 (50);
      history_station          r_wip.route_history%TYPE;
   BEGIN
      lgoon := TRUE;
      to_station := '';
      lcanloop := TRUE;

--從維修出來且有參考工站的全部這里做了處理.默認路徑在后續會作處理.
      IF (p_cur_station_code = 'RO')
      THEN
         history_station := rec_wip_info.route_history;
         length_history_station := LENGTH (history_station);

         WHILE (length_history_station > 0) AND lcanloop
         LOOP
            last_station :=
                      SUBSTR (history_station, length_history_station - 2, 2);

            IF is_test_station (last_station)
            THEN
               last_pre_station :=
                      SUBSTR (history_station, length_history_station - 5, 2);

               IF     (NOT is_test_station (last_pre_station))
                  AND (NOT is_repair_station (last_pre_station))
               THEN
                  to_station :=
                     get_to_station_mul (p_cur_station_code,
                                         last_pre_station,
                                         p_defect_flag
                                        );

                  IF to_station IS NOT NULL
                  THEN
                     lgoon := FALSE;
                     RETURN to_station;
                  END IF;

                  lcanloop := FALSE;
               END IF;
            END IF;

            history_station :=
                       SUBSTR (history_station, 1, length_history_station - 3);
            length_history_station := LENGTH (history_station);
         END LOOP;
      END IF;

      IF lgoon                                                      --唯一路徑
      THEN
         to_station :=
                    get_to_station_single (p_cur_station_code, p_defect_flag);
         RETURN to_station;
      END IF;
   END;
END wip_info_package;
/

