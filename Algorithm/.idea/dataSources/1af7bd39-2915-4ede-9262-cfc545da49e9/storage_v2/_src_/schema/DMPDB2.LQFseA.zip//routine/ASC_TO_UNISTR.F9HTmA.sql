create FUNCTION        ASC_TO_UNISTR(cValues varchar2)return Nvarchar2
is
v_Result nvarchar2(4000);
i integer;
begin
  if cValues is null then
    v_Result := '';
    Return v_Result;
  else
    if (Length(cValues) mod 5) <> 0 then
      v_Result := '';
    else
      if Length(cValues) = 0 then
        v_Result := '';
      else
        for i in 0..Round(Length(cValues) / 5) - 1
        loop
          v_Result := v_Result || UniStr('\'||Fill_Zero(Int_To_Hex(to_number(SubStr(cValues, i * 5 + 1, 5))), 4));
        end loop;
      end if;
    end if;
  end if;
  Return v_Result;
end;


/

