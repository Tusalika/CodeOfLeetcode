create FUNCTION        Bobcat_Retest_Policy(
   cWipno         IN   VARCHAR2,
   cAppleStation  IN   VARCHAR2
)
   RETURN VARCHAR2 
AS
  dRepiarTime date;
  cRet varchar2(1000); 
  cStationType varchar2(60); 
  iIsTsID int;
  cCategoryKey varchar2(30); 
  
  dInitTime date;
    
  cAppleLine varchar2(60);  
  iWipId number;
  iReworkFlag int;
  --iDismantle int;
  iRepairFlag int;
  dInputTime date;
  dRepairCheckOutTime date;  
  iInRepairFlag int;   
  iRecordCount int;
  
  iCheckFlag int;
  
  cTemp varchar2(255);
  iTemp int;
  
  iMaxRetestTimes int;
  
  cStopRetestPolicy varchar2(255);
  
  cStationList varchar2(2500);
  --iAppleStationPos int;
   
  function getMaxRetestTimes(cCurStation in varchar2) 
    return int   
  is
    iRet int;
  begin
    iRet := 0;
    
    if cCurStation = 'TILT1' then
      iRet := 3;
    elsif cCurStation = 'QT0' then
      iRet := 3;      
    elsif cCurStation = 'QT0b' then
      iRet := 3;
    elsif cCurStation = 'IMU' then
      iRet := 3;
    elsif cCurStation = 'SW-DOWNLOAD' then
      iRet := 3;   
    elsif cCurStation = 'CURRENT-POSTBURN' then
      iRet := 3;
    elsif cCurStation = 'ALSAR' then
      iRet := 3;   
    elsif cCurStation = 'ALS-CAL' then
      iRet := 3;  
    elsif cCurStation = 'ALS-TEST' then
      iRet := 3;
    elsif cCurStation = 'QT1' then
      iRet := 3;
    elsif cCurStation = 'QT2-POSTBURN' then
      iRet := 3; 
    elsif cCurStation = 'VIDEO-POSTBURN' then
      iRet := 3;      
    elsif cCurStation = 'FACT2' then
      iRet := 3;
    elsif cCurStation = 'FACT' then
      iRet := 3;
    elsif cCurStation = 'CAMERA-POSTBURN' then
      iRet := 3;     
    elsif cCurStation = 'REDSIG-CELL-OTA' then
      iRet := 3;
    elsif cCurStation = 'CELL-OTA' then
      iRet := 3;   
    elsif cCurStation = 'WIFI-BT-OTA' then
      iRet := 3;
    elsif cCurStation = 'SHIPPING-SETTINGS' then
      iRet := 3;
    elsif cCurStation = 'ICHECK' then
      iRet := 3;   
    elsif cCurStation = 'SA-BUTTONFLEX' then
      iRet := 3;                  
    elsif cCurStation = 'SA-SENSORFLEX' then
      iRet := 3;                                   
    end if;
    Return iRet;
  end;  
BEGIN 
  
  ----------------------------------------------------------------

  cStationList := ''                                
    ||';PAT-MLB,0;SA-PAT1,0;SA-PAT,0;SA-BUTTONFLEX,0;SA-SENSORFLEX,0;SA-COSMETIC,0'
    ||';SYS-VAL-DEV-1,0;SYS-VAL-DEV-2,0;SYS-VAL-DEV-3,0;SYS-VAL-DEV-4,0;SYS-VAL-DEV-5,0'
    ||';TILT1,0;COSMETIC-PRE-1,0;PAT-AM,0;PAT0,0;PAT-WIFILAT,0;PAT,0'
    ||';PAT-UATFEED,0;PAT2,0;PAT-CONNECTOR,0;PAT2B,0;QT0,1;COSMETIC-PRE-2,1'
    ||';QT0b,1;IMU,1;SW-DOWNLOAD,1;GRAPE-PROX-CAL,1'
    ||';GRAPE-PROX-TEST,1;GRAPE-CAL,1;BURNIN,1;BONFIRE,1;DISPLAY,1;CURRENT-POSTBURN,1'
    ||';FA-CHECKIN,1;FA-CHECKOUT,1;GATEKEEPER,1;ALSAR-PREBURN,1;ALS-CAL,1;ALS-TEST,1'
    ||';QT1-PREBURN,1;QT2-PREBURN,1;VIDEO-POSTBURN,1;OPAS-POSTBURN,1;FACT2,1;FACT,1'
    ||';CAMERA-POSTBURN2,1;CAMERA-POSTBURN,1;REDSIG-CELL-OTA,1;GSM-UMTS-OTA,1;CELL-OTA,1'
    ||';WIFI-BT-OTA,1;MMI,1;SHIPPING-SETTINGS,1;ICHECK,1;COSMETIC,1;FACT-POSTFATP,1'  
    ||';DEVELOPMENT1,0;DEVELOPMENT2,0;DEVELOPMENT3,0;DEVELOPMENT4,0;DEVELOPMENT5,0'
    ||';DEVELOPMENT6,0;DEVELOPMENT7,0;DEVELOPMENT8,0;DEVELOPMENT9,0;DEVELOPMENT10,0'
    ||';DEVELOPMENT11,0;DEVELOPMENT12,0;DEVELOPMENT13,0;DEVELOPMENT14,0;DEVELOPMENT15,0'
    ||';DEVELOPMENT16,0;DEVELOPMENT17,0;DEVELOPMENT18,0;DEVELOPMENT19,0;DEVELOPMENT20,0'
    ||';IQC-CAM1,0;IQC-CAM2,0;IQC-CAM3,0;IQC-CAM4,0;IQC-SURF1,0;IQC-SURF2,0;IQC-SURF3,0'
    ||';IQC-LAT-FLEX,0;IQC-WIFI-FLEX,0;IQC-DISPLAY,0;IQC-DISPLAY-2,0;IQC-CG,0'
    ||';IQC-PROXALS,0;IQC-DEV1,0;IQC-DEV2,0;IQC-DEV3,0;IQC-DEV4,0;IQC-DEV5,0' 
    ||';ACTIVATION,1;CAMERA-DESENSE,0;GSM-UMTS-DESENSE,0;C2K-EVD0-DESENSE,0;WITT-POSTFATP,0'
    ||';NAND-NUKER,0;GSM-UMTS-DESENSE,0;SHIPPING-SETTINGS-OQC,1;CELL-DESENSE,0;ICHECK-OQC,1'
    ||';DFU-NAND-INIT,1;FCT,1;SOC-TEST,1;WIFI-BT-COND,1;CELL-CAL,1;CELL-TEST,1;GATEKEEPER-PREBURN,1'
    ||';SMT-DEVELOPMENT1,1;SMT-DEVELOPMENT2,1;SMT-DEVELOPMENT3,1;SMT-DEVELOPMENT4,1;SMT-DEVELOPMENT5,1'
    ||';SMT-DEVELOPMENT6,1;SMT-DEVELOPMENT7,1;SMT-DEVELOPMENT8,1;SMT-DEVELOPMENT9,1;SMT-DEVELOPMENT10,1'
    ||';SMT-DEVELOPMENT11,1;SMT-DEVELOPMENT12,1;SMT-DEVELOPMENT13,1;SMT-DEVELOPMENT14,1'
    ||';FA-REPAIR-IN,1;FA-REPAIR-OUT,1'
    ||';LCD-INSPECT,0;COSMETIC4,1'
    ||';'
  ;  
  ----------------------------------------------------------------

  cRet := '';
  
  dInitTime := to_date('20000101', 'YYYYMMDD');
  
  dInputTime := dInitTime;  
  dRepairCheckOutTime := dInitTime;  
  dRepiarTime := dInitTime;  
  iInRepairFlag := 0;
  iReworkFlag := 0;  
  --iDismantle := 0;
  iRepairFlag := 0;
  
  cAppleLine := '00';
  
  cCategoryKey := 'N94';
  
  cTemp := cAppleStation;
  iTemp := instr(cTemp, '_');      
  if iTemp <= 0 then
    iIsTsID := 0;
    cStationType := cAppleStation;    
  else
    iIsTsID := 1;
    cTemp := substr(cTemp, iTemp + 1, length(cTemp));  
    iTemp := instr(cTemp, '_');
    cAppleLine := substr(cTemp, 1, iTemp - 1);  
    cTemp := substr(cTemp, iTemp + 1, length(cTemp));
    iTemp := instr(cTemp, '_');
    --cAppleStationNum := substr(cTemp, 1, iTemp - 1); 
    cTemp := substr(cTemp, iTemp + 1, length(cTemp));
    cStationType := cTemp;
  end if;    
  --dbms_output.put_line(cAppleLine);  
  
  --select nvl(Key_Value, '0') into cStopRetestPolicy
  --  from Sys_Property
  --  where key_name = 'STOP RETEST POLICY'
  --    and property_02 = 'N94';
  
  cStopRetestPolicy := '0';   

  if cStopRetestPolicy <> '1' then
    -------need retest control----------------------------------------------------------------
    select count(1) into iRecordCount
      from R_WIP A
         , R_WO B
      where a.wo_id = b.id
        and a.no = cWipno
        and a.del_flag + 0 = 0;
    if iRecordCount > 0 then
      select A.ID, A.Input_time, B.Is_Rework, b.Category_Key into iWipId, dInputTime, iReworkFlag, cCategoryKey
        from R_WIP A
           , R_WO B
        where a.wo_id = b.id
          and a.no = cWipno
          and a.del_flag + 0 = 0;
                                        
      if iReworkFlag = 1 then
        dRepiarTime := dInputTime;
      end if;                       
                                     
      select count(1) into iRecordCount
        from R_Repair
        where wip_id = iWipId
          and Del_Flag + 0 = 0;
      if iRecordCount > 0 then
        iRepairFlag := 1;
        select Nvl(Check_Out_Time, dInitTime) into dRepairCheckOutTime
          from R_Repair
          where wip_id = iWipId
          and ID + 0 = (select max(ID) from R_Repair where wip_id = iWipId and del_flag + 0 = 0);
                               
        if dRepairCheckOutTime <= dInitTime then
          iInRepairFlag := 1;  
        else     
          dRepiarTime := dRepairCheckOutTime;  
        end if;        
      end if;      
    end if;            
          
      iCheckFlag := 1;                                                 
      ----------------------------------------------------------------------------------------------------------- 
      --select count(1) into iRecordCount 
      --  from C_Apple_Station
      --  where code = cStationType
      --    and Category_Key = cCategoryKey
      --    and del_flag = 0;  
      iRecordCount := inStr(cStationList, cStationType);     
      if iRecordCount > 0 then
        ------not in repair room-----------------------------------
        if (iInRepairFlag = 0) then                 
            --select nvl(Property_03, '0') into cRetestTimes
            --  from C_Apple_Station
            --  where code = cStationType
            --    and Category_Key = cCategoryKey
            --    and del_flag = 0;
          iMaxRetestTimes := getMaxRetestTimes(cStationType); 
          if iMaxRetestTimes > 0 then    
            select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ count(1) into iRecordCount
              from dmpdb2.CR_DCS@iphone_Bob_L
              where wip_no = cWipno
                and Station_Type = cStationType
                and Start_Time + 0 > dRepiarTime
                and Is_Test_Fail = 1
                and nvl(symptom_code, '-') <> 'Clearing SFC on Connect';
            if iRecordCount >= iMaxRetestTimes then
              iCheckFlag := 0;
              cRet := 'Over fail count. Go to FA-CHECK-IN';
            end if;   
          end if;         
        end if;
                                  
        if iIsTsID = 1 then
          cTemp := 'tsid';
        else
          cTemp := 'ts';
        end if;        
                                  
        cTemp := '0 SFC_OK' || chr(10) || cTemp || '::' || cAppleStation || '::unit_process_check=';
        
        if iCheckFlag = 1 then
          cRet := cTemp || 'OK';
        else
          cRet := cTemp || 'UNIT OUT OF PROCESS ' || cRet;
        end if;
      ----invalid station id------------                    
      else
        cRet := '2 SFC_FATAL_ERROR Invalid station ID<' || cAppleStation || '>';
      end if;
      ----------------------------------------------------------------------------------------------------------- 
  else
    if iIsTsID = 1 then
      cTemp := 'tsid';
    else
      cTemp := 'ts';
    end if;
            
    cTemp := '0 SFC_OK' || chr(10) || cTemp || '::' || cAppleStation || '::unit_process_check=';   
       
    cRet := cTemp || 'OK';
  end if;
                 
  return cRet;
--------------------------------------------------------------------------------------------------------
EXCEPTION
   WHEN OTHERS THEN
      cRet:= '2 SFC_FATAL_ERROR ' || SUBSTR(SQLERRM, 1, 500);   
      dbms_output.put_line(cRet);  
      return   cRet ;  
END;


/

