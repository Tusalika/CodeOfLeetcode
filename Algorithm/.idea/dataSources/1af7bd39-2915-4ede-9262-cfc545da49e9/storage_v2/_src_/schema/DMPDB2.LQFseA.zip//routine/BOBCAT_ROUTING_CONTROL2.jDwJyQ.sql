create FUNCTION        Bobcat_Routing_Control2(cModel VARCHAR2, cWipNo VARCHAR2, cStationType varchar2)
  RETURN VARCHAR2
AS     
      g_ok CONSTANT VARCHAR2(2) := 'OK';
                                          
      cRet VARCHAR2(1024);
      iCount INT;
      cTestSWVer1 varchar(64);
      cTestSWVer2 varchar(64);
      lTestFlag int;
      --cStationType varchar(30);
      cPropertyKeyName varchar(60);
      lCheckRDSWversion int;
      dTestStartTime1 date;
      dTestStartTime2 date;
      dTestStartTime3 date;
                          
      iReworkFlag int;
      iDesmantle int;
                               
      dInitTime date;
      dRepairTime date;
      cRepairCheck varchar(1);
       
      iPOS int;
      cStationTemp varchar(70);
      cStationList varchar2(2500);
       
      iWipID number;
       
      cRouteHistory varchar2(2048); 
      
      dStartTime date;
      dStopTime date;
      iIsTestFail number;    
      
   --------------------------------------------------------------   
   FUNCTION checkRDSWVersion(cCategoryKey VARCHAR2, cStationType VARCHAR2, cTestSWVer VARCHAR2)
      RETURN VARCHAR2
   IS
       cRet VARCHAR2(255);
       lTestFlag int;
       iCount INT;  
       iIsEnable number;     
   BEGIN
         SELECT COUNT(1) INTO iCount 
           FROM C_RD_SW_VERSION 
           WHERE Category_key = cCategoryKey 
             AND STATION_TYPE = cStationType 
             AND TEST_SW_VER = cTestSWVer
             AND DEL_FLAG = 0;
         if iCount > 0 then       
           SELECT IS_ENABLE INTO iIsEnable 
             FROM C_RD_SW_VERSION 
             WHERE Category_key = cCategoryKey 
               AND STATION_TYPE = cStationType 
               AND TEST_SW_VER = cTestSWVer
               AND DEL_FLAG = 0;  
           if iIsEnable = 1 then
             cRet := g_ok;
           else 
             cRet := cStationType || '軟體版本號已經失效;可能原因(沒有使用正確的軟體作業,請聯系TE處理;)';
           end if;          
         else
           cRet := cStationType || '軟體版本號不存在;可能原因(1:沒有使用正確的軟體作業;2:軟體版本號沒有維護進系統,請聯系TE維護;)';
         end if;  

       RETURN cRet;
   END;      
BEGIN
      dInitTime := to_date('2010-01-01', 'YYYY-MM-DD');  
      dRepairTime := dInitTime;
      iReworkFlag := 0;
      iDesmantle := 0;
      
      cStationList := ''                                
    ||';PAT-MLB,0;SA-PAT1,0;SA-PAT,0;SA-BUTTONFLEX,0;SA-SENSORFLEX,0;SA-COSMETIC,0'
    ||';SYS-VAL-DEV-1,0;SYS-VAL-DEV-2,0;SYS-VAL-DEV-3,0;SYS-VAL-DEV-4,0;SYS-VAL-DEV-5,0'
    ||';TILT1,0;COSMETIC-PRE-1,0;PAT-AM,0;PAT0,0;PAT-WIFILAT,0;PAT,0'
    ||';PAT-UATFEED,0;PAT2,0;PAT-CONNECTOR,0;PAT2B,0;QT0,1;COSMETIC-PRE-2,1'
    ||';QT0b,1;IMU,1;SW-DOWNLOAD,1;GRAPE-PROX-CAL,1'
    ||';GRAPE-PROX-TEST,1;GRAPE-CAL,1;BURNIN,1;BONFIRE,1;DISPLAY,1;CURRENT-POSTBURN,1'
    ||';FA-CHECKIN,1;FA-CHECKOUT,1;GATEKEEPER,1;ALSAR,1;ALS-CAL,1;ALS-TEST,1'
    ||';QT1,1;QT2-POSTBURN,1;VIDEO-POSTBURN,1;OPAS-POSTBURN,1;FACT2,1;FACT,1'
    ||';CAMERA-POSTBURN2,1;CAMERA-POSTBURN,1;REDSIG-CELL-OTA,1;GSM-UMTS-OTA,1;CELL-OTA,1'
    ||';WIFI-BT-OTA,1;MMI,1;SHIPPING-SETTINGS,1;ICHECK,1;COSMETIC,1;FACT-POSTFATP,1'  
    ||';DEVELOPMENT1,0;DEVELOPMENT2,0;DEVELOPMENT3,0;DEVELOPMENT4,0;DEVELOPMENT5,0'
    ||';DEVELOPMENT6,0;DEVELOPMENT7,0;DEVELOPMENT8,0;DEVELOPMENT9,0;DEVELOPMENT10,0'
    ||';DEVELOPMENT11,0;DEVELOPMENT12,0;DEVELOPMENT13,0;DEVELOPMENT14,0;DEVELOPMENT15,0'
    ||';DEVELOPMENT16,0;DEVELOPMENT17,0;DEVELOPMENT18,0;DEVELOPMENT19,0;DEVELOPMENT20,0'
    ||';IQC-CAM1,0;IQC-CAM2,0;IQC-CAM3,0;IQC-CAM4,0;IQC-SURF1,0;IQC-SURF2,0;IQC-SURF3,0'
    ||';IQC-LAT-FLEX,0;IQC-WIFI-FLEX,0;IQC-DISPLAY,0;IQC-DISPLAY-2,0;IQC-CG,0'
    ||';IQC-PROXALS,0;IQC-DEV1,0;IQC-DEV2,0;IQC-DEV3,0;IQC-DEV4,0;IQC-DEV5,0' 
    ||';ACTIVATION,1;CAMERA-DESENSE,0;GSM-UMTS-DESENSE,0;C2K-EVD0-DESENSE,0;WITT-POSTFATP,0'
    ||';NAND-NUKER,0;GSM-UMTS-DESENSE,0;SHIPPING-SETTINGS-OQC,1;CELL-DESENSE,0;ICHECK-OQC,1'
    ||';DFU-NAND-INIT,1;FCT,1;SOC-TEST,1;WIFI-BT-COND,1;CELL-CAL,1;CELL-TEST,1;GATEKEEPER-PREBURN,1'
    ||';SMT-DEVELOPMENT1,1;SMT-DEVELOPMENT2,1;SMT-DEVELOPMENT3,1;SMT-DEVELOPMENT4,1;SMT-DEVELOPMENT5,1'
    ||';SMT-DEVELOPMENT6,1;SMT-DEVELOPMENT7,1;SMT-DEVELOPMENT8,1;SMT-DEVELOPMENT9,1;SMT-DEVELOPMENT10,1'
    ||';SMT-DEVELOPMENT11,1;SMT-DEVELOPMENT12,1;SMT-DEVELOPMENT13,1;SMT-DEVELOPMENT14,1'
    ||';FA-REPAIR-IN,1;FA-REPAIR-OUT,1'
    ||';LCD-INSPECT,0;COSMETIC4,1'
    ||';CLEAR-CB,1;OQC,1'    
    ||';'
      ;       
      
       --cStationType := 'QT0';
       lCheckRDSWversion := 0;
       --cPropertyKeyName := 'CHECK DCS ' || cStationType;
       if cStationType = 'QT0' then
         lCheckRDSWversion := 0;
       elsif cStationType = 'QT0b' then
         lCheckRDSWversion := 0;
       elsif cStationType = 'QT1' then
         lCheckRDSWversion := 0; 
       elsif cStationType = 'QT2-POSTBURN' then
         lCheckRDSWversion := 0;           
       elsif cStationType = 'GATEKEEPER' then
         lCheckRDSWversion := 0;
       elsif cStationType = 'CLEAR-CB' then
         lCheckRDSWversion := 0;           
       elsif cStationType = 'SA-SENSORFLEX' then
         lCheckRDSWversion := 0; 
       elsif cStationType = 'SA-BUTTONFLEX' then
         lCheckRDSWversion := 0;                                                                  
       end if;       
                                                    
       --SP_GetSfcPropExt(cPropertyKeyName, cStationCode, cModel, '', '', '', cRet);
       --cRet := nvl(cRet, '0');  
       cRet := '1';   
                                                             
       if cRet = '1' then                              
         if (cStationType = 'ICHECK-OQC') or (cStationType = 'SHIPPING-SETTINGS-OQC') then
           select /*+rule*/a.Is_Rework, b.id, b.input_time into iReworkFlag, iWipID, dRepairTime
             from r_wo a
                , r_wip b
             where a.id = b.wo_id 
               and b.no = cWipNo
               and b.del_flag = 0;
           select count(1) into iCount
             from R_Repair
             where wip_id = iWipID
               and del_flag = 0;
           if iCount > 0 then
             select nvl(Check_out_time, dRepairTime) into dRepairTime
               from (select * from R_repair where wip_id = iWipID and del_flag = 0 order by Check_Out_Time desc)
               where rownum = 1;
           end if;
           SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ COUNT(1) INTO iCount 
             FROM dmpdb2.CR_DCS@iPhone_Bob_L 
             WHERE wip_no = cWipNo 
               AND STATION_TYPE = 'ACTIVATION'
               AND Start_Time + 0 > dRepairTime;   
           if iCount > 0 then
             select IS_TEST_FAIL, add_date
               into lTestFlag, dTestStartTime3
               from( 
                    SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ IS_TEST_FAIL, Property_07, Property_01, Start_Time, Stop_Time, add_date
                      FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                      WHERE wip_no = cWipNo 
                        AND STATION_TYPE = 'ACTIVATION'
                      order by add_date desc, stop_time desc
                   )
               where rownum = 1;
             if lTestFlag = 1 then
               cRet := 'ACTIVATION' || '測試失敗,不允許過此工站;';
             end if;         
           else 
             cRet := '0';
           end if;            
         end if;
       end if;
                         
       IF cRet = '1' THEN
         iPOS := inStr(cStationList, cStationType);    
         cStationTemp := substr(cStationList, iPOS, 70);
         cRepairCheck := substr(cStationTemp, instr(cStationTemp, ',') + 1, 1);                  
               
         if cRepairCheck = '1' then
           select /*+rule*/a.Is_Rework, b.id, b.input_time 
                          into iReworkFlag, iWipID, dRepairTime
             from r_wo a
                , r_wip b
             where a.id = b.wo_id 
               and b.no = cWipNo
               and b.del_flag = 0;
           
           if iReworkFlag = 1 then    
             select /*+rule*/ count(1) into iCount
               from dmpdb2.r_wip a
                  , dmpdb2.swr b
                  , dmpdb2.swr_keep_parts c
               where a.wo_no = b.wo_no
                 and b.id = c.swr_id
                 and a.no = cWipNo
                 and c.part_name = 'BCP'
                 and a.del_flag = 0
                 and b.del_flag = 0;
             if iCount > 0 then
               iDesmantle := 1;
               dRepairTime := dInitTime;
             end if;    
           end if;                    
               
           select count(1) into iCount
             from R_Repair
             where wip_id = iWipID
               and del_flag = 0;
           if iCount > 0 then
             select nvl(Check_out_time, dRepairTime) into dRepairTime
               from (select * from R_repair where wip_id = iWipID and del_flag = 0 order by Check_Out_Time desc)
               where rownum = 1;
           end if;
         end if;           
       
         SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ COUNT(1) INTO iCount 
           FROM dmpdb2.CR_DCS@iPhone_Bob_L  
           WHERE wip_no = cWipNo 
             AND STATION_TYPE = cStationType
             AND Start_Time + 0 > dRepairTime;
         IF iCount = 0 THEN       
           cRet := '沒有' || cStationType ||'測試記錄,不允許過此工站;';
         ELSE
           select IS_TEST_FAIL, nvl(Property_07, '^^^'), nvl(Property_01, '^^^'), add_date, start_time, stop_time, is_test_fail
             into lTestFlag, cTestSWVer1, cTestSWVer2, dTestStartTime1, dStartTime, dStopTime, iIsTestFail
             from( 
                 SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ IS_TEST_FAIL, Property_07, Property_01, Start_Time, Stop_Time, add_date
                   FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                   WHERE wip_no = cWipNo 
                     AND STATION_TYPE = cStationType
                   order by add_date desc, stop_time desc
                 )
             where rownum = 1;
           IF lTestFlag = 1 THEN
             cRet := cStationType || '測試失敗,不允許過此工站;';
           ELSE
             if lCheckRDSWversion = 1 then
               cRet := checkRDSWVersion(cModel, cStationType, cTestSWVer1);
             else
               cRet := g_ok;
             end if;
           END IF;
           
           if cRet = g_ok then
             if (cStationType = 'SHIPPING-SETTINGS') and (cTestSWVer2 = '^^^') then
               select nvl(property_01, '^^^') into cTestSWVer2 
                 from(
                   SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ max(property_01) property_01
                     FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                     WHERE wip_no = cWipNo 
                       AND STATION_TYPE = 'SHIPPING-SETTINGS'
                       AND Property_01 is not null
                       AND Start_Time = dStartTime
                       AND Stop_Time = dStopTime
                       AND Is_Test_Fail = 0
                     order by add_date desc, stop_time desc
                   )
                 where rownum = 1;               
             end if;           
           
             if (cStationType = 'SHIPPING-SETTINGS') and (cTestSWVer2 = '^^^') then
               cRet := cStationType || '上傳的OS版本號為空,不允許過此工站;';
             elsif (cStationType = 'SHIPPING-SETTINGS') then
               SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ COUNT(1) INTO iCount 
                 FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                 WHERE wip_no = cWipNo 
                   AND STATION_TYPE = 'SW-DOWNLOAD'
                   AND Start_Time + 0 > dRepairTime;
               if iCount = 0 then
                 cRet := '沒有' || 'SW-DOWNLOAD' ||'測試記錄,不允許過此工站;';
               else
                 select IS_TEST_FAIL, add_date
                        into lTestFlag, dTestStartTime2
                   from( 
                       SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ IS_TEST_FAIL, Start_Time, Stop_Time, add_date
                         FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                         WHERE wip_no = cWipNo 
                           AND STATION_TYPE = 'SW-DOWNLOAD'
                         order by add_date desc, stop_time desc
                       )
                   where rownum = 1;                 
                 if lTestFlag = 1 then
                   cRet := 'SW-DOWNLOAD' || '測試失敗,不允許過此工站;';
                 elsif dTestStartTime2 > dTestStartTime1 then
                   cRet := 'SW-DOWNLOAD' || '測試時間晚于' || cStationType ||'測試時間,不允許過此工站;';
                 end if;  
               end if;
             elsif (cStationType = 'ICHECK') then
               SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ COUNT(1) INTO iCount 
                 FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                 WHERE wip_no = cWipNo 
                   AND STATION_TYPE = 'SW-DOWNLOAD'
                   AND Start_Time + 0 > dRepairTime;
               if iCount = 0 then
                 cRet := '沒有' || 'SW-DOWNLOAD' ||'測試記錄,不允許過此工站;';
               else
                 select IS_TEST_FAIL, add_date, start_time, stop_time, is_test_fail
                        into lTestFlag, dTestStartTime3, dStartTime, dStopTime, iIsTestFail
                   from( 
                       SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ IS_TEST_FAIL, Start_Time, Stop_Time, add_date
                         FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                         WHERE wip_no = cWipNo 
                           AND STATION_TYPE = 'SW-DOWNLOAD'
                         order by add_date desc, stop_time desc
                       )
                   where rownum = 1;                 
                 if lTestFlag = 1 then
                   cRet := 'SW-DOWNLOAD' || '測試失敗,不允許過此工站;';
                 elsif dTestStartTime3 > dTestStartTime1 then
                   cRet := 'SW-DOWNLOAD' || '測試時間晚于' || cStationType ||'測試時間,不允許過此工站;';
                 end if;  
               end if;   
               if cRet = g_ok then          
                 SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ COUNT(1) INTO iCount 
                   FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                   WHERE wip_no = cWipNo 
                     AND STATION_TYPE = 'SHIPPING-SETTINGS'
                     AND Start_Time + 0 > dRepairTime;
                 if iCount = 0 then
                   cRet := '沒有' || 'SHIPPING-SETTINGS' ||'測試記錄,不允許過此工站;';
                 else
                   select IS_TEST_FAIL, add_date, nvl(Property_01, '^^^'), Start_Time, Stop_Time, iIsTestFail 
                          into lTestFlag, dTestStartTime2, cTestSWVer2, dStartTime, dStopTime, iIsTestFail
                     from( 
                         SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ IS_TEST_FAIL, Start_Time, Stop_Time, Property_01, add_date
                           FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                           WHERE wip_no = cWipNo 
                             AND STATION_TYPE = 'SHIPPING-SETTINGS'
                           order by add_date desc, stop_time desc
                         )
                     where rownum = 1;  
                     
                   if (cTestSWVer2 = '^^^') then                    
                     select nvl(property_01, '^^^') into cTestSWVer2 
                       from(
                         SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ max(property_01) property_01
                           FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                           WHERE wip_no = cWipNo 
                             AND STATION_TYPE = 'SHIPPING-SETTINGS'
                             AND Property_01 is not null
                             AND Start_Time = dStartTime
                             AND Stop_Time = dStopTime
                             AND Is_Test_Fail = 0
                           order by add_date desc, stop_time desc  
                         )
                       where rownum = 1;                    
                   end if; 
                                    
                   if lTestFlag = 1 then
                     cRet := 'SHIPPING-SETTINGS' || '測試失敗,不允許過此工站;';
                   elsif (cTestSWVer2 = '^^^') then
                     cRet := 'SHIPPING-SETTINGS' || '上傳的OS版本號為空,不允許過此工站;'; 
                   elsif dTestStartTime3 > dTestStartTime2 then   
                     cRet := 'SW-DOWNLOAD' || '測試時間晚于' || 'SHIPPING-SETTINGS' ||'測試時間,不允許過此工站;';
                   elsif dTestStartTime2 > dTestStartTime1 then
                     cRet := 'SHIPPING-SETTINGS' || '測試時間晚于' || cStationType ||'測試時間,不允許過此工站;';
                   end if;  
                 end if;
               end if;               
             elsif (cStationType = 'ICHECK-OQC') then
               SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ COUNT(1) INTO iCount 
                 FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                 WHERE wip_no = cWipNo 
                   AND STATION_TYPE = 'SHIPPING-SETTINGS-OQC'
                   AND Start_Time + 0 > dRepairTime;
               if iCount = 0 then
                 cRet := '沒有' || 'SHIPPING-SETTINGS-OQC' ||'測試記錄,不允許過此工站;';
               else
                 ------
                 select IS_TEST_FAIL, add_date
                        into lTestFlag, dTestStartTime2
                   from( 
                       SELECT /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ IS_TEST_FAIL, Start_Time, Stop_Time, add_date
                         FROM dmpdb2.CR_DCS@iPhone_Bob_L  
                         WHERE wip_no = cWipNo 
                           AND STATION_TYPE = 'SHIPPING-SETTINGS-OQC'
                         order by add_date desc, stop_time desc
                       )
                   where rownum = 1;                 
                 if lTestFlag = 1 then
                   cRet := 'SHIPPING-SETTINGS-OQC' || '測試失敗,不允許過此工站;';  
                 elsif dTestStartTime2 > dTestStartTime1 then
                   cRet := 'SHIPPING-SETTINGS-OQC' || '測試時間晚于' || 'ICHECK-OQC' ||'測試時間,不允許過此工站;';
                 elsif dTestStartTime3 > dTestStartTime2 then
                   cRet := 'ACTIVATION' || '測試時間晚于' || 'SHIPPING-SETTINGS-OQC' ||'測試時間,不允許過此工站;';                   
                 end if;
                 -------  
               end if;
               -------                                  
             end if;
           end if;
           --------------------
         END IF;  
       ELSIF cRet = '0' THEN  
         cRet := g_ok;
       END IF;
                 
       RETURN cRet;
EXCEPTION
  WHEN OTHERS then
    cRet:='ERROR(SFC_Routing_Control):' || SUBSTR(SQLERRM, 1, 200);   
    --dbms_output.put_line(cRet);     
    --dmpdb2.write_bob_log('Bobcat_Routing_Control3', 'Bobcat_Routing_Control3', '0', cRet, 'Bobcat_Routing_Control3');         
    return   cRet ;         
END;


/

