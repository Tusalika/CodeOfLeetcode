create PROCEDURE        check_ec (
   DATA      IN       VARCHAR2,
   mygroup   IN       VARCHAR2,
   --測試項目 test_item
   ite       IN       VARCHAR2,
   res       OUT      VARCHAR2
)
IS
   --輸入參數
   in_test_item_code         VARCHAR2 (25);
   in_symptom_code           VARCHAR2 (25);
   in_station_code           VARCHAR2 (25);
   --全局變量
   g_commodity_id   CONSTANT PLS_INTEGER   := constant_package.g_commodity_id;
   g_symptom_id              PLS_INTEGER;
   g_station_id              PLS_INTEGER;
   g_test_item_id            PLS_INTEGER;
   g_ok             CONSTANT VARCHAR2 (2)  := 'OK';

   FUNCTION get_station_id
      RETURN VARCHAR2
   IS
   BEGIN
      SELECT ID
        INTO g_station_id
        FROM station
       WHERE del_flag = 0 AND code = in_station_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '無效的工站代碼: <' || in_station_code || '>';
   END;

   FUNCTION get_item_name
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT namec
        INTO v_name
        FROM test_item
       WHERE del_flag = 0
         AND commodity_id = g_commodity_id
         AND code = in_test_item_code;

      RETURN v_name;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION get_symptom_name
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT namec
        INTO v_name
        FROM symptom
       WHERE del_flag = 0
         AND commodity_id = g_commodity_id
         AND code = in_symptom_code;

      RETURN v_name;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION is_symptom
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT DISTINCT a.ID
                 INTO g_symptom_id
                 FROM symptom a, test_map b
                WHERE a.del_flag = 0
                  AND b.del_flag = 0
                  AND a.commodity_id = g_commodity_id
                  AND b.commodity_id = a.commodity_id
                  AND b.test_item_id = g_test_item_id
                  AND b.symptom_id = a.ID
                  AND b.station_id = g_station_id
                  AND a.code = in_symptom_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_name := get_symptom_name;

         IF v_name IS NOT NULL
         THEN
            RETURN '無此測試症狀: ' || in_symptom_code || '<' || v_name
                   || '>';
         ELSE
            RETURN '無效的不良代碼: <' || in_symptom_code || '>';
         END IF;
   END;

   FUNCTION is_test_item
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT DISTINCT a.ID
                 INTO g_test_item_id
                 FROM test_item a, test_map b
                WHERE a.del_flag = 0
                  AND b.del_flag = 0
                  AND a.commodity_id = g_commodity_id
                  AND b.commodity_id = a.commodity_id
                  AND b.test_item_id = a.ID
                  AND b.station_id = g_station_id
                  AND a.code = in_test_item_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_name := get_item_name;

         IF v_name IS NOT NULL
         THEN
            RETURN    '無此測試項: '
                   || in_test_item_code
                   || '<'
                   || v_name
                   || '>, 請掃<UNDO>重新作業';
         ELSE
            RETURN '無效的測試項: <' || in_test_item_code || '>';
         END IF;
   END;
BEGIN
   in_symptom_code := TRIM (DATA);
   in_test_item_code := TRIM (ite);
   in_station_code := TRIM (mygroup);
   res := get_station_id;

   IF res <> g_ok
   THEN
      RETURN;
   END IF;

   res := is_test_item;

   IF res <> g_ok
   THEN
      RETURN;
   END IF;

   res := is_symptom;
END;


/

