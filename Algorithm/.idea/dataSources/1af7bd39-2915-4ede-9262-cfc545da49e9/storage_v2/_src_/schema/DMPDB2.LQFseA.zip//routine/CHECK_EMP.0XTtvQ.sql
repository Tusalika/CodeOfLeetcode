create PROCEDURE        check_emp (
   DATA   IN       VARCHAR2,
   res    OUT      VARCHAR2
)
IS
   c_emp   PLS_INTEGER;
BEGIN
   SELECT ID
     INTO c_emp
     FROM app_user
    WHERE del_flag = 0 AND employee_id = DATA;

   /*SELECT A.EMPLOYEE_ID INTO C_EMP FROM DMPSFIS1.APP_USER A,DMPSFIS1.DEPARTMENT B
   WHERE B.ID=A.DEPARTMENT_ID
     AND B.ID IN ('3','1')
    AND A.EMPLOYEE_ID=DATA
    AND ROWNUM = 1;*/
   --res := 'OK  JUMP={S1}  SCAN={早 MORNING!} DISPLAY={早 MORNING!}';
   res := 'OK';
EXCEPTION
   WHEN OTHERS
   THEN
      -- res := 'NO EMP JUMP={S0}';
      res := '無效的員工號';
END;
/

