create PROCEDURE        check_fg (
   DATA   IN       VARCHAR2,
   ec     IN       VARCHAR2,
   res    OUT      VARCHAR2
)
IS
   c_no   VARCHAR2 (25);
   sn     VARCHAR2 (25);
BEGIN
   IF ec = 'N/A'                                            --掃描良,掃FG序號
   THEN
      sn := SUBSTR (DATA, 2, LENGTH (DATA) - 1);
   ELSE                                                  --掃描不良,直接掃序號
      sn := DATA;
   END IF;

   SELECT NO
     INTO c_no
     FROM r_wip
    WHERE del_flag = 0 AND NO = sn;

   res := 'OK';
EXCEPTION
   WHEN OTHERS
   THEN
      res := '無效的FG序號';
END;


/

