create PROCEDURE        check_item (
   DATA   IN       VARCHAR2,
   res    OUT      VARCHAR2
)
IS
   c_id   PLS_INTEGER;
BEGIN
   --返回的信息在CMC503看不到﹐不根據工站進行判斷
   SELECT ID
     INTO c_id
     FROM test_item
    WHERE del_flag = 0 AND code = DATA;

   res := 'OK';
EXCEPTION
   WHEN OTHERS
   THEN
      res := '無效的測試項';
END;


/

