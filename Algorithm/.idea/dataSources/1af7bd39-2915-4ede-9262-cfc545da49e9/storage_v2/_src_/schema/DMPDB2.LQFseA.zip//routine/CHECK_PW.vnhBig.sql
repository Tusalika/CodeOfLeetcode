create PROCEDURE        check_PW(
   DATA      IN       VARCHAR2,
   mygroup   IN       VARCHAR2,
   EMP       IN       VARCHAR2,
   res       OUT      VARCHAR2
)
IS
   cPW   varchar2(255); 
   cTmp  varchar2(255); 
   iRecordCount int; 
BEGIN
   SELECT PASSWORD
     INTO cTmp
     FROM app_user
    WHERE del_flag = 0 AND employee_id = EMP;
    
   cPW := DecryptStr(cTmp);
   if cPW = DATA then
     if mygroup in('OQ', 'OC', 'OO') then
        select count(1) into iRecordCount
          from dmpdb2.App_user a
             , dmpdb2.App_grp b
             , dmpdb2.App_grp_member c
          where a.id = c.app_user_id
            and b.id = c.app_grp_id
            and a.del_flag = 0
            and b.del_flag = 0
            and b.code like 'DHP2_QA%'
            and a.EMPLOYEE_ID = EMP;
            
        if iRecordCount > 0 then
          res := 'OK';
        else 
          res := 'FAIL;非QA人員不允許在此工站操作﹔';
        end if;     
     else 
        res := 'OK';
     end if;
   else 
     res := 'FAIL;密碼錯誤﹐請重新輸入﹔';
   end if;   
EXCEPTION
   WHEN OTHERS
     THEN res := 'Error occur when check password';
END;


/*
select * FROM dmpdb2.app_user


select * from dmpdb2.station
where code like 'O%'


select to_number('2.0') from dual


select * from dmpdb2.App_grp
where code like 'DHP2_QA%'
*/


/

