create PROCEDURE        check_ssn_double (
   DATA   IN       VARCHAR2,
   fg     IN       VARCHAR2,
   ec     IN       VARCHAR2,
   res    OUT      VARCHAR2
)
IS
BEGIN
   --在掃PASS時檢查序號和前次掃的FG序號是否相同
   IF ec = 'N/A'
   THEN
      IF INSTR (fg, DATA) = 2
      THEN
         res := 'OK';
      ELSE
         res := '掃描錯誤, 和上次掃描的FG序號不同';
      END IF;
   ELSE
      res := 'OK';
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      res := '無效的序號';
END;


/

