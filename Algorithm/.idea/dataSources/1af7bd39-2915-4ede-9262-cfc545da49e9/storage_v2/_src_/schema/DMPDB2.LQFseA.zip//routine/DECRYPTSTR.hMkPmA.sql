create FUNCTION        DecryptStr(cValue varchar2)
   RETURN VARCHAR2
IS
  cTmp varchar2(255);
  cRet varchar2(255);
  i  int;
  iTmp int;
  iLen int;
BEGIN
    cRet := '';    
    
    i := 1;
    cTmp := '';
    while (i <= length(cValue) / 4) loop
       iTmp := to_number(substr(cValue, (i - 1) * 4 + 1, 2));
       if mod(iTmp, 2) = 0 then
         cTmp := cTmp || substr(cValue, (i - 1) * 4 + 3, 2);
       else
         cTmp := cTmp || '00';
       end if;
       i := i + 1;
    end loop;       
    
    iLen := to_number(substr(cTmp, 1, 3));  
    cTmp := substr(cTmp, 4, iLen);    
    
    i := 1;
    while i <= iLen / 3 loop
      iTmp := to_number(substr(cTmp, (i - 1) * 3 + 1, 3));
      cRet := cRet || chr(iTmp);
      i := i + 1;
    end loop;

    RETURN cRet;
EXCEPTION
   WHEN OTHERS
     THEN RETURN  '';
END; 
   

--select mod(3, 2) from dual

   
--select substr('1234', 2, 1) from dual

--select chr('567') from dual


/* 

select dmpdb2.DecryptStr('940166803456100522104849140507087451020458808672') from dual

*/


/

