create PROCEDURE        DS_Refresh_Schedule(
   ScheduleCode    IN   VARCHAR2,
   StatusFlag      IN   VARCHAR2,
   CurScheduleID   IN   VARCHAR2 
)
as
  iRecordCount int;
  cScheduleCode varchar2(30);
  iMaxID number;
  iTemp number;
  dTimePoint date;
  dIntervalTime float;
  dTemp date;
begin
  dIntervalTime := 1/24; --- by hour 

  cScheduleCode := ScheduleCode;--'A_TEST_RESULT_SEND';
  
  iMaxID := 0;  

if cScheduleCode in('GL_A_TEST_RESULT_SEND'
                  , 'GL_A_TEST_RESULT_RECEIVE'
                  , 'GL_A_INPUT_OUTPUT_SEND'
                  , 'GL_A_INPUT_OUTPUT_RECEIVE'
                  , 'GL_A_INVENTORY'
                  , 'GL_A_INVENTORY_SEND'
                  , 'GL_A_INVENTORY_RECEIVE'
                  , 'GL_A_OFFSET_QTY_SEND'
                  , 'GL_A_OFFSET_QTY_RECEIVE'
                  , 'GL_A_REPAIR_IO_SEND'
                  , 'GL_A_REPAIR_IO_RECEIVE'
                  , 'GL_A_REPAIR_MATRIX_SEND'
                  , 'GL_A_REPAIR_MATRIX_RECEIVE'
                  , 'GL_R_WO_SEND'
                  , 'GL_R_WO_RECEIVE'
                  , 'GL_R_WO'
                  , 'ZZ_A_TEST_RESULT_SEND'
                  , 'ZZ_A_INPUT_OUTPUT_SEND'
                  , 'ZZ_A_INVENTORY_SEND'
                  , 'ZZ_A_OFFSET_QTY_SEND'
                  , 'ZZ_A_REPAIR_IO_SEND'
                  , 'ZZ_A_REPAIR_MATRIX_SEND'
                  , 'ZZ_R_WO_SEND'                  
                  , 'ZZ_A_TEST_RESULT_RECEIVE'
                  , 'ZZ_A_INPUT_OUTPUT_RECEIVE'
                  , 'ZZ_A_INVENTORY'
                  , 'ZZ_A_INVENTORY_RECEIVE'
                  , 'ZZ_A_OFFSET_QTY_RECEIVE'
                  , 'ZZ_A_REPAIR_IO_RECEIVE'
                  , 'ZZ_A_REPAIR_MATRIX_RECEIVE'
                  , 'ZZ_R_WO_RECEIVE'
                  , 'ZZ_R_WO'
                  , 'ZZ_A_TEST_RESULT_FRESH_SEND'
                  ) then   
  if StatusFlag = '0' then
    if (CurScheduleID = '0') then
      select /*+rule*/ count(1) into iRecordCount
        from  C_PDCA_LOG
        where Schedule_Code = cScheduleCode
          and Status_Flag = StatusFlag
          and Del_Flag = 0;
      if iRecordCount = 0 then
        select count(1) into iRecordCount
          from  C_PDCA_LOG
          where Schedule_Code = cScheduleCode
            and Del_Flag = 0
            and Rownum <= 1;
        if iRecordCount = 0 then        
          dTemp := to_date('2011/02/18 07:00:00', 'YYYY/MM/DD HH24:MI:SS') + 1;
          dTimePoint := to_date('2011/02/18 07:00:00', 'YYYY/MM/DD HH24:MI:SS');
          while dTimePoint < dTemp and dTimePoint < sysdate loop 
            iMaxID := get_next_id('C_PDCA_LOG');            
            insert into C_PDCA_LOG
              Values(iMaxID, cScheduleCode, dTimePoint, null, null, 0
                     , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
            dTimePoint := dTimePoint + dIntervalTime;
          end loop;
        else
          select Max(ID) into iTemp
            from  C_PDCA_LOG
            where Schedule_Code = cScheduleCode
              and Del_Flag = 0;
          select Time_Point into dTimePoint
            from  C_PDCA_LOG
            where ID = iTemp;
          if dTimePoint < sysdate - dIntervalTime then
            iMaxID := get_next_id('C_PDCA_LOG');
            insert into  C_PDCA_LOG
              Values(iMaxID, cScheduleCode, dTimePoint + dIntervalTime, null, null, 0
                     , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0); 
          end if;
        end if;  
      end if; 
    else
      select Time_Point into dTimePoint
        from  C_PDCA_LOG
        where ID = to_number(CurScheduleID);      
      dTemp := to_date(to_char(dTimePoint, 'YYYY/MM/DD') || ' 07:00:00', 'YYYY/MM/DD HH24:MI:SS') + 1;
      dTimePoint := dTimePoint + dIntervalTime; 
      while dTimePoint < dTemp and dTimePoint < sysdate loop 
        select count(1) into iRecordCount
        from  C_PDCA_LOG
        where Schedule_Code = cScheduleCode
          and time_point = dTimePoint;
        if iRecordCount = 0 then
          iMaxID := get_next_id('C_PDCA_LOG');            
          insert into C_PDCA_LOG
            Values(iMaxID, cScheduleCode, dTimePoint, null, null, 0
                   , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
        end if;           
        dTimePoint := dTimePoint + dIntervalTime;         
      end loop;     
    end if; 
  elsif StatusFlag = '1' or StatusFlag = '2' then  
    update C_PDCA_LOG set Status_Flag = StatusFlag where id = CurScheduleID; 
  end if;
--elsif cScheduleCode in('R_WO_SEND', 'R_WO_RECEIVE') then

end if; 
  
  commit; 
end;


/

