create FUNCTION        EncryptStr(cValue varchar2)
   RETURN VARCHAR2
IS
  cTmp varchar2(255);
  iTmp int;
  cRet varchar2(255);
  i  int;
  
  function Random1 return int
  is
    iRet int;
  begin
    select trunc(dbms_random.value(1, 99)) into iRet from dual;
    if mod(iRet, 2) = 0 then
      iRet := iRet + 1;
    end if;
    
    return iRet;
  end;
  
  function Random2 return int
  is
    iRet int;
  begin
    select trunc(dbms_random.value(1, 99)) into iRet from dual;
    if mod(iRet, 2) <> 0 then
      iRet := iRet - 1;
    end if;
    
    if iRet = 0 then 
      iRet := 2;
    end if;
    
    return iRet;
  end;  
  
  function GetRandomNum(iMin int, iMax int) return int
  is
    iRet int;
  begin
    select trunc(dbms_random.value(iMin, iMax)) into iRet from dual;
    return iRet;
  end;
  
  function PadL(cText varchar2, iLen int, cSubstr varchar2) return varchar2
  is
    cRet varchar2(255);
    cTmp varchar2(255);
    iTmp int;
  begin
    cRet := '';
  
    cTmp := trim(cText);
    iTmp := length(cTmp);
    if iTmp < iLen then
      cRet := substr(cSubstr, 1, iLen - iTmp) || cTmp;
    else 
      cRet := substr(cTmp, iTmp - iLen, iLen);
    end if;
    
    Return cRet;
  end;
BEGIN
    cRet := '';    
    
    cTmp := '';
    i := 1;
    while i <= Length(cValue) loop
      cTmp := cTmp || PadL(to_char(ascii(substr(cValue, i, 1))), 3, '000');
      i := i + 1;
    end loop;
    
    cTmp := PadL(to_char(Length(cTmp)), 3, '000') || cTmp;

    if mod(Length(cTmp), 2) <> 0 then
      cTmp := cTmp || PadL(to_char(GetRandomNum(1, 255)), 3, '0');
    end if;

    i := 1;
    while i <= (Length(cTmp) / 2) loop
      iTmp := to_char(substr(cTmp, (i - 1) * 2 + 1, 2));
      if iTmp = 0 then
        cRet := cRet || PadL(to_char(Random1), 2, '0') || PadL(to_char(Random2), 2, '0');
      else
        cRet := cRet || PadL(to_char(Random2), 2, '0') || PadL(to_char(iTmp), 2, '0');
      end if;
      i := i + 1;
    end loop;

    RETURN cRet;
EXCEPTION
   WHEN OTHERS
     THEN RETURN  '';
END; 
   
--select random(10, 10) from dual

--select mod(3, 2) from dual

   
--select substr('1234', 2, 1) from dual

--select chr(97) from dual

--select ascii('A') from dual

--select trunc(dbms_random.value(1, 10)) from dual 

/* 

select dmpdb2.EncryptStr('ABcD') from dual

select dmpdb2.DecryptStr('360126206465220608606899660618808831') from dual

*/


/

