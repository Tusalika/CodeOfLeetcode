create FUNCTION        FILL_ZERO(cValue nvarchar2, iLen integer) return varchar2
is
i integer;
v_Result varchar2(4000);
begin
  v_Result := cValue;
  for i in 1..iLen - Length(cValue)
  loop
    v_Result := '0' || v_Result;
  end loop;
  Return v_Result;
end;


/

