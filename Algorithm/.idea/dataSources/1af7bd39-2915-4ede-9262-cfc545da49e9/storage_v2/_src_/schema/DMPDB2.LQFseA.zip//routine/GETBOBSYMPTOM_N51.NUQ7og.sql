create PROCEDURE        GetBobSymptom_N51 (
   last_repair_time       IN       DATE,
   dislink_time             IN       DATE,
   wip_no                      IN       VARCHAR2,
   res                            OUT      VARCHAR2
)
IS
   --輸入參數
   in_last_repair_time      DATE;
   in_dislink_time            DATE;
   in_wip_no                     DATE;
   --全局變量
   g_ok             CONSTANT VARCHAR2 (2)  := 'OK';

BEGIN
   in_last_repair_time := last_repair_time;
   in_dislink_time := dislink_time;
   in_wip_no := wip_no;
   res := 'OK';
 
 SELECT /*+  INDEX(AA.cr_n51_01 cr_n51_01_wip_no)  INDEX(AA.cr_n51_02 cr_n51_02_wip_no)  INDEX(AA.cr_n51_03 cr_n51_03_wip_no)  INDEX(AA.cr_n51_04 cr_n51_04_wip_no)  INDEX(AA.cr_n51_05 cr_n51_05_wip_no)  */
 AA.Wip_No,
 AA.add_date,
 AA.station_type,
 AA.Station_Code,
 AA.symptom_code,
 AA.Is_Test_Fail,
 AA.Stop_Time
  FROM DMPDB2.V_CR_N51 AA,
       (SELECT STATION_TYPE
          FROM (SELECT /*+  INDEX(A.cr_n51_01 cr_n51_01_wip_no)  INDEX(A.cr_n51_02 cr_n51_02_wip_no)  INDEX(A.cr_n51_03 cr_n51_03_wip_no)  INDEX(A.cr_n51_04 cr_n51_04_wip_no)  INDEX(A.cr_n51_05 cr_n51_05_wip_no)  */
                 A.WIP_NO, A.STATION_TYPE, A.STOP_TIME, A.IS_TEST_FAIL
                  FROM DMPDB2.V_CR_N51 A,
                       (SELECT /*+  INDEX(C.cr_n51_01 cr_n51_01_wip_no)  INDEX(C.cr_n51_02 cr_n51_02_wip_no)  INDEX(C.cr_n51_03 cr_n51_03_wip_no)  INDEX(C.cr_n51_04 cr_n51_04_wip_no)  INDEX(C.cr_n51_05 cr_n51_05_wip_no)  */
                         MAX(C.STOP_TIME) STOP_TIME, C.STATION_TYPE
                          FROM dmpdb2.c_prop_n51 C
                         WHERE WIP_NO = in_wip_no
                           AND STATION_TYPE <> 'FA-REPAIR-IN'
                         GROUP BY STATION_TYPE) B
                 WHERE A.STATION_TYPE = B.STATION_TYPE
                   AND A.STOP_TIME = B.STOP_TIME
                   AND A.WIP_NO = in_wip_no
                   AND A.IS_TEST_FAIL = 1
                 ORDER BY STOP_TIME DESC)
         WHERE ROWNUM = 1 ) BB
 WHERE AA.WIP_NO = in_wip_no
   AND AA.STATION_TYPE = BB.STATION_TYPE
   AND Nvl(AA.SYMPTOM_CODE, ' ' ) <> 'Clearing SFC on Connect'
   AND AA.SYMPTOM_CODE NOT LIKE '%CB%'
   AND AA.SYMPTOM_CODE NOT LIKE '%Fail Count%'
   AND AA.IS_TEST_FAIL = 1
 ORDER BY AA.STOP_TIME DESC;
 
 


END;


/

