create FUNCTION        getburninfo2 (
   cwipno         IN   VARCHAR2,
   cstationcode   IN   VARCHAR2,
   cparams        IN   VARCHAR2
--only for N90 now
--STORAGE_SIZE_LOW; STORAGE_SIZE_HIGH; CUST_PART_NO; BATTERY_SN; IMEI; ICC_ID; BUILD_TYPE; HWCONFIG;MODEL;MLB_EEECODE;GRP_SN;LCG_SN;
)
   RETURN VARCHAR2
AS
   burninfo             VARCHAR2 (1500);
   icommodityid         NUMBER;
   cstorage_size_low    VARCHAR2 (10);                                  --1.5
   cstorage_size_high   VARCHAR2 (10);                                  --2.0
   ccust_part_no        VARCHAR2 (20);                            --MA501LL/A
   cbattery_sn          VARCHAR2 (80);                          --ABCDEFGBTYA
   cgrp_sn              VARCHAR2 (80);                         --ABCDEFGDERWE
   cBan_sn              VARCHAR2 (80);
   cimei                VARCHAR2 (30);                      --012345678912345
   cicc_id              VARCHAR2 (30);                  --3023514562854531542
   cbuild_type          VARCHAR2 (10);  --L: Loaner; N: Normal; R: Replacment
   cerror_message       VARCHAR2 (500);
   cmlb_sn              VARCHAR2 (80);                      --2008/11/12 bill
   cWo_Parts_id  NUMBER;
   cEEECode  VARCHAR2(80);
   irecordcount         NUMBER;
   istart               NUMBER;
   iposition            NUMBER;
   cparam               VARCHAR2 (255);
   ctemp                VARCHAR (255);
   cto_station          VARCHAR2 (2);
   lgoon                VARCHAR2 (10);

   cHWConfig VARCHAR2(255);

   TYPE r_record IS RECORD (
      wip_id             r_wip.ID%TYPE,
      wip_no             r_wip.NO%TYPE,
      defect_flag        r_wip.defect_flag%TYPE,
      route_id           r_wip.route_id%TYPE,
      route_history      r_wip.route_history%TYPE,
      finish_flag        r_wip.finish_flag%TYPE,
      lock_flag          r_wip.lock_flag%TYPE,
      pre_station_code   r_wip.pre_station_code%TYPE,
      wo_id              r_wo.ID%TYPE,
      is_msr             r_wo.is_msr%TYPE,
      is_allow_input     r_wo.is_allow_input%TYPE,
      close_flag         r_wo.close_flag%TYPE,
      category_key       product.category_key%TYPE,
      process_lock_id    r_wip.process_lock_id%TYPE,
      cust_part_no       r_wip.cust_part_no%TYPE,
      model_type         c_part_no_add_prop.cust_part_type%TYPE,
      CCC_Code         Product.Property_04%TYPE
   );

   rec_wip_info         r_record;
   my_exception         EXCEPTION;
BEGIN
   burninfo := '';
   icommodityid := 33;
   cstorage_size_low := '';
   cstorage_size_high := '';
   ccust_part_no := '';
   cbattery_sn := '';
   cimei := '';
   cicc_id := '';
   cmlb_sn := '';
   cbuild_type := '';
   ctemp := '';
   istart := 0;
   iposition := 0;

   SELECT COUNT (*)
     INTO irecordcount
     FROM dmpdb2.r_wip a, dmpdb2.r_wo b, dmpdb2.product c
    WHERE a.commodity_id = icommodityid
      AND a.del_flag = 0
      AND b.product_id = c.ID
      AND a.wo_id = b.ID
      AND a.NO = cwipno;

   IF irecordcount <= 0
   THEN
      burninfo := 'INVALID WIP NO!';
      RAISE my_exception;
   END IF;

   SELECT a.ID AS wip_id,
          a.NO AS wip_no,
          a.defect_flag,
          a.route_id,
          a.route_history,
          a.finish_flag,
          a.lock_flag,
          a.pre_station_code,
          b.ID AS wo_id,
          b.is_msr,
          b.is_allow_input,
          b.close_flag,
          c.category_key,
          a.process_lock_id,
          a.cust_part_no,
          c.property_22,
          c.Property_04
     INTO rec_wip_info
     FROM dmpdb2.r_wip a, dmpdb2.r_wo b, dmpdb2.product c
    WHERE a.commodity_id = icommodityid
      AND a.del_flag = 0
      AND b.product_id = c.ID
      AND a.wo_id = b.ID
      AND a.NO = cwipno;

   IF (rec_wip_info.wip_id IS NULL)
   THEN
      burninfo := 'INVALID WIP NO!';
      RAISE my_exception;
   END IF;

   SELECT COUNT (*)
     INTO irecordcount
     FROM dmpdb2.c_part_no_add_prop
    WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

   IF irecordcount <= 0
   THEN
      burninfo := 'NO BURN PART NO FIND!';
      RAISE my_exception;
   END IF;

   SELECT cust_part_type
     INTO rec_wip_info.model_type
     FROM dmpdb2.c_part_no_add_prop
    WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

/*
  IF (rec_wip_info.is_allow_input IS NULL) OR (rec_wip_info.is_allow_input = 0) THEN
    BurnInfo := '馱?衄芘';
    RAISE MY_EXCEPTION;
  --RETURN 'Workorder not allow input';
  END IF;

  IF NVL (rec_wip_info.close_flag, ' ') <> ' ' THEN
    BurnInfo := '馱眒?磐偶';
    RAISE MY_EXCEPTION;
  --RETURN 'Workorder has been closed';
  END IF;

  IF NVL (rec_wip_info.finish_flag, ' ') <> ' ' THEN
    BurnInfo := '家眒?家堤ㄛ祥黺婓秶';
    RAISE MY_EXCEPTION;
  --RETURN 'Have been outputed. can not be wip';
  END IF;

  IF rec_wip_info.lock_flag = '*1' THEN
    BurnInfo := '家掩諶蛂ㄛ祥夔婬厘狟汜家';
    RAISE MY_EXCEPTION;
  --RETURN 'WIP locked, Please contact the locker';
  END IF;

  IF rec_wip_info.lock_flag = cStationCode THEN
    BurnInfo := '家掩諶婓掛馱桴ㄛ祥夔婬厘狟汜家';
    RAISE MY_EXCEPTION;
  --RETURN 'WIP Lock at a station, Please contact QA';
  END IF;

  IF rec_wip_info.process_lock_id IS NOT NULL THEN
    BurnInfo := '家婓奻珨馱桴奾帤瞎娊俇傖妯祥夔婬厘狟汜家';
    RAISE MY_EXCEPTION;
  --RETURN 'WIP Lock at a station, Please contact QA';
  END IF;


 SELECT to_station_code
    INTO cTo_Station
    FROM DMPDB2.route_chart
   WHERE defect_flag = rec_wip_info.defect_flag
     AND from_station_code = rec_wip_info.pre_station_code
     AND ref_station_code IS NULL
     AND is_optional = 0
     AND route_id = rec_wip_info.route_id
     AND ROWNUM < 2;

  IF cTo_Station <> cStationCode THEN
    SELECT namec
      INTO cTemp
      FROM station
     WHERE del_flag = 0
      AND code = cTo_Station;

     BurnInfo:= '繚嶒悷!?: <' || cTemp || '>';

    RAISE MY_EXCEPTION;
  END IF;
*/
   IF LENGTH (cparams) > 0
   THEN
      LOOP
         iposition := INSTR (cparams, ';', istart + 1, 1);
         EXIT WHEN iposition = 0;
         lgoon := 'FAILE';
         cparam :=
                  TRIM (SUBSTR (cparams, istart + 1, iposition - istart - 1));

         IF INSTR(cparam, 'MODEL') > 0 THEN
              lgoon := 'TRUE';
              burninfo := burninfo || 'MODEL:' || rec_wip_info.Category_key || ';';
         END IF;

         IF INSTR (cparam, 'STORAGE_SIZE_LOW') > 0
         THEN
            --cSTORAGE_SIZE_LOW:= '1.5';
            SELECT TO_CHAR (storage_size_1)
              INTO cstorage_size_low
              FROM dmpdb2.c_ipod_add_prop
             WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

            lgoon := 'TRUE';
            burninfo :=
                   burninfo || 'STORAGE_SIZE_LOW:' || cstorage_size_low || ';';
         END IF;

         IF INSTR (cparam, 'STORAGE_SIZE_HIGH') > 0
         THEN
            --cSTORAGE_SIZE_HIGH:= '2.0';
            SELECT TO_CHAR (storage_size_2)
              INTO cstorage_size_high
              FROM dmpdb2.c_ipod_add_prop
             WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

            lgoon := 'TRUE';
            burninfo :=
                 burninfo || 'STORAGE_SIZE_HIGH:' || cstorage_size_high || ';';
         END IF;

         IF INSTR (cparam, 'CUST_PART_NO') > 0
         THEN
              --cCUST_PART_NO:= 'MA501LL/A';
            --cCUST_PART_NO:= rec_wip_info.cust_part_no;
            SELECT burn_part_no
              INTO ccust_part_no
              FROM dmpdb2.c_part_no_add_prop
             WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

            lgoon := 'TRUE';
            burninfo := burninfo || 'CUST_PART_NO:' || ccust_part_no || ';';
         END IF;

         IF INSTR (cparam, 'BATTERY_SN') > 0
         THEN
            --cBATTERY_SN:= 'ABCDEFGBTYA';
            SELECT /*+ index(a,R_WO_PARTS_ID)*/ COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                     UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id)  b
                  , r_wo_parts a
             WHERE b.wo_parts_id = a.ID
               AND b.wip_id = rec_wip_info.wip_id
               AND a.wo_id = rec_wip_info.wo_id
               AND a.part_name || '' = 'BTY'   
               AND a.del_flag = 0            
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT /*+ index(a,R_WO_PARTS_ID)*/ serial_no
                 INTO cbattery_sn
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                        UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                     , r_wo_parts a
                WHERE b.wo_parts_id = a.ID                  
                  AND b.wip_id = rec_wip_info.wip_id
                  AND a.wo_id = rec_wip_info.wo_id
                  AND a.part_name || '' = 'BTY'
                  AND a.del_flag = 0
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'BATTERY_SN:' || cbattery_sn || ';';
            ELSE
               burninfo := 'Battery SN not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'MLB_SN') > 0
         THEN
            SELECT /*+ index(a,R_WO_PARTS_ID)*/ COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                     UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                  , r_wo_parts a
             WHERE b.wo_parts_id = a.ID
               AND b.wip_id = rec_wip_info.wip_id
               AND a.wo_id = rec_wip_info.wo_id
               AND a.part_name || '' = 'MLB'   
               AND a.del_flag = 0            
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT /*+ index(a,R_WO_PARTS_ID)*/ serial_no, wo_parts_id
                 INTO cmlb_sn, cWo_Parts_id
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                        UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                     , r_wo_parts a
                WHERE b.wo_parts_id = a.ID
                  AND b.wip_id = rec_wip_info.wip_id
                  AND a.wo_id = rec_wip_info.wo_id
                  AND a.part_name || '' = 'MLB'  
                  AND a.del_flag = 0                
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'MLB_SN:' || cmlb_sn || ';';
            ELSE
               burninfo := 'MLB SN not found';
               RAISE my_exception;
            END IF;

            IF irecordcount > 0 THEN
               SELECT EEE_Code INTO cEEECode FROM R_WO_Parts WHERE id = cWo_Parts_id;

               burninfo := burninfo || 'MLB_EEECODE:' || cEEECode || ';';
            END IF;
         END IF;

         IF INSTR (cparam, 'IMEI') > 0
         THEN
            --cIMEI:= '012345678912345';
            SELECT COUNT (*)
              INTO irecordcount
              FROM  r_wip
             WHERE NO = cwipno AND del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT property_15
                 INTO cimei
                 FROM  r_wip
                WHERE NO = cwipno AND del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'IMEI:' || cimei || ';';
            ELSE
               burninfo := 'IMEI not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'ICC_ID') > 0
         THEN
            --cICC_ID:= '3023514562854531542';
            SELECT /*+ index(a,R_WO_PARTS_ID)*/ COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                     UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                  , r_wo_parts a
             WHERE b.wo_parts_id = a.ID               
               AND b.wip_id = rec_wip_info.wip_id
               AND a.wo_id = rec_wip_info.wo_id
               AND a.part_name || '' = 'SIM1'
               AND a.del_flag = 0
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT /*+ index(a,R_WO_PARTS_ID)*/ NVL (serial_no, ' ')
                 INTO cicc_id
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                        UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                     , r_wo_parts a
                WHERE b.wo_parts_id = a.ID                  
                  AND b.wip_id = rec_wip_info.wip_id
                  AND a.wo_id = rec_wip_info.wo_id
                  AND a.part_name || '' = 'SIM1'
                  AND a.del_flag = 0
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'ICC_ID:' || cicc_id || ';';
            ELSE
               burninfo := 'ICC ID not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF (INSTR (cparam, 'GRP_SN') > 0) 
            AND (rec_wip_info.category_key = 'N90' or rec_wip_info.category_key = 'N92' or rec_wip_info.category_key = 'N90A')
         THEN
            SELECT /*+ index(a,R_WO_PARTS_ID)*/ COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                     UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                  , r_wo_parts a
             WHERE b.wo_parts_id = a.ID               
               AND b.wip_id = rec_wip_info.wip_id
               AND a.wo_id = rec_wip_info.wo_id
               AND a.part_name || '' = 'GRP'
               AND a.del_flag = 0
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT /*+ index(a,R_WO_PARTS_ID)*/ serial_no
                 INTO cmlb_sn
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                        UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                     , r_wo_parts a
                WHERE b.wo_parts_id = a.ID                  
                  AND b.wip_id = rec_wip_info.wip_id
                  AND a.wo_id = rec_wip_info.wo_id
                  AND a.part_name || '' = 'GRP'
                  AND a.del_flag = 0
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'GRP_SN:' || cmlb_sn || ';';
            ELSE
               burninfo := 'GRP SN not found';
               RAISE my_exception;
            END IF;
         END IF;

         IF (INSTR (cparam, 'LCG_SN') > 0) 
            AND (rec_wip_info.category_key = 'N90' or rec_wip_info.category_key = 'N92' or rec_wip_info.category_key = 'N90A')
         THEN
            SELECT /*+ index(a,R_WO_PARTS_ID)*/ COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                     UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                  , r_wo_parts a
             WHERE b.wo_parts_id = a.ID               
               AND b.wip_id = rec_wip_info.wip_id
               AND a.wo_id = rec_wip_info.wo_id
               AND a.part_name || '' = 'LCG'
               AND a.del_flag = 0
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT /*+ index(a,R_WO_PARTS_ID)*/ serial_no
                 INTO cmlb_sn
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                        UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                     , r_wo_parts a
                WHERE b.wo_parts_id = a.ID                  
                  AND b.wip_id = rec_wip_info.wip_id
                  AND a.wo_id = rec_wip_info.wo_id
                  AND a.part_name || '' = 'LCG'
                  AND a.del_flag = 0
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'LCG_SN:' || cmlb_sn || ';';
            ELSE
               burninfo := 'LCG SN not found';
               RAISE my_exception;
            END IF;
         END IF;
         
         IF (INSTR (cparam, 'BAN_SN') > 0) 
            AND (rec_wip_info.category_key = 'N92')
         THEN
            SELECT /*+ index(a,R_WO_PARTS_ID)*/ COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                     UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                  , r_wo_parts a
             WHERE b.wo_parts_id = a.ID               
               AND b.wip_id = rec_wip_info.wip_id
               AND a.wo_id = rec_wip_info.wo_id
               AND a.part_name || '' = 'BAN'
               AND a.del_flag = 0
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT /*+ index(a,R_WO_PARTS_ID)*/ serial_no
                 INTO cmlb_sn
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                        UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b
                     , r_wo_parts a
                WHERE b.wo_parts_id = a.ID                  
                  AND b.wip_id = rec_wip_info.wip_id
                  AND a.wo_id = rec_wip_info.wo_id
                  AND a.part_name || '' = 'BAN'
                  AND a.del_flag = 0
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'BAN_SN:' || cmlb_sn || ';';
            ELSE
               burninfo := 'BAN SN not found';
               RAISE my_exception;
            END IF;
         END IF;         
       

         IF (INSTR (cparam, 'BAN_SN') > 0) 
            AND ((rec_wip_info.category_key = 'N90') or (rec_wip_info.category_key = 'N90A'))
         THEN
               SELECT COUNT (ID)
                 INTO irecordcount
               FROM(
                SELECT /*+ index(b,R_WO_PARTS_ID)*/ b.ID
                 FROM  r_wo_parts a,
                        r_wip_parts  b,
                       r_wip c
                WHERE c.NO =
                         (SELECT /*+ index(b,R_WO_PARTS_ID)*/ a.serial_no
                            FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                                   UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a
                                , r_wo_parts b
                           WHERE a.wo_parts_id = b.ID
                             AND a.wip_id = rec_wip_info.wip_id
                             AND b.wo_id = rec_wip_info.wo_id
                             AND b.part_name || '' = 'BAND'
                             AND a.del_flag = 0
                             AND b.del_flag = 0)
                  AND c.ID = b.wip_id
                  AND b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'BAN'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND c.del_flag = 0
                UNION ALL
                SELECT /*+ index(b,R_WO_PARTS_ID)*/ b.ID
                 FROM  r_wo_parts a,
                        r_wip_parts_1  b,
                       r_wip c
                WHERE c.NO =
                         (SELECT /*+ index(b,R_WO_PARTS_ID)*/ a.serial_no
                            FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                                   UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a
                                , r_wo_parts b
                           WHERE a.wo_parts_id = b.ID
                             AND a.wip_id = rec_wip_info.wip_id
                             AND b.wo_id = rec_wip_info.wo_id
                             AND b.part_name || '' = 'BAND'
                             AND a.del_flag = 0
                             AND b.del_flag = 0)
                  AND c.ID = b.wip_id
                  AND b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'BAN'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND c.del_flag = 0
                  );

            IF irecordcount > 0
            THEN
                  SELECT serial_no
                    INTO cBan_sn
                 FROM(
                    SELECT /*+ index(a,R_WO_PARTS_ID)*/ b.Serial_No
                    FROM  r_wo_parts a,
                           r_wip_parts  b,
                          r_wip c
                   WHERE c.NO =
                            (SELECT /*+ index(b,R_WO_PARTS_ID)*/ a.serial_no
                               FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                                      UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a
                                   , r_wo_parts b
                              WHERE a.wo_parts_id = b.ID
                                AND a.wip_id = rec_wip_info.wip_id
                                AND b.wo_id = rec_wip_info.wo_id
                                AND b.part_name || '' = 'BAND'
                                AND a.del_flag = 0
                                AND b.del_flag = 0)
                     AND c.ID = b.wip_id
                     AND b.wo_parts_id = a.ID
                     AND a.part_name || '' = 'BAN'
                     AND a.del_flag = 0
                     AND b.del_flag = 0
                     AND c.del_flag = 0
                UNION ALL
                    SELECT /*+ index(a,R_WO_PARTS_ID)*/ b.Serial_No
                    FROM  r_wo_parts a,
                           r_wip_parts_1  b,
                          r_wip c
                   WHERE c.NO =
                            (SELECT /*+ index(b,R_WO_PARTS_ID)*/ a.serial_no
                               FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id 
                                      UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a
                                   , r_wo_parts b
                              WHERE a.wo_parts_id = b.ID
                                AND a.wip_id = rec_wip_info.wip_id
                                AND b.wo_id = rec_wip_info.wo_id
                                AND b.part_name || '' = 'BAND'
                                AND a.del_flag = 0
                                AND b.del_flag = 0)
                     AND c.ID = b.wip_id
                     AND b.wo_parts_id = a.ID
                     AND a.part_name || '' = 'BAN'
                     AND a.del_flag = 0
                     AND b.del_flag = 0
                     AND c.del_flag = 0
                );


               lgoon := 'TRUE';
               burninfo := burninfo || 'BAN_SN:' || cBan_sn || ';';
            ELSE
               burninfo := 'BAN SN not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'BUILD_TYPE') > 0
         THEN
            --cBUILD_TYPE:= 'L';
            IF rec_wip_info.model_type = 'LOANER'
            THEN
               cbuild_type := 'L';
            ELSIF rec_wip_info.model_type = 'REPLACEMENT'
            THEN
               cbuild_type := 'R';
            ELSE
               cbuild_type := 'N';
            END IF;

            lgoon := 'TRUE';
            burninfo := burninfo || 'BUILD_TYPE:' || cbuild_type || ';';
         END IF;

         IF INSTR (cparam, 'HWCONFIG') > 0
         THEN
            SELECT COUNT(1)  INTO iRecordCount FROM C_Apple_HWConfig WHERE Category_key = rec_wip_info.Category_key  AND CCC_Code = rec_wip_info.CCC_Code AND del_flag = 0;

            IF iRecordCount = 1 THEN
                SELECT HWConfig INTO cHWCONFIG FROM C_Apple_HWConfig WHERE Category_key = rec_wip_info.Category_key  AND CCC_Code = rec_wip_info.CCC_Code AND del_flag = 0;
                lgoon := 'TRUE';
                burninfo := burninfo || 'HWCONFIG:' || cHWCONFIG || ';';
            ELSE
               burninfo := 'HWCONFIG not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF lgoon <> 'TRUE'
         THEN
            burninfo := 'parameter ' || cparam || ' not defined!';
            RAISE my_exception;
         END IF;

         istart := iposition;
      END LOOP;

      RETURN 'OKOK;' || burninfo;
-----------------------------------------------------------------------------------------------------------
   ELSE
      burninfo := '0 parameters found!';
      RAISE my_exception;
   END IF;
--------------------------------------------------------------------------------------------------------
EXCEPTION
   WHEN my_exception
   THEN
      RETURN 'FALSE;' || burninfo;
   WHEN OTHERS
   THEN
      RETURN 'FALSE;OTHER ERROR!';
END;


/

