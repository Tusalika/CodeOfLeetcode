create FUNCTION        getburninfo3 (
   cModel         IN   VARCHAR2,
   cparam        IN   VARCHAR2
)
   RETURN VARCHAR2
AS
iRecordCount NUMBER;
cResult VARCHAR2(255);
BEGIN
    SELECT COUNT(1) INTO iRecordCount FROM C_APPLE_HWCONFIG
        WHERE Category_key = cModel AND CCC_Code = cParam AND del_flag = 0;

   IF  iRecordCount = 1 THEN
        SELECT HWConfig INTO cResult FROM C_APPLE_HWCONFIG
            WHERE Category_key = cModel AND CCC_Code = cParam AND del_flag = 0;

        RETURN 'OKOK;' || cResult || ';';
   ELSE
       RETURN 'FALSE;' || 'Data not found' || ';';
   END IF;
END;


/

