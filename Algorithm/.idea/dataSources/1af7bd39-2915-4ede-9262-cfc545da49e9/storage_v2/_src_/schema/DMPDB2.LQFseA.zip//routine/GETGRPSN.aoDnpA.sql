create FUNCTION        getgrpsn (
   cwipno         IN   VARCHAR2,
   cstationcode   IN   VARCHAR2,
   cparams        IN   VARCHAR2
--STORAGE_SIZE_LOW; STORAGE_SIZE_HIGH; CUST_PART_NO; BATTERY_SN; IMEI; ICC_ID; BUILD_TYPE
)
   RETURN VARCHAR2
AS
   burninfo             VARCHAR2 (255);
   icommodityid         NUMBER;
   cstorage_size_low    VARCHAR2 (10);                                  --1.5
   cstorage_size_high   VARCHAR2 (10);                                  --2.0
   ccust_part_no        VARCHAR2 (20);                            --MA501LL/A
   cbattery_sn          VARCHAR2 (30);                          --ABCDEFGBTYA
   cgrp_sn              VARCHAR2 (30);                         --ABCDEFGDERWE
   cimei                VARCHAR2 (30);                      --012345678912345
   cicc_id              VARCHAR2 (30);                  --3023514562854531542
   cbuild_type          VARCHAR2 (10);  --L: Loaner; N: Normal; R: Replacment
   cerror_message       VARCHAR2 (255);
   irecordcount         NUMBER;
   istart               NUMBER;
   iposition            NUMBER;
   cparam               VARCHAR2 (255);
   ctemp                VARCHAR (255);
   cto_station          VARCHAR2 (2);
   lgoon                VARCHAR2 (10);
   cTiltSN            VARCHAR2(20);
   cTiltID            NUMBER;

   TYPE r_record IS RECORD (
      wip_id             r_wip.ID%TYPE,
      wip_no             r_wip.NO%TYPE,
      defect_flag        r_wip.defect_flag%TYPE,
      route_id           r_wip.route_id%TYPE,
      route_history      r_wip.route_history%TYPE,
      finish_flag        r_wip.finish_flag%TYPE,
      lock_flag          r_wip.lock_flag%TYPE,
      pre_station_code   r_wip.pre_station_code%TYPE,
      wo_id              r_wo.ID%TYPE,
      is_msr             r_wo.is_msr%TYPE,
      is_allow_input     r_wo.is_allow_input%TYPE,
      close_flag         r_wo.close_flag%TYPE,
      category_key       product.category_key%TYPE,
      process_lock_id    r_wip.process_lock_id%TYPE,
      cust_part_no       r_wip.cust_part_no%TYPE,
      model_type         c_part_no_add_prop.cust_part_type%TYPE
   );

   rec_wip_info         r_record;
   my_exception         EXCEPTION;
BEGIN
   burninfo := '';
   icommodityid := 33;
   cstorage_size_low := '';
   cstorage_size_high := '';
   ccust_part_no := '';
   cbattery_sn := '';
   cimei := '';
   cicc_id := '';
   cbuild_type := '';
   ctemp := '';
   istart := 0;
   iposition := 0;

   SELECT COUNT (*)
     INTO irecordcount
     FROM  r_wip a,  r_wo b,  product c
    WHERE a.commodity_id = icommodityid
      AND a.del_flag = 0
      AND b.product_id = c.ID
      AND a.wo_id = b.ID
      AND a.NO = cwipno;

   IF irecordcount <= 0
   THEN
      burninfo := 'INVALID WIP NO!';
      RAISE my_exception;
   END IF;

   SELECT a.ID AS wip_id,
          a.NO AS wip_no,
          a.defect_flag,
          a.route_id,
          a.route_history,
          a.finish_flag,
          a.lock_flag,
          a.pre_station_code,
          b.ID AS wo_id,
          b.is_msr,
          b.is_allow_input,
          b.close_flag,
          c.category_key,
          a.process_lock_id,
          a.cust_part_no,
          c.property_22
     INTO rec_wip_info
     FROM  r_wip a,  r_wo b,  product c
    WHERE a.commodity_id = icommodityid
      AND a.del_flag = 0
      AND b.product_id = c.ID
      AND a.wo_id = b.ID
      AND a.NO = cwipno;

   IF (rec_wip_info.wip_id IS NULL)
   THEN
      burninfo := 'INVALID WIP NO!';
      RAISE my_exception;
   END IF;

   SELECT COUNT (*)
     INTO irecordcount
     FROM  c_part_no_add_prop
    WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

   IF irecordcount <= 0
   THEN
      burninfo := 'NO BURN PART NO FIND!';
      RAISE my_exception;
   END IF;

   SELECT cust_part_type
     INTO rec_wip_info.model_type
     FROM  c_part_no_add_prop
    WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

   IF LENGTH (cparams) > 0
   THEN
      LOOP
         iposition := INSTR (cparams, ';', istart + 1, 1);
         EXIT WHEN iposition = 0;
         lgoon := 'FAILE';
         cparam :=
                  TRIM (SUBSTR (cparams, istart + 1, iposition - istart - 1));

         IF INSTR (cparam, 'STORAGE_SIZE_LOW') > 0
         THEN
            --cSTORAGE_SIZE_LOW:= '1.5';
            SELECT TO_CHAR (storage_size_1)
              INTO cstorage_size_low
              FROM  c_ipod_add_prop
             WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

            lgoon := 'TRUE';
            burninfo :=
                   burninfo || 'STORAGE_SIZE_LOW:' || cstorage_size_low || ';';
         END IF;

         IF INSTR (cparam, 'STORAGE_SIZE_HIGH') > 0
         THEN
            --cSTORAGE_SIZE_HIGH:= '2.0';
            SELECT TO_CHAR (storage_size_2)
              INTO cstorage_size_high
              FROM  c_ipod_add_prop
             WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

            lgoon := 'TRUE';
            burninfo :=
                 burninfo || 'STORAGE_SIZE_HIGH:' || cstorage_size_high || ';';
         END IF;

         IF INSTR (cparam, 'CUST_PART_NO') > 0
         THEN
            --cCUST_PART_NO:= 'MA501LL/A';
            SELECT burn_part_no
              INTO ccust_part_no
              FROM  c_part_no_add_prop
             WHERE cust_part_no = rec_wip_info.cust_part_no AND del_flag = 0;

            lgoon := 'TRUE';
            burninfo := burninfo || 'CUST_PART_NO:' || ccust_part_no || ';';
         END IF;

         IF INSTR (cparam, 'BATTERY_SN') > 0
         THEN
            --cBATTERY_SN:= 'ABCDEFGBTYA';
            SELECT COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b,  r_wo_parts a
             WHERE b.wo_parts_id = a.ID
               AND a.part_name || '' = 'BTY'
               AND b.wip_id = rec_wip_info.wip_id
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT serial_no
                 INTO cbattery_sn
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b,  r_wo_parts a
                WHERE b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'BTY'
                  AND b.wip_id = rec_wip_info.wip_id
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'BATTERY_SN:' || cbattery_sn || ';';
            ELSE
               burninfo := 'Battery SN not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'IMEI') > 0
         THEN
            --cIMEI:= '012345678912345';
            SELECT COUNT (*)
              INTO irecordcount
              FROM  r_wip
             WHERE NO = cwipno AND del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT property_15
                 INTO cimei
                 FROM  r_wip
                WHERE NO = cwipno AND del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'IMEI:' || cimei || ';';
            ELSE
               burninfo := 'IMEI not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'ICC_ID') > 0
         THEN
            --cICC_ID:= '3023514562854531542';
            SELECT COUNT (*)
              INTO irecordcount
              FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b,  r_wo_parts a
             WHERE b.wo_parts_id = a.ID
               AND a.part_name || '' = 'SIM1'
               AND b.wip_id = rec_wip_info.wip_id
               AND b.del_flag = 0;

            IF irecordcount > 0
            THEN
               SELECT NVL (serial_no, ' ')
                 INTO cicc_id
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b,  r_wo_parts a
                WHERE b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'SIM1'
                  AND b.wip_id = rec_wip_info.wip_id
                  AND b.del_flag = 0;

               lgoon := 'TRUE';
               burninfo := burninfo || 'ICC_ID:' || cicc_id || ';';
            ELSE
               burninfo := 'ICC ID not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'GRP_SN') > 0
         THEN
            IF    rec_wip_info.category_key = 'N82'
               OR rec_wip_info.category_key = 'N82A'
               OR rec_wip_info.category_key = 'N82C'
               OR rec_wip_info.category_key = 'N80'
               OR rec_wip_info.category_key = 'N88'
               OR rec_wip_info.category_key = 'N88A'
               OR rec_wip_info.category_key = 'N88C'
               OR rec_wip_info.category_key = 'N90'
            THEN
               --N82取GRP方式于M68不同
               SELECT COUNT (ID)
                 INTO irecordcount
               FROM(
                SELECT b.ID
                 FROM  r_wo_parts a,
                        r_wip_parts  b,
                       r_wip c
                WHERE c.NO =
                         (SELECT a.serial_no
                            FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a,  r_wo_parts b
                           WHERE a.wip_id = rec_wip_info.wip_id
                             AND a.wo_parts_id = b.ID
                             AND b.part_name || '' = 'TLT'
                             AND a.del_flag = 0
                             AND b.del_flag = 0)
                  AND c.ID = b.wip_id
                  AND b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'GRP'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND c.del_flag = 0
                UNION ALL
                SELECT b.ID
                 FROM  r_wo_parts a,
                        r_wip_parts_1  b,
                       r_wip c
                WHERE c.NO =
                         (SELECT a.serial_no
                            FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a,  r_wo_parts b
                           WHERE a.wip_id = rec_wip_info.wip_id
                             AND a.wo_parts_id = b.ID
                             AND b.part_name || '' = 'TLT'
                             AND a.del_flag = 0
                             AND b.del_flag = 0)
                  AND c.ID = b.wip_id
                  AND b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'GRP'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND c.del_flag = 0
                  );
            ELSE
               SELECT COUNT (*)
                 INTO irecordcount
                 FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b,  r_wo_parts a
                WHERE b.wo_parts_id = a.ID
                  AND a.part_name || '' = 'GRP'
                  AND b.wip_id = rec_wip_info.wip_id
                  AND b.del_flag = 0;
            END IF;

            IF irecordcount > 0
            THEN
               IF    rec_wip_info.category_key = 'N82'
                  OR rec_wip_info.category_key = 'N82A'
                  OR rec_wip_info.category_key = 'N82C'
                  OR rec_wip_info.category_key = 'N80'
                  OR rec_wip_info.category_key = 'N88'
                  OR rec_wip_info.category_key = 'N88A'
                  OR rec_wip_info.category_key = 'N88C'
                  OR rec_wip_info.category_key = 'N90'
               THEN
                  SELECT serial_no
                    INTO cgrp_sn
                 FROM(
                    SELECT b.Serial_No
                    FROM  r_wo_parts a,
                           r_wip_parts  b,
                          r_wip c
                   WHERE c.NO =
                            (SELECT a.serial_no
                               FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a,  r_wo_parts b
                              WHERE a.wip_id = rec_wip_info.wip_id
                                AND a.wo_parts_id = b.ID
                                AND b.part_name || '' = 'TLT'
                                AND a.del_flag = 0
                                AND b.del_flag = 0)
                     AND c.ID = b.wip_id
                     AND b.wo_parts_id = a.ID
                     AND a.part_name || '' = 'GRP'
                     AND a.del_flag = 0
                     AND b.del_flag = 0
                     AND c.del_flag = 0
                UNION ALL
                    SELECT b.Serial_No
                    FROM  r_wo_parts a,
                           r_wip_parts_1  b,
                          r_wip c
                   WHERE c.NO =
                            (SELECT a.serial_no
                               FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) a,  r_wo_parts b
                              WHERE a.wip_id = rec_wip_info.wip_id
                                AND a.wo_parts_id = b.ID
                                AND b.part_name || '' = 'TLT'
                                AND a.del_flag = 0
                                AND b.del_flag = 0)
                     AND c.ID = b.wip_id
                     AND b.wo_parts_id = a.ID
                     AND a.part_name || '' = 'GRP'
                     AND a.del_flag = 0
                     AND b.del_flag = 0
                     AND c.del_flag = 0
                );
               ELSE
                  SELECT serial_no
                    INTO cgrp_sn
                    FROM  (SELECT * FROM r_wip_parts WHERE Wip_id =  rec_wip_info.wip_id UNION ALL SELECT * FROM r_wip_parts_1 WHERE Wip_id =  rec_wip_info.wip_id) b,  r_wo_parts a
                   WHERE b.wo_parts_id = a.ID
                     AND a.part_name || '' = 'GRP'
                     AND b.wip_id = rec_wip_info.wip_id
                     AND b.del_flag = 0;
               END IF;

               lgoon := 'TRUE';
               burninfo := burninfo || 'GRP_SN:' || cgrp_sn || ';';
            ELSE
               burninfo := 'GRP SN not found!';
               RAISE my_exception;
            END IF;
         END IF;

         IF INSTR (cparam, 'BUILD_TYPE') > 0
         THEN
            --cBUILD_TYPE:= 'L';
            IF rec_wip_info.model_type = 'LOANER'
            THEN
               cbuild_type := 'L';
            ELSIF rec_wip_info.model_type = 'REPLACEMENT'
            THEN
               cbuild_type := 'R';
            ELSE
               cbuild_type := 'N';
            END IF;

            lgoon := 'TRUE';
            burninfo := burninfo || 'BUILD_TYPE:' || cbuild_type || ';';
         END IF;

         IF lgoon <> 'TRUE'
         THEN
            burninfo := 'parameter ' || cparam || ' not defined!';
            RAISE my_exception;
         END IF;

         istart := iposition;
      END LOOP;

      RETURN 'OKOK;' || burninfo;
-----------------------------------------------------------------------------------------------------------
   ELSE
      burninfo := '0 parameters found!';
      RAISE my_exception;
   END IF;
--------------------------------------------------------------------------------------------------------
EXCEPTION
   WHEN my_exception
   THEN
      RETURN 'FALSE;' || burninfo;
   WHEN OTHERS
   THEN
      RETURN 'FALSE;OTHER ERROR!';
END;


/

