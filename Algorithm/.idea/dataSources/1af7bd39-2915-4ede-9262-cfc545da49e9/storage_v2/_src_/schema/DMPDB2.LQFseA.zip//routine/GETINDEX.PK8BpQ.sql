create PROCEDURE        Getindex
 AS
        ind_name VARCHAR2(50);
        col_name VARCHAR2(50);
        str VARCHAR2(200);
        tlb_name VARCHAR2(50);
        ind_type VARCHAR2(50);
        tlb_owner VARCHAR2(50);
         uniques VARCHAR2(50);
        SS INTEGER;
        sqlstr VARCHAR2(300);
        tlbstr VARCHAR2(50);
        OWNER_NAME VARCHAR2(50):='DMPDB2';



      CURSOR tlbcursor IS
             SELECT table_name FROM DBA_TABLES WHERE OWNER =OWNER_NAME ORDER BY table_name;
     CURSOR INDCURSOR IS
             SELECT INDEX_NAME,INDEX_TYPE,TABLE_OWNER,TABLE_NAME,UNIQUENESS
             FROM DBA_INDEXES
             WHERE TABLE_NAME=tlb_name AND OWNER =OWNER_NAME  ;
     CURSOR colcursor IS
             SELECT COLUMN_NAME FROM DBA_IND_COLUMNS
                 WHERE INDEX_NAME =ind_name AND TABLE_OWNER=OWNER_NAME
                  ORDER BY INDEX_NAME,COLUMN_POSITION;
     BEGIN
       OPEN tlbcursor;
        LOOP
         FETCH tlbcursor INTO tlb_name;
          EXIT WHEN tlbcursor%NOTFOUND;
          str:=tlb_name;
          SELECT COUNT(*) INTO SS FROM USER_INDEXES WHERE TABLE_NAME=STR;
          IF SS>0 THEN
          BEGIN
             OPEN INDCURSOR;
              LOOP
              FETCH INDCURSOR INTO IND_NAME,IND_TYPE,TLB_OWNER,TLB_NAME,UNIQUES;
                EXIT WHEN INDCURSOR%NOTFOUND;
                OPEN colcursor;
                  str:=' ';
                 LOOP
                  FETCH colcursor INTO col_name ;
                   EXIT WHEN  colcursor%NOTFOUND;
                   STR:=str||col_name||' , ';
                 END LOOP ;
                 STR:=SUBSTR(STR,1,(LENGTH(STR)-2));
                 INSERT INTO DMPDB2.INDEX_COUNT (INDEX_NAME,INDEX_TYPE,TABLE_NAME,TABLE_OWNER,UNIQUENESS,COLUMN_NAME)
                   VALUES(IND_NAME,IND_TYPE,TLB_NAME,TLB_OWNER,UNIQUES,str);
              CLOSE colcursor;
             END LOOP;
             CLOSE INDCURSOR;
             tlbstr:=''''||tlb_name||'''';
           sqlstr:='UPDATE DMPDB2.INDEX_COUNT SET TABLE_ROW=(SELECT COUNT(*) FROM '||OWNER_NAME||'.'||tlb_name||') WHERE TABLE_NAME='||tlbstr;
         EXECUTE IMMEDIATE sqlstr;
            END;
           ELSE
             INSERT INTO DMPDB2.INDEX_COUNT(INDEX_NAME,INDEX_TYPE,TABLE_NAME,TABLE_OWNER,UNIQUENESS,COLUMN_NAME)
                  VALUES(NULL,NULL,STR,OWNER_NAME,NULL,NULL);
               tlbstr:=''''||tlb_name||'''';
          sqlstr:='UPDATE DMPDB2.INDEX_COUNT SET TABLE_ROW=(SELECT COUNT(*) FROM '||OWNER_NAME||'.'||tlb_name||') WHERE TABLE_NAME='||tlbstr;
          EXECUTE IMMEDIATE sqlstr;
           END IF;
        END LOOP;
        COMMIT;
      CLOSE tlbcursor ;
    END;


/

