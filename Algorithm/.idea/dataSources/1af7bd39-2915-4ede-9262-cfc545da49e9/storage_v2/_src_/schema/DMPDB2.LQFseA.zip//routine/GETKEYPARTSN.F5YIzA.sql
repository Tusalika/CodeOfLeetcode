create FUNCTION        getKeyPartSN(wipno IN VARCHAR2, partname IN VARCHAR2)
 RETURN VARCHAR2
AS
  cRes VARCHAR2(30);
  wipid NUMBER;
  iRecordcount NUMBER;
BEGIN
  cRes := '';

  SELECT COUNT(1) INTO iRecordcount FROM r_wip WHERE no = wipno;
  IF iRecordcount > 0 THEN
      SELECT MAX(id) INTO wipid FROM r_wip WHERE no = wipno;

      INSERT INTO R_WIP_Parts_T
      SELECT a.* FROM R_WIP_Parts a
          , R_WO_Parts b
         WHERE a.wo_Parts_id = b.id
             AND a.wip_id = wipid
             AND b.Part_name  || ''  =  partname;

      INSERT INTO R_WIP_Parts_T
      SELECT a.* FROM R_WIP_Parts_1 a
          , R_WO_Parts b
         WHERE a.wo_Parts_id = b.id
             AND a.wip_id = wipid
             AND b.Part_name  || ''  =  partname;

      SELECT COUNT(1) INTO iRecordCount  FROM R_WIP_Parts_T
      WHERE wip_id = wipid;

      IF iRecordCount > 0 THEN
          SELECT Serial_No INTO cRes FROM R_WIP_Parts_T
              WHERE Scan_Time = (SELECT MAX(Scan_Time) FROM R_WIP_Parts_T  WHERE wip_id = wipid)
                     AND ROWNUM = 1;
      END IF;

      COMMIT;
  END IF;

  RETURN cRes;
END;


/

