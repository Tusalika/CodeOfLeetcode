create FUNCTION        GetQT0Info (cwipno IN VARCHAR2)
---- create by jicaiming
---- create date 2009/8/5
   RETURN VARCHAR2
AS
   lPAT1             INT;
   lPAT2             INT;
   lGrounding1   INT;
   lGrounding2   INT;

   iRecordCount INT;
   cRes VARCHAR2(255);
BEGIN
    lPAT1 :=  0;
    lPAT2 :=  0;
    lGrounding1 := 0;
    lGrounding2 := 0;

    SELECT COUNT(ID) INTO iRecordCount
        FROM CR_PAT1_LOG
        WHERE Wip_No = cwipno
                AND Del_Flag = 1;
    IF iRecordCount > 0 THEN
        lPAT1 := 1;
    END IF;

    SELECT COUNT(ID) INTO iRecordCount
        FROM CR_PAT2_LOG
        WHERE Wip_No = cwipno
                AND Del_Flag = 1;
    IF iRecordCount > 0 THEN
        lPAT2 := 1;
    END IF;

    SELECT COUNT(ID) INTO iRecordCount
        FROM CR_GROUNDING1_LOG
        WHERE Wip_No = cwipno
                AND Del_Flag = 1;
    IF iRecordCount > 0 THEN
        lGrounding1 := 1;
    END IF;

    SELECT COUNT(ID) INTO iRecordCount
        FROM CR_GROUNDING2_LOG
        WHERE Wip_No = cwipno
                AND Del_Flag = 1;
    IF iRecordCount > 0 THEN
        lGrounding2 := 1;
    END IF;

    IF     (lPAT1 = 0) OR  (lPAT2 = 0) OR (lGrounding1 = 0) OR (lGrounding2 = 0) THEN
        cRes := 'FAIL;';

        IF lPAT1 > 0 THEN
            cRes := cRes || 'PAT1:OK;';
        ELSE
            cRes := cRes || 'PAT1:FAIL-no record found;';
        END IF;

        IF lPAT2 > 0 THEN
            cRes := cRes || 'PAT2:OK;';
        ELSE
            cRes := cRes || 'PAT2:FAIL-no record found;';
        END IF;

        IF lGrounding1 > 0 THEN
            cRes := cRes || 'GROUNDING1:OK;';
        ELSE
            cRes := cRes || 'GROUNDING1:FAIL-no record found;';
        END IF;

        IF lGrounding2 > 0 THEN
            cRes := cRes || 'GROUNDING2:OK;';
        ELSE
            cRes := cRes || 'GROUNDING2:FAIL-no record found;';
        END IF;
    ELSE
        cRes := 'OKOK;PAT1:OK;PAT2:OK;GROUNDING1:OK;GROUNDING2:OK;';
    END IF;

    RETURN  cRes;
--------------------------------------------------------------------------------------------------------
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN 'FAIL;OTHER ERROR!';
END;


/

