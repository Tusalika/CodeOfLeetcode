create PROCEDURE        GetSfcStationInfo(cStationCode IN VARCHAR2, Delflag IN NUMBER, cCode OUT VARCHAR2, cType OUT VARCHAR2,
cCName OUT VARCHAR2, cEName OUT VARCHAR2)
AS
   cCommodityID NUMBER;
BEGIN
    cCommodityID := constant_package.g_commodity_id;
    SELECT Code, Type, NameC, NameE INTO cCode, cType, cCName, cEName 
      FROM Station
      WHERE COMMODITY_ID = cCommodityID
      AND CODE = cStationCode
      AND DEL_FLAG = Delflag;
EXCEPTION         
   WHEN NO_DATA_FOUND  
   THEN  
     cCode :='';  
     cType :='';
     cCName := '';
     cEName:= '';                     
END;


/

