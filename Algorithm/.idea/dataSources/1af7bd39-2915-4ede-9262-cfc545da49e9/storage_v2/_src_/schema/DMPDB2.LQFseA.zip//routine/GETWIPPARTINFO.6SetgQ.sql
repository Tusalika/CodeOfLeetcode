create PROCEDURE        GETWIPPARTINFO(cWipNo IN VARCHAR2, cPartNames IN VARCHAR2, cInfo OUT VARCHAR2)
IS
  iWipID   INT; 
  iWoID   INT;
  iProcessID INT;
  cPartName  VARCHAR2(30);
  cPartType  VARCHAR2(30); 
  iCount INT; 
  iPos  INT;
  cSerialNo VARCHAR2(100);
  dAddTime Date;  
  cPartNo VARCHAR2(100);
  cLotCode VARCHAR2(200); 
  cDateCode VARCHAR2(200);
  cTmpPartNames VARCHAR2(500);
  
BEGIN
   --Get Wip info
  BEGIN 
    SELECT a.id, a.Wo_ID, b.Process_ID  into iWipID, iWoID, iProcessID
      FROM R_Wip a, R_Wo b  
     WHERE a.No = cWipNo       
       AND a.Del_Flag = 0
       AND b.ID = a.Wo_ID;
       
  EXCEPTION
    WHEN NO_DATA_FOUND 
    THEN
      --cInfo := 'invalid WipNo!';
      cInfo := '';
    WHEN OTHERS
    THEN
      --cInfo := 'Get Wip ID' || SUBSTR(SQLERRM, 1, 255) ;
      cInfo := '';
      
    GOTO end_of_function;   
  END;

  IF cPartNames <> '' THEN
      SELECT '(''' || REPLACE(cPartNames,',',''',''')  ||''')' INTO cTmpPartNames from dual;
  END IF;
     
  --Get Wip Parts info
  IF cPartNames <> ''
  THEN
    DECLARE
        CURSOR KeyPartCusor IS      
         SELECT aa.SERIAL_NO, aa.SCAN_TIME,bb.Cust_Part_No, bb.Part_Name  
           FROM (
                 SELECT Serial_No, Scan_Time, Wo_Parts_ID
                   FROM R_Wip_Parts
                  WHERE Wip_ID = iWipID
                    AND Del_Flag = 0
                  UNION ALL
                 SELECT Serial_No, Scan_Time, Wo_Parts_ID
                   FROM R_Wip_Parts_1
                  WHERE Wip_ID = iWipID
                    AND Del_Flag = 0) aa, R_Wo_Parts bb, C_PARTNAME_MAP cc
          WHERE aa.Wo_Parts_ID = bb.ID
            AND bb.Part_Name = cc.HH_Part_Name;
    BEGIN
      OPEN KeyPartCusor;
      LOOP
      FETCH KeyPartCusor INTO cSerialNO, dAddTime, cPartNo, cPartName;
      EXIT WHEN KeyPartCusor%NOTFOUND;                
        cInfo := cInfo || 'module::'|| cPartName || '::sn=' ||cSerialNo ||CHR(10)
                       || 'module::'|| cPartName || '::part_num=' ||cPartNo ||CHR(10)
                       || 'module::'|| cPartName || '::add_time=' ||to_char(dAddTime, 'yyyy-mm-dd hh24:mi:ss') ||CHR(10) ;       
      END LOOP;
      CLOSE KeyPartCusor;
    END; 
  ELSE
    DECLARE
        CURSOR KeyPartCusor IS      
         SELECT aa.SERIAL_NO, aa.SCAN_TIME,bb.Cust_Part_No, bb.Part_Name  
           FROM (
                 SELECT Serial_No, Scan_Time, Wo_Parts_ID
                   FROM R_Wip_Parts
                  WHERE Wip_ID = iWipID
                    AND Del_Flag = 0
                  UNION ALL
                 SELECT Serial_No, Scan_Time, Wo_Parts_ID
                   FROM R_Wip_Parts_1
                  WHERE Wip_ID = iWipID
                    AND Del_Flag = 0) aa, R_Wo_Parts bb, C_PARTNAME_MAP cc
          WHERE aa.Wo_Parts_ID = bb.ID
            AND bb.Part_Name = cc.HH_Part_Name
            AND cc.Apple_Part_Name in cTmpPartNames;
    BEGIN
      OPEN KeyPartCusor;
      LOOP
      FETCH KeyPartCusor INTO cSerialNO, dAddTime, cPartNo, cPartName;
      EXIT WHEN KeyPartCusor%NOTFOUND;                
        cInfo := cInfo || 'module::'|| cPartName || '::sn=' ||cSerialNo ||CHR(10)
                       || 'module::'|| cPartName || '::part_num=' ||cPartNo ||CHR(10)
                       || 'module::'|| cPartName || '::add_time=' ||to_char(dAddTime, 'yyyy-mm-dd hh24:mi:ss') ||CHR(10) ;       
      END LOOP;
      CLOSE KeyPartCusor;
    END;   
  END IF;

  
  --Get Wip Lot 
  IF cPartNames <> ''
  THEN
    DECLARE 
          CURSOR LOtCusor IS 
         SELECT  LOT_NO, Cust_Part_No, Station_Time, Part_Name 
           FROM ( 
                 SELECT /*+ INDEX(b IX_WIP_LOG_1_WIP_ID, a IX_LOT_USE_LINE_ID_PART_NO_T) */
                       a.LOT_NO, a.Cust_Part_No, b.Station_Time, a.Part_Name 
                   FROM dmpdb2.r_wip_log_1 b, dmpdb2.r_lot_used a, dmpdb2.station_location c
                  WHERE b.wip_id = iWipID
                    AND b.station_time >= a.input_time
                    AND b.station_time <= NVL (a.end_time, SYSDATE)
                    AND c.ID = b.location_id
                    AND a.line_id = b.line_id
                    AND a.station_no = c.station_no
                    AND a.station_code = c.station_code
                    AND b.fresh_flag = 1
                    AND b.station_time - a.input_time < 1
                  UNION All   
                 SELECT /*+ INDEX(b IX_WIP_LOG_1_WIP_ID, a IX_LOT_USE_LINE_ID_PART_NO_T) */
                       a.LOT_NO, a.Cust_Part_No, b.Station_Time, a.Part_Name 
                   FROM dmpdb2.r_wip_log b, dmpdb2.r_lot_used a, dmpdb2.station_location c
                  WHERE b.wip_id = iWipID
                    AND b.station_time >= a.input_time
                    AND b.station_time <= NVL (a.end_time, SYSDATE)
                    AND c.ID = b.location_id
                    AND a.line_id = b.line_id
                    AND a.station_no = c.station_no
                    AND a.station_code = c.station_code
                    AND b.fresh_flag = 1
                    AND b.station_time - a.input_time < 1
                 ) aa, C_PARTNAME_MAP bb
          WHERE aa.Part_Name = bb.HH_Part_Name
            AND bb.Apple_Part_Name in cTmpPartNames;
    BEGIN
      OPEN LOtCusor;
      LOOP
      FETCH LOtCusor INTO cLotCode, cPartNo, dAddTime, cPartName;
      EXIT WHEN LOtCusor%NOTFOUND;                                                           
         cInfo := cInfo || 'module::'|| cPartName || '::lot_code=' ||cLotCode ||CHR(10)
                        || 'module::'|| cPartName || '::part_num=' ||cPartNo ||CHR(10)
                        || 'module::'|| cPartName || '::add_time=' ||to_char(dAddTime, 'yyyy-mm-dd hh24:mi:ss') ||CHR(10) ;       
             
                  
      END LOOP;
      CLOSE LOtCusor;
    END;                   
  ELSE
    DECLARE 
          CURSOR LOtCusor IS 
         SELECT  LOT_NO, Cust_Part_No, Station_Time, Part_Name 
           FROM ( 
                 SELECT /*+ INDEX(b IX_WIP_LOG_1_WIP_ID, a IX_LOT_USE_LINE_ID_PART_NO_T) */
                       a.LOT_NO, a.Cust_Part_No, b.Station_Time, a.Part_Name 
                   FROM dmpdb2.r_wip_log_1 b, dmpdb2.r_lot_used a, dmpdb2.station_location c
                  WHERE b.wip_id = iWipID
                    AND b.station_time >= a.input_time
                    AND b.station_time <= NVL (a.end_time, SYSDATE)
                    AND c.ID = b.location_id
                    AND a.line_id = b.line_id
                    AND a.station_no = c.station_no
                    AND a.station_code = c.station_code
                    AND b.fresh_flag = 1
                    AND b.station_time - a.input_time < 1
                  UNION All   
                 SELECT /*+ INDEX(b IX_WIP_LOG_1_WIP_ID, a IX_LOT_USE_LINE_ID_PART_NO_T) */
                       a.LOT_NO, a.Cust_Part_No, b.Station_Time, a.Part_Name 
                   FROM dmpdb2.r_wip_log b, dmpdb2.r_lot_used a, dmpdb2.station_location c
                  WHERE b.wip_id = iWipID
                    AND b.station_time >= a.input_time
                    AND b.station_time <= NVL (a.end_time, SYSDATE)
                    AND c.ID = b.location_id
                    AND a.line_id = b.line_id
                    AND a.station_no = c.station_no
                    AND a.station_code = c.station_code
                    AND b.fresh_flag = 1
                    AND b.station_time - a.input_time < 1
                 ) aa, C_PARTNAME_MAP bb
          WHERE aa.Part_Name = bb.HH_Part_Name;
    BEGIN
      OPEN LOtCusor;
      LOOP
      FETCH LOtCusor INTO cLotCode, cPartNo, dAddTime, cPartName;
      EXIT WHEN LOtCusor%NOTFOUND;                                                           
         cInfo := cInfo || 'module::'|| cPartName || '::lot_code=' ||cLotCode ||CHR(10)
                        || 'module::'|| cPartName || '::part_num=' ||cPartNo ||CHR(10)
                        || 'module::'|| cPartName || '::add_time=' ||to_char(dAddTime, 'yyyy-mm-dd hh24:mi:ss') ||CHR(10) ;       
             
                  
      END LOOP;
      CLOSE LOtCusor;
    END;                 
  END IF;
               
 
   
   <<end_of_function>> 
   RETURN;
EXCEPTION
   WHEN NO_DATA_FOUND 
   THEN
      --cInfo := 'invalid WipNo!';
      cInfo := '';
   WHEN OTHERS
   THEN
     cInfo := ' others :' || SUBSTR(SQLERRM, 1, 255); 
END;


/

