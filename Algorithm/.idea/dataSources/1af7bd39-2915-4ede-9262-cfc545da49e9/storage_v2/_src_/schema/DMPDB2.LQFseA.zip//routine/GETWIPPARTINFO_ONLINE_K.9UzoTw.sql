create FUNCTION        GETWIPPARTINFO_ONLINE_K(cWipNo IN VARCHAR2, cPartName IN VARCHAR2)
RETURN VARCHAR2
AS
  iWipID   INT; 
  cProType varchar2(10);
  cInfo VARCHAR2(200);
  cErr varchar2(512);
BEGIN
   --Get Wip info
  BEGIN 
    SELECT a.id, b.Type  into iWipID, cProType
      FROM DMPDB2.R_Wip a, DMPDB2.Product b  
     WHERE a.No = cWipNo       
       AND a.Del_Flag = 0
       AND b.ID = a.Product_ID;       
  EXCEPTION
    WHEN NO_DATA_FOUND 
    THEN      
      cInfo := 'N/A';
    WHEN OTHERS
    THEN      
    BEGIN   
      cInfo := 'N/A';
      cErr := SUBSTR(SQLERRM, 1, 512); 
      INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                        records, errlevel, errdesc, uniqid)
      VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_K','-1', SYSDATE, SYSDATE, 0,
               'R', cErr, 
                'GETWIPPARTINFO_ONLINE_MULTI_' 
                || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                || TRUNC(dbms_random.VALUE(1, 100000)));
    END;  
      
    GOTO end_of_function;   
  END;


  BEGIN     
      IF cProType = 'A' THEN  
         SELECT aa.SERIAL_NO into cInfo
           FROM (
                 SELECT Serial_No
                   FROM DMPDB2.R_Wip_Parts
                  WHERE Wip_ID = iWipID
                    AND Del_Flag = 0
                    AND Part_Name = cPartName
                  UNION ALL
                 SELECT Serial_No
                   FROM DMPDB2.R_Wip_Parts_1
                  WHERE Wip_ID = iWipID
                    AND Del_Flag = 0
                    AND Part_Name = cPartName) aa;
        RETURN cInfo ;                      
      ELSE
         SELECT aa.SERIAL_NO into cInfo
           FROM (
                 SELECT Serial_No FROM(
                    SELECT /*+ INDEX(b IX_R_WIP4_REWORK_WIPNO) INDEX(c IX_R_WPARTS4_REWORK_WIPID)  */ 
                    DECODE(a.Part_Name, cPartName, a.Serial_No, c.Serial_No )  Serial_No
                      FROM DMPDB2.r_wip_parts_1 a, DMPDB2.R_WIP_4_REWORK b, DMPDB2.R_WIP_PARTS_4_REWORK c
                     WHERE a.Wip_ID = iWipID
                       AND a.del_flag = 0
                       AND b.WIP_NO (+) = a.serial_no  
                       AND c.Wip_ID (+)= b.ID
                       AND (a.Part_Name = cPartName or c.Part_Name = cPartName)
                     ORDER BY B.ID DESC)
                 UNION ALL   
                 SELECT Serial_No FROM(
                    SELECT /*+ INDEX(b IX_R_WIP4_REWORK_WIPNO) INDEX(c IX_R_WPARTS4_REWORK_WIPID)  */ 
                    DECODE(a.Part_Name, cPartName, a.Serial_No, c.Serial_No )  Serial_No
                      FROM DMPDB2.r_wip_parts a, DMPDB2.R_WIP_4_REWORK b, DMPDB2.R_WIP_PARTS_4_REWORK c
                     WHERE a.Wip_ID = iWipID
                       AND a.del_flag = 0
                       AND b.WIP_NO (+) = a.serial_no  
                       AND c.Wip_ID (+)= b.ID
                       AND (a.Part_Name = cPartName or c.Part_Name = cPartName)
                     ORDER BY B.ID DESC )                                     
                   ) aa 
           WHERE ROWNUM =1 ;
        RETURN cInfo ;   
      END IF;

   EXCEPTION
    WHEN NO_DATA_FOUND 
    THEN      
      cInfo := 'N/A';
    WHEN OTHERS
    THEN      
    BEGIN   
      cInfo := 'N/A';
      cErr := SUBSTR(SQLERRM, 1, 512); 
      INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                        records, errlevel, errdesc, uniqid)
      VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_K','-1', SYSDATE, SYSDATE, 0,
               'R', cErr, 
                'GETWIPPARTINFO_ONLINE_MULTI_' 
                || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                || TRUNC(dbms_random.VALUE(1, 100000)));
    END;  
    GOTO end_of_function;   
  END; 
 
   
   <<end_of_function>> 
   RETURN cInfo;
EXCEPTION
   WHEN NO_DATA_FOUND 
   THEN
     cInfo := 'N/A';
   WHEN OTHERS
   THEN
    BEGIN   
      cInfo := 'N/A'; 
      cErr := SUBSTR(SQLERRM, 1, 512); 
      INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                        records, errlevel, errdesc, uniqid)
      VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_K','-1', SYSDATE, SYSDATE, 0,
               'R', cErr, 
                'GETWIPPARTINFO_ONLINE_MULTI_' 
                || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                || TRUNC(dbms_random.VALUE(1, 100000)));
    END;      
END;


/

