create PROCEDURE        GETWIPPARTINFO_ONLINE_MULTI(cWipNo IN VARCHAR2, cPartNames IN VARCHAR2, cInfo OUT VARCHAR2)
IS
  iWipID   INT;   
  cType  VARCHAR2(30);   
  cErr varchar2(512);  
BEGIN
  
  
  BEGIN
      EXECUTE IMMEDIATE 'SELECT DMPDB2.GETWIPPARTINFO_ONLINE_K(''' || cWipNo ||''',''' || cPartNames ||''') Serial_No FROM DUAL' into cInfo;
  EXCEPTION
    WHEN NO_DATA_FOUND 
    THEN      
      cInfo := 'N/A';
    WHEN OTHERS
    THEN 
    BEGIN   
      cInfo := 'N/A'; 
      cErr := SUBSTR(SQLERRM, 1, 512); 
      INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                        records, errlevel, errdesc, uniqid)
      VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_MULTI','-1', SYSDATE, SYSDATE, 0,
               'R', cErr, 
                'GETWIPPARTINFO_ONLINE_MULTI_' 
                || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                || TRUNC(dbms_random.VALUE(1, 100000)));
    END;            
  END;

  IF cInfo ='N/A' THEN 
      BEGIN
        EXECUTE IMMEDIATE 'SELECT DMPDB2.GETWIPPARTINFO_ONLINE_L@IPHONE_FATP_L(''' || cWipNo ||''',''' || cPartNames ||''') Serial_No FROM DUAL' into cInfo;
      EXCEPTION
        WHEN NO_DATA_FOUND 
        THEN      
          cInfo := 'N/A';
        WHEN OTHERS
        THEN 
        BEGIN   
          cInfo := 'N/A'; 
          cErr := SUBSTR(SQLERRM, 1, 512); 
          INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                            records, errlevel, errdesc, uniqid)
          VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_MULTI','-1', SYSDATE, SYSDATE, 0,
                   'R', cErr, 
                    'GETWIPPARTINFO_ONLINE_MULTI_' 
                    || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                    || TRUNC(dbms_random.VALUE(1, 100000)));
        END;            
      END;            
  END IF;  

  IF cInfo ='N/A' THEN 
      BEGIN
        EXECUTE IMMEDIATE 'SELECT DMPDB2.GETWIPPARTINFO_ONLINE_F@IPHONE_FATP_F(''' || cWipNo ||''',''' || cPartNames ||''') Serial_No FROM DUAL' into cInfo;
      EXCEPTION
        WHEN NO_DATA_FOUND 
        THEN      
          cInfo := 'N/A';
        WHEN OTHERS
        THEN 
        BEGIN   
          cInfo := 'N/A';
          cErr := SUBSTR(SQLERRM, 1, 512); 
          INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                            records, errlevel, errdesc, uniqid)
          VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_MULTI','-1', SYSDATE, SYSDATE, 0,
                   'R', cErr, 
                    'GETWIPPARTINFO_ONLINE_MULTI_' 
                    || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                    || TRUNC(dbms_random.VALUE(1, 100000)));
        END;            
      END;            
  END IF;    
    
  IF cInfo = 'N/A' THEN 
     cInfo := '' ;
  END IF;   
EXCEPTION
   WHEN NO_DATA_FOUND 
   THEN
     cInfo := '';
   WHEN OTHERS
   THEN
   BEGIN
     cInfo := '';
     cErr := SUBSTR(SQLERRM, 1, 512); 
      INSERT INTO DMPDB2.batch_job_log_file(sysid, progid, userID, startdt, enddt, 
                        records, errlevel, errdesc, uniqid)
      VALUES('SFC-FATP','GETWIPPARTINFO_ONLINE_MULTI','-1', SYSDATE, SYSDATE, 0,
               'R', cErr, 
                'GETWIPPARTINFO_ONLINE_MULTI_' 
                || TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISSSSS_') 
                || TRUNC(dbms_random.VALUE(1, 100000)));
   END;                      
END;


/

