create FUNCTION        Get_Batch_Id (
   ctable     IN   VARCHAR2,
   in_count        PLS_INTEGER
)
   RETURN NUMBER
IS
   ireturn    NUMBER;
   cobjname   VARCHAR2 (255);
   icount     PLS_INTEGER;
BEGIN
   cobjname := UPPER (ctable);

   IF in_count <= 0
   THEN
      icount := 1;
   ELSE
      icount := in_count;
   END IF;

   IF cobjname = 'R_WIP_LOG'
   THEN
      UPDATE    s_id_4_wip_log_1
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSIF cobjname = 'R_WIP_PARTS'
   THEN
      UPDATE    s_id_4_wip_parts_1
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSIF cobjname = 'R_CARTON_DETAIL'
   THEN
      UPDATE    S_ID_4_STOCK
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSIF cobjname = 'R_PALLET_DETAIL'
   THEN
      UPDATE    S_ID_4_STOCK
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSIF cobjname = 'R_CARTON'
   THEN
      UPDATE    S_ID_4_STOCK
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSIF cobjname = 'R_PALLET'
   THEN
      UPDATE    S_ID_4_STOCK
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSIF cobjname = 'R_ONLINE_STOCK'
   THEN
      UPDATE    S_ID_4_STOCK
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   ELSE
      UPDATE    S_ID_INFO
            SET ID = ID + icount
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   END IF;

   ireturn := ireturn - icount + 1;
   RETURN NVL (ireturn, -1);
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN -1;
END;


/

