create PROCEDURE        GET_MAINROUTE(
                    V_CODE IN VARCHAR2, R_MSG OUT VARCHAR2) AS
                       P_CURSOR VARCHAR2(4000);
  BEGIN
  SELECT P_CURS
        INTO P_CURSOR
        FROM (SELECT code || ';' ||version || ';' ||
                   namec || ';' ||namee  AS P_CURS
                FROM DMPDB2.ROUTE 
               WHERE code=v_code
               AND DEL_flag=0 )
       WHERE ROWNUM = 1;
       
        R_MSG := P_CURSOR;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;   
  END;

/

