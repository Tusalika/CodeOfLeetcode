create FUNCTION        Get_Mesa_Info(cSerialNo  IN VARCHAR2, cPartNo IN VARCHAR2)
  RETURN VARCHAR2 IS
  cresult  varchar2(255);
  cEEEECode varchar2(10);
BEGIN
  ---- Create by: wutao
  ---- Create Date: 2015/05/09

  cresult := '獲取MESA信息失敗';
  cEEEECode:= '';

  cEEEECode:= Substr(cSerialNo, 12, 4);

  if  cPartNo = '673-00037'  and cEEEECode = 'G2MM' then
    cresult:= '廠商:Sharp   顏色:黑色';
  elsif cPartNo = '673-00038'  and cEEEECode = 'G2MN' then
    cresult:= '廠商:Sharp   顏色:白色';
  elsif cPartNo = '673-00039'  and cEEEECode = 'G2MP' then
    cresult:= '廠商:Sharp   顏色:金色';
  elsif cPartNo = '673-00040'  and cEEEECode = 'G2MQ' then
    cresult:= '廠商:ASE   顏色:黑色';
  elsif cPartNo = '673-00041'  and cEEEECode = 'G2MR' then
    cresult:= '廠商:ASE   顏色:白色';
  elsif cPartNo = '673-00042'  and cEEEECode = 'G2MT' then
    cresult:= '廠商:ASE   顏色:金色';
  end if;

  RETURN cresult;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'FAIL;OTHER ERROR!';
END;


/

