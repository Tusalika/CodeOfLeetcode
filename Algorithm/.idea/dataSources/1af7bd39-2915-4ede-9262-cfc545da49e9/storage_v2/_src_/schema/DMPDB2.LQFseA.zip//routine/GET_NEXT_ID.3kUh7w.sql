create FUNCTION        get_next_id (ctable VARCHAR2)
   RETURN NUMBER
IS
   ireturn    NUMBER;
   cobjname   VARCHAR2 (255);
BEGIN
   --modify by zhang zhan kun 2006-4-27
   --SELECT ID INTO iReturn FROM DMPSFIS1.S_ID_INFO WHERE OBJ_NAME = cObjName ;
   cobjname := UPPER (ctable);

   IF cobjname = 'R_WIP_LOG'
   THEN
      --UPDATE s_id_4_wip_log
      --  SET ID = ID + 1
      --  WHERE obj_name = cObjName
      --RETURNING ID INTO iReturn;
      --   COMMIT;
      SELECT s_r_wip_log.NEXTVAL ID
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_WIP_PARTS'
   THEN
      SELECT s_r_wip_parts.NEXTVAL ID
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'A_TEST_RESULT_FRESH'
   THEN
      SELECT s_a_test_result_fresh_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'A_TEST_RESULT'
   THEN
      SELECT s_a_test_result_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'A_PACKOUT_RESULT'
   THEN
      SELECT s_a_packout_result_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_CARTON_DETAIL'
   THEN
      SELECT s_r_carton_detail_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_REPAIR'
   THEN
      SELECT s_r_repair_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_REPAIR_DETAIL'
   THEN
      SELECT s_r_repair_detail_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_PALLET_DETAIL'
   THEN
--    UPDATE s_id_4_stock
--      SET ID = ID + 1
--      WHERE obj_name = cObjName
--      RETURNING ID INTO iReturn;
   --COMMIT;
      SELECT s_r_pallet_detail_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_IMPORTANT_EVENT'
   THEN
      SELECT s_r_important_event_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_ONLINE_STOCK'
   THEN
--    UPDATE s_id_4_stock
--      SET ID = ID + 1
--      WHERE obj_name = cObjName
--      RETURNING ID INTO iReturn;
--    COMMIT;
      SELECT s_r_online_stock_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSIF cobjname = 'R_ERROR_NEW'
   THEN
      SELECT s_r_error_new_id.NEXTVAL
        INTO ireturn
        FROM DUAL;
   ELSE
      UPDATE    s_id_info
            SET ID = ID + 1
          WHERE obj_name = cobjname
      RETURNING ID
           INTO ireturn;

      COMMIT;
   END IF;

   RETURN NVL (ireturn, -1);
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN -1;
END;


/

