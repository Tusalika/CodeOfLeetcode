create PROCEDURE        GET_ROUTE(
                    P_CURSOR    OUT SYS_REFCURSOR) AS
  BEGIN
   OPEN P_CURSOR FOR
   SELECT T.code AS TXT, T.ID AS VAL FROM
   DMPDB2.ROUTE T
   WHERE  instr(code,'CO')=0 and instr(code,'CN')=0
   and del_flag=0
   ORDER BY CODE ;---路由排序，一個機種在一起   
   
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;   
  END;

/

