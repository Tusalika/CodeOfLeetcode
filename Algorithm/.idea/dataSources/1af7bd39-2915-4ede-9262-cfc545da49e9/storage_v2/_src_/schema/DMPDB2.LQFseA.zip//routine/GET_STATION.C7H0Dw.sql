create PROCEDURE        GET_STATION(
                  V_ROUTE_ID   IN VARCHAR,
                    P_CURSOR    OUT SYS_REFCURSOR) AS
  BEGIN
   OPEN P_CURSOR FOR
   SELECT  distinct T.TO_STATION_CODE AS TXT ,ROUTE_ID AS VAL  FROM
   DMPDB2.route_chart T
   WHERE route_id =V_ROUTE_ID;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;   
  END;

/

