create FUNCTION        get_user_id (p_user_no IN VARCHAR2)
   RETURN PLS_INTEGER
IS
   v_user_id   PLS_INTEGER;
BEGIN
   SELECT ID
     INTO v_user_id
     FROM app_user
    WHERE del_flag = 0 AND employee_id = p_user_no;

   RETURN v_user_id;
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN -1;
END get_user_id;


/

