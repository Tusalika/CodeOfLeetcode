create FUNCTION        get_xsfis1
   RETURN VARCHAR2
IS
   get_xsfis1   VARCHAR2 (10);
BEGIN
    /* SMO專用  2004/06/09 by shen ping
      *** 一定用各事業處的用記登錄
   */
   SELECT DISTINCT owner
              INTO get_xsfis1
              FROM dba_objects
             WHERE object_name = 'C_STATION_CONFIG_T'
               AND SUBSTR (owner, 1, 3) = SUBSTR (USER, 1, 3)
               AND object_type <> 'SYNONYM';

   IF RTRIM (get_xsfis1) = ''
   THEN
      get_xsfis1 := USER;
   END IF;

   RETURN (get_xsfis1);
END;


/

