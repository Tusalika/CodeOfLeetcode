create PROCEDURE        inprovision (
   sn        IN       VARCHAR2,
   imeino    IN       VARCHAR2,
   iccidno   IN       VARCHAR2,
   res       OUT      NUMBER
)
IS
   v_rowcount   NUMBER;
BEGIN
   INSERT INTO cr_provisioning_log
               (wip_no, imei, icc_id, add_date
               )
        VALUES (sn, imeino, iccidno, SYSDATE
               );

   v_rowcount := SQL%ROWCOUNT;

   IF v_rowcount > 0
   THEN
      res := 1;
   ELSE
      res := 0;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      res := 0;
END;


/

