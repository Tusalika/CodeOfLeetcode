create PROCEDURE        INSERT_ROUTE(V_CODE    IN VARCHAR2,
                                                V_VERSION IN VARCHAR2,
                                                V_NAMEC   IN VARCHAR2,
                                                V_NAMEE   IN VARCHAR2,
                                                V_USER    IN VARCHAR2,
                                                V_ID      OUT VARCHAR2,
                                                V_res     OUT VARCHAR) as
  V_MAXID NUMBER;
  L_COUNT NUMBER;
begin
  V_ID  := 0;
  v_res := '';
  select count(1) into L_COUNT from DMPDB2.ROUTE where code = V_CODE;

  IF L_COUNT = 0 then
    --SELECT MAX(ID) + 1 INTO V_MAXID from DMPDB2.ROUTE;
    V_MAXID := get_next_id ('ROUTE');
    /* Formatted on 2016/3/11 下午 04:29:02 (QP5 v5.163.1008.3004) */
    INSERT INTO dmpdb2.route
      (ID,
       COMMODITY_ID,
       CODE,
       VERSION,
       NAMEC,
       NAMEE,
       ADD_BY,
       ADD_DATE,
       EDIT_BY,
       EDIT_DATE,
       DEL_FLAG)
    VALUES
      (V_MAXID,
       '33',
       v_CODE,
       V_VERSION,
       V_NAMEC,
       V_NAMEE,
       V_USER,
       SYSDATE,
       V_USER,
       SYSDATE,
       '0')
    RETURNING ID INTO V_ID;
  
  else
    v_res := '該路由已經存在！';
    SELECT ID INTO V_ID FROM dmpdb2.route WHERE code = V_CODE AND del_flag=0;
  end if;
  
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    v_res := SUBSTR(SQLERRM, 1, 100);
  
end;
/

