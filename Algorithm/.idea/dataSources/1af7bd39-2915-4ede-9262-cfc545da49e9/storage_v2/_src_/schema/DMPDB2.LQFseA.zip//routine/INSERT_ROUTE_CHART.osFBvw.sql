create PROCEDURE        INSERT_ROUTE_CHART(V_ROUTE_ID     IN VARCHAR, ----新的路由ID
                                                      V_OLD_ROUTE_ID IN VARCHAR, ---舊的主路由
                                                      V_CODE         IN VARCHAR, ---選擇的路由去向
                                                      V_COTYPE       IN VARCHAR, --- 重工類型
                                                      V_ROUTEGO      IN VARCHAR, ---路由去向
                                                      V_USER         IN VARCHAR, ---操作人員ID
                                                      P_CURSOR       OUT SYS_REFCURSOR ---顯示
                                                      
                                                      )

 AS
  V_DEFECT_FLAG NUMBER;
  V_ID          NUMBER;
  V_ID_1        NUMBER;
  L_COUNT       NUMBER;

BEGIN
  /* FORMATTED ON 2016/3/11 下午 04:46:46 (QP5 V5.163.1008.3004) */
  ---先查詢最大ID

  --SELECT MAX(ID) + 1 INTO V_ID FROM DMPDB2.ROUTE_CHART;
  V_ID := GET_NEXT_ID ('ROUTE_CHART');
  --此表?發機會較小未強制加鎖 
  SELECT COUNT(ID)
    INTO L_COUNT
    FROM DMPDB2.ROUTE_CHART
   WHERE ROUTE_ID = V_OLD_ROUTE_ID;
  UPDATE S_ID_INFO SET ID = ID + L_COUNT WHERE OBJ_NAME = 'ROUTE_CHART';
     
  DBMS_OUTPUT.PUT_LINE('00000000000000010');
  ---1先插入一條數據，將之前的主路由全插進去
  V_DEFECT_FLAG := 0;

  --備份/刪除可能存在的記錄,用於更新重工路由的情況;
  INSERT INTO DMPDB2.ROUTE_CHART_BAK
    (ROUTE_ID,
     FROM_STATION_CODE,
     TO_STATION_CODE,
     REF_STATION_CODE,
     DEFECT_FLAG,
     OUTPUT_MODE,
     SEQUENCE,
     IS_OPTIONAL,
     ADD_BY,
     ADD_DATE,
     EDIT_BY,
     EDIT_DATE,
     ROUTE_CHART_ID)
    SELECT ROUTE_ID,
           FROM_STATION_CODE,
           TO_STATION_CODE,
           REF_STATION_CODE,
           DEFECT_FLAG,
           OUTPUT_MODE,
           SEQUENCE,
           IS_OPTIONAL,
           ADD_BY,
           ADD_DATE,
           EDIT_BY,
           EDIT_DATE,
           ID
      FROM DMPDB2.ROUTE_CHART
     WHERE ROUTE_ID = V_ROUTE_ID;

  DELETE FROM DMPDB2.ROUTE_CHART WHERE ROUTE_ID = V_ROUTE_ID;

  INSERT INTO DMPDB2.ROUTE_CHART
    (ROUTE_ID,
     FROM_STATION_CODE,
     TO_STATION_CODE,
     REF_STATION_CODE,
     DEFECT_FLAG,
     OUTPUT_MODE,
     SEQUENCE,
     IS_OPTIONAL,
     ADD_BY,
     ADD_DATE,
     EDIT_BY,
     EDIT_DATE,
     ID)
    SELECT V_ROUTE_ID,
           FROM_STATION_CODE,
           TO_STATION_CODE,
           REF_STATION_CODE,
           DEFECT_FLAG,
           OUTPUT_MODE,
           SEQUENCE,
           IS_OPTIONAL,
           V_USER,
           TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),
           V_USER,
           TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),
           V_ID + ROWNUM
      FROM DMPDB2.ROUTE_CHART
     WHERE ROUTE_ID = V_OLD_ROUTE_ID;
  ----2更新為CO/CN
  UPDATE DMPDB2.ROUTE_CHART
     SET TO_STATION_CODE = V_COTYPE, SEQUENCE = '0'
   WHERE FROM_STATION_CODE = ' '
     AND ROUTE_ID = V_ROUTE_ID;

  ----如果是去向是RI,則DEFECT_FLAG=1，否則應為0
  IF V_CODE IN ('RI', 'RP', '1R') THEN
  
    V_DEFECT_FLAG := 1;
  ELSE
    V_DEFECT_FLAG := 0;
  END IF;
  ----3再插入一條CN-RI
  --SELECT MAX(ID) + 1 INTO V_ID_1 FROM DMPDB2.ROUTE_CHART;
  V_ID_1 := GET_NEXT_ID ('ROUTE_CHART');

  INSERT INTO DMPDB2.ROUTE_CHART
    (ROUTE_ID,
     FROM_STATION_CODE,
     TO_STATION_CODE,
     REF_STATION_CODE,
     DEFECT_FLAG,
     SEQUENCE,
     IS_OPTIONAL,
     ADD_BY,
     ADD_DATE,
     EDIT_BY,
     EDIT_DATE,
     ID)
    SELECT V_ROUTE_ID,
           V_COTYPE,
           V_ROUTEGO,
           REF_STATION_CODE,
           V_DEFECT_FLAG,
           '1',
           '0',
           V_USER,
           TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),
           V_USER,
           TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),
           V_ID_1
      FROM DMPDB2.ROUTE_CHART
     WHERE ROUTE_ID = V_OLD_ROUTE_ID
       AND ROWNUM = 1;
  -----4顯示
  OPEN P_CURSOR FOR
    SELECT ROUTE_ID,
           FROM_STATION_CODE,
           TO_STATION_CODE,
           REF_STATION_CODE,
           DEFECT_FLAG,
           OUTPUT_MODE,
           SEQUENCE,
           IS_OPTIONAL,
           ADD_BY,
           ADD_DATE,
           EDIT_BY,
           EDIT_DATE
      FROM DMPDB2.ROUTE_CHART
     WHERE ROUTE_ID = V_ROUTE_ID
     ORDER BY SEQUENCE;
END;
/

