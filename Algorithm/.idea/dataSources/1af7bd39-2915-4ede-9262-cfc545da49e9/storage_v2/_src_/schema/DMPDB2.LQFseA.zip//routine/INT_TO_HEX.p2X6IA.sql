create FUNCTION        Int_To_Hex(iValues integer) return varchar2
is
v_Result varchar2(2000);
v_str varchar2(2000);
v_Quotient integer;
v_Remainder integer;
begin
  if iValues < 16 then
    if iValues < 10 then
      v_Result := to_char(iValues);
    else
      v_Result := chr(65 + (iValues - 10));
    end if;
  else
    v_Remainder := mod (iValues, 16);
      if v_Remainder < 10 then
      v_str := to_char(v_Remainder);
    else
      v_str := chr(65 + (v_Remainder - 10));
    end if;
    v_Quotient  := round((iValues - v_Remainder)/16);

    v_Result := INT_TO_HEX(v_Quotient) || v_str;
  end if;
  Return v_Result;
end;


/

