create PROCEDURE        is_parts_control (
   cCategoryKey       IN       VARCHAR2,       
   cPartName          IN       VARCHAR2,
   cserialno          IN       VARCHAR2,
   res                OUT      VARCHAR2
)
IS

   cVenderCode         VARCHAR2 (25) := ' ';
   cDateCode           VARCHAR2 (25) := ' ';
   cEeeeCode           VARCHAR2 (25) := ' ';
   cConfig             VARCHAR2 (25) := ' ';
   
   pos0 int;
   startpos int;
   endpos int;

   g_ok             CONSTANT VARCHAR2 (2)  := 'OK';
   
   CURSOR Cur_SERIALRULE(cPartName IN VARCHAR2) IS
      SELECT vender_code_pos,CCCC_CODE_POS,DATE_CODE_POS,BIN_POS
       FROM parts_sn_rule
       WHERE part_name = cPartName
         AND del_flag = '0' ;
            
   CURSOR control_parts_rule(cCategoryKey IN VARCHAR2,cPartName IN VARCHAR2,cVenderCode IN VARCHAR2) IS
      SELECT category_key, part_name, vender_code, eeee_code,date_code, config,property_01 control_by ,property_02 apply_by,property_03 reason
      FROM  C_CONTROL_PARTS_RULE
      WHERE category_key = cCategoryKey
        AND part_name = cPartName
        AND vender_code = cVenderCode
        AND del_flag = 0;

     
BEGIN
   res := g_ok;
   --DBMS_OUTPUT.put_line(cVenderCode || '1'); 
   FOR My_Val in Cur_SERIALRULE(cPartName) LOOP
   
      IF My_Val.vender_code_pos IS NOT NULL  THEN--VENDER_CODE
        select instr(My_Val.vender_code_pos,';') into pos0 from dual;
        startpos := substr(My_Val.vender_code_pos,1,pos0-1);
        endpos := substr(My_Val.vender_code_pos,pos0+1,length(My_Val.vender_code_pos)-pos0);
        cVenderCode := substr(cSerialNo, startpos, endpos-startpos+1);
      END IF ;

      If My_Val.CCCC_CODE_POS IS NOT NULL then--EEEE_CODE
        select instr(My_Val.CCCC_CODE_POS,';') into pos0 from dual;
        startpos := substr(My_Val.CCCC_CODE_POS,1,pos0-1);
        endpos := substr(My_Val.CCCC_CODE_POS,pos0+1,length(My_Val.CCCC_CODE_POS)-pos0);
        cEeeeCode := substr(cSerialNo, startpos, endpos-startpos+1);
      END IF;

      IF My_Val.DATE_CODE_POS IS NOT NULL THEN--DATE_CODE
        select instr(My_Val.DATE_CODE_POS,';') into pos0 from dual;
        startpos := substr(My_Val.DATE_CODE_POS,1,pos0-1);        
        endpos := substr(My_Val.DATE_CODE_POS,pos0+1,length(My_Val.DATE_CODE_POS)-pos0);
        cDateCode := substr(cSerialNo, startpos, endpos-startpos+1);
      END IF; 

      IF My_Val.BIN_POS IS NOT NULL THEN--CONFIG
        cConfig := substr(cSerialNo, My_Val.BIN_POS,1);
      END IF;     
   END LOOP;
         
   FOR v_controlrule IN control_parts_rule(cCategoryKey,cPartName,cVenderCode) LOOP

      IF NOT(((v_controlrule.eeee_code IS NOT NULL) AND (v_controlrule.eeee_code = cEeeeCode) )OR (v_controlrule.eeee_code IS NULL))THEN
         res := g_ok;       
      ELSIF NOT(((v_controlrule.date_code IS NOT NULL) AND (v_controlrule.date_code = cDateCode) )OR (v_controlrule.date_code IS NULL))THEN
         res := g_ok;
      ELSIF NOT(((v_controlrule.config IS NOT NULL) AND (v_controlrule.config = cConfig) )OR (v_controlrule.config IS NULL))THEN   
         res := g_ok;
      ELSE    
         res := 'FA管控物料不充許投入,管控人:' ||v_controlrule.control_by ||'聯繫方式:' ||v_controlrule.apply_by || '管控原因:' ||v_controlrule.reason;
         GOTO  end_of_function ; 
      END IF;
   END LOOP;

   <<end_of_function>>   
   return; 
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         res :=
               'ERROR(PROCEDURE DMPDB2.is_parts_control):'
            || cPartName || ':'||cserialno;
      END;
END;

/

