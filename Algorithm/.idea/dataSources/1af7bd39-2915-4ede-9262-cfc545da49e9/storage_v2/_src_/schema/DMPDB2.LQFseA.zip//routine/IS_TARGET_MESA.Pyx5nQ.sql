create FUNCTION        is_target_mesa(cSerialNo IN VARCHAR2)
  RETURN VARCHAR2 IS
  cresult  varchar2(255);
  cEEECode varchar2(10);
  cFlag    varchar2(1);
BEGIN
  ---- Create by: wutao
  ---- Create Date: 2015/05/09

  cresult  := 'SFC0;無效MESA序列號';
  cEEECode := '';
  cFlag    := '';

  cEEECode := Substr(cSerialNo, 12, 4);
  cFlag    := Substr(cSerialNo, 17, 1);

  if (Length(cEEECode) = 4) and (Length(cFlag) = 1) and
     (Length(cSerialNo) = 18) then
   /* if (cEEECode in ('G2MM', 'G2MN', 'G2MP', 'G2MQ', 'G2MR', 'G2MT')) and
       (cFlag in ('G', 'H', 'I', 'N')) then*/
    if ((cEEECode = 'G2MM' ) and (cFlag in ('G', 'H', 'I'))) or
       ((cEEECode = 'G2MN' ) and (cFlag in ('G', 'H', 'I'))) or
       ((cEEECode = 'G2MP' ) and (cFlag in ('G', 'H', 'I'))) or
       ((cEEECode = 'G2MQ' ) and (cFlag in ('G', 'H', 'I', 'N'))) or
       ((cEEECode = 'G2MR' ) and (cFlag in ('G', 'H', 'I', 'N'))) or
       ((cEEECode = 'G2MT' ) and (cFlag in ('G', 'H', 'I', 'N'))) then
      cresult := 'SFC1;目標MESA';
    else
      cresult := 'SFC2;非目標MESA';
    end if;
  else
    cresult := 'SFC0;無效MESA序列號';
  end if;

  RETURN cresult;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'FAIL;OTHER ERROR!';
END;


/

