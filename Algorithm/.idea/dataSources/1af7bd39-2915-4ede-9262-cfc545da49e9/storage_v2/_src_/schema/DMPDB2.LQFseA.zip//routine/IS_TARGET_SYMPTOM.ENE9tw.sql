create FUNCTION        is_target_symptom(cSymptom IN VARCHAR2)
  RETURN VARCHAR2 IS
  cresult varchar2(255);
BEGIN
  ---- Create by: wutao
  ---- Create Date: 2015/05/09

  cresult := 'SFC0;非目標不良信息';

  if cSymptom in ('Signal Moment C', 'Signal Moment S1', 'Signal Moment S2',
      'Signal Moment S3', 'Signal Moment S4', 'SignalMoment_C',
      'SignalMoment_S1', 'SignalMoment_S2', 'SignalMoment_S3',
      'SignalMoment_S4') then
    cresult := 'SFC1;目標不良信息';
  end if;

  RETURN cresult;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'FAIL;OTHER ERROR!';
END;


/

