create FUNCTION        is_valid_part_T (
   cwipno      IN   VARCHAR2,
   cpartname   IN   VARCHAR2,
   cserialno   IN   VARCHAR2
)
   RETURN VARCHAR2
IS
   cresult        VARCHAR2 (255);
   cEEECode       varchar2(10);
   cTemp          varchar2(1);

   iCount int;
   cWoNo varchar2(30);
   iIsRework numeric;
   cCategoryKey varchar2(30);
   iPos integer;
   cStr varchar2(100);
   cUnitNo varchar2(100);
   cNo varchar2(100);
   --cLBFlag varchar2(10);
   cLockID int;
   cLockReason varchar2(100);
   cApplyBy varchar2(100);
   dTime date;
   iNo int;
   
BEGIN
---- Create by: Benjamin
---- Create Date: 2010/07/12
  cresult := 'OKOK';
  dTime := to_date('20030410000000', 'YYYYMMDDHH24MISS');
  iNo := 0;
  SELECT COUNT(wo_no)
        INTO icount
        FROM dmpdb2.r_wip
       WHERE NO = cwipno AND del_flag = 0;
  if icount > 0 then
    SELECT wo_no
        INTO cwono
        FROM r_wip
       WHERE NO = cwipno AND del_flag = 0;       
    SELECT COUNT(no) INTO iNO FROM FATPSCAN.UNCONTROL_HSG_CG_WO where no = cwono;       
  end if;  
  
  IF cpartname = 'BCP'   THEN
      ceeecode := SUBSTR (cserialno, 14, 8);
      ctemp := SUBSTR (cserialno, 41, 1);

      IF ceeecode IN
            ('810-3727',
             '810-3726',
             '810-3731',
             '810-3745',
             '810-3749',
             '810-3753',
             '810-3735'
            )
      THEN
         IF (UPPER (ctemp) <> 'V') OR LENGTH (cserialno) < 41
         THEN
            cresult := 'FAIL;此為舊的白色BP,不允許使用;(IE要求)';
         END IF;
      END IF;
   elsif cpartname='PRT'   and  iNO = 0  then 
    if   cserialno in ('CH677-0371', 'CH607-9604')  then
            cresult := '舊PRT,不可用請聯繫IE王靜敏';
    end if;
  ELSIF cpartname = 'CGS' and iNO = 0  THEN
    cUnitNo := cserialno; 
    SELECT COUNT(SERIAL_NO) into iCount FROM(
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip a,
             dmpdb2.r_wip_parts_1 b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'LCG'
           AND B.SCAN_TIME <= dTime
           AND A.ROUTE_HISTORY LIKE '%RI%'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
        UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_F a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'LCG'
           AND B.SCAN_TIME <= dTime
           AND A.ROUTE_HISTORY LIKE '%RI%'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
         UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_L a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'LCG'
           AND B.SCAN_TIME <= dTime
           AND A.ROUTE_HISTORY LIKE '%RI%'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo);
    if iCount > 0 then
       cresult := '20130410之前進維修CG不允許投線';
    else              
        SELECT COUNT(SERIAL_NO) into iCount from(
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1
           WHERE SERIAL_NO = cUnitNo
           AND PART_NAME = 'CGS'
           and SCAN_TIME <= dTime
           UNION 
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1@IPHONE_FATP_F
           WHERE SERIAL_NO = cUnitNo
           AND PART_NAME = 'CGS'
           and SCAN_TIME <= dTime
           UNION 
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1@IPHONE_FATP_L
           WHERE SERIAL_NO = cUnitNo
           AND PART_NAME = 'CGS'
           and SCAN_TIME <= dTime);

     if iCount > 0 then
       cresult := '20130410之前Reuse CG不允許投線';
     else
       SELECT COUNT(SERIAL_NO) into iCount FROM(
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip a,
             dmpdb2.r_wip_parts_1 b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'LCG'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
        UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_F a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'LCG'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
        UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_L a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'LCG'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo);
       if iCount > 0 then
        SELECT  serial_no into cNo FROM 
        (SELECT  b.serial_no
            FROM dmpdb2.r_wip a,
                 dmpdb2.r_wip_parts_1 b
            WHERE a.ID = b.wip_id
               AND B.PART_NAME = 'LCG'
            AND a.del_flag = 0
            AND b.del_flag = 0
            AND A.NO = cUnitNo
        UNION
        SELECT  b.serial_no 
            FROM dmpdb2.r_wip@IPHONE_FATP_F a,
                 dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
            WHERE a.ID = b.wip_id
               AND B.PART_NAME = 'LCG'
            AND a.del_flag = 0
            AND b.del_flag = 0
            AND A.NO = cUnitNo
        UNION
        SELECT  b.serial_no 
            FROM dmpdb2.r_wip@IPHONE_FATP_L a,
                 dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
            WHERE a.ID = b.wip_id
               AND B.PART_NAME = 'LCG'
            AND a.del_flag = 0
            AND b.del_flag = 0
            AND A.NO = cUnitNo);
        IF substr(cNo, 16, 1) = 'S' AND substr(cNo, 12, 4) IN('F115')  then
           /*cresult := 'SHARP 白色CG不允許投線'; */
           cresult := 'OKOK';
        ELSIF substr(cNo, LENGTH(cNo) - 1, 1) = 'J' AND substr(cNo, 12, 4) IN('F113','F47Y') then
          cresult := 'JGP FRAME CG不允許投線'; 
        else
          cresult := 'OKOK';
         end if;
       else
         cresult := 'CG下階LCG無資料不能投線';
       END IF;
     end if;
    end if;
  ELSIF cpartname = 'HSGA' and iNO = 0  THEN
    cUnitNo := cserialno; 
    SELECT COUNT(SERIAL_NO) into iCount FROM(
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip a,
             dmpdb2.r_wip_parts_1 b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'HSG'
           AND B.SCAN_TIME <= dTime
           AND A.ROUTE_HISTORY LIKE '%RI%'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
        UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_F a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'HSG'
           AND B.SCAN_TIME <= dTime
           AND A.ROUTE_HISTORY LIKE '%RI%'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
         UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_L a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'HSG'
           AND B.SCAN_TIME <= dTime
           AND A.ROUTE_HISTORY LIKE '%RI%'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo);
    if iCount > 0 then
       cresult := '20130410之前進維修HSG不允許投線';
    else                 
        SELECT COUNT(SERIAL_NO) into iCount from(
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1
           WHERE SERIAL_NO = cUnitNo
           AND PART_NAME = 'HSGA'
           and SCAN_TIME <= dTime
           UNION
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1@IPHONE_FATP_F
           WHERE SERIAL_NO = cUnitNo
           AND PART_NAME = 'HSGA'
           and SCAN_TIME <= dTime
           UNION
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1@IPHONE_FATP_L
           WHERE SERIAL_NO = cUnitNo
           AND PART_NAME = 'HSGA'
           and SCAN_TIME <= dTime);
     if iCount > 0 then
       cresult := '20130410之前Reuse HSG不允許投線';
     else
       SELECT COUNT(SERIAL_NO) into iCount FROM(
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip a,
             dmpdb2.r_wip_parts_1 b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'HSG'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
        UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_F a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'HSG'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo
         UNION
        SELECT B.SERIAL_NO
        FROM dmpdb2.r_wip@IPHONE_FATP_L a,
             dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
        WHERE a.ID = b.wip_id
           AND B.PART_NAME = 'HSG'
           AND a.del_flag = 0
           AND b.del_flag = 0
           AND A.NO = cUnitNo);
       if iCount > 0 then
        SELECT  serial_no into cNo FROM
        (SELECT  b.serial_no 
         FROM dmpdb2.r_wip a,
              dmpdb2.r_wip_parts_1 b
          WHERE a.ID = b.wip_id
             AND B.PART_NAME = 'HSG'
            AND a.del_flag = 0
            AND b.del_flag = 0
            AND A.NO = cUnitNo
         UNION
         SELECT  b.serial_no 
          FROM dmpdb2.r_wip@IPHONE_FATP_F a,
              dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
          WHERE a.ID = b.wip_id
             AND B.PART_NAME = 'HSG'
            AND a.del_flag = 0
            AND b.del_flag = 0
            AND A.NO = cUnitNo
         UNION
         SELECT  b.serial_no 
          FROM dmpdb2.r_wip@IPHONE_FATP_L a,
              dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
          WHERE a.ID = b.wip_id
             AND B.PART_NAME = 'HSG'
            AND a.del_flag = 0
            AND b.del_flag = 0
            AND A.NO = cUnitNo);
         if substr(cNo, 1, 3) = 'DRD' then
           /*cresult := 'JGP HSG不允許投線'; */
           cresult := 'OKOK';
         else
           SELECT COUNT(SERIAL_NO) into iCount FROM
           ( SELECT B.SERIAL_NO
               FROM dmpdb2.r_wip a,
                    dmpdb2.r_wip_parts_1 b
              WHERE a.ID = b.wip_id
                AND B.PART_NAME = 'DKF'
                AND a.del_flag = 0
                AND b.del_flag = 0
                AND A.NO = cUnitNo
             UNION
             SELECT B.SERIAL_NO
               FROM dmpdb2.r_wip@IPHONE_FATP_F a,
                    dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
              WHERE a.ID = b.wip_id
                AND B.PART_NAME = 'DKF'
                AND a.del_flag = 0
                AND b.del_flag = 0
                AND A.NO = cUnitNo
             UNION
             SELECT B.SERIAL_NO
               FROM dmpdb2.r_wip@IPHONE_FATP_L a,
                    dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
              WHERE a.ID = b.wip_id
                AND B.PART_NAME = 'DKF'
                AND a.del_flag = 0
                AND b.del_flag = 0
                AND A.NO = cUnitNo);
            if iCount > 0 then 
              SELECT  serial_no into cNo FROM 
            ( SELECT  b.serial_no
                 FROM dmpdb2.r_wip a,
                   dmpdb2.r_wip_parts_1 b
                 WHERE a.ID = b.wip_id
                  AND B.PART_NAME = 'DKF'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND A.NO = cUnitNo
            UNION
            SELECT  b.serial_no 
                 FROM dmpdb2.r_wip@IPHONE_FATP_F a,
                   dmpdb2.r_wip_parts_1@IPHONE_FATP_F b
                 WHERE a.ID = b.wip_id
                  AND B.PART_NAME = 'DKF'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND A.NO = cUnitNo
            UNION
            SELECT  b.serial_no 
                 FROM dmpdb2.r_wip@IPHONE_FATP_L a,
                   dmpdb2.r_wip_parts_1@IPHONE_FATP_L b
                 WHERE a.ID = b.wip_id
                  AND B.PART_NAME = 'DKF'
                  AND a.del_flag = 0
                  AND b.del_flag = 0
                  AND A.NO = cUnitNo);
            if substr(cNo, 1, 3) = 'DTT' then
                /*cresult := 'Mektec HSG不允許投線'; */
                cresult := 'OKOK';
            else
                cresult := 'OKOK';
            end if;
         else
            cresult := 'HSG下階DKF無資料不能投線';    
         end if;
        END IF;
       else
         cresult := 'HSGA下階HSG無資料不能投線';
       END IF;
      end if; 
     end if;       
  ELSIF cpartname = 'BAND'   THEN
      SELECT wo_no
        INTO cwono
        FROM r_wip
       WHERE NO = cwipno AND del_flag = 0;

      SELECT COUNT (1)
        INTO icount
        FROM r_wip
       WHERE NO = cserialno AND del_flag = 0;

      IF icount > 0
      THEN
         SELECT b.is_rework
           INTO iisrework
           FROM r_wip a, r_wo b
          WHERE a.wo_id = b.ID
            AND a.NO = cserialno
            AND a.del_flag = 0
            AND b.del_flag = 0;

         IF iisrework = 1
         THEN
            IF (SUBSTR (cwono, 1, 3) <> 'WFF') and (SUBSTR (cwono, 1, 3) <> 'WFC') and (SUBSTR (cwono, 1, 3) <> 'WTC')
               and (SUBSTR (cwono, 1, 3) <> 'WF4') and (SUBSTR (cwono, 1, 3) <> 'WFN')  ----- PP Zhai qi long; request add two wo new buy prefix(WF4 and WFN) 2012-08-04
            THEN
               cresult := 'FAIL;重工BAND只能用在CR機台<WFF/WFC/WTC/WF4/WFN>;';
            END IF;
         END IF;
      ELSE
         cresult := 'FAIL;無效BAND序列號;';
      END IF;
   ELSIF cpartname = 'BANDDDDD'   THEN
      /*if cserialno like 'F1D01M03%' then
        cresult := 'FAIL;<F1D01M03>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1F11Z02%' then
        cresult := 'FAIL;<F1F11Z02>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1D__T15%' then
        cresult := 'FAIL;<F1DXXT15>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1E__T15%' then
        cresult := 'FAIL;<F1EXXT15>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1F__T15%' then
        cresult := 'FAIL;<F1FXXT15>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1D__T06%' then
        cresult := 'FAIL;<F1DXXT06>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1E__T06%' then
        cresult := 'FAIL;<F1EXXT06>的BAN已被<SQE>扣貨;';
      elsif cserialno like 'F1F__T06%' then
        cresult := 'FAIL;<F1FXXT06>的BAN已被<SQE>扣貨;';
      end if;*/
      IF cserialno LIKE '____354%'
      THEN
         cresult := 'FAIL;<354>的BAN已被<SQE>扣貨;';
      ELSIF cserialno LIKE '____356%'
      THEN
         cresult := 'FAIL;<356>的BAN已被<SQE>扣貨;';
      ELSIF cserialno LIKE '____364%'
      THEN
         cresult := 'FAIL;<364>的BAN已被<SQE>扣貨;';
      ELSIF cserialno LIKE '____361%'
      THEN
         cresult := 'FAIL;<361>的BAN已被<SQE>扣貨;';
      ELSIF cserialno LIKE '____365%'
      THEN
         cresult := 'FAIL;<365>的BAN已被<SQE>扣貨;';
      END IF;
   elsif cpartname = 'UNITLBL' then
     cUnitNo := cserialno;
     SELECT INSTR(cUnitNo,'_') into iPos FROM DUAL;
     cStr := substr(cUnitNo, 1, iPos) ||'%_'|| substr(cUnitNo, length(cUnitNo) - 4, 5);

     SELECT COUNT(SERIAL_NO) into iCount from(
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS
           WHERE SERIAL_NO like cStr
           AND DEL_FLAG = 0
           UNION ALL
           SELECT SERIAL_NO FROM DMPDB2.R_WIP_PARTS_1
           WHERE SERIAL_NO like cStr
           AND DEL_FLAG =0);
     if iCount > 0 then
       cresult := 'FAIL;UNIT重復;';
     else
       cresult := 'OKOK';
     end if;
   elsif cpartname = 'SPR' then
     cUnitNo := cserialno;
     --if (substr(cUnitNo, 1, 3) = 'CTH') AND (SUBSTR(cUnitNo, 8, 1) in ('E','F')) and (substr(cUnitNo, 12, 4)='F7GT') then
       --cresult := '異常拒收SPR，請聯繫SQE(左紅志)，85552';
     --if (substr(cUnitNo, 1, 3) = 'CTH') and (substr(cUnitNo, 4, 1) = '2') and (substr(cUnitNo, 5, 2)<49) then
     if (substr(cUnitNo, 1, 3) = 'CTH') AND (substr(cUnitNo, 4, 1)= '2') then
       cresult := 'Speaker禁止流線并按來料退倉';
     elsif (substr(cUnitNo, 1, 3) = 'CTH') AND (substr(cUnitNo, 4, 1)= '3') AND (substr(cUnitNo, 5, 2)= '01') then
       cresult := 'Speaker禁止流線并按來料退倉';
     else  
       cresult := 'OKOK';
     end if;
   elsif cpartname = 'DKF' and iNO = 0 then
     cUnitNo := cserialno;
     if substr(cUnitNo, 1, 3) = 'DTT' then
       /*cresult := 'Mektec Dock Flex廠商不允許投線';*/
       cresult := 'OKOK';
     else
       cresult := 'OKOK';
     end if;
   elsif cpartname = 'HSG' and iNO = 0 then
     cUnitNo := cserialno;
     if substr(cUnitNo, 1, 3) = 'DRD' then
       /* cresult := 'JGP HSG廠商不允許投線'; */
       cresult := 'OKOK';
     else
       cresult := 'OKOK';
     end if;
   elsif  cpartname = 'MLB' then
     Select Count(id)  into iCount from 
     (select C.Id, C.Reason, C.Apply_By
        from DMPDB2.FLOCK A, DMPDB2.R_WIP_STATUS B, DMPDB2.LOCK_WIP C
       where  A.LOCK_WIP_ID = C.ID
          and A.ID = B.LOCK_ID
          and B.WIP_NO =cserialno
          and B.DEL_FLAG = 0 ) ; 
     if  iCount = 0 then  begin
        cresult := 'OKOK';
     end;
     else
       select  Id, Reason, Apply_By
          into cLockID,cLockReason ,cApplyBy
        from (select  a.no, C.Id, C.Reason, C.Apply_By
                   from DMPDB2.FLOCK A, DMPDB2.R_WIP_STATUS B, DMPDB2.LOCK_WIP C
                 where  A.LOCK_WIP_ID = C.ID
                     and  A.ID = B.LOCK_ID
                     and  B.WIP_NO  =cserialno
                     and  B.DEL_FLAG = 0
                     and  C.NO not like 'U_%' 
                   order by c.apply_date asc)
     where rownum = 1;
         cresult :='料件被鎖定,扣貨原因:'||cLockReason||',請聯繫'||cApplyBy;
     end if;
   elsif cpartname = 'LCG'  then
     select Property_01,WO_NO into cCategoryKey, cwono from dmpdb2.r_wip where no =cwipno and del_flag = 0 and rownum <2;
     if cCategoryKey in ('N41_CG','N42_CG') then
       cUnitNo := cserialno;
       IF substr(cUnitNo, 16, 1) = 'S' and iNO = 0 AND substr(cUnitNo, 12, 4) IN('F115') then
          /*cresult := 'SHARP 白色LCG不允許投線'; */
          cresult := 'OKOK';
       ELSIF substr(cUnitNo, LENGTH(cUnitNo) - 1, 1) = 'J' and iNO = 0 AND substr(cUnitNo, 12, 4) IN('F113','F47Y') then
          cresult := 'JGP FRAME LCG不允許投線'; 
       ELSif substr(cUnitNo, 16, 1) = 'T' then
             cStr := substr(cUnitNo, 18, 2) ;
             IF cStr = 'DB' then
               cresult := 'OKOK';
             elsif cStr = 'A1' then
               cresult := 'OKOK';
             elsif cStr = 'A2' then
               cresult := 'OKOK';
             elsif cStr = 'A3' then
               cresult := 'OKOK';
             else
               cresult := 'NPI 拒收物料,聯系電話：84506';
             end if;
       else 
         cresult := 'OKOK';
       end if;
     elsIF cCategoryKey in ('N51_CG','N53_CG') then 
         if Substr(cUnitNo,18,2) = 'FR' then
            cresult := '管控物料暫不投線';
         else
            cresult := 'OKOK';
         end if;
     else 
       cresult := 'OKOK';
     end if;   
  END IF; 
   RETURN cresult;
EXCEPTION
   WHEN OTHERS   THEN
      RETURN 'FAIL;OTHER ERROR!';
END;


/

