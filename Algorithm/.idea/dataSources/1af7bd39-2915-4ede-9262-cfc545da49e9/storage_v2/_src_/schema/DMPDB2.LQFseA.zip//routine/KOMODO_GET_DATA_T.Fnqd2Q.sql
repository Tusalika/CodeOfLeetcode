create PROCEDURE        komodo_get_data_t (
   cipaddress          IN       VARCHAR2,
   cmacaddress         IN       VARCHAR2,
   cstationid          IN       VARCHAR2,
   dhuntercreatedate   IN       DATE,
   cmessage            IN       VARCHAR2,
   res                 OUT      VARCHAR2
)
AS
   g_procedure_name   VARCHAR (80)   := 'komodo_get_data';
   cmachinesn         VARCHAR (30);
   cmachineid         VARCHAR (30);
   cbucode            VARCHAR (30);
   cproduct           VARCHAR (30);
   cfloor             VARCHAR (30);
   cline              VARCHAR (30);
   cstationtype       VARCHAR (30);
   cdri               VARCHAR (30);
   cstatus            VARCHAR (30);
   cswrev             VARCHAR (30);
   chwrev             VARCHAR (30);
   cerrcode           VARCHAR (30);
   cvendor            VARCHAR (30);
   ctsid            VARCHAR (30);
   cerrdescn          VARCHAR (2000);
   cnote              VARCHAR (100);
   ctmpmessage        VARCHAR (2000);
   ctmp               VARCHAR (2000);
   duploaddate        DATE;
   dlastuploaddate    DATE;
   dreportdate        DATE;
   dworkdate          DATE;
   dhour              NUMBER;
   itmperrcount       NUMBER;
   itmperrtimecum     NUMBER;
   ierrcount          NUMBER;
   ierrtimecum        NUMBER;
   itimemode          NUMBER;
   icount             NUMBER;
   ipos               NUMBER;
BEGIN
   --dmpdb2.seq_device_monitor_data;
   --dmpdb2.seq_device_monitor_minf;
   --dmpdb2.seq_device_monitor_item;

   --day shift 07:00~19:00 night shif 19:00~07
   dworkdate := TRUNC (SYSDATE);

   SELECT TO_NUMBER (TO_CHAR (SYSDATE, 'hh24'))
     INTO dhour
     FROM DUAL;

   IF 0 < dhour AND dhour < 7
   THEN
      dreportdate := TRUNC (SYSDATE + 1);
   ELSE
      dreportdate := TRUNC (SYSDATE);
   END IF;

   --ROUND(to_number(duploadate - dlastuploaddate) * 24 * 60)

   --demount message
   --message format
   --DateTime  Project  BU Floor Line  AE ID AE SubID AE Vendor   Machine SN  SW rev.  HW rev.  Time Mode   Error Code  Error Description Color Notes
   --check format is correct, has 15 comma
   SELECT LENGTH (REGEXP_REPLACE (REPLACE (cmessage, ',', '@'), '[^@]+', ''))
     INTO icount
     FROM DUAL;

   --DBMS_OUTPUT.put_line ('0');

   IF icount = 16
   THEN
      ctmpmessage := cmessage;

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      DBMS_OUTPUT.put_line ('0.1');
      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      DBMS_OUTPUT.put_line (ctmp);
      duploaddate := TO_DATE (ctmp, 'mm/dd/yyyy hh24:mi:ss');
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);
      DBMS_OUTPUT.put_line ('0.2');
      DBMS_OUTPUT.put_line (ctmpmessage);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cproduct := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cbucode := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cfloor := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cline := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cstationtype := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cmachineid := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cvendor := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cmachinesn := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cswrev := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      chwrev := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      itimemode := TO_NUMBER (ctmp);
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cerrcode := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cerrdescn := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);

      SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cstatus := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);
      
       SELECT INSTR (ctmpmessage, ',')
        INTO ipos
        FROM DUAL;

      ctmp := SUBSTR (ctmpmessage, 1, ipos - 1);
      cnote := ctmp;
      ctmpmessage := SUBSTR (ctmpmessage, ipos + 1);
      ctsid := ctmpmessage;
      
   ELSE
      res := '2:Message format error.';
      RETURN;
   END IF;

   --compare last record
   SELECT COUNT (1)
     INTO icount
     FROM dmpdb2.device_monitor_data
    WHERE upload_date = duploaddate AND station_id = cstationid;

   DBMS_OUTPUT.put_line ('1');

   IF icount > 0
   THEN
      res := '0:duplicat data.';
      RETURN;
   END IF;

   --add DEVICE_MONITOR_DATA
   INSERT INTO dmpdb2.device_monitor_data
               (ID, upload_date, status, bu, product, FLOOR, line, station_id,
                station_type, machine_id, vendor, machine_sn, mac_address,
                ip_address, sw_rev, hw_rev, err_code, err_descn, dri,
                time_mode, hunter_create_date, property_01)
      SELECT dmpdb2.seq_device_monitor_data.NEXTVAL, duploaddate, cstatus,
             cbucode, cproduct, cfloor, cline, ctsid, cstationtype,
             cmachineid, cvendor, cmachinesn, cmacaddress, cipaddress, cswrev,
             chwrev, cerrcode, cerrdescn, cdri, itimemode, dhuntercreatedate,
             cnote
        FROM DUAL;

   DBMS_OUTPUT.put_line ('2');

   --update DEVICE_MONITOR_MINF
   BEGIN
      SELECT last_start_time, err_count, err_time_cum
        INTO dlastuploaddate, ierrcount, ierrtimecum
        FROM dmpdb2.device_monitor_minf
       WHERE station_id = cstationid AND last_stop_time IS NULL;

      DBMS_OUTPUT.put_line ('3');

      IF cstatus = 'Green'
      THEN
         --  itmperrtimecum :=               itmperrtimecum            + ROUND (TO_NUMBER (duploaddate - dlastuploaddate) * 24 * 60);
         UPDATE dmpdb2.device_monitor_minf
            SET err_time_cum =
                    ROUND (TO_NUMBER (duploaddate - dlastuploaddate) * 24 * 60),
                -- machine_sn = cmachinesn,
                -- machine_id = cmachineid,
                -- mac_address = cmacaddress,
                -- ip_address = cipaddress,
                -- sw_rev = cswrev,
                -- hw_rev = chwrev,
                -- last_err_code = cerrcode,
                last_stop_time = duploaddate
          WHERE station_id = cstationid AND last_stop_time IS NULL;

         DBMS_OUTPUT.put_line ('4');
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         itmperrcount := 0;
         itmperrtimecum := 0;
         DBMS_OUTPUT.put_line ('5');

         IF cstatus = 'Red'
         THEN
            ierrcount := 1;
            ierrtimecum := 0;

            INSERT INTO dmpdb2.device_monitor_minf
                        (ID, bu, product, FLOOR, line, station_id,
                         station_type, machine_id, vendor, machine_sn,
                         sw_rev, hw_rev, mac_address, ip_address, status,
                         last_start_time, last_stop_time, last_err_code,
                         err_count, err_time_cum, add_date, edit_date,
                         report_date, work_date, err_descn)
               SELECT dmpdb2.seq_device_monitor_minf.NEXTVAL, cbucode,
                      cproduct, cfloor, cline, ctsid, cstationtype,
                      cmachineid, cvendor, cmachinesn, cswrev, chwrev,
                      cmacaddress, cipaddress, cstatus, duploaddate, NULL,
                      cerrcode, ierrcount, ierrtimecum, SYSDATE, SYSDATE,
                      dreportdate, dworkdate, cerrdescn
                 FROM DUAL;

            DBMS_OUTPUT.put_line ('6');
         END IF;
   END;

   res := '0:ok';
   COMMIT;

/*
--update DEVICE_MONITOR_ITEM
   BEGIN
      SELECT last_start_time, err_count, err_time_cum
        INTO dlastuploaddate, ierrcount, ierrtimecum
        FROM dmpdb2.device_monitor_minf
       WHERE station_id = cstationid
       and err_code = cerrcode;

      IF cstatus <> 'Green'
      THEN
         itmperrcount := itmperrcount + 1;
      END IF;



      UPDATE dmpdb2.device_monitor_minf
         SET err_count = itmperrcount,
             err_time_cum = itmperrtimecum,
             machine_sn = cmachinesn,
             machine_id = cmachineid,
             mac_address = cmacaddress,
             ip_address = cipaddress,
             sw_rev = cswrev,
             hw_rev = chwrev,
             last_err_code = cerrcode,
             last_stop_time = last_stop_time
             last_start_time = duploaddate,
       WHERE station_id = cstationid
       and err_code = cerrcode
       ;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         itmperrcount := 0;
         itmperrtimecum := 0;

         IF cstatus = 'Green'
         THEN
            ierrcount := 0;
            ierrtimecum := 0;
         ELSE
            ierrcount := 1;
            ierrtimecum := 0;
         END IF;

         INSERT INTO dmpdb2.device_monitor_minf
                     (ID, bu, product, FLOOR, line, station_id, station_type,
                      machine_id, vendor, machine_sn, sw_rev, hw_rev,
                      mac_address, ip_address, status, last_start_time,
                      last_stop_time, last_err_code, err_count, err_time_cum,
                      add_date, edit_date)
            SELECT dmpdb2.seq_device_monitor_minf.NEXTVAL, cbucode, cproduct,
                   cfloor, cline, cstationid, cstationtype, cmachineid,
                   cvendor, cmachinesn, cswrev, chwrev, cmacaddress, cstatus,
                   duploaddate, NULL, cerrcode, cerrdescn, ierrcount,
                   ierrtimecum, SYSDATE, SYSDATE
              FROM DUAL;
   END;
   */--adc DEVICE_MONITOR_ITEM

   --update DEVICE_MONITOR_ITEM
   <<end_of_function>>
   ROLLBACK;
   RETURN;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         res :=
            '2:ERROR(' || g_procedure_name || '):'
            || SUBSTR (SQLERRM, 1, 200);
         ROLLBACK;
      END;
END;

/

