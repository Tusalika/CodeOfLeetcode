create PROCEDURE        LOCK_PARTS_WIP (
   CWIPNO      IN     VARCHAR2,
   CPARTNAME   IN     VARCHAR2,
   cFlag          OUT VARCHAR2,
   RES            OUT VARCHAR2)
AS
   ILOCKDETAILID   INT;
   CNO             VARCHAR2 (50);
   CHECKLOCK       VARCHAR2 (50);

   CURSOR CUR_LOCKINFOR1 (
      CWIPNO      IN VARCHAR2,
      CPARTNAME   IN VARCHAR2)
   IS
      SELECT B.ID,
             B.NO,
             B.ADD_BY,
             B.ADD_DATE,
             B.EDIT_BY,
             B.EDIT_DATE
        FROM DMPDB2.LOCK_WIP_DETAIL_P A,
             DMPDB2.LOCK_WIP B,
             (SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@K_FATP A, DMPDB2.R_WIP_PARTS_1@K_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@K_FATP A, DMPDB2.R_WIP_PARTS@K_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@L_FATP A, DMPDB2.R_WIP_PARTS_1@L_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@L_FATP A, DMPDB2.R_WIP_PARTS@L_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@F_FATP A, DMPDB2.R_WIP_PARTS_1@F_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@F_FATP A, DMPDB2.R_WIP_PARTS@F_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@E_FATP A, DMPDB2.R_WIP_PARTS_1@E_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME
              UNION ALL
              SELECT B.SERIAL_NO, A.NO, A.PROPERTY_01 CATEGORY_KEY
                FROM DMPDB2.R_WIP@E_FATP A, DMPDB2.R_WIP_PARTS@E_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = CPARTNAME) C
       WHERE     A.LOCK_WIP_ID = B.ID
             AND A.WIP_NO = C.SERIAL_NO
             AND WIP_STATUS = 'S';

   CURSOR CUR_CGSNO (CWIPNO IN VARCHAR2)
   IS
      SELECT SERIAL_NO
        FROM (SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@K_FATP A, DMPDB2.R_WIP_PARTS_1@K_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@K_FATP A, DMPDB2.R_WIP_PARTS@K_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@L_FATP A, DMPDB2.R_WIP_PARTS_1@L_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@L_FATP A, DMPDB2.R_WIP_PARTS@L_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@F_FATP A, DMPDB2.R_WIP_PARTS_1@F_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@F_FATP A, DMPDB2.R_WIP_PARTS@F_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@E_FATP A, DMPDB2.R_WIP_PARTS_1@E_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS'
              UNION ALL
              SELECT B.SERIAL_NO
                FROM DMPDB2.R_WIP@E_FATP A, DMPDB2.R_WIP_PARTS@E_FATP B
               WHERE     A.ID = B.WIP_ID
                     AND A.DEL_FLAG = 0
                     AND B.DEL_FLAG = 0
                     AND A.NO = CWIPNO
                     AND B.PART_NAME = 'CGS');
BEGIN
   cFlag := '0';
   CNO := CWIPNO;

   IF    (CPARTNAME = 'RCV')
      OR (CPARTNAME = 'MBF')
      OR (CPARTNAME = 'CRP')
      OR (CPARTNAME = 'LCG')
      OR (CPARTNAME = 'SEN')
      OR (CPARTNAME = 'VGA')
      OR (CPARTNAME = 'GRP')
   THEN
      FOR MY_CGS IN CUR_CGSNO (CWIPNO)
      LOOP
         IF MY_CGS.SERIAL_NO IS NOT NULL
         THEN
            CNO := MY_CGS.SERIAL_NO;
         END IF;
      END LOOP;
   END IF;

   FOR MY_LOCK IN CUR_LOCKINFOR1 (CNO, CPARTNAME)
   LOOP
      SELECT COUNT (WIP_NO)
        INTO CHECKLOCK
        FROM DMPDB2.LOCK_WIP_DETAIL_2
       WHERE     WIP_STATUS = 'S'
             AND WIP_NO = CWIPNO
             AND LOCK_WIP_ID = MY_LOCK.ID;

      IF CHECKLOCK = 0
      THEN
         ILOCKDETAILID := get_next_id ('LOCK_WIP_DETAIL_2');

         INSERT INTO DMPDB2.LOCK_WIP_DETAIL_2 (ID,
                                               COMMODITY_ID,
                                               LOCK_WIP_ID,
                                               WIP_NO,
                                               WIP_STATUS,
                                               WIP_FLAG,
                                               ADD_BY,
                                               ADD_DATE,
                                               EDIT_BY,
                                               EDIT_DATE)
              VALUES (ILOCKDETAILID,
                      33,
                      MY_LOCK.ID,
                      CWIPNO,
                      'S',
                      'OK',
                      MY_LOCK.ADD_BY,
                      SYSDATE,
                      MY_LOCK.EDIT_BY,
                      SYSDATE);

         COMMIT;
         cFlag := '1';
      END IF;
   END LOOP;

   RES := 'OK';
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      cFlag := '-1';
      RES := '通過單體料件扣整機扣貨失敗';
END;

/

