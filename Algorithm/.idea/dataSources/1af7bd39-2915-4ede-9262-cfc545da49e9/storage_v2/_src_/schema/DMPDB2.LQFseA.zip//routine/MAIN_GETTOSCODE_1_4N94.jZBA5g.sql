create FUNCTION        MAIN_GETTOSCODE_1_4N94(cRouteID varchar2, cWOID varchar2, cFromStationCode varchar2, cDefectFlag varchar2)
return Type_GetToSCode_2  
as
type l_Type_GetToSCode_1 is record
(To_Station_Code VARCHAR2(255)
);
  type l_Type_GetToSCode_1_list is table of l_Type_GetToSCode_1;  
  r_data l_Type_GetToSCode_1_list;
  r_data2 Type_GetToSCode_2 := Type_GetToSCode_2();
  i int;
begin
  SELECT /*+ INDEX(a IX_ROUTE_CHART_WO_WO_ID) */ To_Station_Code 
  bulk collect into r_data
  FROM Route_Chart_WO a
  WHERE Route_ID = cRouteID
  AND WO_ID = cWOID 
  AND From_Station_Code = cFromStationCode
  AND Ref_Station_Code IS Null
  AND Defect_Flag = cDefectFlag 
  ORDER BY IS_OPTIONAL;  
  i := 1;
  while i <= r_data.count loop
    r_data2.extend;
    r_data2(r_data2.count) := Type_GetToSCode_1(r_data(i).To_Station_Code
                      );   
    i := i + 1;                                  
  end loop;      
  return r_data2;  
EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line('ERROR(MAIN_GETTOSCODE_1_4N94):' || SUBSTR(SQLERRM, 1, 200));
END;


/

