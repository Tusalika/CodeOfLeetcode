create FUNCTION        N94_CanScan(cWipNo in varchar2, cStationCode in varchar2, cTestItemID in varchar2)
      return varchar2
   as
     cRet varchar2(2048);
     cTemp varchar2(2048);
     cSymptom varchar2(2048);
     iIsTestFail number;
     cSecType varchar2(30);
     g_station_code varchar2(10);
     g_ok              CONSTANT VARCHAR2 (2)                    := 'OK';
     cStationType varchar(100);
   begin
     return g_ok;
   end;


/

