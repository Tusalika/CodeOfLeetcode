create FUNCTION        N94_manuallyScan(
  cWipNo in varchar2
, cStationCode in varchar2
, cTestItemID in varchar2
, cSymptomID in varchar2
)
      return varchar2
   as
     g_ok              CONSTANT VARCHAR2 (2)                    := 'OK';   
     cRet varchar2(2048);
     cTemp varchar2(2048);
     cStationType varchar2(100);
     cTestResult varchar2(10);
     cSymptomCode varchar2(255);     
   begin     
     return  g_ok; 
   end;


/

