create PROCEDURE        p3
as
  req   utl_http.req;
  resp  utl_http.resp;
  value VARCHAR2(1024);

BEGIN


  req := utl_http.begin_request('http://10.195.226.15/fatp/iphone?c=MANUALLY_SCAN_CHECK=''C39FN02ZDNCG''=''QT0''', 'POST' , 'HTTP/1.1');

  resp := utl_http.get_response(req);
  LOOP
    utl_http.read_line(resp, value, TRUE);
    
    dbms_output.put_line(value);
  END LOOP;
  utl_http.end_response(resp);
EXCEPTION
  WHEN utl_http.end_of_body THEN
    utl_http.end_response(resp);
END;


/

