create PROCEDURE        PRO_X_TRACK_D10 (
   vBeginTime   IN     DATE,
   vEndTime     IN     DATE,
   res             OUT VARCHAR2)
AS
   wo_no   VARCHAR2 (30);
   iQty    INT;

   CURSOR MY_CURSOR
   IS
      SELECT PROPERTY_01 CONFIG,
             CATEGORY_KEY,
             WIP_NO,
             WO_NO,
             CUST_PART_NO,
             TEST_STATION,
             TEST_SYMPTOM,
             TO_CHAR (ADD_DATE, 'YYYY-MM-DD HH24:MI:SS') start_time
        FROM R_PRQ_CONTROL_WIP
       WHERE     ADD_DATE > vBeginTime
             AND ADD_DATE <= vEndTime
             AND XTRACK_RI_FLAG = 'N'
             AND XTRACK_RO_FLAG = 'N'
             AND CATEGORY_KEY = 'D10'
             AND DEL_FLAG = 0;
BEGIN
   res := 'OK;';
   iQty := 0;

   FOR MY_CURSOR_1 IN MY_CURSOR
   LOOP
      res :=
            res
         || 'WIP_NO='
         || MY_CURSOR_1.WIP_NO
         || '!!CATEGORY_KEY='
         || MY_CURSOR_1.CATEGORY_KEY
         || '!!WO_NO='
         || MY_CURSOR_1.WO_NO
         || '!!CONFIG='
         || MY_CURSOR_1.CONFIG
         || '!!CUST_PART_NO='
         || MY_CURSOR_1.CUST_PART_NO
         || '!!TEST_STATION='
         || MY_CURSOR_1.TEST_STATION
         || '!!TEST_SYMPTOM='
         || MY_CURSOR_1.TEST_SYMPTOM
         || '!!START_TIME='
         || MY_CURSOR_1.start_time
         || CHR (10);

      iQty := iQty + 1;
   END LOOP;
/*update R_PRQ_CONTROL_WIP set XTARCK_RI_FLAG = 'Y'
 WHERE ADD_DATE > vBeginTime
   AND ADD_DATE <= vEndTime
   AND CATEGORY_KEY = 'D10'
   AND XTARCK_RI_FLAG = 'N'
   AND XTARCK_RO_FLAG = 'N'
   AND DEL_FLAG = 0 ;

COMMIT; */

EXCEPTION
   WHEN OTHERS
   THEN
      res := 'ERR PRO_X_TRACK';
END;

/

