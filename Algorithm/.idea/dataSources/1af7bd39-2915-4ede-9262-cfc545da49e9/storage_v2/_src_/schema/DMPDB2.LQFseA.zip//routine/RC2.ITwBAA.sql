create FUNCTION        RC2(
   cWipno         IN   VARCHAR2,
   cAppleStation  IN   VARCHAR2
)
   RETURN VARCHAR2 
AS
  dIT date;   
  dRT date;
  cRet varchar2(1000); 
  cApple1 varchar2(60);   
  cApple2 varchar2(60); 
  iTSID int;
  cCategoryKey varchar2(30); 
   
  iWipId number;
  iReworkFlag int;
  iDismantle int;
  iRF int;
  dIPT date;
  dRCO date;  
  iIRF int;   
  iRecordCount int;
  iTemp int;
  cTemp varchar2(255);
  cCheckStations varchar2(255);
  cRepairCheck varchar2(10);
  cCheckStation varchar2(60);
  dTemp date;
  iIsTestFail int;
  
  iCheckFlag int;
  
  cStopRoutingControl varchar2(255);
  
  cStationList varchar2(2500);
  iPOS int;
  cStationTemp varchar2(70);
  
  function getRoutingControlStations(cCurStation in varchar2) 
    return varchar2   
  is
    cRet varchar2(255);
  begin
    cRet := '00';
    if cCurStation = 'QT0' then
      cRet := 'PAT-WIFILAT,PAT-UATFEED,PAT-CONNECTOR';
    elsif cCurStation = 'QT0b' then
      cRet := 'QT0';
    elsif cCurStation = 'IMU' then
      cRet := 'QT0b';
    --elsif cCurStation = 'SW-DOWNLOAD' then
    --  cRet := 'IMU';  
    elsif cCurStation = 'DISPLAY' then
      cRet := 'BURNIN';        
    elsif cCurStation = 'CURRENT-POSTBURN' then
      cRet := 'DISPLAY'; 
    elsif cCurStation = 'ALSAR-PREBURN' then
      cRet := 'CURRENT-POSTBURN';       
    elsif cCurStation = 'ALS-CAL' then
      cRet := 'ALSAR-PREBURN';         
    elsif cCurStation = 'ALS-TEST' then
      cRet := 'ALS-CAL';
    elsif cCurStation = 'QT1-PREBURN' then
      cRet := 'ALS-TEST';  
    elsif cCurStation = 'QT2-PREBURN' then
      cRet := 'QT1-PREBURN';        
    elsif cCurStation = 'VIDEO-POSTBURN' then
      cRet := 'QT2-PREBURN';          
    elsif cCurStation = 'FACT2' then
      cRet := 'VIDEO-POSTBURN';  
    elsif cCurStation = 'FACT' then
      cRet := 'FACT2';        
    elsif cCurStation = 'CAMERA-POSTBURN' then
      cRet := 'FACT';   
    elsif cCurStation = 'PROX-TEST' then
      cRet := 'CAMERA-POSTBURN';                     
    elsif cCurStation = 'REDSIG-CELL-OTA' then
      cRet := 'PROX-TEST';  
    elsif cCurStation = 'CELL-OTA' then
      cRet := 'PROX-TEST';        
    elsif cCurStation = 'WIFI-BT-OTA' then
      cRet := 'REDSIG-CELL-OTA,CELL-OTA';        
    --elsif cCurStation = 'SHIPPING-SETTINGS' then
    --  cRet := 'WIFI-BT-OTA';  
    --elsif cCurStation = 'ICHECK' then
    --  cRet := 'SHIPPING-SETTINGS';  
    ------             
    elsif cCurStation = 'SA-SENSORFLEX' then
      cRet := 'SA-BUTTONFLEX'; 
    ------    
    elsif cCurStation = 'FCT' then
      cRet := 'DFU-NAND-INIT'; 
    elsif cCurStation = 'SOC-TEST' then
      cRet := 'FCT';  
    elsif cCurStation = 'WIFI-BT-COND' then
      cRet := 'SOC-TEST';  
    elsif cCurStation = 'CELL-CAL' then
      cRet := 'WIFI-BT-COND'; 
    elsif cCurStation = 'CELL-TEST' then
      cRet := 'CELL-CAL';  
    elsif cCurStation = 'GATEKEEPER-PREBURN' then
      cRet := 'CELL-TEST';                                                                             
    end if;
    Return cRet;
  end;
BEGIN 
                                                         
  cStationList := ''                                
    ||';PAT-MLB,0;SA-PAT1,0;SA-PAT,0;SA-BUTTONFLEX,0;SA-SENSORFLEX,0;SA-COSMETIC1,0'
    ||';SYS-VAL-DEV-1,0;SYS-VAL-DEV-2,0;SYS-VAL-DEV-3,0;SYS-VAL-DEV-4,0;SYS-VAL-DEV-5,0'
    ||';TILT1,0;COSMETIC-PRE-1,0;PAT-AM,0;PAT0,0;PAT-WIFILAT,0;PAT,0'
    ||';PAT-UATFEED,0;PAT2,0;PAT-CONNECTOR,0;PAT2B,0;QT0,1;COSMETIC-PRE-2,1'
    ||';QT0b,1;IMU,1;SW-DOWNLOAD,1;GRAPE-PROX-CAL,1'
    ||';GRAPE-PROX-TEST,1;GRAPE-CAL,1;BURNIN,1;BONFIRE,1;DISPLAY,1;CURRENT-POSTBURN,1'
    ||';FA-CHECKIN,1;FA-CHECKOUT,1;GATEKEEPER,1;ALSAR-PREBURN,1;ALS-CAL,1;ALS-TEST,1'
    ||';QT1-PREBURN,1;QT2-PREBURN,1;VIDEO-POSTBURN,1;OPAS-POSTBURN,1;FACT2,1;FACT,1'
    ||';CAMERA-POSTBURN2,1;CAMERA-POSTBURN,1;REDSIG-CELL-OTA,1;GSM-UMTS-OTA,1;CELL-OTA,1'
    ||';WIFI-BT-OTA,1;MMI,1;SHIPPING-SETTINGS,1;ICHECK,1;COSMETIC,1;FACT-POSTFATP,1'  
    ||';DEVELOPMENT1,0;DEVELOPMENT2,0;DEVELOPMENT3,0;DEVELOPMENT4,0;DEVELOPMENT5,0'
    ||';DEVELOPMENT6,0;DEVELOPMENT7,0;DEVELOPMENT8,0;DEVELOPMENT9,0;DEVELOPMENT10,0'
    ||';DEVELOPMENT11,0;DEVELOPMENT12,0;DEVELOPMENT13,0;DEVELOPMENT14,0;DEVELOPMENT15,0'
    ||';DEVELOPMENT16,0;DEVELOPMENT17,0;DEVELOPMENT18,0;DEVELOPMENT19,0;DEVELOPMENT20,0'
    ||';IQC-CAM1,0;IQC-CAM2,0;IQC-CAM3,0;IQC-CAM4,0;IQC-SURF1,0;IQC-SURF2,0;IQC-SURF3,0'
    ||';IQC-LAT-FLEX,0;IQC-WIFI-FLEX,0;IQC-DISPLAY,0;IQC-DISPLAY-2,0;IQC-CG,0'
    ||';IQC-PROXALS,0;IQC-DEV1,0;IQC-DEV2,0;IQC-DEV3,0;IQC-DEV4,0;IQC-DEV5,0' 
    ||';ACTIVATION,1;CAMERA-DESENSE,0;GSM-UMTS-DESENSE,0;C2K-EVD0-DESENSE,0;WITT-POSTFATP,0'
    ||';NAND-NUKER,0;GSM-UMTS-DESENSE,0;SHIPPING-SETTINGS-OQC,1;CELL-DESENSE,0;ICHECK-OQC,1'
    ||';DFU-NAND-INIT,1;FCT,1;SOC-TEST,1;WIFI-BT-COND,1;CELL-CAL,1;CELL-TEST,1;GATEKEEPER-PREBURN,1'
    ||';SMT-DEVELOPMENT1,1;SMT-DEVELOPMENT2,1;SMT-DEVELOPMENT3,1;SMT-DEVELOPMENT4,1;SMT-DEVELOPMENT5,1'
    ||';SMT-DEVELOPMENT6,1;SMT-DEVELOPMENT7,1;SMT-DEVELOPMENT8,1;SMT-DEVELOPMENT9,1;SMT-DEVELOPMENT10,1'
    ||';SMT-DEVELOPMENT11,1;SMT-DEVELOPMENT12,1;SMT-DEVELOPMENT13,1;SMT-DEVELOPMENT14,1'
    ||';FA-REPAIR-IN,1;FA-REPAIR-OUT,1'
    ||';LCD-INSPECT,0;COSMETIC4,1'
    ||';'
  ; 
    
  cRet := '';
  
  dIT := to_date('20000101', 'YYYYMMDD');
  
  dIPT := dIT;  
  dRCO := dIT;  
  dRT := dIT;  
  iIRF := 0;
  iReworkFlag := 0;  
  iDismantle := 0;
  iRF := 0;
  
  cApple2 := '00';
  
  cCategoryKey := 'N94';
  
  cTemp := cAppleStation;
  iTemp := instr(cTemp, '_');      
  if iTemp <= 0 then
    iTSID := 0;
    cApple1 := cAppleStation;    
  else
    iTSID := 1;
    cTemp := substr(cTemp, iTemp + 1, length(cTemp));  
    iTemp := instr(cTemp, '_');
    cApple2 := substr(cTemp, 1, iTemp - 1);  
    cTemp := substr(cTemp, iTemp + 1, length(cTemp));
    iTemp := instr(cTemp, '_');
    --cAppleStationNum := substr(cTemp, 1, iTemp - 1); 
    cTemp := substr(cTemp, iTemp + 1, length(cTemp));
    cApple1 := cTemp;
  end if;    
  --dbms_output.put_line(cApple2);       

  select nvl(min(key_value), '0') into cStopRoutingControl 
    from(
         select key_value from Sys_Property
           where key_name = 'STOP ROUTING CONTROL'
             and property_02 = 'N94'
        )
    where rownum = 1;      
  
  --cStopRoutingControl := '0';
  
  if cStopRoutingControl <> '1' then
    select count(1) into iRecordCount
      from R_WIP A
         , R_WO B
      where a.wo_id = b.id
        and a.no = cWipno
        and a.del_flag + 0 = 0;
    if iRecordCount > 0 then
      select A.ID, A.Input_time, B.Is_Rework, b.Category_Key into iWipId, dIPT, iReworkFlag, cCategoryKey
        from R_WIP A
           , R_WO B
        where a.wo_id = b.id
          and a.no = cWipno
          and a.del_flag + 0 = 0;
                                        
      if iReworkFlag = 1 then
        dRT := dIPT;
      end if;  
      
      select /*+index(CR_DCS IX_CR_DCS_WIP_NO)*/ count(1) into iRecordCount
        from CR_DCS
        where wip_no = cWipno
          and station_type = 'FA-REPAIR-IN';
      if iRecordCount > 0 then
        iRF := 1;
        select /*+index(CR_DCS IX_CR_DCS_WIP_NO)*/ max(Start_Time) into dTemp
          from CR_DCS
          where wip_no = cWipno
            and station_type = 'FA-REPAIR-IN';
        select /*+index(CR_DCS IX_CR_DCS_WIP_NO)*/ count(1) into iRecordCount
          from CR_DCS
          where wip_no = cWipno
            and station_type = 'FA-REPAIR-OUT'
            and start_time + 0 > dTemp;  
        if iRecordCount = 0 then
          iIRF := 1; 
        else
          select /*+index(CR_DCS IX_CR_DCS_WIP_NO)*/ max(Start_Time) into dRT
            from CR_DCS
            where wip_no = cWipno
              and station_type = 'FA-REPAIR-OUT';            
        end if;           
      end if;                         
                                     
      --select count(1) into iRecordCount
      --  from R_Repair
      --  where wip_id = iWipId
      --    and Del_Flag + 0 = 0;
      --if iRecordCount > 0 then
      --  iRF := 1;
      --  select Nvl(Check_Out_Time, dIT) into dRCO
      --    from R_Repair
      --    where wip_id = iWipId
      --    and ID + 0 = (select max(ID) from R_Repair where wip_id = iWipId and del_flag + 0 = 0);
      --                         
      --  if dRCO <= dIT then
      --    iIRF := 1;  
      --  else     
      --    dRT := dRCO;  
      --  end if;        
      --end if;      
    end if;            
          
      iCheckFlag := 1;                                                 
      -------------------------
      iRecordCount := inStr(cStationList, cApple1);     
      if iRecordCount > 0 then
        --------------
        if (iIRF = 0) then 
          ---------------------
          if (cApple2 not like '%REP%') then
            cCheckStations := getRoutingControlStations(cApple1);
          
            cTemp := cCheckStations;
            ---------      
            while cTemp <> '00' loop
              --dbms_output.put_line(cTemp);
                iTemp := instr(cTemp, ','); 
                if iTemp <= 0 then
                  cCheckStation := cTemp;
                  cTemp := '';
                else
                  cCheckStation := substr(cTemp, 1, iTemp - 1);
                  cTemp := substr(cTemp, iTemp + 1, Length(cTemp) - iTemp);
                end if;  
                           
                --dbms_output.put_line('not rework and not repair');                
                ------------
                if (iRF = 0) and (iReworkFlag = 0) then
                  select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ count(1) into iRecordCount
                    from CR_DCS
                    where wip_no = cWipno
                      and Station_Type = cCheckStation;
                      --and nvl(symptom_code, '-') <> 'Clearing SFC on Connect';
                  if iRecordCount > 0 then
                    select Is_test_Fail into iIsTestFail
                      from(
                          select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ Is_test_Fail, Start_Time, Stop_Time
                            from CR_DCS
                            where wip_no = cWipno
                              and Station_Type = cCheckStation
                              --and nvl(symptom_code, '-') <> 'Clearing SFC on Connect'
                            order by add_date desc, stop_time desc    
                          )  
                      where rownum = 1;
                    if iIsTestFail = 1 then
                      iCheckFlag := 0;
                      cRet := cCheckStation || ' no PASS record. Go to ' || cCheckStation;
                      exit;
                    end if;
                  else
                    iCheckFlag := 0;
                    cRet := cCheckStation || ' no PASS record. Go to ' || cCheckStation;
                    exit;
                  end if;
                ---------------
                elsif (iRF = 1) then-----------  
                  iPOS := inStr(cStationList, cCheckStation);    
                  cStationTemp := substr(cStationList, iPOS, 70);
                  cRepairCheck := substr(cStationTemp, instr(cStationTemp, ',') + 1, 1);                  
                  
                  if cRepairCheck = '1' then
                    dTemp := dRT;
                  else
                    dTemp := dIT;
                  end if;    
                  
                  select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ count(1) into iRecordCount
                    from CR_DCS
                    where wip_no = cWipno
                      and Station_Type = cCheckStation
                      --and nvl(symptom_code, '-') <> 'Clearing SFC on Connect'
                      and Start_Time + 0 > dTemp;
                  if iRecordCount > 0 then
                    select Is_test_Fail into iIsTestFail
                      from(
                          select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ Is_test_Fail, Start_Time, Stop_Time
                            from CR_DCS
                            where wip_no = cWipno
                              and Station_Type = cCheckStation
                              --and nvl(symptom_code, '-') <> 'Clearing SFC on Connect'
                            order by add_date desc, stop_time desc    
                          )  
                      where rownum = 1;
                    if iIsTestFail = 1 then
                      iCheckFlag := 0;
                      cRet := cCheckStation || ' no PASS record. Go to ' || cCheckStation;
                      exit;
                    end if;
                  else
                    iCheckFlag := 0;
                    cRet := cCheckStation || ' no PASS record. Go to ' || cCheckStation;
                    exit;
                  end if;
                ---------------
                else
                    iPOS := inStr(cStationList, cCheckStation);    
                    cStationTemp := substr(cStationList, iPOS, 70);
                    cRepairCheck := substr(cStationTemp, instr(cStationTemp, ',') + 1, 1);                     
                    
                    if cRepairCheck = '1' then
                      dTemp := dRT;
                    else
                      dTemp := dIT;
                    end if;    
                    
                    select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ count(1) into iRecordCount
                      from CR_DCS
                      where wip_no = cWipno
                        and Station_Type = cCheckStation
                        --and nvl(symptom_code, '-') <> 'Clearing SFC on Connect'
                        and Start_Time + 0 > dTemp;
                    if iRecordCount > 0 then
                    select Is_test_Fail into iIsTestFail
                      from(
                          select /*+ index(cr_dcs IX_CR_DCS_WIP_NO ) */ Is_test_Fail, Start_Time, Stop_Time
                            from CR_DCS
                            where wip_no = cWipno
                              and Station_Type = cCheckStation
                              --and nvl(symptom_code, '-') <> 'Clearing SFC on Connect'
                            order by add_date desc, stop_time desc    
                          )  
                      where rownum = 1;
                      if iIsTestFail = 1 then
                        iCheckFlag := 0;
                        cRet := cCheckStation || ' no PASS record. Go to ' || cCheckStation;
                        exit;
                      end if;
                    else
                      iCheckFlag := 0;
                      cRet := cCheckStation || ' no PASS record. Go to ' || cCheckStation;
                      exit;
                    end if;
                end if;
            end loop; 
          ----------- 
          else   
            iCheckFlag := 0;
            cRet := 'Must check in at FA-REPAIR-IN';          
          end if;                  
        ------------
        else ----------
          --dbms_output.put_line('cApple2----' || cApple2);
          if cApple2 not like '%REP%' then
            --dbms_output.put_line('bbbbbb');
            iCheckFlag := 0;
            cRet := 'Must check out at FA-REPAIR-OUT';
          end if;  
        end if;         
                                  
        if iTSID = 1 then
          cTemp := 'tsid';
        else
          cTemp := 'ts';
        end if;        
                                  
        cTemp := '0 SFC_OK' || chr(10) || cTemp || '::' || cAppleStation || '::unit_process_check=';
        
        if iCheckFlag = 1 then
          cRet := cTemp || 'OK';
        else
          cRet := cTemp || 'UNIT OUT OF PROCESS ' || cRet;
        end if;
      ----------------                    
      else
        cRet := '2 SFC_FATAL_ERROR Invalid station ID<' || cAppleStation || '>';
      end if;
      -----------------------
  else
    if iTSID = 1 then
      cTemp := 'tsid';
    else
      cTemp := 'ts';
    end if;
            
    cTemp := '0 SFC_OK' || chr(10) || cTemp || '::' || cAppleStation || '::unit_process_check=';   
       
    cRet := cTemp || 'OK';
  end if;
                 
  return cRet;
----------------------
EXCEPTION
   WHEN OTHERS THEN
      cRet:= '2 SFC_FATAL_ERROR ' || SUBSTR(SQLERRM, 1, 500);   
      dbms_output.put_line(cRet);  
      return   cRet ;  
END;


/

