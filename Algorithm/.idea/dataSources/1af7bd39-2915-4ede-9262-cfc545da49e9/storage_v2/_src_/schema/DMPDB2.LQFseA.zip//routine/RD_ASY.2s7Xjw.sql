create PROCEDURE        RD_ASY(
   UnitSN      IN       VARCHAR2,
   ModuleSN    IN       VARCHAR2,
   StationCode IN       VARCHAR2,
   res         OUT      VARCHAR2
)
IS 
   g_ret varchar2(255);
   g_ok CONSTANT VARCHAR2 (2)  := 'OK';
   
   g_WipID number;
   g_WoID number;
   g_ProcessID number;
   g_WoPartsID number;   
   g_PartName varchar2(30); 
   g_ModuleSN varchar2(80);  
   g_WipPartsID number;
   
   g_Count int;
   g_Flag int;
   g_WipPartsTable int;  -- 0 R_WIP_Parts, 1 R_Wip_Parts_1

   FUNCTION Is_valid_Unit_SN
      RETURN VARCHAR2
   IS
     iCount integer;
     cFinishFlag varchar2(10);
   BEGIN
      SELECT count(1) INTO iCount
        FROM r_wip
        WHERE no = UnitSN and del_flag = 0;
      if iCount = 1 then
        select ID, wo_id, nvl(Finish_Flag, '***') into g_wipID, g_WoID, cFinishFlag
          FROM r_wip
          WHERE no = UnitSN and del_flag = 0;
        if cFinishFlag = '***' then
          RETURN g_ok;
        elsif cFinishFlag = 'G' then
          RETURN 'Unit has output';
        else
          RETURN 'Not WIP';
        end if;
      else
        RETURN 'Invalid unit SN';
      end if;   
   exception
     WHEN OTHERS THEN
       return SUBSTR(SQLERRM, 1, 200);    
   END;

   FUNCTION Is_Valid_Module_SN(iWoid in number, iProcessID in number)
      RETURN VARCHAR2
   IS
      --iCount int;
      cRet varchar2(255);
      iEEEPos int;      
      iLength int;
      cEEECode varchar2(30);
      cTemp varchar2(30);
      iPos int;
      cPartName varchar2(30);
      ----cursor My_Cur is select Part_Name
      cursor My_cur(APartName in varchar2) is select ID, Part_Name, Part_Type, EEE_Code, Scan_Type
                          from dmpdb2.r_wo_parts
                          where wo_id = iWoid
                            and Part_name || '' = APartName;
   BEGIN
      
      --select count(1) into iCount 
      --  from dmpdb2.process_chart
      --  where process_id = iProcessID
      --    and part_name = 'VGA';
          --and station_code = 'RD';
      --if iCount > 0 then
        
      --end if;
      iEEEPos := 12;
      iLength := 17;
      
      cPartName := 'VGA';
      cRet := 'Invalid ' || cPartName || ' SN';
      
      if Length(ModuleSN) = 17 then        
        for My_Val in My_cur(cPartName) loop
          cTemp := My_Val.EEE_Code;
          iPos := 1;
          while iPos > 0 loop
            iPos := instr(cTemp, ' ');
            if iPos > 0 then
              cEEECode := substr(cTemp, 1, iPos - 1);
              cTemp := substr(cTemp, iPos + 1, Length(cTemp) - iPos);
            else
              cEEECode := cTemp;
              cTemp := '~';
            end if;
            if substr(ModuleSN, iEEEPos, length(cEEECode)) = cEEECode then
              cRet := g_ok;
              g_WoPartsID := My_Val.id;
              g_PartName := My_Val.Part_Name;
              exit;
            end if;
          end loop;
          
          if cRet = g_ok then
            exit;
          end if;
        end loop;
      end if;
      
      return cRet;
   EXCEPTION
      WHEN OTHERS THEN
         return SUBSTR(SQLERRM, 1, 200); 
   END;
BEGIN

-- 1. Check Unit SN
-- 2. Check Module SN (eee code, length)
-- 3. Unit linked a module, 
-- 4. Asy
   g_ret := Is_valid_Unit_SN;
   g_Flag := 0;

   IF g_ret = g_ok THEN
      g_ProcessID := 46;
      g_ret := Is_Valid_Module_SN(g_WoID, g_ProcessID);
      IF g_ret = g_ok THEN
        select count(1) into g_Count
          from dual
          where exists(
              select a.ID 
                from dmpdb2.r_wip_parts_1 a
                   , dmpdb2.r_wo_parts b
                where a.wip_id = g_wipid
                  and a.wo_parts_id = b.id
                  and b.part_name || '' = g_partName
                  and a.del_flag = 0                
            );
        if g_Count > 0 then  
          g_WipPartsTable := 1; 
          select a.id, a.serial_No into g_WipPartsID, g_moduleSN 
            from dmpdb2.r_wip_parts_1 a
               , dmpdb2.r_wo_parts b
            where a.wip_id = g_wipid
              and a.wo_parts_id = b.id
              and b.part_name || '' = g_partName
              and a.del_flag = 0
              and rownum = 1;
          --dbms_output.put_line(g_moduleSN || '/' || ModuleSN);    
          if g_moduleSN = ModuleSN then            
            g_flag := 1;
          else
            g_flag := 2;    
          end if;   
          --dbms_output.put_line(g_flag);      
        else
          select count(1) into g_Count
            from dual
            where exists(
                select a.ID 
                  from dmpdb2.r_wip_parts a
                     , dmpdb2.r_wo_parts b
                  where a.wip_id = g_wipid
                    and a.wo_parts_id = b.id
                    and b.part_name || '' = g_partName
                    and a.del_flag = 0                
              );    
          if g_Count > 0 then  
            g_WipPartsTable := 1; 
            select a.id, a.serial_No into g_WipPartsID, g_moduleSN 
              from dmpdb2.r_wip_parts a
                 , dmpdb2.r_wo_parts b
              where a.wip_id = g_wipid
                and a.wo_parts_id = b.id
                and b.part_name || '' = g_partName
                and a.del_flag = 0
                and rownum = 1;
            if g_moduleSN = ModuleSN then
              g_flag := 1;
            else
              g_flag := 2;    
            end if;           
          else
            g_WipPartsTable := 1;
          end if;            
        end if;
        
        if g_flag = 2 then
          if g_WipPartsTable = 1 then
            insert into dmpdb2.r_wip_parts_1(ID, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, Del_Type, Del_Flag)
              select S_R_WIP_PARTS.NEXTVAL, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, '0', 1
                from dmpdb2.r_wip_parts_1
                where id = g_WipPartsID;
                 
            update dmpdb2.r_wip_parts_1 set Del_Flag = 1, Del_Type = 'D', Scan_Time = sysdate 
              where ID = g_WipPartsID;                
          else
            insert into dmpdb2.r_wip_parts(ID, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, Del_Type, Del_Flag)
              select S_R_WIP_PARTS.NEXTVAL, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, '0', 1
                from dmpdb2.r_wip_parts
                where id = g_WipPartsID;
                 
            update dmpdb2.r_wip_parts set Del_Flag = 1, Del_Type = 'D', Scan_Time = sysdate
              where ID = g_WipPartsID;        
          end if;
        end if; 
         
        if g_flag = 2 or g_flag = 0 then 
          insert into dmpdb2.r_wip_parts_1(ID, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, Del_Type, Del_Flag)
          values(S_R_WIP_PARTS.NEXTVAL
                 , g_WipID
                 , g_WoPartsID
                 , ModuleSN
                 , sysdate
                 , -777
                 , null
                 , 0);          
        end if;   
        
        g_ret := g_ok;      
      END IF; 
   END IF;
      
   res := '0 SFC_OK RD_ASY=' || g_ret;
   
   return;
EXCEPTION
   WHEN OTHERS THEN
      res := '2 SFC_FATAL_ERROR ' || SUBSTR(SQLERRM, 1, 200); 
      return;  
END;


/

