create PROCEDURE        RD_ASY_N41(
   UnitSN      IN       VARCHAR2,
   ModuleSN    IN       VARCHAR2,
   StationCode IN       VARCHAR2,
   res         OUT      VARCHAR2
)
IS 
   g_ret varchar2(255);
   g_ok CONSTANT VARCHAR2 (2)  := 'OK';
   
   g_WipID number;
   g_WoID number;
   g_ProcessID number;   
   
   
   
   g_SN1 varchar2(80);
   g_SN2 varchar2(80);
   g_pos int;
   t_ModuleSN varchar2(80);
   
   g_WoPartsID1 number;  
   g_EEE_Code1 varchar2(30);
   g_station_code1 varchar2(10);
   g_part_name1 varchar2(10);
   g_HH_Partno1 varchar2(30);
   g_Cust_partno1 varchar2(30);
   
   g_WoPartsID2 number;  
   g_EEE_Code2 varchar2(30);
   g_station_code2 varchar2(10);
   g_part_name2 varchar2(10);
   g_HH_Partno2 varchar2(30);
   g_Cust_partno2 varchar2(30);  
  
   --g_WipPartsID number;   
   --g_Count int;
   --g_Flag int;
   --g_WipPartsTable int;  -- 0 R_WIP_Parts, 1 R_Wip_Parts_1

   FUNCTION Is_valid_Unit_SN
      RETURN VARCHAR2
   IS
     iCount integer;
     cFinishFlag varchar2(10);
   BEGIN
      SELECT count(1) INTO iCount
        FROM r_wip
        WHERE no = UnitSN and del_flag = 0;
      if iCount = 1 then
        select ID, wo_id, nvl(Finish_Flag, '***') into g_wipID, g_WoID, cFinishFlag
          FROM r_wip
          WHERE no = UnitSN and del_flag = 0;
        if cFinishFlag = '***' then
          RETURN g_ok;
        elsif cFinishFlag = 'G' then
          RETURN 'Unit has output';
        else
          RETURN 'Not WIP';
        end if;
      else
        RETURN 'Invalid unit SN';
      end if;   
   exception
     WHEN OTHERS THEN
       return SUBSTR(SQLERRM, 1, 200);    
   END;

   FUNCTION Is_Valid_Module_SN(iWoid in number, iProcessID in number, cPartName in varchar2, cSN in varchar2)
      RETURN VARCHAR2
   IS
      --iCount int;
      cRet varchar2(255);
      --cEEEPos varchar2(255);
      --cLength varchar2(255);
      iEEEPos int;      
      iLength int;
      cEEECode varchar2(30);
      cTemp varchar2(30);
      iPos int;
      ----cursor My_Cur is select Part_Name
      cursor My_cur(APartName in varchar2) is select ID, Part_Name, Part_Type, EEE_Code, Scan_Type, cust_part_No, part_no
                          from dmpdb2.r_wo_parts
                          where wo_id = iWoid
                            and Part_name || '' = APartName;
   BEGIN
      --select to_number()
      --  from dmpdb2.process_chart
      --  where process_id = iProcessID
      --    and part_name = cPartName
      --    and rownum = 1;
      --if iCount > 0 then
        
      --end if;
      
      iEEEPos := 12;
      iLength := 17;
      
      cRet := 'Invalid ' || cPartName || ' SN';
      
      if Length(cSN) = 17 then        
        for My_Val in My_cur(cPartName) loop
          cTemp := My_Val.EEE_Code;
          iPos := 1;
          while iPos > 0 loop
            iPos := instr(cTemp, ' ');
            if iPos > 0 then
              cEEECode := substr(cTemp, 1, iPos - 1);
              cTemp := substr(cTemp, iPos + 1, Length(cTemp) - iPos);
            else
              cEEECode := cTemp;
              cTemp := '~';
            end if;
            if substr(cSN, iEEEPos, length(cEEECode)) = cEEECode then
              cRet := g_ok;
              if cPartName = 'VGA' then
                g_WoPartsID1 := My_Val.id;
                g_EEE_Code1 := cEEECode;
                g_station_code1 := 'RD';
                g_part_name1 := My_Val.Part_Name;
                g_HH_Partno1 := My_Val.part_no;
                g_Cust_partno1 := My_Val.cust_part_No;
              else
                g_WoPartsID2 := My_Val.id;
                g_EEE_Code2 := cEEECode;
                g_station_code2 := 'RD';
                g_part_name2 := My_Val.Part_Name;
                g_HH_Partno2 := My_Val.part_no;
                g_Cust_partno2 := My_Val.cust_part_No;              
              end if;  
              exit;
            end if;
          end loop;
          
          if cRet = g_ok then
            exit;
          end if;
        end loop;
      end if;
      
      return cRet;
   EXCEPTION
      WHEN OTHERS THEN
         return SUBSTR(SQLERRM, 1, 200); 
   END; 
   
   FUNCTION do_asy(cPartName IN VARCHAR, iWipID NUMBER, cSN IN VARCHAR2) RETURN VARCHAR2
   IS
     t_sn varchar2(80);
     t_WipPartsID number;
     t_count int;
     t_WipPartsTable int;
     t_flag int;
     
     t_WoPartsID number;  
     t_EEE_Code varchar2(30);
     t_station_code varchar2(10);
     t_part_name varchar2(10);
     t_HH_Partno varchar2(30);
     t_Cust_partno varchar2(30); 
   BEGIN
      t_WipPartsTable := 1;
      t_flag := 0;
      
              if cPartName = 'VGA' then
                t_WoPartsID := g_WoPartsID1;
                t_EEE_Code := g_EEE_Code1;
                t_station_code := g_station_code1;
                t_part_name := g_part_name1;
                t_HH_Partno := g_HH_Partno1;
                t_Cust_partno := g_Cust_partno1;
              else
                t_WoPartsID := g_WoPartsID2;
                t_EEE_Code := g_EEE_Code2;
                t_station_code := g_station_code2;
                t_part_name := g_part_name2;
                t_HH_Partno := g_HH_Partno2;
                t_Cust_partno := g_Cust_partno2;              
              end if;        
      
        select count(1) into t_count
          from dual
          where exists(
              select a.ID 
                from dmpdb2.r_wip_parts_1 a
                   , dmpdb2.r_wo_parts b
                where a.wip_id = iWipID
                  and a.wo_parts_id = b.id
                  and b.part_name || '' = cPartName
                  and a.del_flag = 0                
            );
        if t_Count > 0 then  
          t_WipPartsTable := 1; 
          select a.id, a.serial_No into t_WipPartsID, t_sn
            from dmpdb2.r_wip_parts_1 a
               , dmpdb2.r_wo_parts b
            where a.wip_id = iWipID
              and a.wo_parts_id = b.id
              and b.part_name || '' = cPartName
              and a.del_flag = 0
              and rownum = 1;
          --dbms_output.put_line(g_moduleSN || '/' || ModuleSN);    
          if t_sn = cSN then            
            t_flag := 1;
          else
            t_flag := 2;    
          end if;   
          --dbms_output.put_line(g_flag);      
        else
          select count(1) into t_count
            from dual
            where exists(
                select a.ID 
                  from dmpdb2.r_wip_parts a
                     , dmpdb2.r_wo_parts b
                  where a.wip_id = iWipID
                    and a.wo_parts_id = b.id
                    and b.part_name || '' = cPartName
                    and a.del_flag = 0                
              );    
          if t_Count > 0 then  
            t_WipPartsTable := 2; 
            select a.id, a.serial_No into t_WipPartsID, t_sn 
              from dmpdb2.r_wip_parts a
                 , dmpdb2.r_wo_parts b
              where a.wip_id = iWipID
                and a.wo_parts_id = b.id
                and b.part_name || '' = cPartName
                and a.del_flag = 0
                and rownum = 1;
            if t_sn = cSN then
              t_flag := 1;
            else
              t_flag := 2;    
            end if;           
          end if;            
        end if;
        
        if t_flag = 2 then
          if t_WipPartsTable = 1 then
            insert into dmpdb2.r_wip_parts_1(ID, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, Del_Type, Del_Flag
                                             , Property_05, Station_Code, part_name, HH_Part_No, Cust_Part_No, Edit_Time)
              select S_R_WIP_PARTS.NEXTVAL, Wip_ID, Wo_Parts_ID, Serial_No, sysdate, Assembly_By, 'D', 1
                     , Property_05, Station_Code, part_name, HH_Part_No, Cust_Part_No, Edit_Time
                from dmpdb2.r_wip_parts_1
                where id = t_WipPartsID;
                 
            update dmpdb2.r_wip_parts_1 set Del_Flag = 1, Del_Type = '0', edit_time = sysdate
              where ID = t_WipPartsID;                
          else
            insert into dmpdb2.r_wip_parts(ID, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, Del_Type, Del_Flag
                                           , Property_05, Station_Code, part_name, HH_Part_No, Cust_Part_No, Edit_Time)
              select S_R_WIP_PARTS.NEXTVAL, Wip_ID, Wo_Parts_ID, Serial_No, sysdate, Assembly_By, 'D', 1
                     , Property_05, Station_Code, part_name, HH_Part_No, Cust_Part_No, Edit_Time
                from dmpdb2.r_wip_parts
                where id = t_WipPartsID;
                 
            update dmpdb2.r_wip_parts set Del_Flag = 1, Del_Type = '0', edit_time = sysdate
              where ID = t_WipPartsID;        
          end if;
        end if; 
         
        if t_flag = 2 or t_flag = 0 then 
          insert into dmpdb2.r_wip_parts_1(ID, Wip_ID, Wo_Parts_ID, Serial_No, Scan_Time, Assembly_By, Del_Type, Del_Flag
                                           , Property_05, Station_Code, part_name, HH_Part_No, Cust_Part_No, Edit_Time)
          values(S_R_WIP_PARTS.NEXTVAL
                 , iWipID
                 , t_WoPartsID
                 , cSN
                 , sysdate
                 , -777
                 , null
                 , 0
                 , t_EEE_Code
                 , t_station_code
                 , t_part_name
                 , t_HH_Partno
                 , t_Cust_partno 
                 , sysdate
                 );                               
        end if;  

        return  g_ok;  
   EXCEPTION
      WHEN OTHERS THEN
         return 'error:' || SUBSTR(SQLERRM, 1, 200); 
   END;       
BEGIN

-- 1. Check Unit SN
-- 2. Check Module SN (eee code, length)
-- 3. Unit linked a module, 
-- 4. Asy
   g_ret := Is_valid_Unit_SN;
   g_WoPartsID1 := 0;
   g_WoPartsID2 := 0;
   
   select ID into g_ProcessID from dmpdb2.process 
     where code = 'N41' 
       and del_flag = 0;  
     
   IF g_ret = g_ok THEN     
     t_ModuleSN := ModuleSN;   
   
     g_pos := instr(ModuleSN, ',');   
     if g_pos > 0 then
       g_SN1 := substr(t_ModuleSN, 1, g_pos - 1);
       g_SN2 := substr(t_ModuleSN, g_pos + 1, length(t_ModuleSN) - g_pos);
       --dbms_output.put_line(g_SN1 || ' / ' || g_SN2);
       
       g_WoPartsID1 := -1;
       g_WoPartsID2 := -1;
       
       g_ret := Is_Valid_Module_SN(g_WoID, g_ProcessID, 'VGA', g_SN1);
       if g_ret = g_ok then
         g_ret := Is_Valid_Module_SN(g_WoID, g_ProcessID, 'CAM', g_SN2);
       end if;
       
       if g_ret = g_ok then
         g_ret := do_asy('VGA', g_WipID, g_SN1);         
       end if;
       
       if g_ret = g_ok then
         g_ret := do_asy('CAM', g_WipID, g_SN2);         
       end if; 
     else
       --g_ret := 'Invalid module SN(vga_sn,cam_sn)';
       g_SN1 := t_ModuleSN;
       
       g_WoPartsID1 := -1;
       g_WoPartsID2 := -1; 
             
       g_ret := Is_Valid_Module_SN(g_WoID, g_ProcessID, 'VGA', g_SN1);
       if g_ret = g_ok then
         g_ret := do_asy('VGA', g_WipID, g_SN1);         
       end if;  
     end if;  
   END IF;    
    
   if g_ret = g_ok then  
     commit;   
   else
     rollback;  
   end if;    
   
   res := '0 SFC_OK RD_ASY=' || g_ret;   
   return;
   
EXCEPTION
   WHEN OTHERS THEN
      res := '2 SFC_FATAL_ERROR ' || SUBSTR(SQLERRM, 1, 200); 
      return;  
END;


/

