create FUNCTION        setQaPlan(wipID in number,
  commodityID   in  number,
  userID        in  number,
  lineID        in  number,
  locationID    in  number,
  stationCode   in  varchar2,
  custPartNo    in  varchar2,
  partMode      in  varchar2,
  categoryKey   in  varchar2,
  countryCode   in  varchar2,
  shiftDate     in  date,
  shiftID       in  number,
  res           out varchar2)
  return number
as  
  var_str_Auto_QA           varchar2(10);
  var_num_QA_Plan_ID        number;
  var_num_Lot_Qty           number;
  var_num_CK_Point_Pos      number;
  var_num_shift_id          number;
  var_num_Count             number;
  var_num_R_QA_Record_id    number;
  var_num_Qty               number;
  var_num_First_PCS_CK      number;
  
  var_num_Not_CK_Only       varchar2(255);
  var_str_part_mode         varchar2(20);
  var_str_Cur_staCode       varchar2(5);
  var_str_Frm_staCode       varchar2(5);
  var_str_To_staCode        varchar2(5);
  var_str_LotCount_By       varchar2(15);
  var_str_LotCycle_By       varchar2(15);
  var_str_ReFlowDesc        varchar2(255);
  var_str_Stop_StaCode      varchar2(5);
  var_str_ReFlowHold        varchar2(2);
  var_str_Where             varchar2(1000);
  var_str_Where_Case        varchar2(4);
  var_str_ShiftDate         varchar2(10);
  
  var_dat_shift             date;
  var_bln_QA_DataExists     boolean;
  var_bln_First_PCS         boolean;
  var_bln_First_PCS_CK      boolean;
  var_bln_ReFlowHold        boolean;
  var_bln_Goon              boolean;
  var_bln_Picked            boolean;
begin
  res := 'N/A';
  var_str_Auto_QA := 'N';
  var_bln_First_PCS := false;
  var_bln_First_PCS_CK := false;
  var_bln_ReFlowHold   := false;
  var_bln_QA_DataExists:= false;
  var_bln_Goon := false;
  var_bln_Picked := false;
  var_str_ShiftDate := to_char(shiftDate, 'yyyy/mm/dd');
  var_str_part_mode := partMode;
  
  begin
    select key_value
      into var_str_Auto_QA
      from dmpdb2.sys_property
     where commodity_id = commodityID
       and key_name = 'SYS_USE_QA_AUTO';
  exception
    when no_data_found then
      var_str_Auto_QA := 'N';      
    when others then
      res := 'errors when check sys_property[SYS_USE_QA_AUTO]' || sqlcode || sqlerrm(sqlcode);
      return 2; --Error  
  end; 
  
  if var_str_Auto_QA is null then
    res := 'OK';    
  else 
    if (var_str_Auto_QA = 'N') or
       (var_str_Auto_QA = '0') then
      res := 'OK'; 
    end if;    
  end if;
  
  if res = 'OK' then 
    return 0;  -- Needn't QA
  end if;  
  
  begin
    select id, count_station_code, from_station_code, to_station_code/*, part_mode*/
         , check_point_pos, lot_qty, lot_count_by, lot_cycle_by, first_pcs_check
         , NVL(property_01,''), NVL(property_03,''), NVL(property_05,'')
      into var_num_QA_Plan_ID, var_str_Cur_staCode, var_str_Frm_staCode, var_str_To_staCode
         , var_num_CK_Point_Pos, var_num_Lot_Qty, var_str_LotCount_By, var_str_LotCycle_By, var_num_First_PCS_CK
         , var_str_Stop_StaCode, var_num_Not_CK_Only, var_str_ReFlowDesc 
      from dmpdb2.qa_plan 
     where commodity_id = commodityID
       and del_flag = 0
       and category_key = categoryKey
       and NVL(part_mode, ' ') =' ' 
       and count_station_code = stationCode
       and line_id = lineID;
    --DBMS_OUTPUT.PUT_LINE(var_num_QA_Plan_ID);
    if var_num_First_PCS_CK >= 1 then
      var_bln_First_PCS_CK := true;
    end if;
       
    if var_num_Not_CK_Only is not null then
      if var_num_Not_CK_Only = '1' then
        var_bln_ReFlowHold := true;        
      end if;
    end if;    
    
    if var_str_Stop_StaCode is null then
      var_str_Where := ' where commodity_id = ' || to_char(commodityID)
                    || '   and category_key = ''' || categoryKey || ''''
                    || '   and from_station_code = ''' || var_str_Frm_staCode || ''''
                    || '   and to_station_code = ''' || var_str_To_staCode || '''' 
                    || '   and qa_plan_id = ''' || to_char(var_num_QA_Plan_ID) || ''''  
                    || '   and property_01 is null';
    else
      var_str_Where := ' where commodity_id = ' || to_char(commodityID)
                    || '   and category_key = ''' || categoryKey || ''''
                    || '   and from_station_code = ''' || var_str_Frm_staCode || ''''
                    || '   and to_station_code = ''' || var_str_To_staCode || '''' 
                    || '   and qa_plan_id = ' || to_char(var_num_QA_Plan_ID) 
                    || '   and property_01 = ''' || var_str_Stop_StaCode || '''';
    end if;                
    
    if instr(var_str_LotCount_By, 'M') > 0 then      
      var_str_Where := var_str_Where
                    || '   and line_id is null'
                    || '   and cust_part_no is null'
                    || '   and country_code is null';
                    
    end if;
    
    if instr(var_str_LotCount_By, 'L') > 0 then     
      var_str_Where := var_str_Where
                    || '   and line_id = ' || to_char(lineID);
    else
      if instr(var_str_LotCount_By, 'S') > 0 then       
        var_str_Where := var_str_Where
                      || '   and location_id = ' || to_char(locationID);
      end if;
    end if;
    
    if instr(var_str_LotCount_By, 'P') > 0 then      
      var_str_Where := var_str_Where
                    || '   and cust_part_no = ''' || custPartNo || '''';                    
    else
      if instr(var_str_LotCount_By, 'C') > 0 then        
        var_str_Where := var_str_Where 
                      || '   and country_code = ''' || countryCode || '''';                      
      end if;
    end if;
    
    if var_str_LotCycle_By is not null then      
      var_str_Where := var_str_Where
                    || '   and shift_date = to_date(''' || var_str_ShiftDate || ''', ''yyyy/mm/dd'')';
      if var_str_LotCycle_By = 'S' then        
        var_str_Where := var_str_Where
                      || '   and shift_id = ' || to_char(shiftID);
      end if;              
    end if;
    
    execute immediate 'select count(1) from dmpdb2.D_QA_Counter ' || var_str_Where into var_num_count;
    if var_num_Count = 0 then
      if var_num_CK_Point_Pos = 0 then
        var_num_CK_Point_Pos := TRUNC(dbms_random.VALUE(0, var_num_Lot_Qty - 1) + 1);
      end if;
      
      insert into dmpdb2.D_QA_Counter(Commodity_ID, Category_Key, Count_Station_Code, From_Station_Code
                  , To_Station_Code, Part_Mode, Line_ID, Location_ID, Cust_Part_No
                  , Country_Code, Qty, Check_Point_Pos, Shift_Date, Shift_ID, QA_PLAN_ID
                  , Property_01)
           values(commodityID, categoryKey, var_str_Cur_staCode, var_str_Frm_staCode
                 , var_str_To_staCode, var_str_part_mode, lineID, locationID, custPartNo
                 , countryCode, 0, to_char(var_num_CK_Point_Pos), shiftDate, shiftID, to_char(var_num_QA_Plan_ID)
                 , var_str_Stop_StaCode);
                 
      if sql%rowcount = 0 then
        res := 'errors when insert data to table D_QA_Counter:' || sqlcode || sqlerrm(sqlcode);
        goto Last_Proc;
      end if;
    end if;
    
    execute immediate 'update dmpdb2.D_QA_Counter set qty = qty + 1 ' || var_str_Where;    
    if sql%rowcount = 0 then
      res := 'errors when update D_QA_Counter:' || sqlcode || sqlerrm(sqlcode);
      goto Last_Proc;
    end if;
    
    begin
      execute immediate 'select qty, check_point_pos, shift_date, shift_id from dmpdb2.D_QA_Counter ' || var_str_Where
                   into var_num_Qty, var_num_CK_Point_Pos, var_dat_shift, var_num_shift_id;
    exception
      when no_data_found then
        res := 'no data found in table D_QA_Counter';
        goto Last_Proc;
      when too_many_rows then
        res := 'to many rows in table D_QA_Counter';
        goto Last_Proc;
      when others then
        res := 'unknow errors in table D_QA_Counter' || sqlcode || sqlerrm(sqlcode);
        goto Last_Proc;
    end;               
    
    if dmpdb2.wipReFlow(wipID, commodityID, 'TA') and (var_str_To_staCode = 'CA') then
      var_bln_Goon := true;
    else
      var_bln_Goon := false;    
    end if;              
    
    if (var_bln_First_PCS and var_bln_First_PCS_CK) or
       (var_num_Qty = var_num_CK_Point_Pos) or
       var_bln_Goon then
       
       if dmpdb2.wipReFlow(wipID, commodityID, 'TA') and var_bln_ReFlowHold then
         res := 'OK ' || var_str_ReFlowDesc;
         return 0;
       else
         Sp_Next_ID('R_QA_Record', var_num_R_QA_Record_id);
         insert into dmpdb2.R_QA_Record(ID, Commodity_ID, WIP_ID, From_Station_Code, To_Station_Code
                     ,  Add_By, Add_Date, Property_01, Property_02)
              values(var_num_R_QA_Record_id, commodityID, wipID, var_str_Frm_staCode, var_str_To_staCode
                     , userID, sysdate, var_str_Stop_StaCode, lineID);  
         
         if sql%rowcount = 0 then
           res := 'Inert data to table R_QA_Record fail';
           goto Last_Proc;
         end if; 
         var_bln_Picked := true;               
       end if;
    end if;  
    
    if var_num_Qty >= var_num_Lot_Qty then
      if var_num_CK_Point_Pos = 0 then
        var_num_CK_Point_Pos := TRUNC(dbms_random.VALUE(0, var_num_Lot_Qty - 1) + 1);
      end if;
      
      execute immediate 'update dmpdb2.D_QA_Counter set qty = 0, check_point_pos = :p_check_point_pos ' || var_str_Where
                  using var_num_CK_Point_Pos; 
      
      if sql%rowcount = 0 then
        res := 'update data with table D_QA_Counter fail';
        goto Last_Proc;
      end if;            
    end if;   
    
    res := 'OK';
    
    <<Last_Proc>>
    if res = 'OK' then
      commit;
      if var_bln_Picked = true then
        res := var_str_To_staCode;
        return 1;
      else
        res := 'No Pick';
        return 0;
      end if;  
    else
      rollback;
      return 2;
    end if;                                              
  exception
    when no_data_found then
      res := 'OK';
      return 0;
    when others then
      res := 'errors when query data in the table of qa_plan:' || sqlcode || sqlerrm(sqlcode);
      return 2;
  end;    
exception
  when others then
    res := 'Unknown errors when setQAPlan:' || sqlcode || sqlerrm(sqlcode);
    return 2;
end;


/

