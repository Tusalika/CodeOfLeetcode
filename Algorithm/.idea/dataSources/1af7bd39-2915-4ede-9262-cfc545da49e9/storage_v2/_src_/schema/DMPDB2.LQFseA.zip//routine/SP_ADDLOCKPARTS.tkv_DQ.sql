create PROCEDURE        SP_ADDLOCKPARTS(cSerialNo varchar2, iLockID number
  , iEditBy number, cMsg out varchar2
)
AS

BEGIN


  INSERT INTO DMPDB2.LOCK_WIP_DETAIL_2 (LOCK_WIP_ID, WIP_NO, WIP_STATUS, ADD_BY, ADD_DATE, EDIT_BY
    , EDIT_DATE)
  VALUES ( iLockID
    , cSerialNO
    , 'S'
    , iEditBy
    , SYSDATE
    , iEditBy
    , SYSDATE
  );

  cMsg := '00:料件扣貨成功';
EXCEPTION
  WHEN OTHERS THEN    
    cMsg := '02:料件扣貨失敗,' || SUBSTR (SQLERRM, 1, 200);
END;

/

