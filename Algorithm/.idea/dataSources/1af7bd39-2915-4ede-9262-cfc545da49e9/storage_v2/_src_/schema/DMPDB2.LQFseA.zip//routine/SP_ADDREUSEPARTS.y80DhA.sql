create PROCEDURE        sp_addreuseparts (
   cserialno            VARCHAR2,
   cpartname            VARCHAR2,
   ireuseflag           NUMBER,
   creason              VARCHAR2,
   iwipid               NUMBER,
   cwipno               VARCHAR2,
   iwoid                NUMBER,
   cwono                VARCHAR2,
   ilineid              NUMBER,
   istationid           NUMBER,
   irepairid            NUMBER,
   irepairtimes         NUMBER,
   itestitemid          NUMBER,
   isymptomid           NUMBER,
   ddislinkdate         DATE,
   cnextaction          VARCHAR2,
   cp1                  VARCHAR2,                                  --chhpartno
   cp2                  VARCHAR2,                                --ccustpartno
   cp3                  VARCHAR2,                                   -- cvendor
   cp4                  VARCHAR2,                            -- csortingresult
   cp5                  VARCHAR2,
   cp6                  VARCHAR2,
   cp7                  VARCHAR2,
   cp8                  VARCHAR2,
   cp9                  VARCHAR2,
   cp10                 VARCHAR2,
   ieditby              NUMBER,
   cmsg           OUT   VARCHAR2
)
AS
   icount   NUMBER;
BEGIN 


   IF ireuseflag = 0
   THEN
      SELECT COUNT (serial_no)
        INTO icount
        FROM dmpdb2.r_reuse_parts
       WHERE serial_no = cserialno
         AND part_name = cpartname
         AND reuse_flag = 0
         AND del_flag = 0;

      IF icount > 0
      THEN
         cmsg := '00:Reuse 物料記錄已存在';
      ELSE
         INSERT INTO dmpdb2.r_reuse_parts
                     (serial_no, part_name, reuse_flag, reason, wip_id,
                      wip_no, wo_id, wo_no, line_id, station_id, repair_id,
                      repair_times, test_item_id, symptom_id, dislink_date,
                      next_action, add_by, add_date, edit_by, edit_date,
                      del_flag, property_01, property_02, property_03,
                      property_04, property_05, property_06
                     )
              VALUES (cserialno, cpartname, ireuseflag, creason, iwipid,
                      cwipno, iwoid, cwono, ilineid, istationid, irepairid,
                      irepairtimes, itestitemid, isymptomid, ddislinkdate,
                      cnextaction, ieditby, SYSDATE, ieditby, SYSDATE,
                      0, cp1, cp2, cp3,
                      cp4, cp5, cp6
                     );

         cmsg := '00:Reuse 物料記錄成功';
      END IF;
   ELSE
      SELECT COUNT (serial_no)
        INTO icount
        FROM dmpdb2.r_reuse_parts
       WHERE serial_no = cserialno
         AND part_name = cpartname
         AND reuse_flag = 0
         AND del_flag = 0;

      IF icount > 0
      THEN                                                     -- only for MLB
         UPDATE dmpdb2.r_reuse_parts
            SET reuse_flag = ireuseflag,
                edit_by = ieditby,
                edit_date = SYSDATE,
                property_01 = cp1,
                property_02 = cp2,
                property_03 = cp3,
                property_05 = cp5,
                property_06 = cp6
          WHERE serial_no = cserialno
            AND part_name = cpartname
            AND reuse_flag = 0
            AND del_flag = 0;

         cmsg := '00:Reuse 物料可用性更新成功';
      ELSE
         INSERT INTO dmpdb2.r_reuse_parts
                     (serial_no, part_name, reuse_flag, reason, wip_id,
                      wip_no, wo_id, wo_no, line_id, station_id, repair_id,
                      repair_times, test_item_id, symptom_id, dislink_date,
                      next_action, add_by, add_date, edit_by, edit_date,
                      del_flag, property_01, property_02, property_03,
                      property_04, property_05, property_06
                     )
              VALUES (cserialno, cpartname, ireuseflag, creason, iwipid,
                      cwipno, iwoid, cwono, ilineid, istationid, irepairid,
                      irepairtimes, itestitemid, isymptomid, ddislinkdate,
                      cnextaction, ieditby, SYSDATE, ieditby, SYSDATE,
                      0, cp1, cp2, cp3,
                      cp4, cp5, cp6
                     );

         cmsg := '00:新物料記錄成功';
      END IF;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := '02:Reuse 物料記錄失敗' || SUBSTR (SQLERRM, 1, 200);
END;
/

