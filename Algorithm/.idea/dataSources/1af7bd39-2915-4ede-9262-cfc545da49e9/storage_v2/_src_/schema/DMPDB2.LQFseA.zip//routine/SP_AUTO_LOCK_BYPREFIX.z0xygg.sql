create procedure        SP_AUTO_LOCK_BYPREFIX(
ccategorykey IN VARCHAR2,
cWipNo        IN VARCHAR2,
cWoNo        IN VARCHAR2,
cPackMode    IN VARCHAR2,
cPsdFlag     IN VARCHAR2,
cFlag         out VARCHAR2,  -----:  -1 error, 0 not lock,  1 lock
cRES           OUT VARCHAR2
) IS

  iLockDetailID NUMBER;
  iLockWipId NUMBER;
  iIsLock  varchar(20);
  iCount INT;
  cLockNo  varchar(100);
  cPrefix varchar(255);
--新產品管控工單自動扣貨成倉
/*
  FUNCTION GET_WO_INFOR
       RETURN VARCHAR2
  IS
  BEGIN
    SELECT pack_mode, property_18
      INTO cPackMode,cPsdFlag
      FROM r_wo
      WHERE no = cWoNo
       AND del_flag = 0;

    RETURN 'OK';
  EXCEPTION
      WHEN OTHERS
      THEN
         cFlag := '-1';
         RETURN  '工單無效 [' || cWoNo || ']';
  END; */
  
  CURSOR Cur_AUTOLOCKRULE(cPrefix IN VARCHAR2,ccategorykey IN VARCHAR2) IS
    SELECT id,category_key,PREFIX,LOCK_TYPE,REASON,REMARK,APPLY_BY,PART_NAME,PART_FACTOR,QUALITY_ALERT
      FROM dmpdb2.C_AUTOLOCK_BYPREFIX
     WHERE Prefix = cPrefix
       AND category_key = ccategorykey
       AND del_flag = 0 ;

  FUNCTION GET_LOCK_FLAG
       RETURN VARCHAR2
  IS
  BEGIN
    SELECT PROPERTY_06
      INTO iIsLock
      FROM DMPDB2.WO_PREFIX_MAP
     WHERE CATEGORY_KEY = ccategorykey
       AND PREFIX = SUBSTR(cWoNo,1,3)
       AND DEL_FLAG = 0;

    RETURN 'OK';
  EXCEPTION
      WHEN OTHERS
      THEN
         cFlag := '-1';
         RETURN  '工單單頭不存在 [' || SUBSTR(cWoNo,1,3) || ']';
  END;

  FUNCTION AUTOLOCK_WIP(cLockNo  varchar2,cLockType varchar2, cReason varchar2,
                       cApplyBy varchar2,cRemark varchar2,cPartName varchar2,cPartFactor varchar2,
                       cQualityAlert varchar2)RETURN VARCHAR2
  IS
       --cDt VARCHAR2 (50);
      iSum INT;
      cLockPattern varchar(100);
      cType varchar(100);
  BEGIN
       cLockPattern := '';
       cType := cLockType;
       SELECT COUNT(1) into iSum FROM DMPDB2.LOCK_WIP WHERE NO = cLockNo;
       --DBMS_OUTPUT.put_line (cLockNo);
       if (iSum <= 0) then
          --SELECT TO_char(sysdate,'yyyymmdd') datetime INTO cDt FROM dual;
          iLockWipId := get_next_id ('LOCK_WIP');
          --cLockNo := cLockNo + cDt;
          if (cLockType <> 'WIP') and (cLockType <> 'WAREHOUSE')then
             cLockPattern := cLockType;
             cType := 'STATION';          
          end if; 
          
          INSERT INTO DMPDB2.Lock_Wip
              (ID, No, Lock_Type, Reason,CATEGORY_KEY,REMARK,lock_pattern, 
               Apply_By, Apply_Date, Lock_By, Add_By, Add_Date, Edit_By, Edit_Date, Is_Product
            , Property_01,Property_02,Property_04,Property_05,IP_ADDRESS,Property_07,Property_08,Property_09  
              ) 
          VALUES (
              iLockWipId
            , cLockNo
            , cType
            , cReason
            , ccategorykey
            , cRemark 
            , cLockPattern
            , cApplyBy
            , SYSDATE
            , 'AUTO'
            , 1
            , SYSDATE
            , 1
            , SYSDATE
            , 'UNIT'
            , 'FOXCONN'
            , '*1'
            , ''
            , 'EPM'
            , ''
            ,cPartName
            ,cPartFactor
            ,cQualityAlert
              );
       else 
          SELECT ID into  iLockWipId FROM DMPDB2.LOCK_WIP WHERE NO = cLockNo;
       end if;
       
       if iLockWipId > 0 then

          SELECT COUNT(1) into iCount
            FROM DMPDB2.LOCK_WIP_DETAIL_2
           WHERE wip_no = cWipNo
             AND lock_wip_id = iLockWipId
             AND wip_status = 'S';

            if (iCount <= 0)  then 
                  iLockDetailID := get_next_id ('LOCK_WIP_DETAIL_2');
                  INSERT INTO DMPDB2.LOCK_WIP_DETAIL_2
                    (ID,
                     COMMODITY_ID,
                     LOCK_WIP_ID,
                     WIP_NO,
                     WIP_STATUS,
                     WIP_FLAG,
                     ADD_BY,
                     ADD_DATE,
                     EDIT_BY,
                     EDIT_DATE)
                  VALUES
                    (iLockDetailID,
                     33,
                     iLockWipID,
                     CWIPNO,
                     'S',
                     'OK',
                     -1,
                     SYSDATE,
                     -1,
                     SYSDATE);
                  commit;
                  cFlag := '1';
                  cRES := 'OK';
            end if;
       end if;

    RETURN 'OK';
  EXCEPTION
      WHEN OTHERS
      THEN
         cFlag := '-1';
         RETURN  'AUTOLOCK_WIP Fail! ';
  END;


BEGIN
    cFlag := '0';
    cRES := 'OK';
    cLockNo := '';
    iLockWipId := 0;
    cPrefix := '';
----auto lock warehouse by wo prefix 、pack mode、PSD flag

    cPrefix := SUBSTR(cWoNo,1,3);
   /* cRES := GET_LOCK_FLAG;
    IF cRES <> 'OK' THEN
       GOTO end_of_function;
    END IF;*/
    FOR My_Val in Cur_AUTOLOCKRULE(cPrefix,ccategorykey) LOOP
    --if  ((cPackMode = '1') or (cPackMode = '2')) then
      cLockNo := 'FATP_AOUTOLOCK_'||My_Val.Prefix||UPPER(My_Val.LOCK_TYPE)||+My_Val.category_key||'_'||My_Val.id; 
      --DBMS_OUTPUT.put_line ('1');                      
      cRES :=AUTOLOCK_WIP(cLockNo,UPPER(My_Val.LOCK_TYPE),My_Val.REASON,My_Val.APPLY_BY,My_Val.REMARK,My_Val.PART_NAME,My_Val.PART_FACTOR,My_Val.QUALITY_ALERT);    
      IF cRES <> 'OK' THEN
       GOTO end_of_function;
      END IF;
    --end if;
    END LOOP;
    commit;
        
    
  <<end_of_function>>    
  return; 

EXCEPTION
  WHEN OTHERS THEN
    rollback;
    cFlag := '-1';
    cRES := '自動扣貨（QH400）失敗';
end;

/

