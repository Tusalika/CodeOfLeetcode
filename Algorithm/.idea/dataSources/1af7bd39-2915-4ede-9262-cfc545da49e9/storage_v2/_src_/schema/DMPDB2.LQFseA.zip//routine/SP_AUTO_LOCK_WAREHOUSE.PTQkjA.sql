create procedure        SP_AUTO_LOCK_WAREHOUSE(
ccategorykey IN VARCHAR2,
cWipId        IN VARCHAR2,
cWipNo        IN VARCHAR2,
cFlag         out VARCHAR2,  -----:  -1 error, 0 not lock,  1 lock
cRES           OUT VARCHAR2
) AS
  iCount int;
  iLockDetailID INT;
  iLockWipID INT;
BEGIN
    cFlag := '0';
    cRES := 'OK';

----auto lock warehouse by repair status
    if (ccategorykey = 'N61') then
        iLockWipID := 97138;
    elsif (ccategorykey = 'N56') then
        iLockWipID := 97137; 
    else
        iLockWipID := 0;  
    end if; 
      
    if iLockWipID > 0 then      
        select count(1) into iCount
        from r_repair
        where wip_id = cwipid
          and del_flag = 0;
        if iCount > 0 then
              iLockDetailID := get_next_id ('LOCK_WIP_DETAIL_2');
              INSERT INTO DMPDB2.LOCK_WIP_DETAIL_2
                (ID,
                 COMMODITY_ID,
                 LOCK_WIP_ID,
                 WIP_NO,
                 WIP_STATUS,
                 WIP_FLAG,
                 ADD_BY,
                 ADD_DATE,
                 EDIT_BY,
                 EDIT_DATE)
              VALUES
                (iLockDetailID,
                 33,
                 iLockWipID,
                 CWIPNO,
                 'S',
                 'OK',
                 -1,
                 SYSDATE,
                 -1,
                 SYSDATE);
              commit;
              cFlag := '1';
              cRES := '維修機台已自動扣貨成品倉,扣貨人:IE陶玉香;568+85047';
          end if;  
    end if;
----
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    cFlag := '-1';
    cRES := '自動扣貨（QH400）失敗';
end;


/

