create procedure        SP_AUTO_LOCK_WAREHOUSE_2_T(
ccategorykey IN VARCHAR2,
cWipNo        IN VARCHAR2,
iCount        IN INT,
cFlag         out VARCHAR2,  -----:  -1 error, 0 not lock,  1 lock
cRES           OUT VARCHAR2
) AS
 -- iCount int;
  iLockDetailID INT;
  iLockWipID INT;
  iLockCount INT;
BEGIN
    cFlag := '0';
    cRES := 'OK';

----auto lock warehouse by repair status
    if (ccategorykey = 'N61') then
        iLockWipID := 159506;
    elsif (ccategorykey = 'N56') then
        iLockWipID := 159505; 
    elsif (ccategorykey = 'D11') then
       -- iLockWipID := 132682;--GL
        iLockWipID := 254042;--ZZ
    else
        iLockWipID := 0;  
    end if; 
      
    if iLockWipID > 0 then      
       select count(wip_no) into iLockCount
        from LOCK_WIP_DETAIL_2
        where lock_wip_id = iLockWipID
          and wip_no = cWipNo
          and wip_status = 'S';
        if (iCount > 0)and (iLockCount = 0) then
              iLockDetailID := get_next_id ('LOCK_WIP_DETAIL_2');
              INSERT INTO DMPDB2.LOCK_WIP_DETAIL_2
                (ID,
                 COMMODITY_ID,
                 LOCK_WIP_ID,
                 WIP_NO,
                 WIP_STATUS,
                 WIP_FLAG,
                 ADD_BY,
                 ADD_DATE,
                 EDIT_BY,
                 EDIT_DATE)
              VALUES
                (iLockDetailID,
                 33,
                 iLockWipID,
                 CWIPNO,
                 'S',
                 'OK',
                 -1,
                 SYSDATE,
                 -1,
                 SYSDATE);
              commit;
              cFlag := '1';
              cRES := '維修機台已自動扣貨成品倉,扣貨人:N61 IE黃渝崴;579-84405;N56 劉曉東;579-87485';
        end if;  
    end if;
----
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    cFlag := '-1';
    cRES := '自動扣貨（QH400）失敗';
end;


/

