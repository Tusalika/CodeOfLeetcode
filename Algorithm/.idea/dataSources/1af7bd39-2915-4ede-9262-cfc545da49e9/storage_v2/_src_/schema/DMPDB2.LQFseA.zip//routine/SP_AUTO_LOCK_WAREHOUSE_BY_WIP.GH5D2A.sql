create PROCEDURE        sp_auto_lock_warehouse_by_wip (
   ccategorykey   IN       VARCHAR2,
   cwipno         IN       VARCHAR2,
   icount         IN       INT,
   cres           OUT      VARCHAR2
)
AS
   -- iCount int;
   ilockdetailid   INT;
   ilockwipid      INT;
   cflag           VARCHAR2 (50);       -----:  -1 error, 0 not lock,  1 lock
BEGIN
   cflag := '0';
   cres := 'OK';

----auto lock warehouse by repair status
   IF (ccategorykey = 'N61')
   THEN
      ilockwipid := 159506;
   ELSIF (ccategorykey = 'N56')
   THEN
      ilockwipid := 159505;
   ELSE
      ilockwipid := 0;
   END IF;

   IF ilockwipid > 0
   THEN
      /* select count(1) into iCount
       from r_repair
       where wip_id = cwipid
         and del_flag = 0;*/
      IF icount > 0
      THEN
         ilockdetailid := get_next_id ('LOCK_WIP_DETAIL_2');

         INSERT INTO dmpdb2.lock_wip_detail_2
                     (ID, commodity_id, lock_wip_id, wip_no, wip_status,
                      wip_flag, add_by, add_date, edit_by, edit_date
                     )
              VALUES (ilockdetailid, 33, ilockwipid, cwipno, 'S',
                      'OK', -1, SYSDATE, -1, SYSDATE
                     );

         COMMIT;
         cflag := '1';
         cres :=
            '維修機台已自動扣貨成品倉,扣貨人:N61 IE黃渝崴;579-84405;N56 劉曉東;579-87485';
      END IF;
   END IF;

   cres := cres || ';' || cflag;
----
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      cres := '自動扣貨（QH400）失敗;-1';
END;

/

