create PROCEDURE        sp_auto_lock_warehouse_by_wo (
   ccategorykey   IN       VARCHAR2,
   cwipno         IN       VARCHAR2,
   cwono          IN       VARCHAR2,
   cpackmode      IN       VARCHAR2,
   cpsdflag       IN       VARCHAR2,
   cres           OUT      VARCHAR2
)
IS
   ilockdetailid   NUMBER;
   ilockwipid      NUMBER;
   iislock         VARCHAR (20);
   icount          INT;
   cflag           VARCHAR2 (50);       -----:  -1 error, 0 not lock,  1 lock

--新產品管控工單自動扣貨成倉
/*
  FUNCTION GET_WO_INFOR
       RETURN VARCHAR2
  IS
  BEGIN
    SELECT pack_mode, property_18
      INTO cPackMode,cPsdFlag
      FROM r_wo
      WHERE no = cWoNo
       AND del_flag = 0;

    RETURN 'OK';
  EXCEPTION
      WHEN OTHERS
      THEN
         cFlag := '-1';
         RETURN  '工單無效 [' || cWoNo || ']';
  END; */
   FUNCTION get_lock_flag
      RETURN VARCHAR2
   IS
   BEGIN
      SELECT property_06
        INTO iislock
        FROM dmpdb2.wo_prefix_map
       WHERE category_key = ccategorykey
         AND prefix = SUBSTR (cwono, 1, 3)
         AND del_flag = 0;

      RETURN 'OK';
   EXCEPTION
      WHEN OTHERS
      THEN
         cflag := '-1';
         RETURN '工單單頭不存在 [' || SUBSTR (cwono, 1, 3) || ']';
   END;
BEGIN
   cflag := '0';
   cres := 'OK';

----auto lock warehouse by wo prefix 、pack mode、PSD flag
   IF (ccategorykey = 'N56')
   THEN
      ilockwipid := 159500;
   ELSIF (ccategorykey = 'N61')
   THEN
      ilockwipid := 159501;
   ELSIF (ccategorykey = 'N66')
   THEN
      ilockwipid := 159502;
   ELSIF (ccategorykey = 'N71')
   THEN
      ilockwipid := 159503;
   ELSIF (ccategorykey = 'N69')
   THEN
      ilockwipid := 159504;
   ELSE
      ilockwipid := 0;
   END IF;

   IF ilockwipid > 0
   THEN
      SELECT COUNT (1)
        INTO icount
        FROM lock_wip_detail_2
       WHERE wip_no = cwipno AND lock_wip_id = ilockwipid AND wip_status = 'S';

      --cRES := GET_WO_INFOR;
            --if cRES <> 'OK' then
               --GOTO end_of_function;
            --end if;
      cres := get_lock_flag;

      IF cres <> 'OK'
      THEN
         GOTO end_of_function;
      END IF;

      IF     (icount <= 0)
         AND (iislock = '1')
         AND ((cpackmode = '1') OR (cpackmode = '2'))
      THEN                                         --and (cPsdFlag = '0') then
         ilockdetailid := get_next_id ('LOCK_WIP_DETAIL_2');

         INSERT INTO dmpdb2.lock_wip_detail_2
                     (ID, commodity_id, lock_wip_id, wip_no, wip_status,
                      wip_flag, add_by, add_date, edit_by, edit_date
                     )
              VALUES (ilockdetailid, 33, ilockwipid, cwipno, 'S',
                      'OK', -1, SYSDATE, -1, SYSDATE
                     );

         COMMIT;
         cflag := '1';
         cres := 'OK';
      ELSIF icount >= 1
      THEN
         cflag := '1';
         cres := 'OK';
      END IF;
   END IF;

   <<end_of_function>>
   cres := cres || ';' || cflag;
   RETURN;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      cres := '自動扣貨（QH400）失敗;-1';
END;

/

