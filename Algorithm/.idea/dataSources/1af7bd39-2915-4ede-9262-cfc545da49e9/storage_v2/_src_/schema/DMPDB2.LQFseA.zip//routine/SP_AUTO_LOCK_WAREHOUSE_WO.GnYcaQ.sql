create procedure        SP_AUTO_LOCK_WAREHOUSE_WO(
ccategorykey IN VARCHAR2,
cWipNo        IN VARCHAR2,
cWoNo        IN VARCHAR2,
cPackMode    IN VARCHAR2,
cPsdFlag     IN VARCHAR2,
cFlag         out VARCHAR2,  -----:  -1 error, 0 not lock,  1 lock
cRES           OUT VARCHAR2
) IS

  iLockDetailID NUMBER;
  iLockWipId NUMBER;
  iIsLock  varchar(20);
  iCount INT;
--新產品管控工單自動扣貨成倉
/*
  FUNCTION GET_WO_INFOR
       RETURN VARCHAR2
  IS
  BEGIN
    SELECT pack_mode, property_18
      INTO cPackMode,cPsdFlag
      FROM r_wo
      WHERE no = cWoNo
       AND del_flag = 0;

    RETURN 'OK';
  EXCEPTION
      WHEN OTHERS
      THEN
         cFlag := '-1';
         RETURN  '工單無效 [' || cWoNo || ']';
  END; */

  FUNCTION GET_LOCK_FLAG
       RETURN VARCHAR2
  IS
  BEGIN
    SELECT PROPERTY_06
      INTO iIsLock
      FROM DMPDB2.WO_PREFIX_MAP
     WHERE CATEGORY_KEY = ccategorykey
       AND PREFIX = SUBSTR(cWoNo,1,3)
       AND DEL_FLAG = 0;

    RETURN 'OK';
  EXCEPTION
      WHEN OTHERS
      THEN
         cFlag := '-1';
         RETURN  '工單單頭不存在 [' || SUBSTR(cWoNo,1,3) || ']';
  END;


BEGIN
    cFlag := '0';
    cRES := 'OK';

----auto lock warehouse by wo prefix 、pack mode、PSD flag
    if (ccategorykey = 'N56') then
        iLockWipId := 159500;
    elsif (ccategorykey = 'N61') then
        iLockWipId := 159501;
    elsif (ccategorykey = 'N66') then
        iLockWipId := 159502;
    elsif (ccategorykey = 'N71') then
        iLockWipId := 159503;
    elsif (ccategorykey = 'N69') then
        iLockWipId := 159504;
    else
        iLockWipId := 0;
    end if;

    if iLockWipId > 0 then

      SELECT COUNT(1) into iCount
        FROM LOCK_WIP_DETAIL_2
       WHERE wip_no = cWipNo
         AND lock_wip_id = iLockWipId
         AND wip_status = 'S';

  --cRES := GET_WO_INFOR;
        --if cRES <> 'OK' then
           --GOTO end_of_function;
        --end if;

  cRES := GET_LOCK_FLAG;
        IF cRES <> 'OK' THEN
           GOTO end_of_function;
        END IF;

        if (iCount <= 0) and (iIsLock = '1') and ((cPackMode = '1') or (cPackMode = '2')) then --and (cPsdFlag = '0') then
              iLockDetailID := get_next_id ('LOCK_WIP_DETAIL_2');
              INSERT INTO DMPDB2.LOCK_WIP_DETAIL_2
                (ID,
                 COMMODITY_ID,
                 LOCK_WIP_ID,
                 WIP_NO,
                 WIP_STATUS,
                 WIP_FLAG,
                 ADD_BY,
                 ADD_DATE,
                 EDIT_BY,
                 EDIT_DATE)
              VALUES
                (iLockDetailID,
                 33,
                 iLockWipID,
                 CWIPNO,
                 'S',
                 'OK',
                 -1,
                 SYSDATE,
                 -1,
                 SYSDATE);
              commit;
              cFlag := '1';
              cRES := 'OK';
         elsif iCount >= 1 then 
              cFlag := '1';
              cRES := 'OK';          
         end if;
    end if;

  <<end_of_function>>

  return;

EXCEPTION
  WHEN OTHERS THEN
    rollback;
    cFlag := '-1';
    cRES := '自動扣貨（QH400）失敗';
end;


/

