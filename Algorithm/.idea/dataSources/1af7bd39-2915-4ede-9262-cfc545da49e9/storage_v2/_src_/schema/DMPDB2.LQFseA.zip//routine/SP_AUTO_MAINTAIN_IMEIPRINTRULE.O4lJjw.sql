create PROCEDURE        sp_auto_maintain_imeiprintrule(
   vCustPartNo  VARCHAR2,
   vRet    OUT  VARCHAR2
)
AS
   g_procedure_name  CONSTANT VARCHAR2 (30) := 'sp_auto_maintain_imeiprintrule';
   g_ok              CONSTANT VARCHAR2 (2)  := 'OK';

   g_ret VARCHAR2(255);
   iCount int;
   iMaxID number;
   
   ---------------------------------------------------------------------------
BEGIN
  SELECT COUNT(1) INTO iCount
    FROM C_IMEI_MEID_PRINT_RULE
    WHERE CUST_PART_NO = vCustPartNo
      --AND del_flag = 0
      ;
      
  IF iCount > 0 THEN
    g_ret := g_ok;
  ELSE
    iMaxID := get_next_id ('C_IMEI_MEID_PRINT_RULE');
    IF iMaxID < 0 THEN
       g_ret := 'Error occur when select symptom id from table [s_id_info]';
    ELSE
       INSERT INTO dmpdb2.c_imei_meid_print_rule(id, cust_part_no, phone_mode
         , add_by, add_date, edit_by, edit_date, del_flag)
       VALUES(iMaxID, vCustPartNo, '', -1, sysdate, -1, sysdate, 1); -- del_flag 務必為 1
       g_ret := g_ok;      
    END IF;    
  END IF;
  
  COMMIT;
  
  vRet := g_ret || ';' || to_char(iMaxID);   
  RETURN;
EXCEPTION
  WHEN OTHERS THEN BEGIN
    vRet := 'ERROR(' || g_procedure_name || '):' || SUBSTR(SQLERRM, 1, 200);
  END;
END;

/

