create PROCEDURE        sp_auto_maintain_symptom(
   vSymptom  VARCHAR2,
   vRet    OUT  VARCHAR2
)
AS
   g_procedure_name  CONSTANT VARCHAR2 (30) := 'sp_auto_maintain_symptom';
   g_ok              CONSTANT VARCHAR2 (2)  := 'OK';

   g_ret VARCHAR2(255);
   iCount int;
   iMaxID number;
   
   ---------------------------------------------------------------------------
BEGIN
  SELECT COUNT(1) INTO iCount
    FROM symptom
    WHERE namee = vSymptom
      AND del_flag = 0;
      
  IF iCount > 0 THEN
    SELECT MAX(id) INTO iMaxID
      FROM symptom
      WHERE namee = vSymptom
        AND del_flag = 0;    
    g_ret := g_ok;
  ELSE
    iMaxID := get_next_id ('SYMPTOM');
    IF iMaxID < 0 THEN
       g_ret := 'Error occur when select symptom id from table [s_id_info]';
    ELSE
       INSERT INTO symptom(id, commodity_id, code, namec, namee
         , add_by, add_date, edit_by, edit_date, del_flag
         , property_01, property_03, property_07, property_08, property_11, property_15, property_16, property_17)
       VALUES(iMaxID, 33, 'AUTO' || to_char(iMaxID), vSymptom, vSymptom
         , -1, SYSDATE, -1, SYSDATE, 0
         , '0', '1', '0', '2', '0', '0', '0', '0');  
       g_ret := g_ok;      
    END IF;    
  END IF;
  
  COMMIT;
  
  vRet := g_ret || ';' || to_char(iMaxID);   
  RETURN;
EXCEPTION
  WHEN OTHERS THEN BEGIN
    vRet := 'ERROR(' || g_procedure_name || '):' || SUBSTR(SQLERRM, 1, 200);
    dmpdb2.write_bob_log(g_procedure_name, g_procedure_name, '0', vRet, vSymptom);
  END;
END;


/

