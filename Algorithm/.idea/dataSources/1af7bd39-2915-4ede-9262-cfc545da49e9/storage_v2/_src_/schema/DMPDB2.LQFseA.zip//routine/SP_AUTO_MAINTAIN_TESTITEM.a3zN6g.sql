create PROCEDURE        sp_auto_maintain_testitem(
   vTestItem  VARCHAR2,
   vRet    OUT  VARCHAR2
)
AS
   g_procedure_name  CONSTANT VARCHAR2 (30) := 'sp_auto_maintain_testitem';
   g_ok              CONSTANT VARCHAR2 (2)  := 'OK';

   g_ret VARCHAR2(255);
   iCount int;
   iMaxID number;
   
   ---------------------------------------------------------------------------
BEGIN
  SELECT COUNT(1) INTO iCount
    FROM Test_Item
    WHERE code = vTestItem
      AND del_flag = 0;
      
  IF iCount > 0 THEN
    SELECT MAX(id) INTO iMaxID
      FROM Test_Item
      WHERE code = vTestItem
        AND del_flag = 0;  
    g_ret := g_ok;
  ELSE
    iMaxID := get_next_id('TEST_ITEM');
    IF iMaxID < 0 THEN
       g_ret := 'Error occur when select Test_Item id from table [s_id_info]';
    ELSE
       INSERT INTO test_item(id, commodity_id, code, namec, namee
         , add_by, add_date, edit_by, edit_date, del_flag
         , property_01, property_02, property_03, property_04)
       VALUES(iMaxID, 33, vTestItem, vTestItem, vTestItem
         , -1, SYSDATE, -1, SYSDATE, 0
         , vTestItem, '0', NULL, '0');  
       g_ret := g_ok;      
    END IF;    
  END IF;
  
  COMMIT;
  
  vRet := g_ret || ';' || to_char(iMaxID);   
  RETURN;
EXCEPTION
  WHEN OTHERS THEN BEGIN
    vRet := 'ERROR(' || g_procedure_name || '):' || SUBSTR(SQLERRM, 1, 200);
    dmpdb2.write_bob_log(g_procedure_name, g_procedure_name, '0', vRet, vTestItem);
  END;
END;


/

