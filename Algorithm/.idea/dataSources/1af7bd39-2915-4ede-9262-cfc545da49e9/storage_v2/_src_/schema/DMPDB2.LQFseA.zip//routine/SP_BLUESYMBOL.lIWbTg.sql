create PROCEDURE        sp_bluesymbol (
   cserialno         VARCHAR2,
   cflag             VARCHAR2,
   cstepcode         VARCHAR2,
   cfloor            VARCHAR2,
   ceditby           VARCHAR2,
   cmsg        OUT   VARCHAR2
)
AS
   g_llost    BOOLEAN;
   g_lscan    BOOLEAN;
   ioverdue   INT;
   cresult    VARCHAR2 (50);

   /*********Blue flag ************/
   /*
   A: asy
   R: rework
   L: Lost
   O: verdue
   S: scrap
      */
   /********* result ************/
   /*
   0: no
   1: yes

   */

   /**************  For Checking LB_LOST  *********************************************/
   FUNCTION checklblost
      RETURN BOOLEAN
   AS
      v_clostno   VARCHAR2 (80);
   BEGIN
      SELECT lost_nal
        INTO v_clostno
        FROM dmpdb2.lb_lost
       WHERE lost_nal = cserialno AND is_acti = 'L';

      cmsg := 'OK:該序列號已申請丟失';
      RETURN FALSE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN TRUE;
      WHEN OTHERS
      THEN
         cmsg := 'ERROR: LB_LOST CHECK FAIL';
         RETURN FALSE;
   END;

/****************************************************************************************/
   FUNCTION checklbscan
      RETURN BOOLEAN
   AS
      v_csfc    VARCHAR2 (20);
      v_cacti   VARCHAR2 (20);
   BEGIN
      SELECT is_sfc, is_acti
        INTO v_csfc, v_cacti
        FROM dmpdb2.lb_scan
       WHERE nal_sn = cserialno AND stage_id = 'S004';

      IF v_csfc = 'Y'
      THEN
         cmsg := 'OK:該序列號已使用過';
         RETURN FALSE;
      ELSIF v_cacti <> 'Y'
      THEN
         cmsg := 'OK:該序列號不可用';
         RETURN FALSE;
      ELSIF v_csfc = 'S'
      THEN
         cmsg := 'OK:該序列號已報廢';
         RETURN FALSE;
      ELSIF v_csfc = 'N'
      THEN
         RETURN TRUE;
      ELSE
         cmsg := 'OK:未知的序列號狀態';
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         cmsg := 'OK:藍標系統不存在該序列號或是上一工站非SOO4';
         RETURN FALSE;
      WHEN OTHERS
      THEN
         cmsg := 'ERROR: LB_SCAN CHECK FAIL';
         RETURN FALSE;
   END;
/*******  Main  *********************************************************/
BEGIN
   IF cflag = 'R'
   THEN
      UPDATE dmpdb2.lb_scan
         SET rework_floor = cfloor,
             is_rework = 1
       WHERE nal_sn = cserialno AND stage_id = cstepcode;

      cresult := '1';
      cmsg := 'OK';
   ELSIF cflag = 'O'
   THEN
      SELECT is_overdue
        INTO ioverdue
        FROM (SELECT   is_overdue
                  FROM dmpdb2.lb_scan
                 WHERE nal_sn = cserialno AND stage_id = cstepcode
              ORDER BY scan_time DESC)
       WHERE ROWNUM < 2;

      IF ioverdue > 2
      THEN
         cresult := '1';
      ELSE
         cresult := '0';
      END IF;

      cmsg := 'OK';
   ELSIF cflag = 'S'
   THEN
      UPDATE dmpdb2.lb_scan
         SET is_sfc = 'S'
       WHERE nal_sn = cserialno AND stage_id = 'S004';

      UPDATE dmpdb2.lb_scan_end
         SET is_sfc = 'S'
       WHERE nal_sn = cserialno AND stage_id = 'S004';

      cresult := '1';
      cmsg := 'OK';
   ELSIF cflag = 'A'
   THEN
      g_llost := checklblost;
      g_lscan := checklbscan;

      IF g_llost AND g_lscan
      THEN
         UPDATE dmpdb2.lb_scan
            SET is_sfc = 'Y',
                stage_id = cstepcode,
                user_id = ceditby
          WHERE nal_sn = cserialno AND stage_id = 'S004';
         cmsg := 'OK';
         cresult := '1';
      ELSE
         cresult := '0';
      END IF;
      
   END IF;

   cmsg := cmsg || ';' || cresult;
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := 'ERROR:藍標回寫失敗' || SUBSTR (SQLERRM, 1, 200) || ';0';
END;

/

