create PROCEDURE        sp_check_in (
   --user name
   emp           IN       VARCHAR2,
   --wip_no
   DATA          IN       VARCHAR2,
   --工站唯一號碼
   station_num   IN       VARCHAR2,
   --返回信息
   res           OUT      VARCHAR2
)
AS
   --輸入參數
   in_user_no                VARCHAR2 (25);
   in_wip_no                 VARCHAR2 (25);
   in_station_num            VARCHAR2 (25);
   --全局變量
   g_commodity_id   CONSTANT PLS_INTEGER   := constant_package.g_commodity_id;
   g_defect_flag             PLS_INTEGER;
   g_line_id                 PLS_INTEGER;
   g_user_id                 PLS_INTEGER;
   g_station_location_id     PLS_INTEGER;
   g_station_id              PLS_INTEGER;
   g_fresh                   PLS_INTEGER;
   g_currdate                DATE;
   g_ok             CONSTANT VARCHAR2 (2)  := 'OK';
   g_work_time               VARCHAR2 (5);
   g_next_station_code       VARCHAR2 (25);
   g_station_code            VARCHAR2 (25);
   g_category_key            VARCHAR2 (25);
   g_wip_id                  PLS_INTEGER;
   g_wo_id                   PLS_INTEGER;
   g_r_wip_log_id            PLS_INTEGER;

   FUNCTION handle_station_location_info
      RETURN VARCHAR2
   IS
      v_flag         PLS_INTEGER;
      v_station_no   PLS_INTEGER;
   BEGIN
      SELECT a.ID, a.line_id, a.station_code, b.ID
        INTO g_station_location_id, g_line_id, g_station_code, g_station_id
        FROM station_location a, station b
       WHERE a.del_flag = 0
         AND b.del_flag = 0
         AND b.code = a.station_code
         AND a.mac_address = in_station_num;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN    'Error occur when select id from [station_location] ,mac_address = '
                || in_station_num
                || ' 請掃<UNDO>重新作業';
   END handle_station_location_info;

   FUNCTION write_wip_log
      RETURN VARCHAR2
   IS
   BEGIN
      IF INSTR (wip_info_package.rec_wip_info.route_history, g_station_code) >
                                                                            0
      THEN
         --重復經過此工站
         g_fresh := 0;
      ELSE
         --第一次通過此工站
         g_fresh := 1;
      END IF;

      INSERT INTO r_wip_log
                  (ID, wip_id, line_id, station_id,
                   station_time, defect_flag, fresh_flag, del_flag,
                   location_id
                  )
           VALUES (g_r_wip_log_id, g_wip_id, g_line_id, g_station_id,
                   g_currdate, g_defect_flag, g_fresh, '0',
                   g_station_location_id
                  );

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when inser into table [r_wip_log]';
   END write_wip_log;

   FUNCTION update_repair
      RETURN VARCHAR2
   IS
   BEGIN
      UPDATE r_repair
         SET edit_by = g_user_id,
             edit_date = g_currdate,
             check_in_time = g_currdate,
             check_in_by = g_user_id
       WHERE check_in_time IS NULL AND del_flag = 0 AND wip_id = g_wip_id;

      IF SQL%ROWCOUNT = 1
      THEN
         RETURN g_ok;
      ELSE
         RETURN '更新表[r_repair]失敗, 數據已經被改變';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when update table [r_repair]';
   END update_repair;

   FUNCTION update_wip (pre_station VARCHAR2)
      RETURN VARCHAR2
   IS
   BEGIN
      UPDATE r_wip
         SET line_id = g_line_id,
             route_history = route_history || g_station_code || '`',
             pre_station_code = g_station_code,
             cur_station_code = g_station_code,
             scan_time = g_currdate,
             defect_flag = g_defect_flag,
             edit_by = g_user_id,
             edit_date = g_currdate,
             property_07 = g_next_station_code
       WHERE (pre_station_code = pre_station OR pre_station_code IS NULL)
         AND ID = g_wip_id;

      IF SQL%ROWCOUNT = 1
      THEN
         RETURN g_ok;
      ELSE
         RETURN '更新表[r_wip]失敗, 數據已經被改變';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when update table [r_wip]';
   END update_wip;
/******************************************************************************
 1. IsActiveWip: 如果成功返回該wip的信息
 2. CheckRoute
 3 IsCanProcess
 4. when Fail: 判斷  IsTestItem  isSymptom  then insert into R_Repair
 5. update r_wip
 6. insert into r_wip_log
 7. update A_test_result
******************************************************************************/
BEGIN
   g_r_wip_log_id := get_next_id ('R_WIP_LOG');

   IF g_r_wip_log_id < 0
   THEN
      res := 'Error occur when select r_wip_log id from table [s_id_info]';
      GOTO end_of_function;
   END IF;

   COMMIT;

   SELECT SYSDATE
     INTO g_currdate
     FROM DUAL;

   g_work_time := TO_CHAR (g_currdate, 'HH24:MI');
   --用戶
   in_user_no := TRIM (emp);
   in_wip_no := TRIM (DATA);
   --line name 對應表line的字段namee
   in_station_num := TRIM (station_num);
   g_user_id := get_user_id (in_user_no);

   IF g_user_id < 0
   THEN
      res :=
            'Error occur when select user id from table [app_user], employee_id = '
         || in_user_no;
      GOTO end_of_function;
   END IF;

   res := handle_station_location_info;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res :=
      wip_info_package.is_active_wip (g_station_code,
                                      in_wip_no,
                                      g_commodity_id
                                     );

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   g_wip_id := wip_info_package.rec_wip_info.wip_id;
   g_wo_id := wip_info_package.rec_wip_info.wo_id;
   g_category_key := wip_info_package.rec_wip_info.category_key;
   g_defect_flag := 1;
   --判斷路由﹐分良與不良
   res := wip_info_package.is_route_correct (g_station_code, g_defect_flag);

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   g_next_station_code :=
        wip_info_package.get_should_to_station (g_station_code, g_defect_flag);

   --res := get_shift_id;
   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   COMMIT;
--以下為更新數據
   --更新R_WIP
   res := update_wip (wip_info_package.rec_wip_info.pre_station_code);

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   --更新到表R_WIP_LOG
   res := write_wip_log ();

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res := update_repair;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   IF res = g_ok
   THEN
      COMMIT;
      res := 'OK DISPLAY={產品已經通過本站}';
      RETURN;
   END IF;

   <<end_of_function>>
   ROLLBACK;
END;


/

