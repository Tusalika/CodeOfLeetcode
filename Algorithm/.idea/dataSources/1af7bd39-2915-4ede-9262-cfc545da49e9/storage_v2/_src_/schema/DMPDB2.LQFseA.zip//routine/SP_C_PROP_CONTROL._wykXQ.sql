create PROCEDURE        SP_C_PROP_CONTROL (
   cAction     IN     VARCHAR2,
   cCategory   IN     VARCHAR2,
   cType       IN     VARCHAR2,
   cKey_Code   IN     VARCHAR2,
   cValue      IN     VARCHAR2,
   cRes           OUT VARCHAR2)
AS
   g_TableName    VARCHAR2 (10);
   g_Type_4       VARCHAR2 (1);
   g_Value_temp   VARCHAR2 (255);
   g_Sql          VARCHAR2 (500);
   g_Count        INT;

   PROCEDURE do_insert (inKey     IN VARCHAR2,
                        inValue   IN VARCHAR2,
                        inTable   IN VARCHAR2)
   AS
      v_sql   VARCHAR2 (1000);
   BEGIN
      IF inTable = 'C_PROP_BAK'
      THEN
         v_sql :=
            'INSERT INTO DMPDB2.C_PROP_BAK (ID,  CATEGORY, TYPE_4, KEY_CODE, PROPERTY_01,ADD_BY,ADD_DATE,EDIT_BY,EDIT_DATE,DEL_FLAG)  VALUES ('
            || dmpdb2.get_next_id ('C_PROP_BAK')
            || ','
            || CHR (39)
            || UPPER (cCategory)
            || CHR (39)
            || ','
            || CHR (39)
            || g_Type_4
            || CHR (39)
            || ','
            || CHR (39)
            || inKey
            || CHR (39)
            || ','
            || CHR (39)
            || inValue
            || CHR (39)
            || ','
            || '-1'
            || ','
            || CHR (39)
            || SYSDATE
            || CHR (39)
            || ','
            || '-1'
            || ','
            || CHR (39)
            || SYSDATE --TO_DATE(TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI;SS'),'YYYY/MM/DD HH24:MI;SS')
            || CHR (39)
            || ',';

         --Delete 備份Del_Flag為1.
         IF UPPER (cAction) = 'UPDATE'
         THEN
            v_sql := v_sql || 0 || ')';
         ELSE
            v_sql := v_sql || 1 || ')';
         END IF;

         EXECUTE IMMEDIATE v_sql;
      ELSE
         v_sql :=
               'INSERT INTO DMPDB2.'
            || inTable
            || ' (ID,TYPE_4,KEY_CODE, PROPERTY_01) VALUES ('
            || dmpdb2.get_next_id (inTable)
            || ','
            || CHR (39)
            || g_Type_4
            || CHR (39)
            || ','
            || CHR (39)
            || inKey
            || CHR (39)
            || ','
            || CHR (39)
            || inValue
            || CHR (39)
            || ')';

         EXECUTE IMMEDIATE v_sql;
      END IF;
   END;

   PROCEDURE do_update (inKey     IN VARCHAR2,
                        inValue   IN VARCHAR2,
                        inTable   IN VARCHAR2)
   AS
      v_sql   VARCHAR2 (500);
   BEGIN
      v_sql :=
            'UPDATE DMPDB2.'
         || inTable
         || ' A  SET A.PROPERTY_01 ='
         || CHR (39)
         || inValue
         || CHR (39)
         || ' WHERE A.KEY_CODE = '
         || CHR (39)
         || inKey
         || CHR (39)
         || ' AND A.TYPE_4 = '
         || CHR (39)
         || g_Type_4
         || CHR (39);

      EXECUTE IMMEDIATE v_sql;
   END;

   PROCEDURE do_delete (inKey     IN VARCHAR2,
                        cValue    IN VARCHAR2,
                        inTable   IN VARCHAR2)
   AS
      v_sql   VARCHAR2 (500);
   BEGIN
      v_sql :=
            ' DELETE DMPDB2.'
         || inTable
         || ' A WHERE A.KEY_CODE = '
         || CHR (39)
         || inKey
         || CHR (39)
         || ' AND A.TYPE_4 = '
         || CHR (39)
         || g_Type_4
         || CHR (39)
         || ' AND A.PROPERTY_01 = '
         || CHR (39)
         || cValue
         || CHR (39);

      EXECUTE IMMEDIATE v_sql;
   END;
BEGIN
   --step 1 傳參有效性檢查
   IF UPPER (cType) = 'NANDID'
   THEN
      g_Type_4 := '7';
   ELSIF UPPER (cType) = 'NANDSIZE'
   THEN
      g_Type_4 := '7';
   ELSIF UPPER (cType) = 'WIFIVENDOR'
   THEN
      g_Type_4 := '8';
   ELSE
      cRes := 'ERROR TYPE:' || cType;
      RETURN;
   END IF;

   SELECT COUNT (1)
     INTO g_Count
     FROM DMPDB2.CATEGORY a
    WHERE A.CATEGORY_KEY = cCategory;



   IF g_Count = 0
   THEN
      cRes := 'ERROR CATEGORY:' || cCategory || 'Not Found !';
      RETURN;
   END IF;

   IF cKey_Code IS NULL
   THEN
      cRes := 'ERROR KEYCODE IS NULL';
      RETURN;
   END IF;


   IF cValue IS NULL AND UPPER (cAction) <> 'SELECT'
   THEN
      cRes := 'ERROR VALUE IS NULL';
      RETURN;
   END IF;

   --Step 2 全局變量賦值
   g_TableName := 'C_PROP_' || UPPER (cCategory);
   g_Sql :=
      'SELECT NVL (Y.PROPERTY_01, 0) A  FROM (SELECT ROWNUM RN FROM DUAL) X, (SELECT A.PROPERTY_01, ROWNUM RN  FROM DMPDB2.'
      || g_TableName
      || ' A  WHERE A.KEY_CODE = '
      || CHR (39)
      || cKey_Code
      || CHR (39)
      || ' AND A.TYPE_4 = '
      || CHR (39)
      || g_Type_4
      || CHR (39)
      || ')Y  WHERE X.RN<= Y.RN(+)';

   EXECUTE IMMEDIATE g_Sql INTO g_Value_temp;

   --Step 3  執行動作
   IF UPPER (cAction) = 'SELECT'
   THEN
      IF g_Value_temp <> '0'
      THEN
         cRes :=
               'Data Found.    KEY_CODE: '
            || cKey_Code
            || '    Key_value: '
            || g_Value_temp;
         RETURN;
      ELSE
         cRes := 'Data Not Found.    KEY_CODE: ' || cKey_Code;
         RETURN;
      END IF;
   ELSIF UPPER (cAction) = 'INSERT'
   THEN
      IF g_Value_temp <> '0'
      THEN
         cRes :=
               'Already exist.    KEY_CODE: '
            || cKey_Code
            || '    Key_value: '
            || g_Value_temp;
         RETURN;
      END IF;

      do_insert (cKey_Code, cValue, g_TableName);
      cRes :=
            'OK.Insert OK.   Category:'
         || cCategory
         || ' KEY_CODE: '
         || cKey_Code
         || '    Key_value: '
         || g_Value_temp;
   ELSIF UPPER (cAction) = 'UPDATE'
   THEN
      IF g_Value_temp = '0'
      THEN
         cRes :=
               'Data not found.   KEY_CODE: '
            || cKey_Code
            || '   TYPE: '
            || cType;
         RETURN;
      END IF;

      do_insert (cKey_Code, g_Value_temp, 'C_PROP_BAK');
      do_update (cKey_Code, cValue, g_TableName);
      cRes :=
            'OK.Update OK.   Category:'
         || cCategory
         || ' KEY_CODE: '
         || cKey_Code
         || '    Key_value: '
         || g_Value_temp;
   ELSIF UPPER (cAction) = 'DELETE'
   THEN
      IF g_Value_temp = '0'
      THEN
         cRes :=
               'Data not found.   KEY_CODE: '
            || cKey_Code
            || '   TYPE: '
            || cType;
         RETURN;
      END IF;

      do_insert (cKey_Code, g_Value_temp, 'C_PROP_BAK');
      do_delete (cKey_Code, cValue, g_TableName);
      cRes :=
            'OK.Delete OK.   Category:'
         || cCategory
         || ' KEY_CODE: '
         || cKey_Code;
   else 
    cRes :=
            'Wrong Actiong.   Action:'
         || cAction;
   END IF;

   COMMIT;
   RETURN;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      cRes := 'SP_C_PROP_CONTROL:' || SUBSTR (SQLERRM, 1, 200);
      RETURN;
END;
/

