create PROCEDURE        SP_FIXTURE_OPERATE (
   cserialno            VARCHAR2,
   cCommand         VARCHAR2,
   cBlock2d             VARCHAR2,    
   cmsg           OUT   VARCHAR2
)
AS
    iremoveid NUMBER;
    icount NUMBER;
BEGIN

         IF cCommand = 'ADD' THEN
             BEGIN
                 INSERT INTO dmpdb2.r_fixtrue
                         (id, serial_no, add_date, edit_date, del_flag,property_01)
                 VALUES 
                         (seq_r_fixtrue_id.nextval  ,cserialno, sysdate, sysdate,0,cBlock2d);

                 cmsg := '00:ADD_OK';
             EXCEPTION
                WHEN OTHERS THEN
                    BEGIN
                        cmsg := '01:ADD_ERROR';
                     END;
             END;
         ELSIF cCommand = 'REMOVE' THEN
                BEGIN
                   
                    select count(*) into icount  from dmpdb2.r_fixtrue where serial_no = cserialno and del_flag = 0  order by add_date desc;
                
                    if (icount > 1) then
                       select  id into iremoveid  from
                         (
                            select *  from dmpdb2.r_fixtrue where serial_no = cserialno and del_flag = 0  order by add_date desc
                        ) 
                       where rownum <= 1;
                   
                       UPDATE dmpdb2.r_fixtrue SET edit_date = sysdate, del_flag = 1 WHERE serial_no = cserialno and id = iremoveid;
                       
                       cmsg := '00:REMOVE_OK';
                       
                    elsif (icount = 1) then
                    
                       UPDATE dmpdb2.r_fixtrue SET edit_date = sysdate, del_flag = 1 WHERE serial_no = cserialno;
                       
                       cmsg := '00:REMOVE_OK';
                    else
                    
                       cmsg := '00:REMOVE_OK';
                       
                    end if;
                       
                EXCEPTION
                    WHEN OTHERS THEN
                     BEGIN
                        cmsg := '01:REMOVE_ERROR';
                      END;
                 END; 
                 
         ELSE
         
               cmsg := '02:INVALID_OPERATION';  
               
         END IF;
         
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := '03:GIF_REQUEST_EXCEPTION:' || SUBSTR (SQLERRM, 1, 200);
END;

/

