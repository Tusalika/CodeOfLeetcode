create PROCEDURE        SP_FIXTURE_QUERY (
   cserialno            VARCHAR2,
   cmsg           OUT   VARCHAR2
)
AS
  icount  NUMBER; 
  delflag NUMBER;
BEGIN
        icount := 0;

        select count(*) into icount  from dmpdb2.r_fixtrue where serial_no = cserialno  order by add_date desc;
        
        
        if icount > 0 then
            begin
             select  del_flag into delflag  from
                (
                 select * from dmpdb2.r_fixtrue where serial_no = cserialno  order by add_date desc
                ) 
             where rownum <= 1;
          
             if delflag = 0 then
                   cmsg := '00:'||cserialno||':1';  
             else 
                   cmsg :=  '00:'||cserialno||':0';  
             end if;
          
           exception
                when others then
                 begin
                     cmsg := '02:INVALID_OPERATION';  
                 end;
           end;
          
        else
            cmsg :=  '00:'||cserialno||':0';  
        end if;
      
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := '03:GIF_REQUEST_EXCEPTION:' || SUBSTR (SQLERRM, 1, 200);
END;

/

