create PROCEDURE        SP_FIXTURE_QUERY_TIME (
   cserialno            VARCHAR2,
   cmsg           OUT   VARCHAR2
)
AS
  icount  NUMBER; 
  delflag NUMBER;
  addTime DATE;
  cBlack2d  VARCHAR2(255);
BEGIN
        icount := 0;

        select count(*) into icount  from dmpdb2.r_fixtrue where serial_no = cserialno  order by add_date desc;
        
        
        if icount > 0 then
            begin
             select  del_flag,add_date,property_01 into delflag,addTime,cBlack2d  from
                (
                 select * from dmpdb2.r_fixtrue where serial_no = cserialno  order by add_date desc
                ) 
             where rownum <= 1;
          
             if delflag = 0 then
                   cBlack2d := replace(cBlack2d,',','`');
                   cmsg := '00:'||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')||':'||to_char(addTime,'YYYY-MM-DD HH24:MI:SS')||':'||cBlack2d;  
             else 
                   cmsg :=  '01:'|| cserialno ||' not in whitelist';  
             end if;
          
           exception
                when others then
                 begin
                     cmsg := '02:INVALID_OPERATION';  
                 end;
           end;
          
        else
            cmsg := '01:'|| cserialno ||' not in whitelist'; 
        end if;
      
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := '03:GIF_REQUEST_EXCEPTION:' || SUBSTR (SQLERRM, 1, 200);
END;

/

