create PROCEDURE        Sp_Function_Test_Auto(wip_no            IN VARCHAR2,
                                                         sfc_station_code  IN VARCHAR2,
                                                         pdca_station_code IN VARCHAR2,
                                                         test_machine_id   IN VARCHAR2,
                                                         res               OUT VARCHAR2) AS
  --輸入參數
  g_procedure_name CONSTANT varchar2(60) := 'sp_function_test_auto';
  in_user_no           VARCHAR2(25);
  in_wip_no            VARCHAR2(25);
  in_wip_no2           VARCHAR2(25);
  in_sfc_station_code  VARCHAR2(25);
  in_pdca_station_code VARCHAR2(50);
  in_test_machine_id   VARCHAR2(50);
  in_test_item_code    VARCHAR2(25);
  in_symptom_code      VARCHAR2(25);

  g_commodity_id CONSTANT PLS_INTEGER := constant_package.g_commodity_id;
  g_defect_flag         PLS_INTEGER;
  g_shift_id            PLS_INTEGER;
  g_line_id             PLS_INTEGER;
  g_line_name           varchar2(60);
  g_user_id             PLS_INTEGER;
  g_station_location_id PLS_INTEGER;
  g_station_id          PLS_INTEGER;
  g_test_item_id        PLS_INTEGER;
  g_symptom_id          PLS_INTEGER;
  g_fresh               PLS_INTEGER;
  g_currdate            DATE;
  g_report_date         DATE;
  g_ok CONSTANT VARCHAR2(2) := 'OK';
  g_work_time              VARCHAR2(5);
  g_next_station_code      VARCHAR2(25);
  g_station_code           VARCHAR2(25);
  g_time_slot              TIME_SLOT.act_begin_time%TYPE;
  g_wip_id                 NUMBER;
  g_input_time             date;
  g_wo_id                  NUMBER;
  g_wo_no                  varchar2(20);
  g_wo_floor               varchar2(255);
  g_Not_Check_RC           varchar2(255);
  g_is_rework              int;
  g_category_key           varchar2(20);
  g_Repair_time            date;
  g_r_repair_id            NUMBER;
  g_r_wip_log_id           NUMBER;
  g_a_test_result_id       NUMBER;
  g_a_test_result_fresh_id NUMBER;
  g_repair_times           PLS_INTEGER;
  g_Table_WIP_Log          VARCHAR(20);
  g_part_dislink_id        NUMBER;

  g_StationType             varchar(66);
  g_SFCStationType          varchar(66);
  g_PDCA_SymptomCode        varchar(255);
  g_Symptomtype             varchar(255);
  g_station_location_tab_id NUMBER;
  g_station_num             VARCHAR(20);
  g_pdca_line               VARCHAR(20);
  is_route_correct       VARCHAR(60);

  --cRet  VARCHAR2(30);

  iRecordCount INT;

  g_need_redirect       number;
  g_redirect_line_id    number;
  g_redirect_station_id number;

  g_line_floor varchar2(20);
  ----------------------------------------------------
  FUNCTION Get_User_Id RETURN VARCHAR2 IS
  BEGIN
    SELECT ID
      INTO g_user_id
      FROM app_user
     WHERE del_flag = 0
       AND employee_id = in_user_no;

    RETURN g_ok;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur when select user id from table [app_user], employee_id = ' || in_user_no;
  END;

  FUNCTION GetSfcLineInfo RETURN VARCHAR2 IS
    ipos1                     PLS_INTEGER;
    ipos2                     PLS_INTEGER;
    ipos3                     PLS_INTEGER;
    in_pdca_station_code_tmp1 varchar(50);
    in_pdca_station_code_tmp2 varchar(50);
    v_category varchar2(20);
    v_floor varchar2(20);
  BEGIN
    ipos1 := Instr(in_pdca_station_code, '_');
    in_pdca_station_code_tmp1 := Substr(in_pdca_station_code, ipos1 + 1, Length(in_pdca_station_code) - ipos1);
    ipos2:= Instr(in_pdca_station_code_tmp1, '_');
    in_pdca_station_code_tmp2 := Substr(in_pdca_station_code_tmp1, ipos2 + 1, Length(in_pdca_station_code_tmp1) -ipos2);
    ipos3 := Instr(in_pdca_station_code_tmp2, '_');

    g_station_num := Substr(in_pdca_station_code_tmp2, 1, ipos3 - 1);
    g_pdca_line   := Substr(in_pdca_station_code, ipos1 + 1, ipos2 - 1);

   v_category := '';
   v_floor := '';
    BEGIN
        SELECT A.PROPERTY_01, B.PROPERTY_04
          INTO v_category, v_floor
          FROM dmpdb2.R_WIP A, dmpdb2.LINE B
         WHERE A.NO = in_wip_no AND A.DEL_FLAG = 0 AND A.LINE_ID = B.ID;
    EXCEPTION
        WHEN OTHERS THEN
          RETURN 'Error occur when init sfc line info, invalid wip = ' || in_wip_no;    
    END;
     
    SELECT ID
      INTO g_line_id
      FROM LINE
     WHERE del_flag = 0
       AND ALIAS_NAME = g_pdca_line
       AND PROPERTY_02 = v_category
       AND PROPERTY_04 = v_floor
       ;

    RETURN g_ok;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur when init sfc line info, pdca_station_code = ' || in_pdca_station_code;
  END;

  FUNCTION handle_station_location_info RETURN VARCHAR2 IS
    iCount       PLS_INTEGER;
  BEGIN
    iCount := 0;
    SELECT COUNT(a.ID)
      INTO iCount
      FROM station_location a, station b, line c
     WHERE a.del_flag = 0
       AND b.del_flag = 0
       AND b.code = a.station_code
       AND a.mac_address = in_test_machine_id
       AND b.code = in_sfc_station_code
       AND c.id = g_line_id
       AND a.line_id = c.id;

    IF iCount = 0 THEN

      g_station_location_tab_id := Get_next_id('STATION_LOCATION');
      IF g_station_location_tab_id < 0 THEN
        res := 'Error occur when select g_station_location_tab_id from table [s_id_info]';
      END IF;

      INSERT INTO STATION_LOCATION
        (COMMODITY_ID,
         CATEGORY_KEY,
         MAC_ADDRESS,
         STATION_CODE,
         STATION_NO,
         LINE_ID,
         ADD_BY,
         ADD_DATE,
         EDIT_BY,
         EDIT_DATE,
         DEL_FLAG,
         ID,
         IP_ADDRESS,
         IS_DPU,
         PORT_NO)
      VALUES
        (g_commodity_id,
         '',
         in_test_machine_id,
         in_sfc_station_code,
         g_station_num,
         g_line_id,
         '-1',
         g_currdate,
         '-1',
         g_currdate,
         '0',
         g_station_location_tab_id,
         '',
         '0',
         '');

      COMMIT;

    END IF;

    SELECT a.ID,
           a.line_id,
           a.station_code,
           b.ID,
           c.alias_name,
           NVL(b.Property_02, ' '),
           NVL(b.Property_01, 'N/A'),
           NVL(c.Property_04, 'N/A')
      INTO g_station_location_id,
           g_line_id,
           g_station_code,
           g_station_id,
           g_line_name,
           g_Table_WIP_Log,
           g_SFCStationType,
           g_line_floor
      FROM station_location a, station b, line c
     WHERE a.del_flag = 0
       AND b.del_flag = 0
       AND b.code = a.station_code
       AND a.mac_address = in_test_machine_id
       AND b.code = in_sfc_station_code
       AND c.id = g_line_id
       AND a.line_id = c.id;

    RETURN g_ok;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur when select id from [station_location] ,mac_address = ' || in_test_machine_id;
  END;

  FUNCTION get_item_name RETURN VARCHAR2 IS
    v_name VARCHAR2(50);
  BEGIN
    SELECT namee
      INTO v_name
      FROM test_item
     WHERE del_flag = 0
       AND commodity_id = g_commodity_id
       AND code = in_test_item_code;

    RETURN v_name;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  FUNCTION is_test_item(p_category VARCHAR2) RETURN VARCHAR2 IS
    v_name VARCHAR2(50);
  BEGIN
    SELECT DISTINCT a.ID
      INTO g_test_item_id
      FROM test_item a, test_map b
     WHERE a.del_flag = 0
       AND b.del_flag = 0
       AND a.commodity_id = g_commodity_id
       AND b.commodity_id = a.commodity_id
       AND b.category_key = p_category
       AND b.test_item_id = a.ID
       AND b.station_id = g_station_id
       AND a.code = in_test_item_code;

    RETURN g_ok;
  EXCEPTION
    WHEN OTHERS THEN
      v_name := get_item_name;

      IF v_name IS NOT NULL THEN
        RETURN '無此測試項: ' || in_test_item_code || ' < ' || v_name || '> , 機種: <' || p_category || '>, 請掃<UNDO>重新作業';
      ELSE
        RETURN '無效的測試項: <' || in_test_item_code || '>, 請掃<UNDO>重新作業';
      END IF;
  END;

  FUNCTION get_symptom_name RETURN VARCHAR2 IS
    v_name VARCHAR2(50);
  BEGIN
    SELECT namee, namee, property_01
      INTO v_name, g_PDCA_SymptomCode, g_symptomtype
      FROM symptom
     WHERE del_flag = 0
       AND commodity_id = g_commodity_id
       AND code = in_symptom_code;

    RETURN v_name;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  FUNCTION is_symptom(p_category VARCHAR2) RETURN VARCHAR2 IS
    v_name VARCHAR2(50);
  BEGIN
    SELECT a.ID, a.namee, a.property_01
      INTO g_symptom_id, g_PDCA_SymptomCode, g_symptomtype
      FROM symptom a, test_map b
     WHERE a.del_flag = 0
       AND b.del_flag = 0
       AND a.commodity_id = g_commodity_id
       AND b.commodity_id = a.commodity_id
       AND b.category_key = p_category
       AND b.test_item_id = g_test_item_id
       AND b.symptom_id = a.ID
       AND b.station_id = g_station_id
       AND a.code = in_symptom_code;

    RETURN g_ok;
  EXCEPTION
    WHEN OTHERS THEN
      v_name := get_symptom_name;

      IF v_name IS NOT NULL THEN
        RETURN '測試項<' || in_test_item_code || '>無此測試症狀: ' || in_symptom_code || '<' || v_name || '> , 機種: <' || p_category || '>, 請掃<UNDO>重新作業';
      ELSE
        RETURN '無效的測試症狀: <' || in_symptom_code || '>, 請掃<UNDO>重新作業';
      END IF;
  END;

  FUNCTION within_range(p_begin_time VARCHAR2,
                        p_end_time   VARCHAR2,
                        p_cur_time   VARCHAR2) RETURN BOOLEAN IS
    --v_tem_b      BOOLEAN;
    v_date       VARCHAR2(20);
    v_cur_date   DATE;
    v_begin_date DATE;
    v_end_date   DATE;
  BEGIN
    IF p_begin_time > p_end_time THEN
      v_date     := TO_CHAR(g_currdate, 'YYYY-MM-DD');
      v_cur_date := TO_DATE(v_date || ' ' || p_cur_time,
                            'YYYY-MM-DD HH24:MI:SS');

      IF p_cur_time <= p_end_time THEN
        v_cur_date := v_cur_date + 1;
      END IF;

      v_end_date   := TO_DATE(v_date || ' ' || p_end_time,
                              'YYYY-MM-DD HH24:MI:SS');
      v_end_date   := v_end_date + 1;
      v_begin_date := TO_DATE(v_date || ' ' || p_begin_time,
                              'YYYY-MM-DD HH24:MI:SS');
      RETURN(v_cur_date >= v_begin_date) AND(v_cur_date < v_end_date);
    ELSE
      RETURN(p_cur_time >= p_begin_time) AND(p_cur_time < p_end_time);
    END IF;
  END;

  FUNCTION get_time_slot RETURN VARCHAR2 IS
    v_second_day INTEGER;
    v_begin      VARCHAR2(10);
    v_end        VARCHAR2(10);
    v_goon       BOOLEAN;

    CURSOR time_slot_cursor IS
      SELECT second_day, act_begin_time, act_end_time
        FROM TIME_SLOT
       WHERE del_flag = 0
         AND commodity_id = g_commodity_id;
  BEGIN
    OPEN time_slot_cursor;

    LOOP
      FETCH time_slot_cursor
        INTO v_second_day, v_begin, v_end;

      EXIT WHEN time_slot_cursor%NOTFOUND;

      IF within_range(v_begin, v_end, g_work_time) THEN
        v_goon := TRUE;
        EXIT;
      END IF;
    END LOOP;

    CLOSE time_slot_cursor;

    IF v_goon THEN
      g_time_slot := v_begin;

      IF (v_second_day = 0) AND (v_begin > v_end) AND
         (v_begin > g_work_time) THEN
        v_second_day := 1;
      END IF;

      g_report_date := g_currdate - v_second_day;
      RETURN g_ok;
    ELSE
      RETURN 'Error occur when handle time slot ';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur when select time slot from table [time_slot]';
  END;

  FUNCTION getrepairtimes RETURN INTEGER AS
    v_recordcount INTEGER;
  BEGIN
    SELECT COUNT(*)
      INTO v_recordcount
      FROM r_repair
     WHERE wip_id = g_wip_id
       AND del_flag = 0
       AND check_out_time IS NOT NULL;

    RETURN v_recordcount;
  END;

  FUNCTION check_carton_detail(p_wipid VARCHAR2) RETURN VARCHAR2 IS
    v_wipid VARCHAR2(30);
  BEGIN
    SELECT wip_id
      INTO v_wipid
      FROM r_carton_detail
     WHERE wip_id = p_wipid
       AND del_flag = 0;

    RETURN 'wip has Carton, can not scan fail';
  EXCEPTION
    WHEN OTHERS THEN
      RETURN g_ok;
  END;
  ----------------------------------------------------
  FUNCTION checkRDSWVersion(cCategoryKey VARCHAR2,
                            cStationType VARCHAR2,
                            cTestSWVer   VARCHAR2) RETURN VARCHAR2 IS
    cRet      VARCHAR2(255);
   --lTestFlag int;
    iCount    INT;
    iIsEnable number;
  BEGIN
    SELECT COUNT(1)
      INTO iCount
      FROM C_RD_SW_VERSION
     WHERE Category_key = cCategoryKey
       AND STATION_TYPE = cStationType
       AND TEST_SW_VER = cTestSWVer
       AND DEL_FLAG = 0;
    if iCount > 0 then
      SELECT IS_ENABLE
        INTO iIsEnable
        FROM C_RD_SW_VERSION
       WHERE Category_key = cCategoryKey
         AND STATION_TYPE = cStationType
         AND TEST_SW_VER = cTestSWVer
         AND DEL_FLAG = 0;
      if iIsEnable = 1 then
        cRet := g_ok;
      else
        cRet := cStationType || '軟體版本號已經失效;可能原因(沒有使用正確的軟體作業,請聯系TE處理;)';
      end if;
    else
      cRet := cStationType ||
              '軟體版本號不存在;可能原因(1:沒有使用正確的軟體作業;2:軟體版本號沒有維護進系統,請聯系TE維護;)';
    end if;

    RETURN cRet;
  END;

  PROCEDURE disLink_Part(cPartName VARCHAR2) IS
    --cRet         VARCHAR2(255);
    cSerialNo    VARCHAR2(4000);
    --nWipPartsID  NUMBER;
    iRecordCount NUMBER;
  BEGIN
    --SP_GetSfcPropExt('DISLINK PART BY DEFECT', g_station_code, Wip_Info_Package.rec_wip_info.category_key, cPartName, '', '', cRet);
    -- IF cRet = '1' THEN
    SELECT COUNT(1)
      INTO iRecordCount
      FROM r_wip_parts
     WHERE wip_id = g_wip_id
       AND del_flag + 0 = 0
       AND wo_parts_id IN (SELECT ID
                             FROM r_wo_parts
                            WHERE wo_id = g_wo_id
                              AND Part_Name || '' = cPartName
                              AND del_flag = 0);
    IF iRecordCount > 0 THEN
      SELECT Serial_No
        INTO cSerialNo
        FROM r_wip_parts
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (SELECT ID
                               FROM r_wo_parts
                              WHERE wo_id = g_wo_id
                                AND Part_Name || '' = cPartName
                                AND del_flag = 0)
         AND ROWNUM = 1;

      g_part_dislink_id := get_next_id('R_PART_DISLINK');

      INSERT INTO R_PART_DISLINK
        (ID,
         WIP_ID,
         PART_NAME,
         LINE_ID,
         STATION_CODE,
         SERIAL_NO,
         SYMPTOM_ID,
         ADD_BY,
         ADD_DATE,
         EDIT_BY,
         EDIT_DATE,
         DEL_FLAG)
      VALUES
        (g_part_dislink_id,
         g_wip_id,
         cPartName,
         g_line_id,
         g_Station_code,
         cSerialNo,
         g_symptom_id,
         g_user_id,
         SYSDATE,
         g_user_id,
         SYSDATE,
         0);

      INSERT INTO r_wip_parts
        (ID,
         WIP_ID,
         WO_PARTS_ID,
         SERIAL_NO,
         SCAN_TIME,
         ASSEMBLY_BY,
         DEL_TYPE,
         DEL_FLAG,
         PROPERTY_01,
         PROPERTY_02,
         PROPERTY_03,
         PROPERTY_04,
         PROPERTY_05)
        SELECT S_R_WIP_PARTS.NEXTVAL,
               WIP_ID,
               WO_PARTS_ID,
               SERIAL_NO,
               sysdate,
               ASSEMBLY_BY,
               'D',
               1,
               PROPERTY_01,
               PROPERTY_02,
               PROPERTY_03,
               PROPERTY_04,
               PROPERTY_05
          FROM r_wip_parts
         WHERE wip_id = g_wip_id
           AND del_flag + 0 = 0
           AND wo_parts_id IN (SELECT ID
                                 FROM r_wo_parts
                                WHERE wo_id = g_wo_id
                                  AND Part_Name || '' = cPartName
                                  AND del_flag = 0);

      UPDATE r_wip_parts
         SET del_flag = 1, del_Type = '0'
      --, Scan_Time = SysDate
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (SELECT ID
                               FROM r_wo_parts
                              WHERE wo_id = g_wo_id
                                AND Part_Name || '' = cPartName
                                AND del_flag = 0);

    END IF;
    SELECT COUNT(1)
      INTO iRecordCount
      FROM r_wip_parts_1
     WHERE wip_id = g_wip_id
       AND del_flag + 0 = 0
       AND wo_parts_id IN (SELECT ID
                             FROM r_wo_parts
                            WHERE wo_id = g_wo_id
                              AND Part_Name || '' = cPartName
                              AND del_flag = 0);
    IF iRecordCount > 0 THEN
      SELECT Serial_No
        INTO cSerialNo
        FROM r_wip_parts_1
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (SELECT ID
                               FROM r_wo_parts
                              WHERE wo_id = g_wo_id
                                AND Part_Name || '' = cPartName
                                AND del_flag = 0)
         AND ROWNUM = 1;

      g_part_dislink_id := get_next_id('R_PART_DISLINK');

      INSERT INTO R_PART_DISLINK
        (ID,
         WIP_ID,
         PART_NAME,
         LINE_ID,
         STATION_CODE,
         SERIAL_NO,
         SYMPTOM_ID,
         ADD_BY,
         ADD_DATE,
         EDIT_BY,
         EDIT_DATE,
         DEL_FLAG)
      VALUES
        (g_part_dislink_id,
         g_wip_id,
         cPartName,
         g_line_id,
         g_Station_code,
         cSerialNo,
         g_symptom_id,
         g_user_id,
         SYSDATE,
         g_user_id,
         SYSDATE,
         0);

      INSERT INTO r_wip_parts_1
        (ID,
         WIP_ID,
         WO_PARTS_ID,
         SERIAL_NO,
         SCAN_TIME,
         ASSEMBLY_BY,
         DEL_TYPE,
         DEL_FLAG,
         PROPERTY_01,
         PROPERTY_02,
         PROPERTY_03,
         PROPERTY_04,
         PROPERTY_05)
        SELECT S_R_WIP_PARTS.NEXTVAL,
               WIP_ID,
               WO_PARTS_ID,
               SERIAL_NO,
               sysdate,
               ASSEMBLY_BY,
               'D',
               1,
               PROPERTY_01,
               PROPERTY_02,
               PROPERTY_03,
               PROPERTY_04,
               PROPERTY_05
          FROM r_wip_parts_1
         WHERE wip_id = g_wip_id
           AND del_flag + 0 = 0
           AND wo_parts_id IN (SELECT ID
                                 FROM r_wo_parts
                                WHERE wo_id = g_wo_id
                                  AND Part_Name || '' = cPartName
                                  AND del_flag = 0);

      UPDATE r_wip_parts_1
         SET del_flag = 1, del_Type = '0'
      --, Scan_Time = SysDate
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (SELECT ID
                               FROM r_wo_parts
                              WHERE wo_id = g_wo_id
                                AND Part_Name || '' = cPartName
                                AND del_flag = 0);

    END IF; -------------------------

    --  END IF;---------

  END;

  FUNCTION update_test_result RETURN VARCHAR2 AS
    v_flag             PLS_INTEGER;
    v_temp_work_date   DATE;
    v_temp_report_date DATE;
    v_field            VARCHAR2(50);
    v_sql_block        VARCHAR2(1000);
    v_msr_flag         VARCHAR2(50);
    v_res                  VARCHAR2(50);
  BEGIN
    v_temp_work_date   := TRUNC(g_currdate);
    v_temp_report_date := TRUNC(g_report_date);
    v_res := '-1';

    SELECT COUNT(*)
      INTO v_flag
      FROM a_test_result
     WHERE line_id = g_line_id
       AND station_id = g_station_id
       AND TIME_SLOT = g_time_slot
       AND wo_id = g_wo_id
       AND work_date = v_temp_work_date
       AND ROWNUM = 1;

    IF Wip_Info_Package.rec_wip_info.is_msr <> 0 THEN
      IF g_fresh = 1 THEN
        IF g_defect_flag <> 0 THEN
          v_field := 'msr_first_fail_qty';
        ELSE

          v_field := 'msr_first_pass_qty';
        END IF;
      ELSE
        IF g_defect_flag <> 0 THEN
          v_field := 'msr_multi_fail_qty';
        ELSE
          v_field := 'msr_multi_pass_qty';
        END IF;
      END IF;
    ELSE
      IF g_fresh = 1 THEN
        IF g_defect_flag <> 0 THEN
          v_field := 'first_fail_qty';
        ELSE
          v_field := 'first_pass_qty';
        END IF;
      ELSE
        IF g_defect_flag <> 0 THEN
          v_field := 'multi_fail_qty';
        ELSE
          v_field := 'multi_pass_qty';
        END IF;
      END IF;
    END IF;

    IF v_flag > 0 THEN
      v_sql_block := 'BEGIN UPDATE a_test_result set ' || v_field || ' = ' ||
                     v_field || ' + 1 ' || ' WHERE line_id =:1' ||
                     ' AND station_id = :2' || ' AND time_slot = :3' ||
                     ' AND wo_id = :4' || ' AND work_date = :5' || ';END;';

      --DBMS_OUTPUT.put_line (g_sql_block);
      EXECUTE IMMEDIATE v_sql_block
        USING g_line_id, g_station_id, g_time_slot, g_wo_id, v_temp_work_date;
    ELSE
      g_a_test_result_id := get_next_id('A_TEST_RESULT');
      IF g_a_test_result_id < 0 THEN
        v_res := 'Error occur when select a_test_result id from table [s_id_info]';
      ELSE
        v_sql_block := 'BEGIN INSERT INTO a_test_result' ||
                       '(ID, work_date, commodity_id, wo_id,  report_date,line_id,' ||
                       'station_id, ' || 'time_slot, shift_id, category_key,' ||
                       v_field || ')' ||
                       ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11); END;';

        --   DBMS_OUTPUT.put_line (g_sql_block);
        EXECUTE IMMEDIATE v_sql_block
          USING g_a_test_result_id, v_temp_work_date, g_commodity_id, g_wo_id, v_temp_report_date, g_line_id, g_station_id, g_time_slot, g_shift_id, Wip_Info_Package.rec_wip_info.category_key, 1;
      END IF;
    END IF;

    IF g_commodity_id = 33 THEN
      SELECT COUNT(*)
        INTO v_flag
        FROM a_test_result_fresh
       WHERE line_id = g_line_id
         AND station_id = g_station_id
         AND TIME_SLOT = g_time_slot
         AND wo_id = g_wo_id
         AND work_date = v_temp_work_date
         AND ROWNUM = 1;

      v_msr_flag := '';

      IF Wip_Info_Package.rec_wip_info.is_msr = 1 THEN
        v_msr_flag := 'MSR_';
      ELSE
        v_msr_flag := '';
      END IF;

      IF getrepairtimes = 0 THEN
        IF g_defect_flag <> 0 --Fresh Yeild
         THEN
          v_field := v_msr_flag || 'Fresh_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Fresh_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes = 1 THEN
        --First Repair
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'First_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'First_Repair_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes = 2 THEN
        --Second Repair
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'Second_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Second_Repair_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes = 3 THEN
        --Third Repair
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'Third_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Third_Repair_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes > 3 THEN
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'Ott_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Ott_Repair_Pass_Qty';
        END IF;
      END IF;

      IF v_flag > 0 THEN
        v_sql_block := 'BEGIN UPDATE a_test_result_fresh set ' || v_field ||
                       ' = ' || v_field || ' + 1 ' || ' WHERE line_id =:1' ||
                       ' AND station_id = :2' || ' AND time_slot = :3' ||
                       ' AND wo_id = :4' || ' AND work_date = :5' ||
                       ';END;';

        --DBMS_OUTPUT.put_line (g_sql_block);
        EXECUTE IMMEDIATE v_sql_block
          USING g_line_id, g_station_id, g_time_slot, g_wo_id, v_temp_work_date;
      END IF;

      IF v_flag = 0 THEN
        g_a_test_result_fresh_id := get_next_id('A_TEST_RESULT_FRESH');
        IF g_a_test_result_fresh_id < 0 THEN
           v_res := 'Error occur when select a_test_result_fresh id from table [s_id_info]';
        ELSE
          v_sql_block := 'BEGIN INSERT INTO a_test_result_fresh' ||
                         '(ID, work_date, commodity_id, wo_id,  report_date,line_id,' ||
                         'station_id, ' ||
                         'time_slot, shift_id, category_key,' || v_field || ')' ||
                         ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11); END;';

        --   DBMS_OUTPUT.put_line (g_sql_block);
          EXECUTE IMMEDIATE v_sql_block
            USING g_a_test_result_fresh_id, v_temp_work_date, g_commodity_id, g_wo_id, v_temp_report_date, g_line_id, g_station_id, g_time_slot, g_shift_id, Wip_Info_Package.rec_wip_info.category_key, 1;
        END IF;
      END IF;
    END IF;

    if v_res = '-1' then
      RETURN g_ok;
    else
      RETURN v_res;
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur whern update table [a_test_result]';
  END;

  --add by joshua
  FUNCTION OQC_FINISH RETURN VARCHAR2 IS
    V_TO_STATION_CODE    VARCHAR2(10);
    V_CHECK_STATION      VARCHAR2(10);
    V_CHECK_STATION_LIST VARCHAR2(1024);
  BEGIN
    SELECT TO_STATION_CODE, PROPERTY_01
      INTO V_TO_STATION_CODE, V_CHECK_STATION
      FROM DMPDB2.R_QA_RECORD
     WHERE WIP_ID = g_wip_id
       AND Del_Flag = 0
       AND (QA_Flag IS NULL OR QA_Flag = 0)
       AND TO_STATION_CODE = g_station_code
       AND ROWNUM <= 1;

    IF V_CHECK_STATION = g_station_code THEN
      --CHECK PROTECT STATION
      IF V_TO_STATION_CODE IS NOT NULL THEN
        RETURN V_TO_STATION_CODE;
      ELSE
        RETURN g_ok;
      END IF;
    ELSE
      -- CHECK OQC PATH
      SP_GetSfcPropExt('OQC CHECK PATH',
                       '',
                       Wip_Info_Package.rec_wip_info.category_key,
                       '',
                       '',
                       '',
                       V_CHECK_STATION_LIST);
      IF V_CHECK_STATION_LIST is null THEN
        RETURN g_ok; --NEED NOT CHECK
      ELSE
        IF (V_TO_STATION_CODE <> g_station_code) AND
           (INSTR(V_CHECK_STATION_LIST, g_station_code) > 0) THEN
          RETURN V_TO_STATION_CODE;
        ELSE
          RETURN g_ok;
        END IF;
      END IF;
    END IF;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN g_ok;
  END;

  --add by joshua
  FUNCTION NEED_REDIRECT RETURN NUMBER IS
    v_redirect_station_code varchar2(10);
  BEGIN
    SP_GetSfcPropExt('NEED REDIRECT',
                     g_station_code,
                     Wip_Info_Package.rec_wip_info.category_key,
                     '',
                     '',
                     '',
                     v_redirect_station_code);
    IF v_redirect_station_code is null THEN
      RETURN 0; --NEED NOT REDIRECT
    ELSE
      SELECT Line_ID, Station_ID
        INTO g_redirect_line_ID, g_redirect_station_id
        FROM (SELECT *
                FROM DMPDB2.R_Wip_Log a, DMPDB2.STATION b
               WHERE A.Wip_ID = g_wip_id
                 AND B.Code = v_redirect_station_code
                 AND a.STATION_ID = b.ID
                 AND a.Del_Flag = 0
              UNION ALL
              SELECT *
                FROM DMPDB2.R_Wip_Log_1 a, DMPDB2.STATION b
               WHERE A.Wip_ID = g_wip_id
                 AND B.Code = v_redirect_station_code
                 AND a.STATION_ID = b.ID
                 AND a.Del_Flag = 0)
       WHERE Rownum = 1;
      RETURN 1;
    END IF;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 0;
  END;

  FUNCTION redirect_test_result RETURN VARCHAR2 AS
    v_flag             PLS_INTEGER;
    v_temp_work_date   DATE;
    v_temp_report_date DATE;
    v_field            VARCHAR2(50);
    v_sql_block        VARCHAR2(1000);
    v_msr_flag         VARCHAR2(50);
    v_res                  VARCHAR2(50);
  BEGIN
    v_temp_work_date   := TRUNC(g_currdate);
    v_temp_report_date := TRUNC(g_report_date);
    v_res := '-1';

    SELECT COUNT(*)
      INTO v_flag
      FROM a_test_result
     WHERE line_id = g_redirect_line_id
       AND station_id = g_station_id
       AND TIME_SLOT = g_time_slot
       AND wo_id = g_wo_id
       AND work_date = v_temp_work_date
       AND ROWNUM = 1;

    IF Wip_Info_Package.rec_wip_info.is_msr <> 0 THEN
      IF g_fresh = 1 THEN
        IF g_defect_flag <> 0 THEN
          v_field := 'msr_first_fail_qty';
        ELSE
          v_field := 'msr_first_pass_qty';
        END IF;
      ELSE
        IF g_defect_flag <> 0 THEN
          v_field := 'msr_multi_fail_qty';
        ELSE
          v_field := 'msr_multi_pass_qty';
        END IF;
      END IF;
    ELSE
      IF g_fresh = 1 THEN
        IF g_defect_flag <> 0 THEN
          v_field := 'first_fail_qty';
        ELSE
          v_field := 'first_pass_qty';
        END IF;
      ELSE
        IF g_defect_flag <> 0 THEN
          v_field := 'multi_fail_qty';
        ELSE
          v_field := 'multi_pass_qty';
        END IF;
      END IF;
    END IF;

    IF v_flag > 0 THEN
      v_sql_block := 'BEGIN UPDATE a_test_result set ' || v_field || ' = ' ||
                     v_field || ' + 1 ' || ' WHERE line_id =:1' ||
                     ' AND station_id = :2' || ' AND time_slot = :3' ||
                     ' AND wo_id = :4' || ' AND work_date = :5' || ';END;';

      --DBMS_OUTPUT.put_line (g_sql_block);
      EXECUTE IMMEDIATE v_sql_block
        USING g_redirect_line_id, g_station_id, g_time_slot, g_wo_id, v_temp_work_date;
    ELSE
      g_a_test_result_id := get_next_id('A_TEST_RESULT');
      IF g_a_test_result_id < 0 THEN
        v_res := 'Error occur when select a_test_result id from table [s_id_info]';
      ELSE
        v_sql_block := 'BEGIN INSERT INTO a_test_result' ||
                       '(ID, work_date, commodity_id, wo_id,  report_date,line_id,' ||
                       'station_id, ' || 'time_slot, shift_id, category_key,' ||
                       v_field || ')' ||
                       ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11); END;';

        EXECUTE IMMEDIATE v_sql_block
          USING g_a_test_result_id, v_temp_work_date, g_commodity_id, g_wo_id, v_temp_report_date, g_redirect_line_id, g_station_id, g_time_slot, g_shift_id, Wip_Info_Package.rec_wip_info.category_key, 1;
      END IF;
    END IF;

    IF g_commodity_id = 33 THEN
      SELECT COUNT(*)
        INTO v_flag
        FROM a_test_result_fresh
       WHERE line_id = g_redirect_line_id
         AND station_id = g_station_id
         AND TIME_SLOT = g_time_slot
         AND wo_id = g_wo_id
         AND work_date = v_temp_work_date
         AND ROWNUM = 1;

      v_msr_flag := '';

      IF Wip_Info_Package.rec_wip_info.is_msr = 1 THEN
        v_msr_flag := 'MSR_';
      ELSE
        v_msr_flag := '';
      END IF;

      IF getrepairtimes = 0 THEN
        IF g_defect_flag <> 0 --Fresh Yeild
         THEN
          v_field := v_msr_flag || 'Fresh_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Fresh_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes = 1 THEN
        --First Repair
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'First_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'First_Repair_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes = 2 THEN
        --Second Repair
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'Second_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Second_Repair_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes = 3 THEN
        --Third Repair
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'Third_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Third_Repair_Pass_Qty';
        END IF;
      END IF;

      IF getrepairtimes > 3 THEN
        IF g_defect_flag <> 0 THEN
          v_field := v_msr_flag || 'Ott_Repair_Fail_Qty';
        ELSE
          v_field := v_msr_flag || 'Ott_Repair_Pass_Qty';
        END IF;
      END IF;

      IF v_flag > 0 THEN
        v_sql_block := 'BEGIN UPDATE a_test_result_fresh set ' || v_field ||
                       ' = ' || v_field || ' + 1 ' || ' WHERE line_id =:1' ||
                       ' AND station_id = :2' || ' AND time_slot = :3' ||
                       ' AND wo_id = :4' || ' AND work_date = :5' ||
                       ';END;';

        --DBMS_OUTPUT.put_line (g_sql_block);
        EXECUTE IMMEDIATE v_sql_block
          USING g_redirect_line_id, g_station_id, g_time_slot, g_wo_id, v_temp_work_date;
      END IF;

      IF v_flag = 0 THEN
        g_a_test_result_fresh_id := get_next_id('A_TEST_RESULT_FRESH');
        IF g_a_test_result_fresh_id < 0 THEN
          v_res := 'Error occur when select a_test_result_fresh id from table [s_id_info]';
        ELSE
          v_sql_block := 'BEGIN INSERT INTO a_test_result_fresh' ||
                         '(ID, work_date, commodity_id, wo_id,  report_date,line_id,' ||
                         'station_id, ' ||
                         'time_slot, shift_id, category_key,' || v_field || ')' ||
                         ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11); END;';
          EXECUTE IMMEDIATE v_sql_block
          USING g_a_test_result_fresh_id, v_temp_work_date, g_commodity_id, g_wo_id, v_temp_report_date, g_redirect_line_id, g_station_id, g_time_slot, g_shift_id, Wip_Info_Package.rec_wip_info.category_key, 1;
        END IF;
      END IF;
    END IF;

    if v_res = '-1' then
      RETURN g_ok;
    else
      RETURN v_res;
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur whern update table [a_test_result]';
  END;

  FUNCTION redirect_wip_log RETURN VARCHAR2 IS
  BEGIN
    IF INSTR(Wip_Info_Package.rec_wip_info.route_history, g_station_code) > 0 THEN
      g_fresh := 0;
    ELSE
      g_fresh := 1;
    END IF;

    IF UPPER(g_Table_WIP_Log) = 'R_WIP_LOG' THEN
      INSERT INTO r_wip_log
        (ID,
         wip_id,
         line_id,
         station_id,
         station_time,
         defect_flag,
         fresh_flag,
         del_flag,
         location_id,
         user_id)
      VALUES
        (g_r_wip_log_id,
         g_wip_id,
         g_redirect_line_id,
         g_station_id,
         g_currdate,
         g_defect_flag,
         g_fresh,
         '0',
         g_station_location_id,
         g_user_id);
    ELSIF UPPER(g_Table_WIP_Log) = 'R_WIP_LOG_1' THEN
      INSERT INTO r_wip_log_1
        (ID,
         wip_id,
         line_id,
         station_id,
         station_time,
         defect_flag,
         fresh_flag,
         del_flag,
         location_id,
         user_id)
      VALUES
        (g_r_wip_log_id,
         g_wip_id,
         g_redirect_line_id,
         g_station_id,
         g_currdate,
         g_defect_flag,
         g_fresh,
         '0',
         g_station_location_id,
         g_user_id);
    ELSE
      INSERT INTO r_wip_log
        (ID,
         wip_id,
         line_id,
         station_id,
         station_time,
         defect_flag,
         fresh_flag,
         del_flag,
         location_id,
         user_id)
      VALUES
        (g_r_wip_log_id,
         g_wip_id,
         g_redirect_line_id,
         g_station_id,
         g_currdate,
         g_defect_flag,
         g_fresh,
         '0',
         g_station_location_id,
         g_user_id);
    END IF;

    RETURN g_ok;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Error occur when inser into table [r_wip_log]';
  END;

  function checkSWR return int is
    iRet   int;
    iCount int;
  begin
    iRet := 0;
    select /*+rule*/
     count(1)
      into iCount
      from swr b, swr_keep_parts c
     where b.id = c.swr_id
       AND b.wo_no = g_wo_no
       AND c.part_name = 'CGS'
       AND b.del_flag = 0;
    if iCount = 0 then
      iRet := 1;
    end if;
    return iRet;
  end;

  function getRepairTime return date is
    dTime  date;
    iCheck int;
    iCount int;
  begin
    dTime  := to_date('2000-01-01', 'YYYY-MM-DD');
    iCheck := checkSWR;
    if g_is_rework = 1 and iCheck = 1 then
      dTime := g_input_time;
    end if;
    select count(1)
      into iCount
      from R_Repair
     where wip_id = g_wip_id
       and del_flag = 0;
    if iCount > 0 then
      select nvl(Check_out_time, test_time)
        into dTime
        from (select id, test_time, Check_out_time
                from R_Repair
               where wip_id = g_wip_id
                 and del_flag = 0
               order by test_time desc)
       where rownum <= 1;
    end if;
    return dTime;
  end;

  FUNCTION change2D21D RETURN VARCHAR2 IS
    cRet         varchar2(255);
    cStationList varchar(255);
    iPos         number;
  BEGIN
    cRet := g_ok;

    SP_GetSfcPropExt('CHANGE_2D_WIP',
                     '',
                     Wip_Info_Package.rec_wip_info.category_key,
                     '',
                     '',
                     '',
                     cStationList);
    if instr(cStationList, g_station_code) > 0 then
      if instr(in_wip_no, ':') > 0 then
        select instr(in_wip_no, ':') into ipos from dual;
        in_wip_no := substr(in_wip_no, iPos + 1, 12);
      else
        cRet := '請掃描2D條碼.';
      end if;
    end if;
    return cRet;
  EXCEPTION
    WHEN others THEN
      cRet := 'ERROR(' || g_procedure_name || '):' ||
              SUBSTR(SQLERRM, 1, 200) || '<' || in_wip_no || '><' ||
              in_test_machine_id || '>';
      RETURN cRet;
  END;

BEGIN
  in_wip_no := TRIM(wip_no);
  in_sfc_station_code  := TRIM(sfc_station_code);
  in_pdca_station_code := TRIM(pdca_station_code);
  in_test_machine_id   := Upper(TRIM(test_machine_id));

  g_user_id := -2;
  SELECT SYSDATE INTO g_currdate FROM DUAL;
  g_work_time := TO_CHAR(g_currdate, 'HH24:MI');

  res := GetSfcLineInfo;
  IF res <> g_ok THEN
    GOTO end_of_function;
  END IF;

  res := handle_station_location_info;
  IF res <> g_ok THEN
    GOTO end_of_function;
  END IF;

  res := Wip_Info_Package.is_active_wip(g_station_code,
                                        in_wip_no,
                                        g_commodity_id);
  IF res <> g_ok THEN
    GOTO end_of_function;
  END IF;

  g_wip_id       := Wip_Info_Package.rec_wip_info.wip_id;
  g_wo_id        := Wip_Info_Package.rec_wip_info.wo_id;
  g_category_key := Wip_Info_Package.rec_wip_info.category_key;

  IF res = g_ok THEN
    res := 'SFC OK';
    RETURN;
  END IF;

  <<end_of_function>>
  ROLLBACK;

  RETURN;

exception
  WHEN OTHERS THEN
    begin
      res := SUBSTR(SQLERRM, 1, 200);
    end;
END;
/

