create PROCEDURE        sp_function_test_fg (
   --user name
   emp           IN       VARCHAR2,
   --wip_no
   DATA          IN       VARCHAR2,
   --測試項目 test_item
   ite           IN       VARCHAR2,
   --測試症狀
   ec            IN       VARCHAR2,
   --工站唯一號碼
   station_num   IN       VARCHAR2,
   --返回信息
   res           OUT      VARCHAR2
)
AS
   --輸入參數
   in_wip_no   VARCHAR2 (25);
BEGIN
   --掃FG或序號都可以通過
   IF SUBSTR (DATA, 1, 1) = 'S'
   THEN
      in_wip_no := SUBSTR (DATA, 2, LENGTH (DATA) - 1);
   ELSE
      in_wip_no := DATA;
   END IF;

   sp_function_test (emp, in_wip_no, ite, ec, station_num, res);
   COMMIT;
END;


/

