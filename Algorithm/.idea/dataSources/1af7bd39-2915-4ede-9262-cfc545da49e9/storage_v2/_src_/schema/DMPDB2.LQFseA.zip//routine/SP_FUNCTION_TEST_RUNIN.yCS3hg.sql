create PROCEDURE        Sp_Function_Test_RUNIN (
   --user name
   emp           IN       VARCHAR2,
   --wip_no
   DATA          IN       VARCHAR2,
   --測試項目 test_item
   ite           IN       VARCHAR2,
   --測試症狀
   ec            IN       VARCHAR2,
   --工站唯一號碼
   station_num   IN       VARCHAR2,
   --返回信息
   res           OUT      VARCHAR2
)
AS
   --輸入參數
   in_user_no                 VARCHAR2 (25);
   in_wip_no                  VARCHAR2 (25);
   in_test_item_code          VARCHAR2 (25);
   in_symptom_code            VARCHAR2 (25);
   in_station_num             VARCHAR2 (25);
   --全局變量
   g_commodity_id    CONSTANT PLS_INTEGER  := constant_package.g_commodity_id;
   g_defect_flag              PLS_INTEGER;
   g_shift_id                 PLS_INTEGER;
   g_line_id                  PLS_INTEGER;
   g_user_id                  PLS_INTEGER;
   g_station_location_id      PLS_INTEGER;
   g_station_id               PLS_INTEGER;
   g_test_item_id             PLS_INTEGER;
   g_symptom_id               PLS_INTEGER;
   g_fresh                    PLS_INTEGER;
   g_currdate                 DATE;
   g_report_date              DATE;
   g_ok              CONSTANT VARCHAR2 (2)                    := 'OK';
   g_work_time                VARCHAR2 (5);
   g_next_station_code        VARCHAR2 (25);
   g_station_code             VARCHAR2 (25);
   g_time_slot                TIME_SLOT.act_begin_time%TYPE;
   g_wip_id                   NUMBER;
   g_wo_id                    NUMBER;
   g_r_repair_id              NUMBER;
   g_r_wip_log_id             NUMBER;
   g_a_test_result_id         NUMBER;
   g_a_test_result_fresh_id   NUMBER;
   g_repair_times             PLS_INTEGER;
   g_Table_WIP_Log    VARCHAR(20);
   g_part_dislink_id    NUMBER;

   cRet  VARCHAR2(30);
   iCount INT;
   iRecordCount  INT;

   FUNCTION Get_User_Id
      RETURN VARCHAR2
   IS
   BEGIN
      SELECT ID
        INTO g_user_id
        FROM app_user
       WHERE del_flag = 0 AND employee_id = in_user_no;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN    'Error occur when select user id from table [app_user], employee_id = '
                || in_user_no;
   END;

   FUNCTION handle_station_location_info
      RETURN VARCHAR2
   IS
      v_flag         PLS_INTEGER;
      v_station_no   PLS_INTEGER;
   BEGIN
      SELECT a.ID, a.line_id, a.station_code, b.ID
        INTO g_station_location_id, g_line_id, g_station_code, g_station_id
        FROM station_location a, station b
       WHERE a.del_flag = 0
         AND b.del_flag = 0
         AND b.code = a.station_code
         AND a.mac_address = in_station_num;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN    'Error occur when select id from [station_location] ,mac_address = '
                || in_station_num
                || ' 請掃<UNDO>重新作業';
   END;

   FUNCTION get_item_name
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT namee
        INTO v_name
        FROM test_item
       WHERE del_flag = 0
         AND commodity_id = g_commodity_id
         AND code = in_test_item_code;

      RETURN v_name;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION is_test_item (p_category VARCHAR2)
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT DISTINCT a.ID
                 INTO g_test_item_id
                 FROM test_item a, test_map b
                WHERE a.del_flag = 0
                  AND b.del_flag = 0
                  AND a.commodity_id = g_commodity_id
                  AND b.commodity_id = a.commodity_id
                  AND b.category_key = p_category
                  AND b.test_item_id = a.ID
                  AND b.station_id = g_station_id
                  AND a.code = in_test_item_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_name := get_item_name;

         IF v_name IS NOT NULL
         THEN
            RETURN    '無此測試項: '
                   || in_test_item_code
                   || ' < '
                   || v_name
                   || '> , 機種: <'
                   || p_category
                   || '>, 請掃<UNDO>重新作業';
         ELSE
            RETURN    '無效的測試項: <'
                   || in_test_item_code
                   || '>, 請掃<UNDO>重新作業';
         END IF;
   END;

   FUNCTION get_symptom_name
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT namee
        INTO v_name
        FROM symptom
       WHERE del_flag = 0
         AND commodity_id = g_commodity_id
         AND code = in_symptom_code;

      RETURN v_name;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION is_symptom (p_category VARCHAR2)
      RETURN VARCHAR2
   IS
      v_name   VARCHAR2 (50);
   BEGIN
      SELECT a.ID
        INTO g_symptom_id
        FROM symptom a, test_map b
       WHERE a.del_flag = 0
         AND b.del_flag = 0
         AND a.commodity_id = g_commodity_id
         AND b.commodity_id = a.commodity_id
         AND b.category_key = p_category
         AND b.test_item_id = g_test_item_id
         AND b.symptom_id = a.ID
         AND b.station_id = g_station_id
         AND a.code = in_symptom_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_name := get_symptom_name;

         IF v_name IS NOT NULL
         THEN
            RETURN    '測試項<'
                   || in_test_item_code
                   || '>無此測試症狀: '
                   || in_symptom_code
                   || '<'
                   || v_name
                   || '> , 機種: <'
                   || p_category
                   || '>, 請掃<UNDO>重新作業';
         ELSE
            RETURN    '無效的測試症狀: <'
                   || in_symptom_code
                   || '>, 請掃<UNDO>重新作業';
         END IF;
   END;

   FUNCTION within_range (
      p_begin_time   VARCHAR2,
      p_end_time     VARCHAR2,
      p_cur_time     VARCHAR2
   )
      RETURN BOOLEAN
   IS
      v_tem_b        BOOLEAN;
      v_date         VARCHAR2 (20);
      v_cur_date     DATE;
      v_begin_date   DATE;
      v_end_date     DATE;
   BEGIN
      IF p_begin_time > p_end_time
      THEN
         v_date := TO_CHAR (g_currdate, 'YYYY-MM-DD');
         v_cur_date :=
               TO_DATE (v_date || ' ' || p_cur_time, 'YYYY-MM-DD HH24:MI:SS');

         IF p_cur_time <= p_end_time
         THEN
            v_cur_date := v_cur_date + 1;
         END IF;

         v_end_date :=
                TO_DATE (v_date || ' ' || p_end_time, 'YYYY-MM-DD HH24:MI:SS');
         v_end_date := v_end_date + 1;
         v_begin_date :=
              TO_DATE (v_date || ' ' || p_begin_time, 'YYYY-MM-DD HH24:MI:SS');
         RETURN (v_cur_date >= v_begin_date) AND (v_cur_date < v_end_date);
      ELSE
         RETURN (p_cur_time >= p_begin_time) AND (p_cur_time < p_end_time);
      END IF;
   END;

   FUNCTION get_time_slot
      RETURN VARCHAR2
   IS
      v_second_day   INTEGER;
      v_begin        VARCHAR2 (10);
      v_end          VARCHAR2 (10);
      v_goon         BOOLEAN;

      CURSOR time_slot_cursor
      IS
         SELECT second_day, act_begin_time, act_end_time
           FROM TIME_SLOT
          WHERE del_flag = 0 AND commodity_id = g_commodity_id;
   BEGIN
      OPEN time_slot_cursor;

      LOOP
         FETCH time_slot_cursor
          INTO v_second_day, v_begin, v_end;

         EXIT WHEN time_slot_cursor%NOTFOUND;

         IF within_range (v_begin, v_end, g_work_time)
         THEN
            v_goon := TRUE;
            EXIT;
         END IF;
      END LOOP;

      CLOSE time_slot_cursor;

      IF v_goon
      THEN
         g_time_slot := v_begin;

         --跨天的需減1
         IF     (v_second_day = 0)
            AND (v_begin > v_end)
            AND (v_begin > g_work_time)
         THEN
            v_second_day := 1;
         END IF;

         g_report_date := g_currdate - v_second_day;
         RETURN g_ok;
      ELSE
         RETURN 'Error occur when handle time slot ';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when select time slot from table [time_slot]';
   END;

   FUNCTION get_shift_id
      RETURN VARCHAR2
   IS
      v_begin   VARCHAR2 (10);
      v_end     VARCHAR2 (10);
      v_goon    BOOLEAN;

      CURSOR shift_cursor
      IS
         SELECT ID, begin_time, end_time
           FROM shift
          WHERE del_flag = 0 AND commodity_id = g_commodity_id;
   BEGIN
      OPEN shift_cursor;

      LOOP
         FETCH shift_cursor
          INTO g_shift_id, v_begin, v_end;

         EXIT WHEN shift_cursor%NOTFOUND;

         IF within_range (v_begin, v_end, g_work_time)
         THEN
            v_goon := TRUE;
            EXIT;
         END IF;
      END LOOP;

      CLOSE shift_cursor;

      IF v_goon
      THEN
         RETURN g_ok;
      ELSE
         RETURN 'Error occur when handle shift id';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when select shift id from table [shift]';
   END;

   FUNCTION insert_repair
      RETURN VARCHAR2
   IS
   BEGIN
      INSERT INTO r_repair
                  (ID, wip_id, test_line_id, test_station_id,
                   test_item_id, symptom_id1, test_time, test_by,
                   add_by, edit_by, repair_times
                  )
           VALUES (g_r_repair_id, g_wip_id, g_line_id, g_station_id,
                   g_test_item_id, g_symptom_id, g_currdate, g_user_id,
                   g_user_id, g_user_id, g_repair_times + 1
                  );

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when insert into table [r_repair]';
   END;

   FUNCTION write_wip_log
      RETURN VARCHAR2
   IS
   BEGIN
      IF INSTR (Wip_Info_Package.rec_wip_info.route_history, g_station_code) >
                                                                            0
      THEN
         --重復經過此工站
         g_fresh := 0;
      ELSE
         --第一次通過此工站
         g_fresh := 1;
      END IF;

      IF UPPER(g_Table_WIP_Log) = 'R_WIP_LOG' THEN
          INSERT INTO r_wip_log
                  (ID, wip_id, line_id, station_id,
                   station_time, defect_flag, fresh_flag, del_flag,
                   location_id, user_id
                  )
               VALUES (g_r_wip_log_id, g_wip_id, g_line_id, g_station_id,
                   g_currdate, g_defect_flag, g_fresh, '0',
                   g_station_location_id, g_user_id
                  );
      ELSIF UPPER(g_Table_WIP_Log) = 'R_WIP_LOG_1' THEN
          INSERT INTO r_wip_log_1
                  (ID, wip_id, line_id, station_id,
                   station_time, defect_flag, fresh_flag, del_flag,
                   location_id, user_id
                  )
               VALUES (g_r_wip_log_id, g_wip_id, g_line_id, g_station_id,
                   g_currdate, g_defect_flag, g_fresh, '0',
                   g_station_location_id, g_user_id
                  );
      ELSE
          INSERT INTO r_wip_log
                  (ID, wip_id, line_id, station_id,
                   station_time, defect_flag, fresh_flag, del_flag,
                   location_id, user_id
                  )
               VALUES (g_r_wip_log_id, g_wip_id, g_line_id, g_station_id,
                   g_currdate, g_defect_flag, g_fresh, '0',
                   g_station_location_id, g_user_id
                  );
      END IF;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when inser into table [r_wip_log]';
   END;

   FUNCTION update_wip
      RETURN VARCHAR2
   IS
   BEGIN
      UPDATE r_wip
         SET line_id = g_line_id,
             route_history = route_history || g_station_code || '`',
             test_history =
                 test_history || g_station_code || '|' || g_defect_flag || '`',
             pre_station_code = g_station_code,
             cur_station_code = g_station_code,
             scan_time = g_currdate,
             defect_flag = g_defect_flag,
             edit_by = g_user_id,
             edit_date = g_currdate,
             property_07 = g_next_station_code
       WHERE ID = g_wip_id;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur when update table [r_wip]';
   END;

   --*******For Fresh Yield Add by Bill 080307**********--
   FUNCTION getrepairtimes
      RETURN INTEGER
   AS
      v_recordcount   INTEGER;
   BEGIN
      SELECT COUNT (*)
        INTO v_recordcount
        FROM r_repair
       WHERE wip_id = g_wip_id AND del_flag = 0 AND check_out_time IS NOT NULL
                                                                              --Because Insert Repair Before Update A_Test_Result_Fresh
      ;

      RETURN v_recordcount;
   END;

--******************End***********--
   FUNCTION check_carton_detail (p_wipid VARCHAR2)
      RETURN VARCHAR2
   IS
      v_wipid   VARCHAR2 (30);
   BEGIN
      SELECT wip_id
        INTO v_wipid
        FROM r_carton_detail
       WHERE wip_id = p_wipid AND del_flag = 0;

      RETURN '該機台已裝大箱,不能掃不良';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN g_ok;
   END;

   FUNCTION check_SWDL_log (cWipNo VARCHAR2, cStationCode VARCHAR2, cModel VARCHAR2)
      RETURN VARCHAR2
   IS
       cRet VARCHAR2(255);
   BEGIN
       SP_GetSfcPropExt('CHECK SWDL LOG', cStationCode, cModel, '', '', '', cRet);

       IF cRet = '1'   THEN
            SELECT COUNT(1) INTO iCount FROM CR_SWDL_LOG WHERE wip_no = cWipNo AND del_flag = 0;
           IF iCount = 0    THEN
               cRet := 'No SWDL record[CR_SWDL_LOG]';
           ELSE
               cRet := g_ok;
           END IF;
       ELSE
           cRet := g_ok;
       END IF;

       RETURN cRet;
   END;

   PROCEDURE disLink_Part(cPartName VARCHAR2)
   IS
       cRet VARCHAR2(255);
       cSerialNo VARCHAR2(30);
       nWipPartsID NUMBER;
       iRecordCount NUMBER;
   BEGIN
       SP_GetSfcPropExt('DISLINK PART BY DEFECT', g_station_code, Wip_Info_Package.rec_wip_info.category_key, cPartName, '', '', cRet);

       IF cRet = '1' THEN
          ----------------------------------R_WIP_PARTS---------------
          SELECT COUNT(1) INTO iRecordCount FROM r_wip_parts
              WHERE wip_id = g_wip_id
                    AND  del_flag + 0 = 0
                    AND wo_parts_id IN (
                        SELECT ID
                            FROM r_wo_parts
                           WHERE wo_id = g_wo_id
                               AND Part_Name || '' = cPartName
                               AND del_flag = 0);
          IF iRecordCount > 0 THEN
                SELECT Serial_No INTO cSerialNo FROM r_wip_parts
                  WHERE wip_id = g_wip_id
                        AND  del_flag + 0 = 0
                        AND wo_parts_id IN (
                            SELECT ID
                                FROM r_wo_parts
                               WHERE wo_id = g_wo_id
                                   AND Part_Name || '' = cPartName
                                   AND del_flag = 0)
                        AND ROWNUM = 1;

              g_part_dislink_id := get_next_id('R_PART_DISLINK');

              INSERT INTO R_PART_DISLINK(ID, WIP_ID, PART_NAME, LINE_ID, STATION_CODE, SERIAL_NO, SYMPTOM_ID
                     , ADD_BY, ADD_DATE, EDIT_BY, EDIT_DATE, DEL_FLAG)
              VALUES( g_part_dislink_id, g_wip_id, cPartName, g_line_id, g_Station_code, cSerialNo, g_symptom_id
                     ,  g_user_id, SYSDATE, g_user_id, SYSDATE, 0);
                     
      INSERT INTO r_wip_parts(ID, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, DEL_TYPE, DEL_FLAG
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05)
      SELECT S_R_WIP_PARTS.NEXTVAL, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, '0', 1
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05
          FROM r_wip_parts 
                  WHERE wip_id = g_wip_id
                       AND del_flag + 0 = 0
                       AND wo_parts_id IN (
                            SELECT ID
                                FROM r_wo_parts
                                WHERE wo_id = g_wo_id
                                      AND Part_Name || '' = cPartName
                                     AND del_flag = 0);                      

              UPDATE r_wip_parts
                  SET del_flag = 1,
                      del_Type = 'D',
                      Scan_Time = SysDate
                  WHERE wip_id = g_wip_id
                       AND del_flag + 0 = 0
                       AND wo_parts_id IN (
                            SELECT ID
                                FROM r_wo_parts
                                WHERE wo_id = g_wo_id
                                      AND Part_Name || '' = cPartName
                                     AND del_flag = 0);

          END IF;
         --------------------------R_WIP_Parts_1-------------------------------------
          SELECT COUNT(1) INTO iRecordCount FROM r_wip_parts_1
              WHERE wip_id = g_wip_id
                    AND  del_flag + 0 = 0
                    AND wo_parts_id IN (
                        SELECT ID
                            FROM r_wo_parts
                           WHERE wo_id = g_wo_id
                               AND Part_Name || '' = cPartName
                               AND del_flag = 0);
          IF iRecordCount > 0 THEN
                SELECT Serial_No INTO cSerialNo FROM r_wip_parts_1
                  WHERE wip_id = g_wip_id
                        AND  del_flag + 0 = 0
                        AND wo_parts_id IN (
                            SELECT ID
                                FROM r_wo_parts
                               WHERE wo_id = g_wo_id
                                   AND Part_Name || '' = cPartName
                                   AND del_flag = 0)
                        AND ROWNUM = 1;

              g_part_dislink_id := get_next_id('R_PART_DISLINK');

              INSERT INTO R_PART_DISLINK(ID, WIP_ID, PART_NAME, LINE_ID, STATION_CODE, SERIAL_NO, SYMPTOM_ID
                     , ADD_BY, ADD_DATE, EDIT_BY, EDIT_DATE, DEL_FLAG)
              VALUES( g_part_dislink_id, g_wip_id, cPartName, g_line_id, g_Station_code, cSerialNo, g_symptom_id
                     ,  g_user_id, SYSDATE, g_user_id, SYSDATE, 0);
                     
      INSERT INTO r_wip_parts_1(ID, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, DEL_TYPE, DEL_FLAG
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05)
      SELECT S_R_WIP_PARTS.NEXTVAL, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, '0', 1
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05
          FROM r_wip_parts_1 
                  WHERE wip_id = g_wip_id
                       AND del_flag + 0 = 0
                       AND wo_parts_id IN (
                            SELECT ID
                                FROM r_wo_parts
                                WHERE wo_id = g_wo_id
                                      AND Part_Name || '' = cPartName
                                     AND del_flag = 0);                   

              UPDATE r_wip_parts_1
                  SET del_flag = 1,
                      del_Type = 'D',
                      Scan_Time = SysDate
                  WHERE wip_id = g_wip_id
                       AND del_flag + 0 = 0
                       AND wo_parts_id IN (
                            SELECT ID
                                FROM r_wo_parts
                                WHERE wo_id = g_wo_id
                                      AND Part_Name || '' = cPartName
                                     AND del_flag = 0);

          END IF;-------------------------

       END IF;---------

   END;

   FUNCTION update_test_result
      RETURN VARCHAR2
   AS
      v_flag               PLS_INTEGER;
      v_temp_work_date     DATE;
      v_temp_report_date   DATE;
      v_field              VARCHAR2 (50);
      v_sql_block          VARCHAR2 (1000);
      v_msr_flag           VARCHAR2 (50);
   BEGIN
      v_temp_work_date := TRUNC (g_currdate);
      v_temp_report_date := TRUNC (g_report_date);

      SELECT COUNT (*)
        INTO v_flag
        FROM a_test_result
       WHERE line_id = g_line_id
         AND station_id = g_station_id
         AND TIME_SLOT = g_time_slot
         AND wo_id = g_wo_id
         AND work_date = v_temp_work_date
         AND ROWNUM = 1;

      --msr工單
      IF Wip_Info_Package.rec_wip_info.is_msr <> 0
      THEN
         --第一次測試
         IF g_fresh = 1
         THEN
            --不良
            IF g_defect_flag <> 0
            THEN
               v_field := 'msr_first_fail_qty';
            ELSE
               --良
               v_field := 'msr_first_pass_qty';
            END IF;
         ELSE
            IF g_defect_flag <> 0
            THEN
               v_field := 'msr_multi_fail_qty';
            ELSE
               v_field := 'msr_multi_pass_qty';
            END IF;
         END IF;
      ELSE                                                         --非msr工單
         --第一次測試
         IF g_fresh = 1
         THEN
            --不良
            IF g_defect_flag <> 0
            THEN
               v_field := 'first_fail_qty';
            ELSE
               --良
               v_field := 'first_pass_qty';
            END IF;
         ELSE
            IF g_defect_flag <> 0
            THEN
               v_field := 'multi_fail_qty';
            ELSE
               v_field := 'multi_pass_qty';
            END IF;
         END IF;
      END IF;

      IF v_flag > 0
      THEN
         v_sql_block :=
               'BEGIN UPDATE a_test_result set '
            || v_field
            || ' = '
            || v_field
            || ' + 1 '
            || ' WHERE line_id =:1'
            || ' AND station_id = :2'
            || ' AND time_slot = :3'
            || ' AND wo_id = :4'
            || ' AND work_date = :5'
            || ';END;';

         --DBMS_OUTPUT.put_line (g_sql_block);
         EXECUTE IMMEDIATE v_sql_block
                     USING g_line_id,
                           g_station_id,
                           g_time_slot,
                           g_wo_id,
                           v_temp_work_date;
      ELSE
         v_sql_block :=
               'BEGIN INSERT INTO a_test_result'
            || '(ID, work_date, commodity_id, wo_id,  report_date,line_id,'
            || 'station_id, '
            || 'time_slot, shift_id, category_key,'
            || v_field
            || ')'
            || ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11); END;';

         --   DBMS_OUTPUT.put_line (g_sql_block);
         EXECUTE IMMEDIATE v_sql_block
                     USING g_a_test_result_id,
                           v_temp_work_date,
                           g_commodity_id,
                           g_wo_id,
                           v_temp_report_date,
                           g_line_id,
                           g_station_id,
                           g_time_slot,
                           g_shift_id,
                           Wip_Info_Package.rec_wip_info.category_key,
                           1;
      END IF;

      --****For Fresh Yeild Add by Bill 20080302***********--
      IF g_commodity_id = 33
      THEN
         --Get A_Test_Result_Fresh  Count
         SELECT COUNT (*)
           INTO v_flag
           FROM a_test_result_fresh
          WHERE line_id = g_line_id
            AND station_id = g_station_id
            AND TIME_SLOT = g_time_slot
            AND wo_id = g_wo_id
            AND work_date = v_temp_work_date
            AND ROWNUM = 1;

         v_msr_flag := '';

         IF Wip_Info_Package.rec_wip_info.is_msr = 1
         THEN
            v_msr_flag := 'MSR_';
         ELSE
            v_msr_flag := '';
         END IF;

         IF getrepairtimes = 0
         THEN
            IF g_defect_flag <> 0                               --Fresh Yeild
            THEN
               v_field := v_msr_flag || 'Fresh_Fail_Qty';
            ELSE
               v_field := v_msr_flag || 'Fresh_Pass_Qty';
            END IF;
         END IF;

         IF getrepairtimes = 1
         THEN                                                   --First Repair
            IF g_defect_flag <> 0
            THEN
               v_field := v_msr_flag || 'First_Repair_Fail_Qty';
            ELSE
               v_field := v_msr_flag || 'First_Repair_Pass_Qty';
            END IF;
         END IF;

         IF getrepairtimes = 2
         THEN                                                  --Second Repair
            IF g_defect_flag <> 0
            THEN
               v_field := v_msr_flag || 'Second_Repair_Fail_Qty';
            ELSE
               v_field := v_msr_flag || 'Second_Repair_Pass_Qty';
            END IF;
         END IF;

         IF getrepairtimes = 3
         THEN                                                   --Third Repair
            IF g_defect_flag <> 0
            THEN
               v_field := v_msr_flag || 'Third_Repair_Fail_Qty';
            ELSE
               v_field := v_msr_flag || 'Third_Repair_Pass_Qty';
            END IF;
         END IF;

         IF getrepairtimes > 3
         THEN
            IF g_defect_flag <> 0
            THEN
               v_field := v_msr_flag || 'Ott_Repair_Fail_Qty';
            ELSE
               v_field := v_msr_flag || 'Ott_Repair_Pass_Qty';
            END IF;
         END IF;

         IF v_flag > 0
         THEN
            v_sql_block :=
                  'BEGIN UPDATE a_test_result_fresh set '
               || v_field
               || ' = '
               || v_field
               || ' + 1 '
               || ' WHERE line_id =:1'
               || ' AND station_id = :2'
               || ' AND time_slot = :3'
               || ' AND wo_id = :4'
               || ' AND work_date = :5'
               || ';END;';

            --DBMS_OUTPUT.put_line (g_sql_block);
            EXECUTE IMMEDIATE v_sql_block
                        USING g_line_id,
                              g_station_id,
                              g_time_slot,
                              g_wo_id,
                              v_temp_work_date;
         END IF;

         IF v_flag = 0
         THEN
            v_sql_block :=
                  'BEGIN INSERT INTO a_test_result_fresh'
               || '(ID, work_date, commodity_id, wo_id,  report_date,line_id,'
               || 'station_id, '
               || 'time_slot, shift_id, category_key,'
               || v_field
               || ')'
               || ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11); END;';

            --   DBMS_OUTPUT.put_line (g_sql_block);
            EXECUTE IMMEDIATE v_sql_block
                        USING g_a_test_result_fresh_id,
                              v_temp_work_date,
                              g_commodity_id,
                              g_wo_id,
                              v_temp_report_date,
                              g_line_id,
                              g_station_id,
                              g_time_slot,
                              g_shift_id,
                              Wip_Info_Package.rec_wip_info.category_key,
                              1;
         END IF;
      END IF;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'Error occur whern update table [a_test_result]';
   END;
/******************************************************************************
 1. IsActiveWip: 如果成功返回該wip的信息
 2. CheckRoute
 3 IsCanProcess
 4. when Fail: 判斷  IsTestItem  isSymptom  then insert into R_Repair
 5. update r_wip
 6. insert into r_wip_log
 7. update A_test_result
******************************************************************************/
BEGIN

   g_r_repair_id := get_next_id ('R_REPAIR');

   IF g_r_repair_id < 0
   THEN
      res := 'Error occur when select r_repair id from table [s_id_info]';
      GOTO end_of_function;
   END IF;

   COMMIT;
   g_r_wip_log_id := get_next_id ('R_WIP_LOG');

   IF g_r_wip_log_id < 0
   THEN
      res := 'Error occur when select r_wip_log id from table [s_id_info]';
      GOTO end_of_function;
   END IF;

   COMMIT;
   g_a_test_result_id := get_next_id ('A_TEST_RESULT');

   IF g_a_test_result_id < 0
   THEN
      res :=
            'Error occur when select a_test_result id from table [s_id_info]';
      GOTO end_of_function;
   END IF;

   COMMIT;
   g_a_test_result_fresh_id := get_next_id ('A_TEST_RESULT_FRESH');

   IF g_a_test_result_fresh_id < 0
   THEN
      res :=
         'Error occur when select a_test_result_fresh id from table [s_id_info]';
      GOTO end_of_function;
   END IF;

   COMMIT;

   SELECT SYSDATE
     INTO g_currdate
     FROM DUAL;

   g_work_time := TO_CHAR (g_currdate, 'HH24:MI');
   --用戶
   in_user_no := TRIM (emp);
   in_wip_no := TRIM (DATA);
   in_test_item_code := TRIM (ite);
   in_symptom_code := TRIM (ec);
   --line name 對應表line的字段namee
   in_station_num := TRIM (station_num);
   res := Get_User_Id;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res := handle_station_location_info;

   SELECT  COUNT(*) INTO iRecordCount FROM station WHERE code = g_station_code AND del_flag = 0;
   IF iRecordCount > 0 THEN
         SELECT NVL(Property_07, ' ') INTO g_Table_WIP_Log FROM station WHERE code = g_station_code AND Del_flag = 0;
   ELSE
       --dbms_output.put_line(g_station_code);
        GOTO end_of_function;
   END IF;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res :=
      Wip_Info_Package.is_active_wip (g_station_code,
                                      in_wip_no,
                                      g_commodity_id
                                     );

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   g_wip_id := Wip_Info_Package.rec_wip_info.wip_id;
   g_wo_id := Wip_Info_Package.rec_wip_info.wo_id;

   IF INSTR(Wip_Info_Package.rec_wip_info.category_key, 'N94') >0
   THEN
     res := 'N94 機台不可以在此工站作業。';
     GOTO end_of_function;
   END IF; 
   
   IF (in_test_item_code IS NULL) OR (in_test_item_code = 'N/A')
   THEN
      g_defect_flag := 0;
   ELSE
      --不良
      g_defect_flag := 1;
   END IF;

   IF g_defect_flag = 0 THEN
       res :=check_SWDL_log(Wip_Info_Package.rec_wip_info.wip_No, g_station_code, Wip_Info_Package.rec_wip_info.category_key);
       IF res <> g_ok
       THEN
          GOTO end_of_function;
       END IF;
   END IF;

   --判斷路由﹐分良與不良
   res := Wip_Info_Package.is_route_correct (g_station_code, g_defect_flag);

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   IF g_defect_flag <> 0
   THEN
      res := check_carton_detail (Wip_Info_Package.rec_wip_info.wip_id);

      IF res <> g_ok
      THEN
         GOTO end_of_function;
      END IF;

      --檢查Item是否正確
      res := is_test_item (Wip_Info_Package.rec_wip_info.category_key);

      IF res <> g_ok
      THEN
         GOTO end_of_function;
      END IF;

      --當掃描Fail時﹐檢查掃描的Symptom是否正確
      res := is_symptom (Wip_Info_Package.rec_wip_info.category_key);

      IF res <> g_ok
      THEN
         GOTO end_of_function;
      END IF;

      g_repair_times := getrepairtimes;
      res := insert_repair;

      IF res <> g_ok
      THEN
         GOTO end_of_function;
      END IF;
   END IF;

   --更新R_WIP
   g_next_station_code :=
        Wip_Info_Package.get_should_to_station (g_station_code, g_defect_flag);
   res := update_wip;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   --更新到表R_WIP_LOG
   res := write_wip_log ();

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res := get_shift_id;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res := get_time_slot;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

-- 應丁勝要求刪除RP10相關ICCID信息
   IF     (g_defect_flag <> 0)
      AND (   (Wip_Info_Package.rec_wip_info.category_key = 'M68')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'M68X')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N82')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N82C')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N80')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N88')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N88A')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N88C')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N90')
           OR (Wip_Info_Package.rec_wip_info.category_key = 'N89')
          )
   THEN
      UPDATE cr_provisioning_log
         SET del_flag = 1
       WHERE wip_no = in_wip_no AND del_flag = 0;

      UPDATE cr_ship_set_log
         SET del_flag = 1
       WHERE wip_no = in_wip_no AND del_flag = 0;

      disLink_Part('MIILBL');
      
      INSERT INTO r_wip_parts(ID, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, DEL_TYPE, DEL_FLAG
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05)
      SELECT S_R_WIP_PARTS.NEXTVAL, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, '0', 1
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05
          FROM r_wip_parts 
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (
                SELECT ID
                  FROM r_wo_parts
                 WHERE wo_id = g_wo_id
                   AND (   part_name = 'SIM1'
                        OR part_name = 'SIM2'
                        OR part_name = 'IMEI LBL'
                       )
                   AND del_flag = 0);                         

      UPDATE r_wip_parts
         SET del_flag = 1,
             del_Type = 'D',
             Scan_Time = SysDate 
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (
                SELECT ID
                  FROM r_wo_parts
                 WHERE wo_id = g_wo_id
                   AND (   part_name = 'SIM1'
                        OR part_name = 'SIM2'
                        OR part_name = 'IMEI LBL'
                       )
                   AND del_flag = 0);
                   
      INSERT INTO r_wip_parts_1(ID, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, DEL_TYPE, DEL_FLAG
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05)
      SELECT S_R_WIP_PARTS.NEXTVAL, WIP_ID, WO_PARTS_ID, SERIAL_NO, SCAN_TIME, ASSEMBLY_BY, '0', 1
                   , PROPERTY_01, PROPERTY_02, PROPERTY_03, PROPERTY_04, PROPERTY_05
          FROM r_wip_parts_1 
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (
                SELECT ID
                  FROM r_wo_parts
                 WHERE wo_id = g_wo_id
                   AND (   part_name = 'SIM1'
                        OR part_name = 'SIM2'
                        OR part_name = 'IMEI LBL'
                       )
                   AND del_flag = 0);                   

      UPDATE r_wip_parts_1
         SET del_flag = 1,
             del_Type = 'D',
             Scan_Time = SysDate          
       WHERE wip_id = g_wip_id
         AND del_flag + 0 = 0
         AND wo_parts_id IN (
                SELECT ID
                  FROM r_wo_parts
                 WHERE wo_id = g_wo_id
                   AND (   part_name = 'SIM1'
                        OR part_name = 'SIM2'
                        OR part_name = 'IMEI LBL'
                       )
                   AND del_flag = 0);

   END IF;

   --update table A_Test_Result
   res := update_test_result;

   --when error occur, then transaction roll back
   IF res = g_ok
   THEN
      COMMIT;
      res := 'OK DISPLAY={產品已經通過本站}';
      RETURN;
   END IF;

   <<end_of_function>>
   ROLLBACK;
END;


/

