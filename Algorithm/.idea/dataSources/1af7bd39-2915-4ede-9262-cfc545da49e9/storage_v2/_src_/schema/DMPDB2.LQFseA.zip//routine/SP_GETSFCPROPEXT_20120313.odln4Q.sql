create PROCEDURE        SP_GetSfcPropExt_20120313(cKeyName IN VARCHAR2, cProperty01 IN VARCHAR2, cProperty02 IN VARCHAR2
, cProperty03 IN VARCHAR2, cProperty04 IN VARCHAR2, cProperty05 IN VARCHAR2, cRes OUT VARCHAR2)
AS
   iCount  INT;
   cCommodityID NUMBER;
   nID NUMBER;
   cKeyNameTmp varchar2(200);
BEGIN
   cRes := '';
   cCommodityID := constant_package.g_commodity_id;
   BEGIN
       iCount:=TRUNC(dbms_random.VALUE(-1, -6));
       if iCount=-1 then
       SELECT NVL(MIN(Key_Value), '') , key_name as A1  INTO cRes,  cKeyNameTmp
         FROM Sys_Property WHERE Key_Name = cKeyName
          AND NVL(Property_01, ' ') = (CASE WHEN cProperty01 IS NOT NULL THEN cProperty01 ELSE ' ' END)
          AND NVL(Property_02, ' ') = (CASE WHEN cProperty02 IS NOT NULL THEN cProperty02 ELSE ' ' END)
          AND NVL(Property_03, ' ') = (CASE WHEN cProperty03 IS NOT NULL THEN cProperty03 ELSE ' ' END)
          AND NVL(Property_04, ' ') = (CASE WHEN cProperty04 IS NOT NULL THEN cProperty04 ELSE ' ' END)
          AND NVL(Property_05, ' ') = (CASE WHEN cProperty05 IS NOT NULL THEN cProperty05 ELSE ' ' END)
          AND COMMODITY_ID = cCommodityID
          GROUP BY key_name;
      elsif  iCount=-2 then 
          SELECT NVL(MIN(Key_Value), '') , key_name as A2 INTO cRes,  cKeyNameTmp
         FROM Sys_Property WHERE Key_Name = cKeyName
          AND NVL(Property_01, ' ') = (CASE WHEN cProperty01 IS NOT NULL THEN cProperty01 ELSE ' ' END)
          AND NVL(Property_02, ' ') = (CASE WHEN cProperty02 IS NOT NULL THEN cProperty02 ELSE ' ' END)
          AND NVL(Property_03, ' ') = (CASE WHEN cProperty03 IS NOT NULL THEN cProperty03 ELSE ' ' END)
          AND NVL(Property_04, ' ') = (CASE WHEN cProperty04 IS NOT NULL THEN cProperty04 ELSE ' ' END)
          AND NVL(Property_05, ' ') = (CASE WHEN cProperty05 IS NOT NULL THEN cProperty05 ELSE ' ' END)
          AND COMMODITY_ID = cCommodityID
          GROUP BY key_name;
     elsif  iCount=-3 then      
          SELECT NVL(MIN(Key_Value), '') , key_name as A3 INTO cRes,  cKeyNameTmp
         FROM Sys_Property WHERE Key_Name = cKeyName
          AND NVL(Property_01, ' ') = (CASE WHEN cProperty01 IS NOT NULL THEN cProperty01 ELSE ' ' END)
          AND NVL(Property_02, ' ') = (CASE WHEN cProperty02 IS NOT NULL THEN cProperty02 ELSE ' ' END)
          AND NVL(Property_03, ' ') = (CASE WHEN cProperty03 IS NOT NULL THEN cProperty03 ELSE ' ' END)
          AND NVL(Property_04, ' ') = (CASE WHEN cProperty04 IS NOT NULL THEN cProperty04 ELSE ' ' END)
          AND NVL(Property_05, ' ') = (CASE WHEN cProperty05 IS NOT NULL THEN cProperty05 ELSE ' ' END)
          AND COMMODITY_ID = cCommodityID
          GROUP BY key_name;
     elsif  iCount=-4 then 
          SELECT  NVL(MIN(Key_Value), '') , key_name as A4 INTO cRes,  cKeyNameTmp
         FROM Sys_Property WHERE Key_Name = cKeyName
          AND NVL(Property_01, ' ') = (CASE WHEN cProperty01 IS NOT NULL THEN cProperty01 ELSE ' ' END)
          AND NVL(Property_02, ' ') = (CASE WHEN cProperty02 IS NOT NULL THEN cProperty02 ELSE ' ' END)
          AND NVL(Property_03, ' ') = (CASE WHEN cProperty03 IS NOT NULL THEN cProperty03 ELSE ' ' END)
          AND NVL(Property_04, ' ') = (CASE WHEN cProperty04 IS NOT NULL THEN cProperty04 ELSE ' ' END)
          AND NVL(Property_05, ' ') = (CASE WHEN cProperty05 IS NOT NULL THEN cProperty05 ELSE ' ' END)
          AND COMMODITY_ID = cCommodityID
          GROUP BY key_name;
     elsif  iCount=-5 then 
          SELECT NVL(MIN(Key_Value), '') , key_name as A5 INTO cRes,  cKeyNameTmp
         FROM Sys_Property WHERE Key_Name = cKeyName
          AND NVL(Property_01, ' ') = (CASE WHEN cProperty01 IS NOT NULL THEN cProperty01 ELSE ' ' END)
          AND NVL(Property_02, ' ') = (CASE WHEN cProperty02 IS NOT NULL THEN cProperty02 ELSE ' ' END)
          AND NVL(Property_03, ' ') = (CASE WHEN cProperty03 IS NOT NULL THEN cProperty03 ELSE ' ' END)
          AND NVL(Property_04, ' ') = (CASE WHEN cProperty04 IS NOT NULL THEN cProperty04 ELSE ' ' END)
          AND NVL(Property_05, ' ') = (CASE WHEN cProperty05 IS NOT NULL THEN cProperty05 ELSE ' ' END)
          AND COMMODITY_ID = cCommodityID
          GROUP BY key_name;
    else 
         SELECT NVL(MIN(Key_Value), '') , key_name as A6 INTO cRes,  cKeyNameTmp
         FROM Sys_Property WHERE Key_Name = cKeyName
          AND NVL(Property_01, ' ') = (CASE WHEN cProperty01 IS NOT NULL THEN cProperty01 ELSE ' ' END)
          AND NVL(Property_02, ' ') = (CASE WHEN cProperty02 IS NOT NULL THEN cProperty02 ELSE ' ' END)
          AND NVL(Property_03, ' ') = (CASE WHEN cProperty03 IS NOT NULL THEN cProperty03 ELSE ' ' END)
          AND NVL(Property_04, ' ') = (CASE WHEN cProperty04 IS NOT NULL THEN cProperty04 ELSE ' ' END)
          AND NVL(Property_05, ' ') = (CASE WHEN cProperty05 IS NOT NULL THEN cProperty05 ELSE ' ' END)
          AND COMMODITY_ID = cCommodityID
          GROUP BY key_name;
     end if;
   EXCEPTION
    WHEN no_data_found THEN
      nID := get_next_id('SYS_PROPERTY');
      INSERT INTO Sys_Property(ID, COMMODITY_ID, KEY_NAME, KEY_VALUE, PROPERTY_01, PROPERTY_02
                               , PROPERTY_03, PROPERTY_04, PROPERTY_05
                               , PROPERTY_06, PROPERTY_07, PROPERTY_08, PROPERTY_09
                               , ADD_BY, ADD_DATE, EDIT_BY, EDIT_DATE)
          VALUES(nID, cCommodityID, cKeyName, NULL, cProperty01, cProperty02
                              , cProperty03, cProperty04, cProperty05
                              ,NULL, NULL, NULL, NULL
                              ,-1, SYSDATE, -1, SYSDATE);
        COMMIT;
      cRes := '';
    END ;
EXCEPTION
   WHEN OTHERS THEN   cRes := '';
END;


/

