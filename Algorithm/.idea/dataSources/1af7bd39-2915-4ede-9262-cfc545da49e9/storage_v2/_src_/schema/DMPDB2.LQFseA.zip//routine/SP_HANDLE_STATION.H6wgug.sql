create PROCEDURE        sp_handle_station (
   line          IN       VARCHAR2,
   section       IN       VARCHAR2,
   --station_code
   mygroup       IN       VARCHAR2,
   w_station     IN       VARCHAR2,
   station_num   IN       VARCHAR2,
   --返回信息
   res           OUT      VARCHAR2
)
AS
   --輸入參數
   in_station_num            VARCHAR2 (25);
   in_line_code              VARCHAR2 (25);
   in_station_code           VARCHAR2 (25);
   --全局變量
   g_commodity_id   CONSTANT PLS_INTEGER   := constant_package.g_commodity_id;
   g_line_id                 PLS_INTEGER;
   g_station_id              PLS_INTEGER;
   g_station_no              PLS_INTEGER;
   g_currdate                DATE;
   g_ok             CONSTANT VARCHAR2 (2)  := 'OK';
   g_station_location_id     NUMBER;

   PROCEDURE update_station_location
   AS
   BEGIN
      UPDATE station_location
         SET del_flag = 1
       WHERE mac_address = station_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   FUNCTION get_station_no
      RETURN NUMBER
   AS
      v_station_no   PLS_INTEGER;
   BEGIN
      SELECT MAX (station_no)
        INTO v_station_no
        FROM station_location
       WHERE del_flag = 0
         AND station_code = in_station_code
         AND line_id = g_line_id;

      RETURN NVL (v_station_no, 0) + 1;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 1;
   END;

   FUNCTION get_line_id
      RETURN VARCHAR2
   IS
   BEGIN
      SELECT ID
        INTO g_line_id
        FROM line
       WHERE del_flag = 0 AND code = in_line_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN    'Error occur when select line id from table [line], line code = '
                || in_line_code;
   END;

   FUNCTION get_station_id
      RETURN VARCHAR2
   IS
   BEGIN
      SELECT ID
        INTO g_station_id
        FROM station
       WHERE del_flag = 0 AND code = in_station_code;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN    'Error occur when select station id from table [station], station code = '
                || in_station_code;
   END;

   FUNCTION handle_station_location_info
      RETURN VARCHAR2
   IS
      v_flag         PLS_INTEGER;
      v_station_no   PLS_INTEGER;
   BEGIN
      SELECT COUNT (*)
        INTO v_flag
        FROM station_location
       WHERE del_flag = 0
         AND mac_address = in_station_num
         AND station_code = in_station_code
         AND line_id = g_line_id;

      IF v_flag <> 1
      THEN
         update_station_location;
         v_station_no := get_station_no;
         g_station_location_id := get_next_id ('STATION_LOCATION');

         IF g_station_location_id < 0
         THEN
            RETURN 'Error occur when select station location id from table [s_id_info]';
         END IF;

         INSERT INTO station_location
                     (commodity_id, category_key, mac_address, station_code,
                      station_no, line_id, add_by, add_date, edit_by,
                      edit_date, del_flag, ID
                     )
              VALUES (g_commodity_id, NULL, in_station_num, in_station_code,
                      v_station_no, g_line_id, -1, g_currdate, -1,
                      g_currdate, 0, g_station_location_id
                     );
      ELSE
         SELECT ID
           INTO g_station_location_id
           FROM station_location
          WHERE del_flag = 0
            AND mac_address = station_num
            AND station_code = mygroup
            AND line_id = g_line_id;
      END IF;

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN    'Error occur when handle station_location ,mac_address = '
                || in_station_num;
   END;
BEGIN
   in_line_code := TRIM (line);
   in_station_num := TRIM (station_num);
   in_station_code := TRIM (mygroup);

   SELECT SYSDATE
     INTO g_currdate
     FROM DUAL;

   res := get_line_id;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res := get_station_id;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   res := handle_station_location_info;

   IF res <> g_ok
   THEN
      GOTO end_of_function;
   END IF;

   --when error occur, then transaction roll back
   IF res = g_ok
   THEN
      COMMIT;
      RETURN;
   END IF;

   <<end_of_function>>
   ROLLBACK;
END;


/

