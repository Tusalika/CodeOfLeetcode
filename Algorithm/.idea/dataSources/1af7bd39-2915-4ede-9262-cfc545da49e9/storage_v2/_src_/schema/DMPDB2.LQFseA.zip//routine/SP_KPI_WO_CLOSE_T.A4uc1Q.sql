create PROCEDURE        SP_KPI_WO_CLOSE_T(vWorkDate date) as
  iWorkDays int;
  iCloseDays int;
  iRecordCount int;
  dWorkDate date;
  cWorkDate varchar(20);
  dTempDate date;
  cFloorName varchar(20);
  cCloseDate varchar(20);
  iTargetWoCloseQty int;
  iRealWoCloseQty int;
  
  cursor cur_produce_plan1(vWorkDate date) is 
    select distinct Category_Key, work_date, floor_name 
    from dmpdb2.r_Produce_Plan
    where work_date = vWorkDate
      and del_Flag = 0;
  cursor cur_produce_plan2(vFloorName varchar, vWorkDate date) is      
    select distinct work_date
    from dmpdb2.r_Produce_Plan
    where work_date < vWorkDate
      and work_date >= vWorkDate - 30
      and floor_name = vFloorName
      and del_Flag = 0
    order by work_date desc;     
begin
  --dWorkDate := to_date('20110323', 'YYYYMMDD');
  --dWorkDate := to_date(to_char(sysdate - 1, 'YYYY/MM/DD'), 'YYYY/MM/DD');
  dWorkDate := vWorkDate;
  
  for v_Sal1 in cur_produce_plan1(dWorkDate) loop  
    iCloseDays := 3;
    select count(1) into iRecordCount
      from dmpdb2.c_Wo_Close_Days
      where Category_Key = v_Sal1.Category_Key
        and Del_Flag = 0;
    if iRecordCount = 1 then
      select close_days into iCloseDays
        from dmpdb2.c_Wo_Close_Days
        where Category_Key = v_Sal1.Category_Key
          and Del_Flag = 0;    
    end if;
    
    iWorkDays := 0;
    dTempDate := v_Sal1.Work_Date;
    dbms_output.put_line(dTempDate);
    for v_Sal2 in cur_produce_plan2(v_Sal1.Floor_Name, v_Sal1.Work_Date) loop
      dTempDate := v_Sal2.Work_Date;
      iWorkDays := iWorkDays + 1;      
      if iWorkDays >= iCloseDays then        
        Exit;
      end if;    
    end loop;    
    
    dbms_output.put_line(dTempDate);
    if iWorkDays < iCloseDays then 
      dbms_output.put_line(iWorkDays || iCloseDays);
      while iWorkDays < iCloseDays loop
        dTempDate := dTempDate - 1;
        dbms_output.put_line(dTempDate);
        if to_char(dTempDate, 'D') <> '1' then  ----- '1' means sunday
          iWorkDays := iWorkDays + 1;          
        end if;
      end loop;    
    end if;
    
    cCloseDate := to_char(dTempDate, 'YYYY/MM/DD');
    cWorkDate := to_char(dWorkDate, 'YYYY/MM/DD');
    
    select count(1) into iTargetWoCloseQty from dmpdb2.R_WO a
        , (select distinct Property_01 floor_code, property_04 floor_name from dmpdb2.line) b
      where a.Property_17 = b.floor_code(+)
        and (a.close_flag is null 
             or (a.close_flag is not null 
                 and a.close_time >= to_date(cCloseDate || ' 07:00:00', 'YYYY/MM/DD HH24:MI:SS')
                )
            )
        and a.begin_date_act >= to_date('2011/06/05 07:00:00', 'YYYY/MM/DD HH24:MI:SS')
        and a.begin_date_act <  to_date(cCloseDate || ' 07:00:00', 'YYYY/MM/DD HH24:MI:SS')
        and b.Floor_name = v_Sal1.Floor_name
        and a.del_flag = 0;   
        
    select count(1) into iRealWoCloseQty from dmpdb2.R_WO a
        , (select distinct Property_01 floor_code, property_04 floor_name from dmpdb2.line) b
      where a.Property_17 = b.floor_code(+)
        and a.close_time >= to_date(cWorkDate || ' 07:00:00', 'YYYY/MM/DD HH24:MI:SS')
        and a.close_time <  to_date(cWorkDate || ' 07:00:00', 'YYYY/MM/DD HH24:MI:SS') + 1
        and b.Floor_name = v_Sal1.Floor_name
        and a.del_flag = 0;
    
    update dmpdb2.r_Produce_Plan
      set Property_08 = cCloseDate
        , Property_09 = iTargetWoCloseQty
        , Property_10 = iRealWoCloseQty
      where work_date = v_Sal1.Work_Date
        and Floor_name = v_Sal1.Floor_name;
    
    commit;
  end loop;
end;


/*

select count(1) from dmpdb2.R_WO a
, (select distinct Group_Flag, property_04 floor_name from dmpdb2.line) b
where a.Property_17 = b.Group_Flag(+)
  and a.close_flag is null
  and a.begin_date_act < to_date('2011/03/28 07:00:00', 'YYYY/MM/DD HH24:MI:SS')
  and b.Floor_name = 'C04-5F'
  and a.del_flag = 0


select count(1) from dmpdb2.R_WO a
, (select distinct Group_Flag, property_04 floor_name from dmpdb2.line) b
where a.Property_17 = b.Group_Flag(+)
  and a.close_time >= to_date('2011/03/29 07:00:00', 'YYYY/MM/DD HH24:MI:SS')
  and a.close_time <  to_date('2011/03/29 07:00:00', 'YYYY/MM/DD HH24:MI:SS') + 1
  and b.Floor_name = 'C04-5F'
  and a.del_flag = 0
  
*/


/

