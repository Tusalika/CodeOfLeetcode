create PROCEDURE        SP_LOCK (cno     in     VARCHAR2 ,
                                            lock_id   in  NUMBER,
                                            wstatus1 in   VARCHAR2,
                                            wstatus2  in  VARCHAR2 )
IS
   wno   VARCHAR2 (120);
BEGIN
   DECLARE
      CURSOR cur_t
      IS
         SELECT DISTINCT b.wip_no
           FROM dmpdb2.lock_wip A,
                dmpdb2.lock_wip_detail_2 b,
                dmpdb2.lock_wip_detail_2 C,
                dmpdb2.lock_wip d
          WHERE     a.ID = b.lock_wip_id
                AND b.wip_no = c.wip_no
                AND c.lock_wip_id = d.ID
                AND a.lock_type = d.lock_type
                AND a.reason = d.reason
                AND a.part_reason = d.part_reason
                AND a.remark = d.remark
                AND a.NO <> d.NO
                AND b.wip_status = wstatus1
                AND c.wip_status = wstatus2
                AND a.NO = cno;
   BEGIN
      OPEN cur_t;

      
      LOOP
      FETCH cur_t  INTO  wno  ;

         EXIT WHEN cur_t% NOTFOUND;

         UPDATE dmpdb2.lock_wip_detail_2
            SET wip_status = '1',
                wip_flag = '2',
                property_01 = '3',
                edit_date = SYSDATE
          WHERE lock_wip_id = lock_id AND wip_no =  wno  ;

         COMMIT;
      END LOOP;

      CLOSE cur_t;
   END;
END;

/

