create PROCEDURE        sp_lockwipduplicatedetail (
   ccategorykey         VARCHAR2,
   cwono                VARCHAR2,
   cwipno               VARCHAR2,
   clockno              VARCHAR2,
   cstatus              VARCHAR2,
   cwipflag             VARCHAR2,
   cuserinfo            VARCHAR2,
   cipaddress           VARCHAR2,
   clineid              VARCHAR2,
   cret           OUT   VARCHAR2
)
AS
   g_procedure_name   CONSTANT VARCHAR2 (30)  := 'sp_lockwipduplicatedetail';
   g_ok               CONSTANT VARCHAR2 (2)   := 'OK';
   g_ret                       VARCHAR2 (255);
   icount                      INT;
   ilockid                     INT;
   ilockdetailid               INT;
---------------------------------------------------------------------------
BEGIN
-- check lock main info
   BEGIN
      SELECT ID
        INTO ilockid
        FROM dmpdb2.lock_wip
       WHERE NO = clockno;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         BEGIN
            ilockid := dmpdb2.get_next_id ('LOCK_WIP');              

            INSERT INTO dmpdb2.lock_wip
                        (ID, NO, lock_type, reason,
                         apply_by, apply_date, is_product, ip_address,
                         user_name, add_by, add_date, edit_by, edit_date,
                         lock_by, property_01, property_02, property_03,
                         property_04, property_05, property_06, lock_qty,
                         unlock_qty, category_key, lock_pattern, part_reason,
                         remark, status, property_07, property_08,
                         property_09, property_10
                        )
                 VALUES (ilockid, clockno, 'WAREHOUSE', 'DUPLICATEWIP',
                         'AUTO', SYSDATE, '1', cipaddress,
                         '', -1, SYSDATE, -1, SYSDATE,
                         -1, '', '', '',
                         '', 'MFG', 'FATP', 0,
                         0, ccategorykey, '', '',
                         'DUPLICATEWIP', '2', '', '',
                         '', ''
                        );
         END;
   END;

   --add lock detail
   SELECT dmpdb2.seq_lock_wip_detail_2_id.NEXTVAL
     INTO ilockdetailid
     FROM DUAL;

   INSERT INTO dmpdb2.lock_wip_detail_2
               (ID, commodity_id, lock_wip_id, wip_no, wip_status, wip_flag,
                store_code, add_by, add_date, edit_by, edit_date, wo_no,
                carton_no, pallet_no, property_01, property_02, property_03
               )
        VALUES (ilockdetailid, 33, ilockid, cwipno, cstatus, cwipflag,
                '', -1, SYSDATE, -1, SYSDATE, cwono,
                '', '', cuserinfo, clineid, ''
               );

   COMMIT;
   cret := g_ok;
   RETURN;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         ROLLBACK;
         cret :=
             'ERROR(' || g_procedure_name || '):' || SUBSTR (SQLERRM, 1, 200);
         dmpdb2.write_bob_log (g_procedure_name,
                               g_procedure_name,
                               '0',
                               cret,
                               cwipno
                              );
      END;
END;

/

