create PROCEDURE        sp_lock_parts_wip (
   cwipno      IN       VARCHAR2,
   cpartname   IN       VARCHAR2,
   res         OUT      VARCHAR2
)
AS
   ilockdetailid   INT;
   cno             VARCHAR2 (50);
   checklock       VARCHAR2 (50);
   cflag           VARCHAR2 (50);

   CURSOR cur_lockinfor1 (cwipno IN VARCHAR2, cpartname IN VARCHAR2)
   IS
      SELECT b.ID, b.NO, b.add_by, b.add_date, b.edit_by, b.edit_date
        FROM dmpdb2.lock_wip_detail_p a,
             dmpdb2.lock_wip b,
             (SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@k_fatp a, dmpdb2.r_wip_parts_1@k_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@k_fatp a, dmpdb2.r_wip_parts@k_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@l_fatp a, dmpdb2.r_wip_parts_1@l_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@l_fatp a, dmpdb2.r_wip_parts@l_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@f_fatp a, dmpdb2.r_wip_parts_1@f_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@f_fatp a, dmpdb2.r_wip_parts@f_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@e_fatp a, dmpdb2.r_wip_parts_1@e_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname
              UNION ALL
              SELECT b.serial_no, a.NO, a.property_01 category_key
                FROM dmpdb2.r_wip@e_fatp a, dmpdb2.r_wip_parts@e_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = cpartname) c
       WHERE a.lock_wip_id = b.ID
         AND a.wip_no = c.serial_no
         AND wip_status = 'S';

   CURSOR cur_cgsno (cwipno IN VARCHAR2)
   IS
      SELECT serial_no
        FROM (SELECT b.serial_no
                FROM dmpdb2.r_wip@k_fatp a, dmpdb2.r_wip_parts_1@k_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@k_fatp a, dmpdb2.r_wip_parts@k_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@l_fatp a, dmpdb2.r_wip_parts_1@l_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@l_fatp a, dmpdb2.r_wip_parts@l_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@f_fatp a, dmpdb2.r_wip_parts_1@f_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@f_fatp a, dmpdb2.r_wip_parts@f_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@e_fatp a, dmpdb2.r_wip_parts_1@e_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS'
              UNION ALL
              SELECT b.serial_no
                FROM dmpdb2.r_wip@e_fatp a, dmpdb2.r_wip_parts@e_fatp b
               WHERE a.ID = b.wip_id
                 AND a.del_flag = 0
                 AND b.del_flag = 0
                 AND a.NO = cwipno
                 AND b.part_name = 'CGS');
BEGIN
   cflag := '0';
   cno := cwipno;

   IF    (cpartname = 'RCV')
      OR (cpartname = 'MBF')
      OR (cpartname = 'CRP')
      OR (cpartname = 'LCG')
      OR (cpartname = 'SEN')
      OR (cpartname = 'VGA')
   THEN
      FOR my_cgs IN cur_cgsno (cwipno)
      LOOP
         IF my_cgs.serial_no IS NOT NULL
         THEN
            cno := my_cgs.serial_no;
         END IF;
      END LOOP;
   END IF;

   FOR my_lock IN cur_lockinfor1 (cno, cpartname)
   LOOP
      SELECT COUNT (wip_no)
        INTO checklock
        FROM dmpdb2.lock_wip_detail_2
       WHERE wip_status = 'S' AND wip_no = cwipno AND lock_wip_id = my_lock.ID;

      IF checklock = 0
      THEN
         ilockdetailid := get_next_id ('LOCK_WIP_DETAIL_2');

         INSERT INTO dmpdb2.lock_wip_detail_2
                     (ID, commodity_id, lock_wip_id, wip_no, wip_status,
                      wip_flag, add_by, add_date, edit_by, edit_date
                     )
              VALUES (ilockdetailid, 33, my_lock.ID, cwipno, 'S',
                      'OK', my_lock.add_by, SYSDATE, my_lock.edit_by, SYSDATE
                     );

         COMMIT;
         cflag := '1';
      END IF;
   END LOOP;

   res := 'OK;' || cflag;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      res := '通過單體料件扣整機扣貨失敗;-1';
END;

/

