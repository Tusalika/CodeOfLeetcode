create PROCEDURE        Sp_Next_ID (
   DATA   IN       VARCHAR2,
   res    OUT      Number
) AS
BEGIN
   res := Get_Next_ID(DATA);
END;
/

