create PROCEDURE        SP_PDCA_FIRST_YIELD_SCH
as
  fTimeGenerate CONSTANT number := 5/(24*60); --------一次Run 5分鐘的資料
  iRecordCount int;
  cScheduleCode varchar2(30);
  iMaxID number;  
  iTemp number;
  dTimePoint date;
  dTemp date;
  cRet varchar2(255);
  g_OK varchar2(10);   
  dTemp2 date;
  
  g_Recordcount number;
  g_FirstYieldCount number;
  g_FirstOffsetCount number;
  
  iScheduleID number;
  iLogID number;
  
  iRunContinue int;
  
  g_sysdate date;
  
  procedure write_batch_Job_Log_file(vResultLevel varchar2, vResultDesc varchar2) as
  begin    
    --iMaxID := get_next_id('PDCA_FIRST_YIELD');
    --select dmpdb2.Batch_Job_Log_File_Id.nextval into iMaxID from dual;
    --INSERT INTO dmpdb2.BATCH_JOB_LOG_FILE(UniqID, SysID, ProgID, UserID, StartDt, EndDt, Records, ErrLevel, ErrDesc)
    --  VALUES( cScheduleCode || '_' || iMaxID
    --    , 'SFC(PDCA)'
    --    , cScheduleCode || '_FATP2'
    --    , 'SFC'
    --    , Sysdate
    --    , SYSDATE + fTimeGenerate
    --    , '0'
    --    , vResultLevel  --- 'G'
    --    , vResultDesc   --- 'OK'
    --    )
    --    ;
        
     dmpdb2.write_batch_Job_Log_file(
       'SFC(PDCA)'
       , cScheduleCode || '_FATP2'
       , 'SFC'
       , sysdate
       , sysdate + fTimeGenerate
       , 0
       , vResultLevel
       , vResultDesc
      );        
  end;
begin
  g_sysdate := sysdate;

  cScheduleCode := 'PDCA_FIRST_YIELD';--;
  
  g_OK := 'OK';
  
  iMaxID := 0;  
  
  iRunContinue := 0;
  select count(1) into iRecordCount
    from Schedule_Config
    where code = cScheduleCode
      and del_flag = 0;
  if iRecordCount > 0 then
    select Is_Run_Continue into iRunContinue
      from Schedule_Config
      where code = cScheduleCode
        and del_flag = 0;      
    update Schedule_Config set Is_Run_Continue = 1
      where code = cScheduleCode
        and del_flag = 0;      
  else
    insert into dmpdb2.schedule_config(ID,commodity_id, Code, Namec, NameE, descriptionE, Start_Time, Time_Flag, Time_Point
      , Time_Interval, Time_out, Day_Type, Day_Flag, Day_Point, Day_Interval, Is_Run_Continue, Is_Auto_Start,descriptionc
      , Property_01, Property_02, Property_03, Property_04, Property_05
      , Add_By, Add_Date, Edit_by, Edit_Date, Del_Flag)
    values(66, 33, cScheduleCode, cScheduleCode, cScheduleCode, ''
      , sysdate, 2, '07:00:00', 300, 900, 1, 1, null, null, 0, 1, ''
      , '', '', '', '', ''
      , -1, sysdate, -1, sysdate, 0);   
  end if;
  
  commit;
  
  if iRunContinue = 0 then
     --dbms_output.put_line('aaaaa>' || iRunContinue);
      select /*+rule*/ count(1) into iRecordCount
        from  C_PDCA_LOG
        where Schedule_Code = cScheduleCode
          and Status_Flag = 0
          and Del_Flag = 0;
      if iRecordCount = 0 then
        select count(1) into iRecordCount
          from  C_PDCA_LOG
          where Schedule_Code = cScheduleCode
            and Del_Flag = 0
            and Rownum <= 1;
        if iRecordCount = 0 then
          iMaxID := get_next_id('C_PDCA_LOG');
          --select C_PDCA_LOG_ID.nextval into iMaxID from dual;
          insert into  C_PDCA_LOG
            Values(iMaxID, cScheduleCode, to_date('2011/06/14 070000', 'YYYY/MM/DD HH24MISS'), null, null, 0
                   , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);       
        else
          select Max(ID) into iTemp
            from  C_PDCA_LOG
            where Schedule_Code = cScheduleCode
              and Del_Flag = 0;
          select Time_Point into dTimePoint
            from  C_PDCA_LOG
            where ID = iTemp;
          dTemp := to_date(to_char(dTimePoint, 'YYYY/MM/DD') || ' 070000', 'YYYY/MM/DD HH24MISS') + 1;
          dTimePoint := dTimePoint + fTimeGenerate;   
          while dTimePoint < dTemp and dTimePoint <= g_sysdate - 10/(24*60) loop 
            iMaxID := get_next_id('C_PDCA_LOG'); 
            --select C_PDCA_LOG_ID.nextval into iMaxID from dual;           
            insert into C_PDCA_LOG
              Values(iMaxID, cScheduleCode, dTimePoint, null, null, 0
                     , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
            dTimePoint := dTimePoint + fTimeGenerate;         
          end loop;                      
        end if;         
      else        
        select min(id) into iScheduleID
          from C_PDCA_LOG 
          where Schedule_Code = cScheduleCode 
            and Status_Flag = 0 
            and Del_Flag = 0;
         
        select Time_Point into dTimePoint
          from  C_PDCA_LOG
          where ID = iScheduleID;
        iTemp := 0;   
               
        while dTimePoint + fTimeGenerate <= g_sysdate - 10/(24*60) loop
          --cRet := 'OK';
          --dbms_output.put_line('bbbbb>' || to_char(dTimePoint, 'YYYY-MM-DD HH24:MI:SS'));   
            cRet := '';
            dTemp2 := sysdate;           
            SP_PDCA_Yield_First(dTimePoint, dTimePoint + fTimeGenerate, '', g_Recordcount, g_FirstYieldCount, g_FirstOffsetCount, cRet);
            if cRet = g_OK then
              ---- Add Monitor info
              update C_PDCA_LOG set generate_time = g_sysdate, Transfer_Time = sysdate
                                    , Status_Flag = 2
                                    , Property_03 = to_char(Round((sysdate - dTemp2)*24*3600))
                                    , property_04 = to_char(g_Recordcount)
                                    , property_01 = to_char(g_FirstYieldCount)
                                    , property_02 = to_char(g_FirstOffsetCount)   
                                    , property_05 = cRet                                    
                where ID = iScheduleID;               
              write_batch_Job_Log_file('G', 'OK');
            else
              ---- Add Warning
              exit;
            end if;
        
          iTemp := iTemp + 1;
          
          if iTemp < iRecordCount then
            select min(id) into iScheduleID
              from C_PDCA_LOG 
              where Schedule_Code = cScheduleCode 
                and Status_Flag = 0 
                and Del_Flag = 0;           
            select Time_Point into dTimePoint
              from  C_PDCA_LOG
              where ID = iScheduleID; 
          else 
            exit;    
          end if;         
        end loop;
        
        if iTemp = iRecordCount then
          dTemp := to_date(to_char(dTimePoint, 'YYYY/MM/DD') || ' 070000', 'YYYY/MM/DD HH24MISS') + 1;
          --dTemp := dTimePoint + 1/24;
          dTimePoint := dTimePoint + fTimeGenerate; 
          while dTimePoint < dTemp and dTimePoint <= g_sysdate - 10/(24*60) loop 
            iMaxID := get_next_id('C_PDCA_LOG'); 
            --select C_PDCA_LOG_ID.nextval into iMaxID from dual;           
            insert into C_PDCA_LOG
              Values(iMaxID, cScheduleCode, dTimePoint, null, null, 0
                     , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
            dTimePoint := dTimePoint + fTimeGenerate;         
          end loop;      
        end if;        
      end if;  
      commit;        
---------------------------------------------------
      select /*+rule*/ count(1) into iRecordCount
        from  C_PDCA_LOG
        where Schedule_Code = cScheduleCode
          and Status_Flag = 1
          and Del_Flag = 0;      
      if iRecordCount > 0 then
        select min(id) into iScheduleID
          from C_PDCA_LOG 
          where Schedule_Code = cScheduleCode 
            and Status_Flag = 1 
            and Del_Flag = 0;
        select Time_Point into dTimePoint
          from  C_PDCA_LOG
          where ID = iScheduleID;
        iTemp := 0;  
        while dTimePoint + fTimeGenerate <= g_sysdate - 10/(24*60) loop
          cRet := '';
          dTemp2 := sysdate;
          SP_PDCA_Yield_First(dTimePoint, dTimePoint + fTimeGenerate, '', g_Recordcount, g_FirstYieldCount, g_FirstOffsetCount, cRet);
          
          if cRet = g_OK then
              ---- Add Monitor info
              update C_PDCA_LOG set generate_time = g_sysdate, Transfer_Time = sysdate
                                    , Status_Flag = 2
                                    , Property_03 = to_char(Round((sysdate - dTemp2)*24*3600))
                                    , property_04 = to_char(g_Recordcount)
                                    , property_01 = to_char(g_FirstYieldCount)
                                    , property_02 = to_char(g_FirstOffsetCount)
                                    , property_05 = cRet   
                where ID = iScheduleID;               
              write_batch_Job_Log_file('G', 'OK');
          else
            ---- Add Warning
            exit;  
          end if;
        
          iTemp := iTemp + 1;
          
          if iTemp < iRecordCount then
            select min(id) into iScheduleID
              from C_PDCA_LOG 
              where Schedule_Code = cScheduleCode 
                and Status_Flag = 1 
                and Del_Flag = 0;           
            select Time_Point into dTimePoint
              from  C_PDCA_LOG
              where ID = iScheduleID; 
          else 
            exit;    
          end if;         
        end loop;         
      end if;        
      
    -----------------------------------    
    update Schedule_Config set Is_Run_Continue = 0
      where code = cScheduleCode
        and del_flag = 0;     
      
    commit;  
  end if;  ----Is_Run_Continue      
end;


/

