create PROCEDURE        SP_PDCA_LOG_AUTO
(
vSchCode in varchar2
, vSchID out number
, vBeginTime out date  ----  timepoint
, vEndTime out date
, vStatusFlag out varchar2
)
as
  g_procedure_name constant varchar2(24) := 'SP_PDCA_LOG_AUTO';
  g_ok constant varchar2(2) := 'OK';
  dInitStartTime date;
  fIntervalTime number;
  fTimeGenerate number;
  iRecordCount int;
  iSch0Count int;
  iMaxID number;

  cScheduleCode varchar2(30);
  dTimePoint date;
  cRet varchar2(255);
begin
  vSchID := '-1';

  cScheduleCode := vSchCode;

  select interval, start_time into fIntervalTime, dInitStartTime
    from c_pdca_sch
    where code = cScheduleCode;

  fTimeGenerate := fIntervalTime/(24*3600);

  select /*+ index(a C_PDCA_LOG_STATUS_FLAG)*/ count(1) into iSch0Count
    from  C_PDCA_LOG a
    where Schedule_Code = cScheduleCode
      and Status_Flag = '0'
      and Del_Flag = 0;
  if iSch0Count <= 0 then
        select count(1) into iRecordCount
          from  C_PDCA_LOG a
          where Schedule_Code = cScheduleCode
            and Del_Flag = 0
            and Rownum <= 1;
        if iRecordCount = 0 then
          dTimePoint := dInitStartTime;
        else
          select Max(time_point) into dTimePoint
            from  C_PDCA_LOG
            where Schedule_Code = cScheduleCode
              and Del_Flag = 0;
          dTimePoint := dTimePoint + fTimeGenerate;
        end if;

        iMaxID := get_next_id('C_PDCA_LOG');
        insert into C_PDCA_LOG
        values(iMaxID, cScheduleCode, dTimePoint, null, null, '0'
               , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
        iSch0Count := 1;
  end if;

  select /*+ index(a C_PDCA_LOG_STATUS_FLAG)*/ min(id) into vSchID
    from C_PDCA_LOG a
    where Schedule_Code = cScheduleCode
      and Status_Flag in('0', '1', '4', '5', '6')
      and Del_Flag = 0;

  select /*+ index(a C_PDCA_LOG_PK)*/ time_point, status_flag into dTimePoint, vStatusFlag
    from C_PDCA_LOG a
    where id = vSchID;

  vBeginTime := dTimePoint;
  vEndtime := dTimePoint + fTimeGenerate;

  if vEndtime < sysdate then
    if iSch0Count = 1 and vStatusFlag = '0' then
        --select C_PDCA_LOG_ID.nextval into iMaxID from dual;
        iMaxID := get_next_id('C_PDCA_LOG');
        dTimePoint := vEndtime;
        insert into C_PDCA_LOG
          values(iMaxID, cScheduleCode, dTimePoint, null, null, '0'
                 , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
    end if;
  else
    vSchID := -1;
  end if;

exception
    WHEN OTHERS THEN begin
     cRet := 'ERROR(' || g_procedure_name || '):' || SUBSTR(SQLERRM, 1, 100);
     write_bob_log(g_procedure_name, g_procedure_name, '0', cRet, g_procedure_name);
  end;
end;


/

