create PROCEDURE        SP_PDCA_LOG_AUTO2
(
vSchCode in varchar2
, vStatusFlag in varchar2
, vSchID out number
, vBeginTime out date  ----  timepoint
, vEndTime out date
)
as
  g_procedure_name constant varchar2(24) := 'SP_PDCA_LOG_AUTO';
  g_ok constant varchar2(2) := 'OK';
  g_time_gap number;
  dInitStartTime date;
  fIntervalTime number;
  fTimeGenerate number;
  iRecordCount int;
  iSch0Count int;
  iMaxID number;

  cScheduleCode varchar2(30);
  dTimePoint date;
  cRet varchar2(255);
begin
  vSchID := -1;

  g_time_gap := 15/(24*60);

  cScheduleCode := vSchCode;

  select interval, start_time into fIntervalTime, dInitStartTime
    from c_pdca_sch
    where code = cScheduleCode;

  fTimeGenerate := fIntervalTime/(24*3600);

  select /*+ index(a C_PDCA_LOG_STATUS_FLAG)*/ count(1) into iSch0Count
    from C_PDCA_LOG a
    where Schedule_Code = cScheduleCode
      and Status_Flag = vStatusFlag
      and Del_Flag = 0;
  if iSch0Count <= 0 and vStatusFlag = '0' then
        select count(1) into iRecordCount
          from  C_PDCA_LOG
          where Schedule_Code = cScheduleCode
            and Del_Flag = 0
            and Rownum <= 1;
        if iRecordCount = 0 then
          dTimePoint := dInitStartTime;
        else
          select Max(time_point) into dTimePoint
            from C_PDCA_LOG
            where Schedule_Code = cScheduleCode
              and Del_Flag = 0;
          dTimePoint := dTimePoint + fTimeGenerate;
        end if;

        iMaxID := get_next_id('C_PDCA_LOG');
        insert into C_PDCA_LOG
        values(iMaxID, cScheduleCode, dTimePoint, null, null, '0'
               , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
        iSch0Count := 1;
  end if;

  if iSch0Count > 0 then
    select /*+ index(a C_PDCA_LOG_STATUS_FLAG)*/ min(id) into vSchID
      from C_PDCA_LOG a
      where Schedule_Code = cScheduleCode
        and Status_Flag = vStatusFlag
        and Del_Flag = 0;

    select /*+ index(a C_PDCA_LOG_PK)*/ time_point into dTimePoint
      from C_PDCA_LOG a
      where id = vSchID;

    vBeginTime := dTimePoint;
    vEndtime := dTimePoint + fTimeGenerate;

    if vEndtime < sysdate - g_time_gap then
      if iSch0Count = 1 and vStatusFlag = '0' then
          --select C_PDCA_LOG_ID.nextval into iMaxID from dual;
          iMaxID := get_next_id('C_PDCA_LOG');
          dTimePoint := vEndtime;
          insert into C_PDCA_LOG
            values(iMaxID, cScheduleCode, dTimePoint, null, null, '0'
                   , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
      end if;
    else
      vSchID := -1;
    end if;
  else
    vSchID := -1;
    vBeginTime := sysdate;
    vEndTime := sysdate;
  end if;

  commit;
exception
    WHEN OTHERS THEN begin
     cRet := 'ERROR(' || g_procedure_name || '):' || SUBSTR(SQLERRM, 1, 100);
     write_bob_log(g_procedure_name, g_procedure_name, '0', cRet, g_procedure_name);
  end;
end;


/

