create PROCEDURE        SP_PDCA_SYNC_SFC_DATA_SCH
as 
  fTimeGenerate CONSTANT number := 5/(24*60); --------一次Run 5分鐘的資料
  iRecordCount int;
  cScheduleCode varchar2(30);
  iMaxID number;  
  iTemp number;
  dTimePoint date;
  dTemp date;
  cRet varchar2(255);
  g_OK varchar2(10);   
  dTemp2 date; 
  
  g_Recordcount1 number;
  g_Recordcount2 number;
  g_Recordcount3 number;
  g_Recordcount4 number;
  
  iScheduleID number;
  iLogID number;
  
  iRunContinue int;
  
  g_sysdate date;
  
  procedure write_Bob_PDCA_Log(vSchCode varchar2, vTimepoint date)
  as
  begin
    insert into zbcdmp2_dmpdb2.C_PDCA_LOG@zz_bob_report_lk(ID, Schedule_Code, Time_point, Generate_Time, Transfer_Time, Status_Flag
          , add_by, add_date, edit_by, edit_date, del_flag)
    values(zbcdmp2_dmpdb2.C_PDCA_LOG_ID.nextval@zz_bob_report_lk
           , vSchCode
           , vTimepoint
           , sysdate
           , sysdate
           , 2
           , -2011
           , sysdate
           , -2011
           , sysdate
           , 0
           );
  end;
  
  procedure write_batch_Job_Log_file(vResultLevel varchar2, vResultDesc varchar2) as
  begin    
    --iMaxID := get_next_id('PDCA_FIRST_YIELD');
    --select dmpdb2.Batch_Job_Log_File_Id.nextval into iMaxID from dual;
    --INSERT INTO dmpdb2.BATCH_JOB_LOG_FILE(UniqID, SysID, ProgID, UserID, StartDt, EndDt, Records, ErrLevel, ErrDesc)
    --  VALUES( cScheduleCode || '_' || iMaxID
    --    , 'SFC(PDCA)'
    --    , cScheduleCode || '_FATP2'
    --    , 'SFC'
    --    , Sysdate
    --    , SYSDATE + fTimeGenerate
    --    , '0'
    --    , vResultLevel  --- 'G'
    --    , vResultDesc   --- 'OK'
    --    )
    --    ;
        
     dmpdb2.write_batch_Job_Log_file(
       'SFC(PDCA)'
       , cScheduleCode || '_FATP2'
       , 'SFC'
       , sysdate
       , sysdate + fTimeGenerate
       , 0
       , vResultLevel
       , vResultDesc
      );        
  end;
begin
  g_sysdate := sysdate;

  cScheduleCode := 'PDCA_SYNC_SFC_DATA';--;
  
  g_OK := 'OK';
  
  iMaxID := 0;  
  
  iRunContinue := 0;
  select count(1) into iRecordCount
    from Schedule_Config
    where code = cScheduleCode
      and del_flag = 0;
  if iRecordCount > 0 then
    select Is_Run_Continue into iRunContinue
      from Schedule_Config
      where code = cScheduleCode
        and del_flag = 0;      
    update Schedule_Config set Is_Run_Continue = 1
      where code = cScheduleCode
        and del_flag = 0;      
  else
    insert into dmpdb2.schedule_config(ID,commodity_id, Code, Namec, NameE, descriptionE, Start_Time, Time_Flag, Time_Point
      , Time_Interval, Time_out, Day_Type, Day_Flag, Day_Point, Day_Interval, Is_Run_Continue, Is_Auto_Start,descriptionc
      , Property_01, Property_02, Property_03, Property_04, Property_05
      , Add_By, Add_Date, Edit_by, Edit_Date, Del_Flag)
    values(66, 33, cScheduleCode, cScheduleCode, cScheduleCode, ''
      , sysdate, 2, '07:00:00', 300, 900, 1, 1, null, null, 0, 1, ''
      , '', '', '', '', ''
      , -1, sysdate, -1, sysdate, 0);   
  end if;
  
  commit;
  
  if iRunContinue = 0 then
     --dbms_output.put_line('aaaaa>' || iRunContinue);
      select /*+rule*/ count(1) into iRecordCount
        from  C_PDCA_LOG
        where Schedule_Code = cScheduleCode
          and Status_Flag = 0
          and Del_Flag = 0;
      if iRecordCount = 0 then
        select count(1) into iRecordCount
          from  C_PDCA_LOG
          where Schedule_Code = cScheduleCode
            and Del_Flag = 0
            and Rownum <= 1;
        if iRecordCount = 0 then
          iMaxID := get_next_id('C_PDCA_LOG');
          --select C_PDCA_LOG_ID.nextval into iMaxID from dual;
          insert into  C_PDCA_LOG
            Values(iMaxID, cScheduleCode, to_date('2011/09/01 070000', 'YYYY/MM/DD HH24MISS'), null, null, 0
                   , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);       
        else
          select Max(ID) into iTemp
            from  C_PDCA_LOG
            where Schedule_Code = cScheduleCode
              and Del_Flag = 0;
          select Time_Point into dTimePoint
            from  C_PDCA_LOG
            where ID = iTemp;
          dTemp := to_date(to_char(dTimePoint, 'YYYY/MM/DD') || ' 070000', 'YYYY/MM/DD HH24MISS') + 1;
          dTimePoint := dTimePoint + fTimeGenerate;   
          while dTimePoint < dTemp and dTimePoint <= g_sysdate - 5/(24*60) loop 
            iMaxID := get_next_id('C_PDCA_LOG'); 
            --select C_PDCA_LOG_ID.nextval into iMaxID from dual;           
            insert into C_PDCA_LOG
              Values(iMaxID, cScheduleCode, dTimePoint, null, null, 0
                     , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
            dTimePoint := dTimePoint + fTimeGenerate;         
          end loop;                      
        end if;         
      else        
        select min(id) into iScheduleID
          from C_PDCA_LOG 
          where Schedule_Code = cScheduleCode 
            and Status_Flag = 0 
            and Del_Flag = 0;
         
        select Time_Point into dTimePoint
          from  C_PDCA_LOG
          where ID = iScheduleID;
        iTemp := 0;   
               
        while dTimePoint + fTimeGenerate <= g_sysdate - 5/(24*60) loop
          --cRet := 'OK';
          --dbms_output.put_line('bbbbb>' || to_char(dTimePoint, 'YYYY-MM-DD HH24:MI:SS'));   
            cRet := '';
            dTemp2 := sysdate;   
            --dbms_output.put_line('Begin');        
            --SP_PDCA_Yield_First(dTimePoint, dTimePoint + fTimeGenerate, '', g_Recordcount, g_FirstYieldCount, g_FirstOffsetCount, cRet);
            dmpdb2.sp_sync_unit_info_n94(dTimePoint, dTimePoint + fTimeGenerate, g_Recordcount1, cRet);
            --dbms_output.put_line('sp_sync_unit_info_n94'); 
            if cRet <> g_OK then
              exit;
            end if;
             
            dmpdb2.sp_sync_unit_log_n94(dTimePoint, dTimePoint + fTimeGenerate, g_Recordcount2, cRet);
            --dbms_output.put_line('sp_sync_unit_log_n94'); 
            if cRet <> g_OK then
              exit;
            end if; 
            
            dmpdb2.sp_sync_unit_repair_n94(dTimePoint, dTimePoint + fTimeGenerate, g_Recordcount3, cRet);
            --dbms_output.put_line('sp_sync_unit_repair_n94'); 
            if cRet <> g_OK then
              exit;
            end if;             
            
            update C_PDCA_LOG set generate_time = g_sysdate, Transfer_Time = sysdate
                                  , Status_Flag = 2
                                  , Property_03 = to_char(Round((sysdate - dTemp2)*24*3600))
                                  , property_04 = to_char(g_Recordcount3)
                                  , property_01 = to_char(g_Recordcount1)
                                  , property_02 = to_char(g_Recordcount2)   
                                  , property_05 = cRet                                    
              where ID = iScheduleID; 
            --dbms_output.put_line('End');    
            
            write_Bob_PDCA_Log(cScheduleCode, dTimePoint);
                         
            write_batch_Job_Log_file('G', 'OK');
                    
          iTemp := iTemp + 1;
          
          if iTemp < iRecordCount then
            select min(id) into iScheduleID
              from C_PDCA_LOG 
              where Schedule_Code = cScheduleCode 
                and Status_Flag = 0 
                and Del_Flag = 0;           
            select Time_Point into dTimePoint
              from  C_PDCA_LOG
              where ID = iScheduleID; 
          else 
            exit;    
          end if;         
        end loop;
        
        if iTemp = iRecordCount then
          dTemp := to_date(to_char(dTimePoint, 'YYYY/MM/DD') || ' 070000', 'YYYY/MM/DD HH24MISS') + 1;
          --dTemp := dTimePoint + 1/24;
          dTimePoint := dTimePoint + fTimeGenerate; 
          while dTimePoint < dTemp and dTimePoint <= g_sysdate - 5/(24*60) loop 
            iMaxID := get_next_id('C_PDCA_LOG'); 
            --select C_PDCA_LOG_ID.nextval into iMaxID from dual;           
            insert into C_PDCA_LOG
              Values(iMaxID, cScheduleCode, dTimePoint, null, null, 0
                     , null, null, null, null, null, -2011, sysdate, -2011, sysdate, 0);
            dTimePoint := dTimePoint + fTimeGenerate;         
          end loop;      
        end if;        
      end if;  
      commit;        
---------------------------------------------------
      select /*+rule*/ count(1) into iRecordCount
        from  C_PDCA_LOG
        where Schedule_Code = cScheduleCode
          and Status_Flag = 1
          and Del_Flag = 0;      
      if iRecordCount > 0 then
        select min(id) into iScheduleID
          from C_PDCA_LOG 
          where Schedule_Code = cScheduleCode 
            and Status_Flag = 1 
            and Del_Flag = 0;
        select Time_Point into dTimePoint
          from  C_PDCA_LOG
          where ID = iScheduleID;
        iTemp := 0;  
        while dTimePoint + fTimeGenerate <= g_sysdate - 5/(24*60) loop
          cRet := '';
          dTemp2 := sysdate;
          --SP_PDCA_Yield_First(dTimePoint, dTimePoint + fTimeGenerate, '', g_Recordcount, g_FirstYieldCount, g_FirstOffsetCount, cRet);
          --dbms_output.put_line('Begin');  
          dmpdb2.sp_sync_unit_info_n94(dTimePoint, dTimePoint + fTimeGenerate, g_Recordcount1, cRet);
          --dbms_output.put_line('sp_sync_unit_info_n94');  
          if cRet <> g_OK then
            exit;
          end if;
             
          dmpdb2.sp_sync_unit_log_n94(dTimePoint, dTimePoint + fTimeGenerate, g_Recordcount2, cRet);
          --dbms_output.put_line('sp_sync_unit_log_n94');  
          if cRet <> g_OK then
            exit;
          end if; 
            
          dmpdb2.sp_sync_unit_repair_n94(dTimePoint, dTimePoint + fTimeGenerate, g_Recordcount3, cRet);
          --dbms_output.put_line('sp_sync_unit_repair_n94');  
          if cRet <> g_OK then
            exit;
          end if;   
          
          --dbms_output.put_line('sp_sync_unit_repair_n94-----------2');           
            
          update C_PDCA_LOG set generate_time = g_sysdate, Transfer_Time = sysdate
                                , Status_Flag = 2
                                , Property_03 = to_char(Round((sysdate - dTemp2)*24*3600))
                                , property_04 = to_char(g_Recordcount3)
                                , property_01 = to_char(g_Recordcount1)
                                , property_02 = to_char(g_Recordcount2)   
                                , property_05 = cRet                                    
            where ID = iScheduleID;  
            
          --dbms_output.put_line('end');   
            
          write_batch_Job_Log_file('G', 'OK');  
          
          --dbms_output.put_line('write_batch_Job_Log_file'); 
        
          iTemp := iTemp + 1;
          
          if iTemp < iRecordCount then
            select min(id) into iScheduleID
              from C_PDCA_LOG 
              where Schedule_Code = cScheduleCode 
                and Status_Flag = 1 
                and Del_Flag = 0;           
            select Time_Point into dTimePoint
              from  C_PDCA_LOG
              where ID = iScheduleID; 
          else 
            exit;    
          end if;         
        end loop;         
      end if;        
      
    -----------------------------------    
    update Schedule_Config set Is_Run_Continue = 0
      where code = cScheduleCode
        and del_flag = 0
        and Is_Run_Continue = 1;     
      
    commit;  
  end if;  ----Is_Run_Continue  
  
  --dbms_output.put_line(cRet); 
  --dbms_output.put_line('return');    
  
  return;  
exception
  WHEN OTHERS THEN begin
    --update C_PDCA_LOG set property_01 = iLogID
    --  where ID = vScheduleID;
    cRet:='ERROR(SP_PDCA_SYNC_SFC_DATA_SCH):' || SUBSTR(SQLERRM, 1, 200);   
    --dbms_output.put_line(cRet); 
    dmpdb2.write_bob_log('SP_PDCA_SYNC_SFC_DATA_SCH', 'SP_PDCA_SYNC_SFC_DATA_SCH', '0', cRet, 'SP_PDCA_SYNC_SFC_DATA_SCH');      
  end;   
end;


/

