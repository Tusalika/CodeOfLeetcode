create PROCEDURE        SP_PDCA_Yield_First(
vTimeBegin in date
, vTimeEnd in date
, vTestLine in varchar2
, vRecortCount out number
, vFirstYieldCounts out number
, vFirstOffsetCounts out number
, vRet out varchar2
)
---- 2011-09-09 恢復﹔
as
--declare
  --dTimePoint date; 
  cWipNo varchar2(20);
  iWipID number;  
  iFirstTestFlag int;
  iPreWoID number;
  iPreRepairTimes int;
  iRepairTimes int;
  iTestTimes int;
  
  dFirstStartTime date;
  dFirstStopTime date;
  dFirstFailTime date;
  iFirstTestResult int;
  cFirstTestLine varchar2(60);
  cFirstTestNum varchar2(10);
  
  iPreTestResult int;
  iPreRetestFlag int;
  iPreIsTimeOutPass int;
  iPreIsOverridePass int;
  cPreReportType varchar(10);
  
  iCurTestResult int;
  iCurRetestFlag int;
  iCurIsTimeOutPass int;
  iCurIsOverridePass int;  
  cCurReportType varchar(10);
  
  cAppleStationCode varchar(60);
  cAppleStationNum varchar(10);
  cAppleLine varchar(60);
  iTemp int;
  cTemp varchar(1024);
  
  g_SymptomCode varchar(1024);
  g_SymptomCode2 varchar(255);
  g_SymptomDesc varchar(512);
  
  iRecordCount int;
  g_OK CONSTANT varchar2(2) := 'OK';
  cRet varchar2(1000); 
  
  nTimeOutPeriod number; 
  
  iNewID number;
  
  g_P_Id varchar2(30);

  --------------------------------------------------     
  ----cursor_Apple_station--------------------------    
  cursor cursor_DCS_log(v_BeginTime date, v_EndTime date) is 
    select * from (    
      select /*+index(b idx_r_wip_no)*/ b.commodity_id, b.id WIP_ID, a.wip_no, b.wo_id, c.Category_Key, c.Is_Msr, a.station_type, a.station_code
             , nvl(a.start_time, a.stop_time) start_time, a.stop_time, a.is_test_fail, a.symptom_code, a.symptom_desc
             , 'AUTO' Report_Type
             , a.Property_20 OverridePass_Flag
      from dmpdb2.CR_DCS@iphone_bob_l a
         , dmpdb2.R_WIP b
         , dmpdb2.R_WO c
      where a.add_date >= v_BeginTime
        and a.add_date <  v_EndTime
        and a.wip_no = b.no
        and b.wo_id = c.id
        and a.start_time + 0 > b.input_time + 0
        and (b.finish_time is null or b.finish_time > a.stop_time)          
        and nvl(a.symptom_code, '-') <> 'Clearing SFC on Connect'
        and c.Category_Key like 'N94%'
        and nvl(a.Property_21, '0') = '0'
      union all-----------------------   
      select  /*+rule leading(c,a,b,d,f)  use_nl(c,a,b,d,f)*/
             a.commodity_id, a.id wip_id, a.no wip_no, a.wo_id, b.category_key, b.Is_Msr
             , d.property_01 station_type
             , 'FXGL_' || f.alias_name || '_1_' || d.property_01 as Station_code
             , c.station_time start_time, c.station_time stop_time, 0 is_test_fail
             , '' symptom_code, '' symptom_desc
             , 'MANUL' Report_type
             , '0' OverridePass_Flag
      from dmpdb2.R_WO b      
         , dmpdb2.R_WIP a
         , dmpdb2.R_WIP_LOG c
         , dmpdb2.Station d
         , dmpdb2.line f
      where a.wo_id = b.id
        and a.id = c.wip_id
        and c.station_id = d.id
        and c.line_id = f.id
        and c.station_time >= v_BeginTime
        and c.station_time <  v_EndTime          
        and d.code in('CM', 'MI','1Q','Q1','C4','4C','LE', '5C') --  ,'CM','PK','PN','LE','OQ','RI','RO', 'ST','SS'
        and c.Defect_Flag + 0 = 0
        and b.Category_Key like 'N94%'   
      union all  
      select  /*+rule leading(c,a,b,d,f)  use_nl(c,a,b,d,f)*/
             a.commodity_id, a.id wip_id, a.no wip_no, a.wo_id, b.category_key, b.Is_Msr
             , d.property_01 station_type
             , 'FXGL_' || f.alias_name || '_1_' || d.property_01 as Station_code
             , c.station_time start_time, c.station_time stop_time, 0 is_test_fail
             , '' symptom_code, '' symptom_desc
             , 'MANUL' Report_type
             , '0' OverridePass_Flag
      from dmpdb2.R_WO b      
         , dmpdb2.R_WIP a
         , dmpdb2.R_WIP_LOG_1 c
         , dmpdb2.Station d
         , dmpdb2.line f
      where a.wo_id = b.id
        and a.id = c.wip_id
        and c.station_id = d.id
        and c.line_id = f.id
        and c.station_time >= v_BeginTime
        and c.station_time <  v_EndTime
        and d.code in('CM', 'MI','1Q','Q1','C4','4C','LE', '5C') --  ,'CM','PK','PN','LE','OQ','RI','RO', 'ST','SS'
        and c.Defect_Flag + 0 = 0
        and b.Category_Key like 'N94%' 
      union all------------------------
      select /*+index(c R_REPAIR_TEST_TIME)*/ a.commodity_id, a.id wip_id, a.no wip_no, a.wo_id, b.category_key, b.Is_Msr, d.property_01 station_type
             , 'FXGL_' || f.alias_name || '_1_' || d.property_01 as Station_code
             , c.test_time start_time, c.test_time stop_time, 1 is_test_fail
             , e.namee symptom_code, e.namee symptom_desc
             , 'MANUL' Report_type
             , '0' OverridePass_Flag
      from dmpdb2.R_WIP a
         , dmpdb2.R_WO b
         , dmpdb2.R_Repair c
         , dmpdb2.test_Item d
         , dmpdb2.symptom e
         , dmpdb2.line f
      where a.wo_id = b.id
        and a.id = c.wip_id
        and c.test_item_id = d.id
        and c.symptom_id1 = e.id
        and c.test_line_id = f.id
        and c.test_time >= v_BeginTime
        and c.test_time <  v_EndTime            
        and d.property_01 in(select code from dmpdb2.C_Apple_Station where category_key like 'N94%')  
        and b.Category_Key like 'N94%' 
    )  
    order by start_time, stop_time;    
   --------------------------------------------------  
   FUNCTION get_time_slot(vWorkTime date) RETURN VARCHAR2
   IS
   BEGIN
     return to_char(vWorkTime, 'HH24')  || ':00';
   END;
   
   FUNCTION get_shift_id(vWorkTime date) RETURN int
   IS
      v_begin   VARCHAR2 (10);
      v_end     VARCHAR2 (10);
      v_date    varchar2 (10);
   BEGIN
      v_begin := '07:00';
      v_end := '19:00';
      v_date := to_char(vWorkTime, 'YYYY/MM/DD');
      if vWorkTime >= to_date(v_date || ' ' || v_begin, 'YYYY/MM/DD HH24:MI:SS')
         and vWorkTime < to_date(v_date || ' ' || v_end, 'YYYY/MM/DD HH24:MI:SS') then
        return 1;
      else 
        return 2;
      end if;
   END;  
   
   FUNCTION get_report_date(vWorkTime date) RETURN date
   IS
      v_begin   VARCHAR2 (10);
      v_end     VARCHAR2 (10);
      v_date    varchar2 (10);
   BEGIN
      v_begin := '00:00';
      v_end := '07:00';
      v_date := to_char(vWorkTime, 'YYYY/MM/DD');
      if vWorkTime >= to_date(v_date || ' ' || v_begin, 'YYYY/MM/DD HH24:MI:SS')
         and vWorkTime < to_date(v_date || ' ' || v_end, 'YYYY/MM/DD HH24:MI:SS') then
        return to_date(v_date, 'YYYY/MM/DD') - 1;
      else 
        return to_date(v_date, 'YYYY/MM/DD');
      end if;
   END; 
   
   FUNCTION update_Bobcat_First_Yield(
     vCommodityID int 
     , vWorkTime date
     , vTestLine varchar2
     , vTestStation varchar2
     , vCategoryKey varchar2
     , vWoID number
     , vIsMsr int
     , vDefectFlag int
     , vTestTimes int  
     , vIsOverridePass int
     )
      RETURN VARCHAR2
   AS 
      v_ID                 number;
      v_flag               PLS_INTEGER;
      v_temp_work_date     DATE;
      v_temp_report_date   DATE;
      v_field              VARCHAR2 (50);
      v_sql_block          VARCHAR2 (2000);
      v_msr_flag           VARCHAR2 (50);
      v_TimeSlot           varchar2(10);
      v_ShiftID            int;
      v_OverrideField      varchar2(50);
      v_OverrideQty        varchar2(10);
   BEGIN
      --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'FY_1', cWipno); 
      
      --dbms_output.put_line('update_Bobcat_First_Yield');  
      vFirstYieldCounts := vFirstYieldCounts + 1;  
   
      v_temp_work_date := to_date(to_char(vWorkTime, 'YYYYMMDD'), 'YYYYMMDD');
      --dbms_output.put_line (to_char(v_temp_work_date, 'YYYY-MM-DD'));
      v_temp_report_date := get_report_date(vWorkTime);
      --dbms_output.put_line (to_char(v_temp_report_date, 'YYYY-MM-DD'));
      v_TimeSlot := get_time_slot(vWorkTime);
      --dbms_output.put_line (v_TimeSlot);
      v_ShiftID := get_shift_id(vWorkTime);
      --dbms_output.put_line (v_ShiftID);

      --dbms_output.put_line('update_Bobcat_First_Yield222222');    
      
      v_flag := 0;
       
         --Get r_pdca_FRESH_YIELD  Count

         SELECT /*+index(A_PDCA_FIRST_YIELD IX_A_PDCA_FIRST_)*/ COUNT (*) INTO v_flag
           FROM dmpdb2.A_PDCA_FIRST_YIELD
          WHERE test_line = vTestLine
            AND test_station_code = vTestStation
            AND TIME_SLOT = v_TimeSlot
            AND wo_id = vWoID
            AND work_date = v_temp_work_date
            AND ROWNUM = 1; 
            
        --dbms_output.put_line('update_Bobcat_First_Yield3333333');   
        
        --dbms_output.put_line(v_flag);  
        
        --dbms_output.put_line('aaaaaaa');            
            
         v_msr_flag := '';

         IF vIsMsr = 1 THEN
           v_msr_flag := 'MSR_';
         ELSE
            v_msr_flag := '';
         END IF;

         IF vTestTimes = 1
         THEN
            IF vDefectFlag <> 0                               --Fresh Yeild
            THEN
               v_field := v_msr_flag || 'First_Fail_Qty';               
            ELSE
               v_field := v_msr_flag || 'First_Pass_Qty';
            END IF;
         END IF;

         IF vTestTimes > 1
         THEN                                                   --First Repair
            IF vDefectFlag <> 0
            THEN
               v_field := v_msr_flag || 'Multi_Fail_Qty';
            ELSE
               v_field := v_msr_flag || 'Multi_Pass_Qty';
            END IF;
         END IF;
         
         v_OverrideField := v_msr_flag || 'OVERRIDE_PASS_QTY';
         
         if vIsOverridePass >= 1 then
           v_OverrideQty := '+1'; 
         else
           v_OverrideQty := '+0'; 
         end if;         

         IF v_flag > 0  THEN  
           --dbms_output.put_line('update');            
            v_sql_block :=
                  'BEGIN UPDATE /*+index(A_PDCA_FIRST_YIELD IX_A_PDCA_FIRST_)*/ ' || 'A_PDCA_FIRST_YIELD' 
               ||' set '
               || v_field || ' = ' || v_field || ' + 1 '
               || ',' || v_OverrideField || '=' || v_OverrideField || v_OverrideQty
               || ' WHERE test_line =:1'
               || ' AND test_station_code = :2'
               || ' AND time_slot = :3'
               || ' AND wo_id = :4'
               || ' AND work_date = :5'
               || ';END;';
            --dbms_output.put_line (v_sql_block);
            EXECUTE IMMEDIATE v_sql_block
                        USING vTestLine,
                              vTestStation,
                              v_TimeSlot,
                              vWoID,
                              v_temp_work_date
                              ;
         END IF;

         IF v_flag = 0
         THEN
           --dbms_output.put_line('insert');  
           --dbms_output.put_line('v_OverrideQty ---' || v_OverrideQty);  
            --v_ID := dmpdb2.get_next_id ('A_PDCA_YIELD_FRESH');
            select dmpdb2.A_PDCA_FIRST_YIELD_ID.nextval into v_ID from dual;
            --dbms_output.put_line('A_PDCA_YIELD_FRESH ID ==> ' || v_ID);
            v_sql_block :=
                  'BEGIN INSERT INTO ' || 'A_PDCA_FIRST_YIELD'
               || '(ID, work_date, commodity_id, wo_id,  report_date, test_Line,'
               || 'test_station_code, '
               || 'time_slot, shift_id, category_key,'
               || v_field
               || ',' || v_OverrideField
               || ', Property_05'
               || ')'
               || ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12, :13); END;'
               ;
            --dbms_output.put_line (v_sql_block);
            --dbms_output.put_line (v_ID);
            EXECUTE IMMEDIATE v_sql_block
                        USING v_ID,
                              v_temp_work_date,
                              vCommodityID,
                              vWoID,
                              v_temp_report_date,
                              vTestLine,
                              vTestStation,
                              v_TimeSlot,
                              v_ShiftID,
                              vCategoryKey,
                              1,
                              v_OverrideQty,
                              g_P_id;
         END IF;
         
      --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'FY_2', cwipno);      

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS THEN
         vRet:='ERROR(update_Bobcat_First_Yield):' || SUBSTR(SQLERRM, 1, 500);   
           --dbms_output.put_line(vRet);  
         dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', vRet, 'update_Bobcat_First_Yield');   
         return   vRet ;         
   END;  
   
   FUNCTION update_Bobcat_First_OffSet(
     vCommodityID int 
     , vWorkTime date
     , vTestLine varchar2
     , vTestStation varchar2
     , vCategoryKey varchar2
     , vWoID number
     , vIsMsr int
     , vTestTimes int  
     )
      RETURN VARCHAR2
   AS 
      v_ID                 number;
      v_flag               PLS_INTEGER;
      v_temp_work_date     date;
      v_temp_report_date   date;
      v_TimeSlot           varchar2(10);
      v_Adddate            date;
      v_ShiftID            int;
      v_msr_flag           VARCHAR2 (50);  
      v_sql_block          VARCHAR2 (2000);          
      
      v_PassField          varchar2(50); 
      v_PassQty            varchar2(10);        
      v_FailField          varchar2(50);    
      v_FailQty            varchar2(10);  
      v_RetestField        varchar2(50);    
      v_RetestQty          varchar2(10);         
      v_OverrideField      varchar2(50);
      v_OverrideQty        varchar2(10);
      v_TimeOutField      varchar2(50);
      v_TimeOutQty        varchar2(10);      
   BEGIN
      --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'FO_1', cwipno); 
   
      --dbms_output.put_line('update_Bobcat_First_OffSet'); 
      vFirstOffsetCounts := vFirstOffsetCounts + 1;        
   
      v_temp_work_date := TRUNC (vWorkTime);
      --dbms_output.put_line (v_temp_work_date);
      v_temp_report_date := get_report_date(vWorkTime);
      --dbms_output.put_line (v_temp_report_date);
      v_TimeSlot := get_time_slot(vWorkTime);
      --dbms_output.put_line (v_TimeSlot);
      v_ShiftID := get_shift_id(vWorkTime);
      --dbms_output.put_line (v_ShiftID);
      v_Adddate := to_date(to_char(sysdate, 'YYYY-MM-DD HH24'), 'YYYY-MM-DD HH24');

      v_flag := 0;   
       
         --Get r_pdca_FRESH_YIELD  Count

         SELECT /*+index(A_PDCA_FIRST_OFFSET_YIELD IX_A_PDCA_FIRST_OFFSET_)*/ COUNT (*)
           INTO v_flag
           FROM dmpdb2.A_PDCA_FIRST_OFFSET_YIELD
          WHERE test_line = vTestLine
            AND test_station_code = vTestStation
            AND TIME_SLOT = v_TimeSlot
            AND wo_id = vWoID
            AND work_date = v_temp_work_date
            and Add_date = v_Adddate
            AND ROWNUM = 1;         
            
         v_msr_flag := '';

         IF vIsMsr = 1 THEN
            v_msr_flag := 'MSR_';
         ELSE
            v_msr_flag := '';
         END IF;

         if vTestTimes = 1 then
           v_FailField := v_msr_flag || 'First_Fail_Qty';               
           v_PassField := v_msr_flag || 'First_Pass_Qty';
         else
           v_FailField := v_msr_flag || 'Multi_Fail_Qty';
           v_PassField := v_msr_flag || 'Multi_Pass_Qty';
         end if;
         v_RetestField := v_msr_flag || 'FIRST_RETEST_QTY';
         v_TimeOutField := v_msr_flag || 'TIME_OUT_FAIL_QTY'; 
         v_OverrideField := v_msr_flag || 'OVERRIDE_PASS_QTY'; 
         
         v_PassQty := '+0';
         v_FailQty := '+0';
         v_RetestQty := '+0'; 
         v_TimeOutQty := '+0';
         v_OverrideQty := '+0';    
         
         if iCurTestResult = 1 then
           iCurIsOverridePass := 0;
         end if;   
         
         if iCurIsTimeOutPass = 1 then
           iCurRetestFlag := 0;
         end if;             
         
         if (iPreTestResult <> iCurTestResult) then
           if iPreTestResult = 0 and iCurTestResult = 1 then
             v_PassQty := '-1';
             v_FailQty := '+1';
             if iPreIsOverridePass = 1 then
               v_OverrideQty := '-1';
             end if;
           elsif iPreTestResult = 1 and iCurTestResult = 0 then
             v_PassQty := '+1';
             v_FailQty := '-1';
             if iCurIsOverridePass = 1  then
               v_OverrideQty := '+1';
             end if;             
           end if;
         end if;      
            
         if vTestTimes = 1 then
           if (iPreIsTimeOutPass = 0) and (iCurIsTimeOutPass = 1) then
             v_TimeOutQty := '+1';
           elsif (iPreIsTimeOutPass = 1) and (iCurIsTimeOutPass = 0) then  
             v_TimeOutQty := '-1';
           end if;
           
           if (iPreRetestFlag = 0) and (iCurRetestFlag = 1) then
             v_RetestQty := '+1';
           elsif (iPreRetestFlag = 1) and (iCurRetestFlag = 0) then  
             v_RetestQty := '-1';
             --dbms_output.put_line(cwipno);  
           end if;                      
         end if;  
         
         --dbms_output.put_line('wwwwwwww');  

         IF v_flag > 0  THEN            
            v_sql_block :=
                  'BEGIN UPDATE /*+index(A_PDCA_FIRST_OFFSET_YIELD IX_A_PDCA_FIRST_OFFSET_)*/ ' || 'A_PDCA_FIRST_OFFSET_YIELD' 
               ||' set '
               || v_PassField || '=' || v_PassField ||  v_PassQty   
               || ',' || v_FailField || ' = ' || v_FailField ||  v_FailQty               
               || ',' || v_RetestField || '=' || v_RetestField ||  v_RetestQty
               || ',' || v_TimeOutField || '=' || v_TimeOutField ||  v_TimeOutQty
               || ',' || v_OverrideField || '=' || v_OverrideField ||  v_OverrideQty
               || ' WHERE test_line =:1'
               || '   AND test_station_code = :2'
               || '   AND time_slot = :3'
               || '   AND wo_id = :4'
               || '   AND work_date = :5'
               || '   AND add_date = :6'
               || ';END;';
            ----dbms_output.put_line (g_sql_block);
            EXECUTE IMMEDIATE v_sql_block
                        USING vTestLine,
                              vTestStation,
                              v_TimeSlot,
                              vWoID,
                              v_temp_work_date,
                              v_Adddate;

         else
           --dbms_output.put_line('insert');  
            --v_ID := dmpdb2.get_next_id ('A_PDCA_YIELD_FRESH');
            select dmpdb2.A_PDCA_OFFSET_YIELD_ID.nextval into v_ID from dual;
            --dbms_output.put_line('A_PDCA_YIELD_FRESH ID ==> ' || v_ID);
            v_sql_block :=
                  'BEGIN INSERT INTO ' || 'A_PDCA_FIRST_OFFSET_YIELD'
               || '(ID, work_date, commodity_id, wo_id,  report_date, test_Line,'
               || 'test_station_code, '
               || 'time_slot, shift_id, category_key,'
               || v_PassField
               || ',' || v_FailField
               || ',' || v_RetestField
               || ',' || v_TimeOutField
               || ',' || v_OverrideField
               || ', Add_Date'
               || ', Property_05'
               || ')'
               || ' VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12, :13, :14, :15, :16, :17); END;'
               ;            
            EXECUTE IMMEDIATE v_sql_block
                        USING v_ID,
                              v_temp_work_date,
                              vCommodityID,
                              vWoID,
                              v_temp_report_date,
                              vTestLine,
                              vTestStation,
                              v_TimeSlot,
                              v_ShiftID,
                              vCategoryKey,
                              v_PassQty,
                              v_FailQty,
                              v_RetestQty,
                              v_TimeOutQty,  
                              v_OverrideQty,
                              v_Adddate,
                              g_P_id;
         END IF;
         
      --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'FY_2', cwipno);    

      RETURN g_ok;
   EXCEPTION
      WHEN OTHERS then
         vRet:='ERROR(update_Bobcat_First_OffSet):' || SUBSTR(SQLERRM, 1, 500);   
           --dbms_output.put_line(vRet); 
         dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', vRet, 'update_Bobcat_First_OffSet');      
         return   vRet ;  
   END;     
        
   FUNCTION Bobcat_decode_Symptom(
     vFirstFailDataID number
     , vSymptomCode varchar2
     , vSymptomDesc varchar2
     , vFirstStartTime date
     )
      RETURN VARCHAR2
   AS 
     iTmp1 int;
     iTmp2 int;
     cSymptomCode varchar2(512);
     cSymptomDesc varchar2(512);
     cMyCode varchar2(512);
     cMyDesc varchar2(512);     
   BEGIN
     --dbms_output.put_line('update_Bobcat_First_OffSet');  
     cSymptomCode := vSymptomCode;
     cSymptomDesc := vSymptomDesc;
         
     iTmp1 := instr(cSymptomCode, ';');
     iTmp2 := instr(cSymptomDesc, ';');
     while iTmp1 > 0 loop
       cMyCode := substr(cSymptomCode, 1, iTmp1 - 1);
       if iTmp2 > 0 then
         cMyDesc := substr(cSymptomDesc, 1, iTmp2 - 1); 
         cSymptomDesc := substr(cSymptomDesc, iTmp2 + 1, length(cSymptomDesc) - iTmp2);   
       else
         cMyDesc := cSymptomDesc;
         cSymptomDesc := '';
       end if;
       cSymptomCode := substr(cSymptomCode, iTmp1 +1, length(cSymptomCode) - iTmp1); 
       
       insert into R_PDCA_FIRST_FAIL_DATA_DETAIL(
         ID
         , PDCA_FIRST_FAIL_DATA_ID
         , TEST_ITEM
         , TEST_SYMPTOM
         , ADD_BY
         , ADD_DATE
         , EDIT_BY
         , EDIT_DATE
         , DEL_FLAG
         )
       values(
         R_PDCA_DATA_DETAIL_ID.nextval
         , vFirstFailDataID
         , cMyCode
         , cMyDesc
         , -1
         , vFirstStartTime
         , -1
         , sysdate
         , 0
         );       
        
       iTmp1 := instr(cSymptomCode, ';');
       iTmp2 := instr(cSymptomDesc, ';');
     end loop; 
     
       insert into R_PDCA_FIRST_FAIL_DATA_DETAIL(
         ID
         , PDCA_FIRST_FAIL_DATA_ID
         , TEST_ITEM
         , TEST_SYMPTOM
         , ADD_BY
         , ADD_DATE
         , EDIT_BY
         , EDIT_DATE
         , DEL_FLAG
         )
       values(
         R_PDCA_DATA_DETAIL_ID.nextval
         , vFirstFailDataID
         , cSymptomCode
         , cSymptomDesc
         , -1
         , vFirstStartTime
         , -1
         , sysdate
         , 0
         );     

     RETURN g_ok;
   EXCEPTION
      WHEN OTHERS then
         vRet:='ERROR(Bobcat_decode_Symptom):' || SUBSTR(SQLERRM, 1, 500);   
           --dbms_output.put_line(vRet);    
         dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', vRet, 'Bobcat_decode_Symptom');           
         return   vRet ;  
   END;         
  --------------------------------------------------
begin
  vRet := 'N/A';  

  --dbms_output.put_line('Begin');
  --dTimePoint := to_date('20110321 080000', 'YYYYMMDD HH24MISS');
  --fTimeGenerate := 5/(24*60);
  --dbms_output.put_line('Open cursor_sfc_log1====> ' || to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS'));
  --dbms_output.put_line(cursor_sfc_log%rowcount);  
  
  SELECT to_char(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF') || round(dbms_random.value(1,9)) 
      into g_P_id 
    FROM DUAL;
    
  --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'BEGIN', 'BEGIN');   
       
  vRecortCount := 0; 
  vFirstYieldCounts := 0;
  vFirstOffsetCounts := 0;                       
  for v_Dcs_sal in cursor_DCS_log(vTimeBegin, vTimeEnd) loop
    --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'LOOP1', v_Dcs_sal.Wip_No);   
  
    vRecortCount := vRecortCount + 1;
   
    ------------------------------------------------------
    cTemp := v_Dcs_sal.station_code;
    if (nvl(cTemp, 'N/A') <> 'N/A') then
      iTemp := instr(cTemp, '_');
      cTemp := substr(cTemp, iTemp + 1, length(cTemp));  
      iTemp := instr(cTemp, '_');
      cAppleLine := substr(cTemp, 1, iTemp - 1);  
      cTemp := substr(cTemp, iTemp + 1, length(cTemp));
      iTemp := instr(cTemp, '_');
      cAppleStationNum := substr(cTemp, 1, iTemp - 1); 
    end if;  
    
    cAppleLine := nvl(cAppleLine, 'N/A');
    cAppleStationNum := nvl(cAppleStationNum, 'N/A');
    cFirstTestLine := cAppleLine;
    cFirstTestNum := cAppleStationNum;

    if cAppleLine like '%REP' 
       or cAppleLine like '%RD'
       or cAppleLine like '%QE'
       or cAppleLine like '%CA'
       or cAppleLine like '%IQC'
       or cAppleLine like '%THERMAL' then
      goto continue_here;
    end if;
    ------------------------------------------------------    
    
    cWipNo := v_Dcs_sal.Wip_No; 
    
    cPreReportType := '';   
    iPreTestResult := 0;
    iCurTestResult := 0;
    
    --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'LOOP2', v_Dcs_sal.Wip_No); 
    
    iTestTimes := 1;
    select /*+index(r_repair IX_R_REPAIR_WIP_ID)*/ count(1) into iRepairTimes
      from dmpdb2.R_Repair
      where WIP_ID = v_Dcs_sal.wip_id  
        and Check_In_Time < v_Dcs_sal.stop_time
        and del_flag = 0;
        
    --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'LOOP3', v_Dcs_sal.Wip_No);      
        
    iWipID := v_Dcs_sal.wip_id;  
    --iRepairTimes
    dFirstStartTime := v_Dcs_sal.start_time;
    dFirstStopTime := v_Dcs_sal.stop_time;
    dFirstFailTime := v_Dcs_sal.start_time;
    
    iFirstTestResult := v_Dcs_sal.Is_Test_Fail;
    
    iPreTestResult := 0;
    iPreRetestFlag := 0;
    iPreIsTimeOutPass := 0;
    iPreIsOverridePass := 0;
    cPreReportType := 'AUTO';
    
    iCurTestResult := v_Dcs_sal.Is_Test_Fail;
    iCurRetestFlag := 0;    
    iCurIsTimeOutPass := 0;
    iCurIsOverridePass := 0; 
    if v_Dcs_sal.OverridePass_Flag = '1' then 
      iCurIsOverridePass := 1;
    end if;    
    
    cCurReportType := v_Dcs_sal.Report_Type;       
    cAppleStationCode := v_Dcs_sal.Station_Type;
    
    --------------------------------------------------------------------------
    g_symptomcode2 := '';
    if iCurTestResult = 1 then
      cTemp := v_Dcs_sal.symptom_code;
      iTemp := instr(cTemp, ';');
      if iTemp = 0 then
        g_symptomcode2 := substr(cTemp, 1, 255);
      else      
        if iTemp >= 255 then
          iTemp := iTemp - 1; 
        end if; 
        g_symptomcode2 := substr(cTemp, 1, iTemp - 1);
      end if;      
    end if; 
    ---------------------------------------------------------------------------
    
    if cAppleStationCode in('BURNIN', 'BONFIRE', 'LCD-INSPECT', 'DISPLAY') then
      nTimeOutPeriod := 12;
    else
      nTimeOutPeriod := 5;
    end if;    
    
    --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'LOOP4', v_Dcs_sal.Wip_No);  
     
    select /*+index(r_Pdca_First_Yield_Data IX_R_PDCA_DATA_WIP_NO)*/ count(1) into iFirstTestFlag
      from dmpdb2.r_Pdca_First_Yield_Data
      where wip_no = v_Dcs_sal.wip_no
        --and Repair_Times = iRepairTimes
        and test_station_code = cAppleStationCode;  
        
    --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'LOOP5', v_Dcs_sal.Wip_No);     
        
    if iFirstTestFlag = 0 then
      --dbms_output.put_line('aaaaa');
      cRet := update_Bobcat_first_Yield(v_Dcs_sal.Commodity_Id, dFirstStartTime, cFirstTestLine, cAppleStationCode
                                         , v_Dcs_sal.Category_Key, v_Dcs_sal.Wo_ID, v_Dcs_sal.Is_Msr
                                         , iCurTestResult, iTestTimes, iCurIsOverridePass);       
      insert into dmpdb2.r_Pdca_First_Yield_Data(id, wip_no, wip_id, wo_id, repair_times
                          , first_test_result, test_result, test_start_time, test_stop_time
                          , test_line, test_station_num, test_station_code, retest_flag
                          , is_time_out_fail, is_override_pass, report_type, Test_times
                          , add_by, add_date, edit_by, edit_date, del_flag, property_05)
      values(dmpdb2.R_PDCA_YIELD_DATA_ID.nextval, v_Dcs_sal.wip_no, v_Dcs_sal.wip_id, v_Dcs_sal.wo_id
             , iRepairTimes, iFirstTestResult, iCurTestResult, dFirstStartTime, dFirstStopTime
             , cFirstTestLine, cFirstTestNum, cAppleStationCode, iCurRetestFlag
             , iCurIsTimeOutPass, iCurIsOverridePass, cCurReportType, iTestTimes
             , -1, sysdate, -1, sysdate, 0, g_P_id);
      if iCurTestResult = 1 then
        --dbms_output.put_line('bbbbb');
        select dmpdb2.R_PDCA_FAIL_DATA_ID.nextval into iNewID from dual;
        insert into dmpdb2.R_PDCA_FIRST_FAIL_DATA(id, wip_no, wip_id, wo_id, test_result
                            , repair_times, test_start_time, test_stop_time, test_line
                            , test_station_num, test_station_code, symptom_code, symptom_desc
                            , retest_flag, is_time_out_fail, report_type, is_override_pass, test_times
                            , add_by, add_date, edit_by, edit_date, del_flag, first_fail_time
                            , Property_01)
        values(iNewID, v_Dcs_sal.wip_no, v_Dcs_sal.wip_id, v_Dcs_sal.wo_id
               , iCurTestResult, iRepairTimes, dFirstStartTime, dFirstStopTime, cFirstTestLine
               , cFirstTestNum, cAppleStationCode, v_Dcs_sal.symptom_code, v_Dcs_sal.symptom_desc
               , iCurRetestFlag, iCurIsTimeOutPass, cCurReportType, iCurIsOverridePass, iTestTimes
               , -1, sysdate, -1, sysdate, 0, dFirstFailTime
               , g_symptomcode2);  
        cRet := Bobcat_decode_Symptom(iNewID, v_Dcs_sal.Symptom_Code, v_Dcs_sal.Symptom_Desc, dFirstStartTime);               
      end if;
    else----------------------------------------------------------------------------------------------
      select /*+index(r_Pdca_First_Yield_Data IX_R_PDCA_DATA_WIP_NO)*/
             wo_id, test_start_time, test_stop_time, first_test_result, test_result
             , retest_flag, is_time_out_fail, is_override_pass, Report_Type, Repair_times, nvl(Test_times, 1)
             , test_line, test_station_num
        into iPreWoID, dFirstStartTime, dFirstStopTime, iFirstTestResult, iPreTestResult
             , iPreRetestFlag, iPreIsTimeOutPass, iPreIsOverridePass, cPreReportType, iPreRepairTimes, iTestTimes
             , cFirstTestLine, cFirstTestNum
        from dmpdb2.r_Pdca_First_Yield_Data
        where wip_no = v_Dcs_sal.wip_no
          and ID = (select /*+index(r_Pdca_First_Yield_Data IX_R_PDCA_DATA_WIP_NO)*/
                           max(ID) from dmpdb2.r_Pdca_First_Yield_Data 
                      where wip_no = v_Dcs_sal.wip_no
                        and test_station_code = cAppleStationCode);
          --and Repair_Times = iRepairTimes
          --and test_station_code = cAppleStationCode;
          
      if v_Dcs_sal.Start_Time <= dFirstStartTime then
        goto continue_here;
      end if; 
          
      if (iPreRepairTimes <> iRepairTimes) or (iPreWoID <> v_Dcs_sal.Wo_id) then
        iTestTimes := iTestTimes + 1;
        dFirstStartTime := v_Dcs_sal.start_time;
        dFirstStopTime := v_Dcs_sal.stop_time;   
        iFirstTestResult := v_Dcs_sal.is_test_Fail; 
        cFirstTestLine := cAppleLine;
        cFirstTestNum := cAppleStationNum;
        cRet := update_Bobcat_first_Yield(v_Dcs_sal.Commodity_Id, dFirstStartTime, cFirstTestLine, cAppleStationCode
                                           , v_Dcs_sal.Category_Key, v_Dcs_sal.Wo_ID, v_Dcs_sal.Is_Msr
                                           , iCurTestResult, iTestTimes, iCurIsOverridePass);     
        insert into dmpdb2.r_Pdca_First_Yield_Data(id, wip_no, wip_id, wo_id, repair_times
                            , first_test_result, test_result, test_start_time, test_stop_time
                            , test_line, test_station_num, test_station_code, retest_flag
                            , is_time_out_fail, is_override_pass, report_type, Test_times
                            , add_by, add_date, edit_by, edit_date, del_flag, Property_05)
        values(dmpdb2.R_PDCA_YIELD_DATA_ID.nextval, v_Dcs_sal.wip_no, v_Dcs_sal.wip_id, v_Dcs_sal.wo_id
               , iRepairTimes, iFirstTestResult, iCurTestResult, dFirstStartTime, dFirstStopTime
               , cFirstTestLine, cFirstTestNum, cAppleStationCode, iCurRetestFlag
               , iCurIsTimeOutPass, iCurIsOverridePass, cCurReportType, iTestTimes
               , -1, sysdate, -1, sysdate, 0, g_P_id);
        if iCurTestResult = 1 then
          --dbms_output.put_line('bbbbb');
          select dmpdb2.R_PDCA_FAIL_DATA_ID.nextval into iNewID from dual;
          insert into dmpdb2.R_PDCA_FIRST_FAIL_DATA(id, wip_no, wip_id, wo_id, test_result
                              , repair_times, test_start_time, test_stop_time, test_line
                              , test_station_num, test_station_code, symptom_code, symptom_desc
                              , retest_flag, is_time_out_fail, report_type, is_override_pass, test_times
                              , add_by, add_date, edit_by, edit_date, del_flag, first_fail_time
                              , Property_01)
          values(iNewID, v_Dcs_sal.wip_no, v_Dcs_sal.wip_id, v_Dcs_sal.wo_id
                 , iCurTestResult, iRepairTimes, dFirstStartTime, dFirstStopTime, cFirstTestLine
                 , cFirstTestNum, cAppleStationCode, v_Dcs_sal.symptom_code, v_Dcs_sal.symptom_desc
                 , iCurRetestFlag, iCurIsTimeOutPass, cCurReportType, iCurIsOverridePass, iTestTimes
                 , -1, sysdate, -1, sysdate, 0, dFirstFailTime
                 , g_symptomcode2);  
          cRet := Bobcat_decode_Symptom(iNewID, v_Dcs_sal.Symptom_Code, v_Dcs_sal.Symptom_Desc, dFirstStartTime);               
        end if;
      else ---------------------repeat test------------------------------------------------------
        if (iPreTestResult = 1) and (iCurTestResult = 0) then
          --dbms_output.put_line(v_Dcs_sal.wip_no);
          --dbms_output.put_line(v_Dcs_sal.station_type);
          --dbms_output.put_line(to_char(dFirstStartTime, 'YYYY-MM-DD HH24:MI:SS'));
          --dbms_output.put_line(to_char(v_Dcs_sal.start_time, 'YYYY-MM-DD HH24:MI:SS'));
          --dbms_output.put_line(iPreTestResult);  
          select /*+index(r_Pdca_First_Fail_Data IX_R_PDCA_FAIL_DATA_WIP_NO)*/
                 nvl(First_Fail_Time, test_Start_Time) into dFirstFailTime
            from dmpdb2.r_Pdca_First_Fail_Data
            where wip_no = v_Dcs_sal.wip_no
              and ID = (select /*+index(r_Pdca_First_Fail_Data IX_R_PDCA_FAIL_DATA_WIP_NO)*/
                                   max(ID) from dmpdb2.r_Pdca_First_Fail_Data 
                              where wip_no = v_Dcs_sal.wip_no
                                and test_station_code = cAppleStationCode);          
                
          if ((v_Dcs_sal.start_time - dFirstFailTime)*24 >= nTimeOutPeriod) then
            --iCurTestResult := iPreTestResult;
            iCurIsTimeOutPass := 1;
          else
            --dbms_output.put_line(cPreReportType);
            if (nvl(cPreReportType, 'AUTO') = 'AUTO') then
              iCurRetestFlag := 1;
            else
              iCurTestResult := iPreTestResult;
            end if;
          end if;
          --dbms_output.put_line(iCurTestResult);
          --dbms_output.put_line(iCurRetestFlag);
        end if;
      
        if (iPreTestResult <> iCurTestResult) or (iCurIsTimeOutPass = 1) then
          cRet := update_Bobcat_first_Offset(v_Dcs_sal.Commodity_Id, dFirstStartTime, cFirstTestLine, cAppleStationCode
                                             , v_Dcs_sal.Category_Key, v_Dcs_sal.Wo_ID, v_Dcs_sal.Is_Msr, iTestTimes);         
          update /*+index(r_Pdca_First_Yield_Data IX_R_PDCA_DATA_WIP_NO)*/ dmpdb2.r_Pdca_First_Yield_Data 
            set test_result = iCurTestResult, report_type = cCurReportType
              , retest_flag = iCurRetestFlag, is_time_out_fail = iCurIsTimeOutPass
              , is_override_pass = iCurIsOverridePass 
              , edit_date = sysdate
            where wip_no = v_Dcs_sal.wip_no
              and wip_id = v_Dcs_sal.wip_id
              and Repair_Times = iRepairTimes
              and test_station_code = cAppleStationCode;
        end if;
      
        if iPreTestResult = 0 and iCurTestResult = 1 then
          select /*+index(r_Pdca_First_Fail_Data IX_R_PDCA_FAIL_DATA_WIP_NO)*/
                 count(1) into iRecordCount
            from dmpdb2.R_PDCA_FIRST_FAIL_DATA
            where wip_no = v_Dcs_sal.wip_no
              and wip_id = v_Dcs_sal.wip_id
              and Repair_Times = iRepairTimes
              and test_station_code = cAppleStationCode;
          if iRecordCount = 0 then
            select dmpdb2.R_PDCA_FAIL_DATA_ID.nextval into iNewID from dual;
            insert into dmpdb2.R_PDCA_FIRST_FAIL_DATA(id, wip_no, wip_id, wo_id, test_result
                                , repair_times, test_start_time, test_stop_time, test_line
                                , test_station_num, test_station_code, symptom_code, symptom_desc
                                , retest_flag, is_time_out_fail, report_type, is_override_pass, Test_times
                                , add_by, add_date, edit_by, edit_date, del_flag, first_fail_time
                                , Property_01)
            values(iNewID, v_Dcs_sal.wip_no, v_Dcs_sal.wip_id, v_Dcs_sal.wo_id
                   , iCurTestResult, iRepairTimes, dFirstStartTime, dFirstStopTime, cFirstTestLine
                   , cFirstTestNum, cAppleStationCode, v_Dcs_sal.symptom_code, v_Dcs_sal.symptom_desc
                   , iCurRetestFlag, iCurIsTimeOutPass, cCurReportType, iCurIsOverridePass, iTestTimes
                   , -1, sysdate, -1, sysdate, 0, dFirstFailTime
                   , g_symptomcode2);
            cRet := Bobcat_decode_Symptom(iNewID, v_Dcs_sal.Symptom_Code, v_Dcs_sal.Symptom_Desc, dFirstStartTime);
          else
            update /*+index(r_Pdca_First_Fail_Data IX_R_PDCA_FAIL_DATA_WIP_NO)*/ dmpdb2.R_PDCA_FIRST_FAIL_DATA 
              set test_result = iCurTestResult, report_type = cCurReportType
                , retest_flag = iCurRetestFlag, is_time_out_fail = iCurIsTimeOutPass
                , is_override_pass = iCurIsOverridePass
                , edit_date = sysdate
              where wip_no = v_Dcs_sal.wip_no
                and wip_id = v_Dcs_sal.wip_id
                and Repair_Times = iRepairTimes
                and test_station_code = cAppleStationCode;
          end if;
          -------------------
        elsif (iPreTestResult <> iCurTestResult) or (iCurIsTimeOutPass = 1) then
          update /*+index(r_Pdca_First_Fail_Data IX_R_PDCA_FAIL_DATA_WIP_NO)*/ dmpdb2.R_PDCA_FIRST_FAIL_DATA 
            set test_result = iCurTestResult, report_type = cCurReportType
              , retest_flag = iCurRetestFlag, is_time_out_fail = iCurIsTimeOutPass
              , is_override_pass = iCurIsOverridePass
              , edit_date = sysdate
            where wip_no = v_Dcs_sal.wip_no
              and wip_id = v_Dcs_sal.wip_id
              and Repair_Times = iRepairTimes
              and test_station_code = cAppleStationCode;
        end if;      
      end if;      
    end if; -------multi 
    
    --dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', 'LOOP6', v_Dcs_sal.Wip_No); 

    <<continue_here>> -----  
    commit; 
  end loop;  

  vRet := g_OK;
exception
  WHEN OTHERS THEN begin
    --update C_PDCA_LOG set property_01 = iLogID
    --  where ID = vScheduleID;
    vRet:='ERROR(SP_PDCA_Yield_First):' || SUBSTR(SQLERRM, 1, 255) || '===' || cWipNo;   
    --dbms_output.put_line(vRet); 
    dmpdb2.write_bob_log(g_P_id, 'sp_pdca_yield_first', '0', vRet, 'SP_PDCA_Yield_First');      
  end;
end;



-----------------------------------------------------------------------------------------------------------------------------------------------


/

