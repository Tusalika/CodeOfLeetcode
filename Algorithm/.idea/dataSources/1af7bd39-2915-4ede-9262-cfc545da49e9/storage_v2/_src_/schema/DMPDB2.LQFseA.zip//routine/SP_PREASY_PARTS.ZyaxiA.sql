create PROCEDURE        sp_preasy_parts (
   cCategory            VARCHAR2,
   cserialnoA           VARCHAR2,
   cserialnoB           VARCHAR2,
   iIfDelrecord         NUMBER,
   cOpid                VARCHAR2,
   cLine_id             NUMBER,
   clocation_id         NUMBER,
   cReason              VARCHAR2,
   cp1                  VARCHAR2,                                 
   cp2                  VARCHAR2,                                
   cp3                  VARCHAR2,                                
   cp4                  VARCHAR2,                        
   cp5                  VARCHAR2,
   cp6                  VARCHAR2,
   cp7                  VARCHAR2,
   cp8                  VARCHAR2,
   cp9                  VARCHAR2,
   cp10                 VARCHAR2,
   ieditby              VARCHAR2,
   cmsg           OUT   VARCHAR2
)
AS
   icount   NUMBER;
BEGIN
   IF iIfDelrecord = 0
   THEN
      SELECT COUNT (PARTS_A)
        INTO icount
        FROM dmpdb2.R_PREASY_PARTS
       WHERE PARTS_A = cserialnoA
         AND PARTS_B = cserialnoB
         AND del_flag = 0;

      IF icount > 0
      THEN
         cmsg := '00: 物料組裝記錄已存在';
      ELSE
         INSERT INTO dmpdb2.R_PREASY_PARTS
                     (CATEGORY_KEY,PARTS_A,PARTS_B,SCAN_TIME,OPID,Line_ID,Location_ID,
                     PROPERTY_01,PROPERTY_02,PROPERTY_03,PROPERTY_04,PROPERTY_05,PROPERTY_06,
                     PROPERTY_07,PROPERTY_08,PROPERTY_09,PROPERTY_10,ADD_BY,ADD_DATE,EDIT_BY,EDIT_DATE,DEL_FLAG
                     )
              VALUES (cCategory, cserialnoA, cserialnoB, sysdate, cOpid,
                      cLine_id, clocation_id, cp1, cp2, cp3,
                      cp4, cp5, cp6, cp7, cp8, cp9, cp10, ieditby, SYSDATE, ieditby, SYSDATE, 0 
                     );

         cmsg := '00: 物料組裝記錄成功';
      END IF;
   ELSE
      SELECT COUNT (PARTS_A)
        INTO icount
        FROM dmpdb2.R_PREASY_PARTS
       WHERE PARTS_A = cserialnoA
--         AND PARTS_B = cserialnoB
         AND del_flag = 0;

      IF icount > 0
      THEN                                                    
         UPDATE dmpdb2.R_PREASY_PARTS
            SET del_flag = 1,
                edit_by = ieditby,
                edit_date = SYSDATE,
                property_01 = cReason,
                property_02 = cp2,
                property_03 = cp3,
                property_04 = cp4,
                property_05 = cp5
          WHERE PARTS_A = cserialnoA
--            AND PARTS_B = cserialnoB
            AND del_flag = 0;

         cmsg := '00: 預組裝物料刪除成功';
      ELSE
         cmsg := '00: 沒有預組裝記錄不需要刪除';
      END IF;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := '02: 物料預組裝更新失敗' || SUBSTR (SQLERRM, 1, 200);
END;

/

