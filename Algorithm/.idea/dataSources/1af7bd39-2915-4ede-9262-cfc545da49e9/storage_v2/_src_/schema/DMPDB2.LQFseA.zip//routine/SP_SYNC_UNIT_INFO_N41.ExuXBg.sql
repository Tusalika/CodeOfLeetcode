create PROCEDURE        SP_SYNC_UNIT_INFO_N41(
vTimeBegin in date
, vTimeEnd in date
, vRecortCount out number
, vRet out varchar2
)
as
 g_ok CONSTANT VARCHAR2(2) := 'OK';
 cWipNo varchar2(20);
 
/* cursor Cur_WIP1(dBegin in date, dEnd in date) is
  select b.wo_id, b.wo_no, b.id Wip_ID, b.no Wip_no, a.category_key, a.cust_part_No, a.sku_No
         , b.input_time, b.finish_time, b.finish_flag
         , a.is_rework, a.Is_Msr, b.Property_15 imei_code, b.property_26 meid_code, nvl(c.Property_04, 'N/A') floor_name
         , a.Property_14 telecom_code, b.del_flag
         , sysdate add_date, sysdate edit_date
    from dmpdb2.R_WO a
       , dmpdb2.R_Wip b
       , dmpdb2.line c
    where a.id = b.wo_id
      and b.line_id = c.id
      and b.input_time >= dBegin
      and b.input_time <  dEnd  
      and a.category_key like 'N94%';*/
      
 cursor Cur_WIP2(dBegin in date, dEnd in date) is
   select b.ID WIP_ID, b.NO WIP_NO, b.Input_Time, b.Finish_Flag, b.Finish_Time, b.Del_Flag 
     from dmpdb2.r_wo a
        , dmpdb2.r_wip b
     where a.id = b.wo_id
       and b.Finish_Time >= dBegin
       and b.Finish_Time <  dEnd
       and (a.category_key like 'N41%' or a.category_key like 'N42%')
       ;        
begin
  --cScheduleCode := 'SYNC_UNIT_INFO';--
  vRecortCount := 0;
  
/*  for My_Val in Cur_WIP1(vTimeBegin, vTimeEnd) loop  
    cWipNo := My_Val.wip_no;
    vRecortCount := vRecortCount + 1;
  */  
  --  delete /*+Index(R_Unit_info R_UNIT_INFO_WIP_ID)*/ from gbcdmp2_dmpdb2.R_Unit_info@zz_bob_report_lk
  --    where wip_id = My_Val.Wip_ID;
/*      
    insert into gbcdmp2_dmpdb2.R_Unit_info@zz_bob_report_lk
      (wo_id, wo_no, wip_id, wip_no, category_key, cust_part_no, sku_no, input_time
       , finish_time, finish_flag, is_rework, is_msr, imei_code, meid_code, floor_name
       , telecom_code, del_flag, add_date, edit_date) 
    values(My_Val.Wo_id, My_Val.Wo_no, My_Val.wip_id, My_Val.wip_no, My_Val.category_key, My_Val.cust_part_no
       , My_Val.sku_no, My_Val.input_time, My_Val.finish_time, My_Val.finish_flag, My_Val.is_rework, My_Val.is_msr
       , My_Val.imei_code, My_Val.meid_code, My_Val.floor_name, My_Val.telecom_code, My_Val.del_flag
       , My_Val.add_date, My_Val.edit_date);    

    commit;
  end loop;  
*/
  insert into zbcdmp2_dmpdb2.R_U_info_n41@zz_bob_report_lk
      (wo_id, wo_no, wip_id, wip_no, category_key, cust_part_no, sku_no, input_time
       , finish_time, finish_flag, is_rework, is_msr, imei_code, meid_code, floor_name
       , telecom_code, del_flag, add_date, edit_date, Repair_Times) 
  select b.wo_id, b.wo_no, b.id, b.no, a.category_key, a.cust_part_No, a.sku_No
         , b.input_time, b.finish_time, b.finish_flag
         , a.is_rework, a.Is_Msr, b.Property_15, b.property_26, nvl(c.Property_04, 'N/A')
         , a.Property_14, b.del_flag
         , sysdate, sysdate
         , 0
    from dmpdb2.R_WO a
       , dmpdb2.R_Wip b
       , dmpdb2.line c
    where a.id = b.wo_id
      and b.line_id = c.id
      and b.input_time >= vTimeBegin - 1/(24*60)
      and b.input_time <  vTimeEnd  
      and (a.category_key like 'N41%' or a.category_key like 'N42%')
      and not exists(select /*+index(R_U_info_n41 IX_INFO_N41_WIP_ID)*/ 1 from zbcdmp2_dmpdb2.r_u_info_n41@zz_bob_report_lk where wip_id = b.id);  
  
  vRecortCount := vRecortCount + sql%rowcount;  
  
  commit;
  
  for My_Val in Cur_WIP2(vTimeBegin, vTimeEnd) loop
    cWipNo := My_Val.wip_no;
    vRecortCount := vRecortCount + 1;

    update /*+Index(R_U_info_n41 IX_INFO_N41_WIP_ID)*/ zbcdmp2_dmpdb2.R_U_info_n41@zz_bob_report_lk
      set Finish_Flag = My_Val.Finish_Flag, Finish_Time = My_Val.Finish_Time, Del_Flag = My_Val.Del_Flag
      where wip_id = My_Val.Wip_id;
  end loop; 
   
  commit;  
  
  vRet := g_OK;
exception
  WHEN OTHERS THEN begin
    vRet := 'SP_SYNC_UNIT_INFO_N41:' || SUBSTR(SQLERRM, 1, 255);   
    dmpdb2.write_bob_log('SP_SYNC_UNIT_INFO_N41', 'SP_SYNC_UNIT_INFO_N41', '1', vRet, cWipNo);      
  end;
end;


/

