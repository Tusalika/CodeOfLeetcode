create PROCEDURE        SP_SYNC_UNIT_Log_N94(
vTimeBegin in date
, vTimeEnd in date
, vRecortCount out number
, vRet out varchar2
)
as
 g_ok CONSTANT VARCHAR2(2) := 'OK';
begin
  --cScheduleCode := 'SYNC_UNIT_INFO';--
  vRecortCount := 0; 
  
    insert into zbcdmp2_dmpdb2.R_Unit_log@zz_bob_report_lk(wo_id, wo_no, wip_id, wip_no, category_key, cust_part_no, sku_no
       , is_rework, is_msr, station_time, line_code, line_pdca_name, station_code, station_pdca_name
       , defect_flag, fresh_flag, del_flag)
    select /*+rule*/b.wo_id, b.wo_no, b.id, b.no, a.category_key, a.cust_part_No, a.sku_No
         , a.is_rework, a.is_msr, d.station_time
         , c.code, nvl(c.Alias_name, 'N/A'), e.code, nvl(e.property_01, 'N/A')
         , d.defect_flag, d.fresh_flag, d.del_flag
    from dmpdb2.R_WO a
       , dmpdb2.R_Wip b
       , dmpdb2.r_wip_log_1 d
       , dmpdb2.line c
       , dmpdb2.station e
    where a.id = b.wo_id      
      and b.id = d.wip_id
      and d.line_id = c.id
      and d.station_id = e.id
      and d.station_time >= vTimeBegin
      and d.station_time <  vTimeEnd  
      and (a.category_key like 'N94%' or a.category_key like 'N41%')
      and e.code in('CM', 'MI','1Q','Q1','C4','4C','LE', '5C', 'FG', 'FH', 'FK', 'FB'); 
      
   vRecortCount := vRecortCount + sql%rowcount;  
      
    insert into zbcdmp2_dmpdb2.R_Unit_log@zz_bob_report_lk(wo_id, wo_no, wip_id, wip_no, category_key, cust_part_no, sku_no
       , is_rework, is_msr, station_time, line_code, line_pdca_name, station_code, station_pdca_name
       , defect_flag, fresh_flag, del_flag)
    select /*+rule*/b.wo_id, b.wo_no, b.id, b.no, a.category_key, a.cust_part_No, a.sku_No
         , a.is_rework, a.is_msr, d.station_time
         , c.code, nvl(c.Alias_name, 'N/A'), e.code, nvl(e.property_01, 'N/A')
         , d.defect_flag, d.fresh_flag, d.del_flag
    from dmpdb2.R_WO a
       , dmpdb2.R_Wip b
       , dmpdb2.r_wip_log d
       , dmpdb2.line c
       , dmpdb2.station e
    where a.id = b.wo_id      
      and b.id = d.wip_id
      and d.line_id = c.id
      and d.station_id = e.id
      and d.station_time >= vTimeBegin
      and d.station_time <  vTimeEnd  
      and (a.category_key like 'N94%' or a.category_key like 'N41%')
      and e.code in('CM', 'MI','1Q','Q1','C4','4C','LE', '5C', 'FG', 'FH', 'FK', 'FB');       
   
   vRecortCount := vRecortCount + sql%rowcount;   
   
  commit; 
   
  vRet := g_OK;
exception
  WHEN OTHERS THEN begin
    vRet := 'SP_SYNC_UNIT_Log_N94:' || SUBSTR(SQLERRM, 1, 255);   
    dmpdb2.write_bob_log('SP_SYNC_UNIT_LOG_N94', 'SP_SYNC_UNIT_LOG_N94', '1', vRet, 'SP_SYNC_UNIT_LOG_N94');      
  end;
end;


/

