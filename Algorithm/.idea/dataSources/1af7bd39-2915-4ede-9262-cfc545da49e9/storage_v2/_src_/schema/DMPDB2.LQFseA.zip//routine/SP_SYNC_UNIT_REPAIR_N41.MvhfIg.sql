create PROCEDURE        SP_SYNC_UNIT_REPAIR_N41(
vTimeBegin in date
, vTimeEnd in date
, vRecortCount out number
, vRet out varchar2
)
as
 g_ok CONSTANT VARCHAR2(2) := 'OK';
 cWipNo varchar2(20);
 
  cursor Cur_WIP1(dBegin in date, dEnd in date) is
    select /*+rule*/d.id Repair_ID, b.wo_id, b.wo_no, b.id WIP_ID, b.no wip_no, a.category_key, a.cust_part_No, a.sku_No
           , a.is_rework, a.is_msr, c.code line_code, nvl(c.Alias_name, 'N/A') line_pdca_name
           , e.code station_code, nvl(e.property_01, 'N/A') station_pdca_name
           , d.repair_times, f.code Item_code, nvl(f.property_01, 'N/A') item_pdca_name
           , g.code symptom_code, nvl(g.namee, 'N/A') symptom_name
           , d.test_time, d.check_in_time, d.Repair_Time, d.check_out_time, d.del_flag
      from dmpdb2.R_WO a
         , dmpdb2.R_Wip b
         , dmpdb2.R_Repair d
         , dmpdb2.line c
         , dmpdb2.station e
         , dmpdb2.test_item f
         , dmpdb2.symptom g
      where a.id = b.wo_id      
        and b.id = d.wip_id
        and d.test_line_id = c.id
        and d.test_station_id = e.id
        and d.test_item_id = f.id
        and d.symptom_id1 = g.id
        and d.test_time >= dBegin
        and d.test_time <  dEnd  
        and (a.category_key like 'N41%' or a.category_key like 'N42%');
      
 cursor Cur_WIP2(dBegin in date, dEnd in date) is
   select /*+rule*/ d.id repair_id, d.wip_id, b.no wip_no, d.repair_times, d.test_time, d.check_in_time
          , d.repair_time, d.check_out_time, d.del_flag
     from dmpdb2.r_wo a
        , dmpdb2.R_wip b
        , dmpdb2.R_Repair d       
     where a.id = b.wo_id
       and b.id = d.wip_id
       and d.check_in_time >= dBegin
       and d.check_in_time <  dEnd
       and (a.category_key like 'N41%' or a.category_key like 'N42%');   
       
 cursor Cur_WIP3(dBegin in date, dEnd in date) is
   select /*+rule*/ d.id repair_id, d.wip_id, b.no wip_no, d.repair_times, d.test_time, d.check_in_time
          , d.repair_time, d.check_out_time, d.del_flag
     from dmpdb2.r_wo a
        , dmpdb2.R_wip b
        , dmpdb2.R_Repair d       
     where a.id = b.wo_id
       and b.id = d.wip_id
       and d.check_out_time >= dBegin
       and d.check_out_time <  dEnd
       and (a.category_key like 'N41%' or a.category_key like 'N42%');     
            
begin
  --cScheduleCode := 'SYNC_UNIT_INFO';--
  vRecortCount := 0;
  
  for My_Val in Cur_WIP1(vTimeBegin, vTimeEnd) loop  
    cWipNo := My_Val.wip_no;
    vRecortCount := vRecortCount + 1;
    
    delete /*+index(R_Unit_Repair IX_REPAIR_N41_WIP_ID)*/ from zbcdmp2_dmpdb2.R_U_REPAIR_N41@zz_bob_report_lk
      where wip_id = My_Val.Wip_ID
        and test_times = My_Val.Repair_Times;
      
    insert into zbcdmp2_dmpdb2.R_U_REPAIR_N41@zz_bob_report_lk(repair_id, wo_id, wo_no, wip_id, wip_no
        , category_key, cust_part_no, sku_no, is_rework, is_msr
        , line_code, line_pdca_name, station_code, station_pdca_name, test_times
        , item_code, item_pdca_name, symptom_code, symptom_name
        , test_time, check_in_time, repair_time, check_out_time, del_flag)
      values(My_Val.repair_id, My_Val.wo_id, My_Val.wo_no, My_Val.wip_id, My_Val.wip_no
        , My_Val.category_key, My_Val.cust_part_no, My_Val.sku_no, My_Val.is_rework, My_Val.is_msr
        , My_Val.line_code, My_Val.line_pdca_name, My_Val.station_code, My_Val.station_pdca_name, My_Val.repair_times
        , My_Val.item_code, My_Val.item_pdca_name, My_Val.symptom_code, My_Val.symptom_name
        , My_Val.test_time, My_Val.check_in_time, My_Val.Repair_time, My_Val.check_out_time, My_Val.del_flag);
        
    update zbcdmp2_dmpdb2.R_U_Info_N41@zz_bob_report_lk
      set Repair_Times = My_Val.repair_times, Last_repair_time = My_Val.test_time
      where wip_id = My_Val.wip_id;
    
    --commit;
  end loop;  
  
  for My_Val in Cur_WIP2(vTimeBegin, vTimeEnd) loop
    cWipNo := My_Val.wip_no;
    vRecortCount := vRecortCount + 1;

    update /*+index(R_U_REPAIR_N41 IX_R_U_REPAIR_N41_WIP_ID)*/ zbcdmp2_dmpdb2.R_U_REPAIR_N41@zz_bob_report_lk
      set check_in_time = My_Val.check_in_time, repair_time = My_Val.Repair_time
        , check_out_time = My_Val.check_out_time, Del_Flag = My_Val.Del_Flag
      where wip_id = My_Val.Wip_id
        and test_times = My_Val.repair_times;
        
    update zbcdmp2_dmpdb2.R_U_Info_N41@zz_bob_report_lk
      set Last_repair_time = My_Val.check_in_time
      where wip_id = My_Val.wip_id;        
      
    --commit;  
  end loop;  
  
  for My_Val in Cur_WIP3(vTimeBegin, vTimeEnd) loop
    cWipNo := My_Val.wip_no;
    vRecortCount := vRecortCount + 1;

    update /*+index(R_U_REPAIR_N41 IX_REPAIR_N41_WIP_ID)*/ zbcdmp2_dmpdb2.R_U_REPAIR_N41@zz_bob_report_lk
      set repair_time = My_Val.Repair_time
        , check_out_time = My_Val.check_out_time, Del_Flag = My_Val.Del_Flag
      where wip_id = My_Val.Wip_id
        and test_times = My_Val.repair_times;
        
    update zbcdmp2_dmpdb2.R_U_Info_N41@zz_bob_report_lk
      set Last_repair_time = My_Val.check_out_time
      where wip_id = My_Val.wip_id;           
      
    --commit;  
  end loop;
  
  commit;    
  
  vRet := g_OK;
exception
  WHEN OTHERS THEN begin
    vRet := 'SP_SYNC_UNIT_REPAIR_N41:' || SUBSTR(SQLERRM, 1, 255);   
    dmpdb2.write_bob_log('SP_SYNC_UNIT_REPAIR_N41', 'SP_SYNC_UNIT_REPAIR_N41', '1', vRet, cWipNo);      
  end;
end;


/

