create PROCEDURE        sp_updatebluetag (
   cserialno         VARCHAR2,
   cflag             VARCHAR2,
   cstepcode         VARCHAR2,
   ceditby           VARCHAR2,
   cmsg        OUT   VARCHAR2
)
AS
   g_llost   BOOLEAN;
   g_lscan   BOOLEAN;

/**************  For Checking LB_LOST  *********************************************/
   FUNCTION checklblost
      RETURN BOOLEAN
   AS
      v_clostno   VARCHAR2 (80);
   BEGIN
      SELECT lost_nal
        INTO v_clostno
        FROM dmpdb2.lb_lost
       WHERE lost_nal = cserialno AND is_acti = 'L';

      cmsg := '02:該序列號已申請丟失';
      RETURN FALSE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN TRUE;
      WHEN OTHERS
      THEN
         cmsg := '02:ERROR: LB_LOST CHECK FAIL';
         RETURN FALSE;
   END;

/****************************************************************************************/
   FUNCTION checklbscan
      RETURN BOOLEAN
   AS
      v_csfc    VARCHAR2 (20);
      v_cacti   VARCHAR2 (20);
   BEGIN
      SELECT is_sfc, is_acti
        INTO v_csfc, v_cacti
        FROM dmpdb2.lb_scan
       WHERE nal_sn = cserialno AND stage_id = 'S004';

      IF v_csfc = 'Y'
      THEN
         cmsg := '02:該序列號已使用過';
         RETURN FALSE;
      ELSIF v_cacti <> 'Y'
      THEN
         cmsg := '02:該序列號不可用';
         RETURN FALSE;
      ELSIF v_csfc = 'S'
      THEN
         cmsg := '02:該序列號已報廢';
         RETURN FALSE;
      ELSIF v_csfc = 'N'
      THEN
         RETURN TRUE;
      ELSE
         cmsg := '02:未知的序列號狀態';
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         cmsg := '02:藍標系統不存在該序列號或是上一工站非SOO4';
         RETURN FALSE;
      WHEN OTHERS
      THEN
         cmsg := '02:ERROR: LB_SCAN CHECK FAIL';
         RETURN FALSE;
   END;
/*******  Main  *********************************************************/
BEGIN
   g_llost := checklblost;
   g_lscan := checklbscan;

   IF g_llost AND g_lscan
   THEN
      UPDATE dmpdb2.lb_scan
         SET is_sfc = cflag,
             stage_id = cstepcode,
             user_id = ceditby
       WHERE nal_sn = cserialno AND stage_id = 'S004';

      cmsg := '00:藍標回寫成功';
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      cmsg := '02:藍標回寫失敗' || SUBSTR (SQLERRM, 1, 200);
END;

/

