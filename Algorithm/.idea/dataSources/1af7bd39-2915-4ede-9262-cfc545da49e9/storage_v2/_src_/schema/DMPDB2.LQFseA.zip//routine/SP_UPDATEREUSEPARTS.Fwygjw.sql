create PROCEDURE        sp_updatereuseparts (
   cserialno          VARCHAR2,
   cpartname          VARCHAR2,
   ireuseflag         NUMBER,
   ieditby            NUMBER,
   cp4                VARCHAR2,
   cmsg         OUT   VARCHAR2
)
AS
   icount   NUMBER;
BEGIN
   SELECT COUNT (serial_no)
     INTO icount
     FROM dmpdb2.r_reuse_parts
    WHERE serial_no = cserialno
      AND part_name = cpartname
      AND reuse_flag = 0
      AND del_flag = 0;

   IF icount > 0
   THEN
      UPDATE dmpdb2.r_reuse_parts
         SET reuse_flag = ireuseflag,
             property_04 = cp4,
             edit_by = ieditby,
             edit_date = SYSDATE
       WHERE serial_no = cserialno
         AND part_name = cpartname
         AND reuse_flag = 0
         AND del_flag = 0;

      cmsg := '00:Reuse 物料可用性更新成功';
   ELSE
      cmsg := '00:Reuse 物料無記錄';
   END IF;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      cmsg := '02:Reuse 物料無記錄x';
   WHEN OTHERS
   THEN
      cmsg := '02:Reuse 物料可用性更新失敗' || SUBSTR (SQLERRM, 1, 200);
END;

/

