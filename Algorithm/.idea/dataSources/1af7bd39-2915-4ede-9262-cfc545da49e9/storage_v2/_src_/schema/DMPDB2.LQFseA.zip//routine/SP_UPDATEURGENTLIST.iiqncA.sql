create PROCEDURE        SP_UPDATEURGENTLIST (
   cGbFloor       VARCHAR2,
   cFgFloor       VARCHAR2,
   cMpn           VARCHAR2,
   iQty           NUMBER,
   iFlag          NUMBER,           -- 0: SUM Insert;  1: SUM Decrease;  2: LIST Insert
   cMsg       OUT VARCHAR2)
AS
    iTotal NUMBER;
    iSumID NUMBER;
    iSumQty NUMBER;
BEGIN
    iTotal := iQty;
    IF iTotal <= 0 THEN
        cMsg := 'sp_updateurgentlist error: iQty error: ' || To_CHAR(iTotal);        
        GOTO end_of_function;
    END IF;

    IF iFlag = 0 THEN    
        SELECT ID, TARGET_QTY - OUTPUT_QTY QTY INTO iSumID, iSumQty FROM DMPDB2.R_URGENT_SUM WHERE GB_FLOOR = cGbFloor AND FG_FLOOR = cFgFloor AND MPN = cMpn AND DEL_FLAG = 0;
        IF iSumQty <= iTotal THEN
            UPDATE DMPDB2.R_URGENT_SUM SET OUTPUT_QTY = OUTPUT_QTY + iTotal, IS_CLOSE = 1, EDIT_DATE = sysdate WHERE ID = iSumID;
        ELSE 
            UPDATE DMPDB2.R_URGENT_SUM SET OUTPUT_QTY = OUTPUT_QTY + iTotal, IS_CLOSE = 0, EDIT_DATE = sysdate WHERE ID = iSumID;        
        END IF;
        cMsg := 'OK';
        
    ELSIF iFlag = 1 THEN
        SELECT ID, OUTPUT_QTY INTO iSumID, iSumQty FROM DMPDB2.R_URGENT_SUM WHERE GB_FLOOR = cGbFloor AND FG_FLOOR = cFgFloor AND MPN = cMpn AND DEL_FLAG = 0;
        IF iSumQty >= iTotal THEN
            UPDATE DMPDB2.R_URGENT_SUM SET OUTPUT_QTY = OUTPUT_QTY - iTotal, IS_CLOSE = 0, EDIT_DATE = sysdate WHERE ID = iSumID;
            UPDATE DMPDB2.R_URGENT_SUM SET IS_CLOSE = 1 WHERE ID = iSumID AND OUTPUT_QTY >= TARGET_QTY;
            cMsg := 'OK';            
        ELSE 
            cMsg := 'sp_updateurgentlist error: Error Qty: Output Qty less than Carton Qty';     
        END IF;
    ELSIF iFlag = 2 THEN
        FOR R IN (  SELECT ID, TARGET_QTY - OUTPUT_QTY QTY FROM DMPDB2.R_URGENT_LIST WHERE GB_FLOOR = cGbFloor AND FG_FLOOR = cFgFloor AND MPN = cMpn AND IS_CLOSE = 0 AND DEL_FLAG = 0 ORDER BY FG_FLOOR_LEVEL ASC, ID ASC)
        LOOP
            IF iTotal >= R.QTY THEN
                UPDATE DMPDB2.R_URGENT_LIST SET IS_CLOSE = 1, OUTPUT_QTY = TARGET_QTY WHERE ID = R.ID;
            ELSE
                UPDATE DMPDB2.R_URGENT_LIST SET OUTPUT_QTY = OUTPUT_QTY + iTotal WHERE ID = R.ID;
                cMsg := 'OK';
                
                GOTO end_of_function;
            END IF;
            iTotal := iTotal - R.QTY;
        END LOOP;
        cMsg := 'OK';    
    ELSE
        cMsg := 'sp_updateurgentlist error: Undefine iFlag: ' || To_CHAR(iFlag);        
    END IF;
    
  <<end_of_function>>

   COMMIT;
   RETURN;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;   
      cMsg := 'sp_updateurgentlist error: ' || SUBSTR (SQLERRM, 1, 200);
END;

/

