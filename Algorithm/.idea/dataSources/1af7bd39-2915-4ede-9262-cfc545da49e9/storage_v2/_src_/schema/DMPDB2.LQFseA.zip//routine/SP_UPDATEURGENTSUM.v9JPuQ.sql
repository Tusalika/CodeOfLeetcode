create PROCEDURE        SP_UPDATEURGENTSUM (
   cGbFloor       VARCHAR2,
   cFgFloor       VARCHAR2,
   cMpn           VARCHAR2,
   iQty           NUMBER,
   cMsg       OUT VARCHAR2)
AS
    iTotal NUMBER;
    iCount NUMBER;
    iSumID NUMBER;
    iSumQty NUMBER;
BEGIN
    iTotal := iQty;
    IF iTotal <= 0 THEN
        cMsg := 'sp_updateurgentsum error: iQty error: ' || To_CHAR(iTotal);        
        GOTO end_of_function;
    END IF;
    
    SELECT COUNT(ID) INTO iCount FROM DMPDB2.R_URGENT_SUM WHERE GB_FLOOR = cGbFloor AND FG_FLOOR = cFgFloor AND MPN = cMpn AND IS_CLOSE = 0 AND DEL_FLAG = 0;
    IF iCount = 1 THEN
        SELECT ID, TARGET_QTY - OUTPUT_QTY QTY INTO iSumID, iSumQty FROM DMPDB2.R_URGENT_SUM WHERE GB_FLOOR = cGbFloor AND FG_FLOOR = cFgFloor AND MPN = cMpn AND IS_CLOSE = 0 AND DEL_FLAG = 0;
            
        IF iTotal = iSumQty THEN
            UPDATE DMPDB2.R_URGENT_SUM SET IS_CLOSE = 1, OUTPUT_QTY = TARGET_QTY WHERE ID = iSumID;
            cMsg := 'OK';            
        ELSIF iTotal < iSumQty THEN
            UPDATE DMPDB2.R_URGENT_SUM SET OUTPUT_QTY = OUTPUT_QTY + iTotal WHERE ID = iSumID;
            cMsg := 'OK';
        ELSE
            cMsg := 'sp_updateurgentsum error: iQty is greater: ' || To_CHAR(iTotal);    
        END IF;
    ELSE
        cMsg := 'sp_updateurgentsum error: No Record or Record is more than 1';
    END IF;
    
  <<end_of_function>>

   COMMIT;
   RETURN;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;   
      cMsg := 'sp_updateurgentsum error: ' || SUBSTR (SQLERRM, 1, 200);
END;

/

