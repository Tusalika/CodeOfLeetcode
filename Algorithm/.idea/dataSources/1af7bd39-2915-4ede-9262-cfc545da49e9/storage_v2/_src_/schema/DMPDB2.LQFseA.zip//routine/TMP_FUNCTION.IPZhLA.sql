create PROCEDURE        TMP_FUNCTION(CCATEGORY IN VARCHAR2)
IS
  ICOMMODITYID NUMBER;
  CKEYNAME VARCHAR2(100);
  CSTATIONCODE VARCHAR2(100);
  CCATEGORYKEY VARCHAR2(100);
  IID NUMBER;
BEGIN

   DECLARE 
          CURSOR LOtCusor IS 
            select  33 COMMODITYID,'CHECK LABEL FAI' KEYNAME,
             code STATIONCODE, CCATEGORY CATEGORYKEY FROM DMPDB2.STATION WHERE TYPE NOT LIKE 'T%';
                   

    BEGIN
      OPEN LOtCusor;
      LOOP
      FETCH LOtCusor INTO ICOMMODITYID, CKEYNAME, CSTATIONCODE, CCATEGORYKEY;
      EXIT WHEN LOtCusor%NOTFOUND;                                                           
        IID := dmpdb2.GET_NEXT_ID('SYS_PROPERTY'); 
         insert into dmpdb2.sys_property(id, commodity_id, key_name, property_01,
          property_02,add_by, add_date, edit_by, edit_date) VALUES(
             IID, ICOMMODITYID, CKEYNAME, CSTATIONCODE, CCATEGORYKEY , -1,
              SYSDATE, -1,  SYSDATE );

                  
      END LOOP;
      CLOSE LOtCusor;
    END;   
END;


/

