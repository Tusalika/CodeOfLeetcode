create procedure        UPDATE_X_TRACK_FLAG(
cWipNo in varchar2
, vRet out varchar2
)
AS
  icount INT;
BEGIN
   vRet := 'OK';
   SELECT count(1) INTO icount
     FROM R_PRQ_CONTROL_WIP
    WHERE WIP_NO = cWipNo
      AND XTRACK_RI_FLAG = 'N'
      AND XTRACK_RO_FLAG = 'N'
      AND DEL_FLAG = 0;

   IF icount > 0 THEN

     UPDATE R_PRQ_CONTROL_WIP set XTRACK_RO_FLAG = 'Y'
      WHERE WIP_NO = cWipNo
        AND XTRACK_RI_FLAG = 'N'
        AND XTRACK_RO_FLAG = 'N'
        AND DEL_FLAG = 0 ;

      COMMIT;

   ELSE
     vRet := 'UNIT FLAG ERR; ';

   END IF ;


EXCEPTION
   WHEN OTHERS
   THEN
      vRet := 'ERR PRO_X_TRACK';
END;


/

