create PROCEDURE        use_lb_package (
   lb_stage      IN       VARCHAR2,
   lb_user       IN       VARCHAR2,
   lb_flow       IN       VARCHAR2,
   lb_project    IN       VARCHAR2,
   lb_floor      IN       VARCHAR2,
   lb_to_floor   IN       VARCHAR2,
   lb_ailno      IN       VARCHAR2,
   lb_expire     IN       VARCHAR2,
   lb_nal_list   IN       VARCHAR2,
   lb_msg        OUT      VARCHAR2
)
IS
BEGIN
   dmpdb2.lb_pk_c.p_main (lb_stage,
                          lb_user,
                          lb_flow,
                          lb_project,
                          lb_floor,
                          lb_to_floor,
                          lb_ailno,
                          lb_expire,
                          lb_nal_list
                         );
END;

/

