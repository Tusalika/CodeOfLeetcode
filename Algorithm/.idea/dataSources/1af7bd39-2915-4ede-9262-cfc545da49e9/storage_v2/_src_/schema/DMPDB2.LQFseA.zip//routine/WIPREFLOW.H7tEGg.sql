create FUNCTION        wipReFlow(wipID in number, commodityID in number, toStaCode in varchar2) return boolean
is
  var_num_WipID number;
begin
  select wip_id 
    into var_num_WipID
    from dmpdb2.R_QA_Record
   where wip_id = wipID
     and commodity_id = commodityID
     and to_station_code = toStaCode
     and qa_flag = 1;
       
  return true;     
exception
  when no_data_found then
    return false;
  when too_many_rows then
    return true;
  when others then
    return false;       
end;


/

