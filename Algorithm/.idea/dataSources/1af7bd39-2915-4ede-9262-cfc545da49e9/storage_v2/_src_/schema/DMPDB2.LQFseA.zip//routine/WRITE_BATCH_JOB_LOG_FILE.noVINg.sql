create PROCEDURE        write_batch_Job_Log_file(
vSysID varchar2
, vProgID varchar2
, vUserID varchar2
, vStartDt date
, vEndDt date
, vRecords number
, vErrLevel varchar2
, vErrDesc varchar2
) 
as
 iMaxID number;
 vRet varchar2(255);
begin    
-- dmpdb2.write_batch_Job_Log_file(
--   'SFC(PDCA)'
--   , 'PDCA_FIRST_YIELD_FATP'
--   , 'SFC'
--   , sysdate
--   , sysdate - fTimeGenerate
--   , 0
--   , 'G'
--   , 'OK'
--    )
    --iMaxID := get_next_id('PDCA_FIRST_YIELD');
    select dmpdb2.Batch_Job_Log_File_Id.nextval into iMaxID from dual;
    INSERT INTO dmpdb2.BATCH_JOB_LOG_FILE(UniqID, SysID, ProgID, UserID
                 , StartDt, EndDt, Records, ErrLevel, ErrDesc)
      VALUES( vProgID || 'DHP2_' || iMaxID
        , vSysID
        , vProgID
        , vUserID
        , vStartDt
        , vEndDt
        , vRecords
        , vErrLevel
        , vErrDesc
        )
        ;
    commit;    
exception
  WHEN OTHERS THEN begin
    vRet := SUBSTR(SQLERRM, 1, 255);   
    dmpdb2.write_bob_log(vProgID, 'write_batch_Job_Log_file', '1', vRet, 'write_batch_Job_Log_file');      
  end;        
end;


/

