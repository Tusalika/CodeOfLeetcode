create PROCEDURE        Write_Bob_Log(
vbobcode varchar2
, vbobname varchar2
, vbobflag varchar2
, vbobmsg varchar2
, vwipno varchar2
)
is
begin
  insert into dmpdb2.r_bob_log(id, bob_code, bob_name, bob_flag, time_stamp, wip_no, add_DATE, BOB_MSG)
  values(dmpdb2.s_r_bob_log_id.nextval
    , vbobcode
    , vbobname
    , vbobflag
    , to_char(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF')
    , vwipno
    , sysdate
    , vbobmsg
    );
  commit;
end ;


/

