create trigger TRI_APP_GRP_MEMBER_ADD_ID
    before insert
    on APP_GRP_MEMBER
    for each row
BEGIN  SELECT seq_APP_GRP_MEMBER_id.nextval into :new.id from dual; end;
/

