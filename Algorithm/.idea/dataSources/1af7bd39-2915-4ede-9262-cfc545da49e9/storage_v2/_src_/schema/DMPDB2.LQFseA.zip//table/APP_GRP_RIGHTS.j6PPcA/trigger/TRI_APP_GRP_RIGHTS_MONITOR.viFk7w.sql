create trigger TRI_APP_GRP_RIGHTS_MONITOR
    after insert or update or delete
    on APP_GRP_RIGHTS
    for each row
begin
   if inserting
   then
      insert into sfc_f1215267.app_grp_rights_monitor (app_grp_id,
                                                       function_code,
                                                       rights_str,
                                                       add_by,
                                                       add_date,
                                                       edit_by,
                                                       edit_date,
                                                       del_flag,
                                                       id,
                                                       session_user,
                                                       os_user,
                                                       host,
                                                       ip_address,
                                                       action)
           values (:new.app_grp_id,
                   :new.function_code,
                   :new.rights_str,
                   :new.add_by,
                   :new.add_date,
                   :new.edit_by,
                   :new.edit_date,
                   :new.del_flag,
                   :new.id,
                   sys_context ('userenv', 'session_user'),
                   sys_context ('userenv', 'os_user'),
                   sys_context ('userenv', 'host'),
                   sys_context ('userenv', 'ip_address'),
                   'INSERT');
   elsif updating
   then
      insert into sfc_f1215267.app_grp_rights_monitor (app_grp_id,
                                                       function_code,
                                                       rights_str,
                                                       add_by,
                                                       add_date,
                                                       edit_by,
                                                       edit_date,
                                                       del_flag,
                                                       id,
                                                       session_user,
                                                       os_user,
                                                       host,
                                                       ip_address,
                                                       action)
           values (:old.app_grp_id,
                   :old.function_code,
                   :old.rights_str,
                   :old.add_by,
                   :old.add_date,
                   :old.edit_by,
                   :old.edit_date,
                   :old.del_flag,
                   :old.id,
                   sys_context ('userenv', 'session_user'),
                   sys_context ('userenv', 'os_user'),
                   sys_context ('userenv', 'host'),
                   sys_context ('userenv', 'ip_address'),
                   'UPDATE_OLD');



      insert into sfc_f1215267.app_grp_rights_monitor (app_grp_id,
                                                       function_code,
                                                       rights_str,
                                                       add_by,
                                                       add_date,
                                                       edit_by,
                                                       edit_date,
                                                       del_flag,
                                                       id,
                                                       session_user,
                                                       os_user,
                                                       host,
                                                       ip_address,
                                                       action)
           values (:new.app_grp_id,
                   :new.function_code,
                   :new.rights_str,
                   :new.add_by,
                   :new.add_date,
                   :new.edit_by,
                   :new.edit_date,
                   :new.del_flag,
                   :new.id,
                   sys_context ('userenv', 'session_user'),
                   sys_context ('userenv', 'os_user'),
                   sys_context ('userenv', 'host'),
                   sys_context ('userenv', 'ip_address'),
                   'UPDATE_NEW');
   else
      insert into sfc_f1215267.app_grp_rights_monitor (app_grp_id,
                                                       function_code,
                                                       rights_str,
                                                       add_by,
                                                       add_date,
                                                       edit_by,
                                                       edit_date,
                                                       del_flag,
                                                       id,
                                                       session_user,
                                                       os_user,
                                                       host,
                                                       ip_address,
                                                       action)
           values (:old.app_grp_id,
                   :old.function_code,
                   :old.rights_str,
                   :old.add_by,
                   :old.add_date,
                   :old.edit_by,
                   :old.edit_date,
                   :old.del_flag,
                   :old.id,
                   sys_context ('userenv', 'session_user'),
                   sys_context ('userenv', 'os_user'),
                   sys_context ('userenv', 'host'),
                   sys_context ('userenv', 'ip_address'),
                   'DELETE');
   end if;
end;
/

