create trigger TRI_APP_RIGHTS_GRANTED_ADD_ID
    before insert
    on APP_RIGHTS_GRANTED
    for each row
BEGIN  SELECT seq_APP_RIGHTS_GRANTED_id.nextval into :new.id from dual; end;
/

