create trigger TRI_APP_USER_RIGHTS_ADD_ID
    before insert
    on APP_USER_RIGHTS
    for each row
BEGIN  SELECT seq_APP_USER_RIGHTS_id.nextval into :new.id from dual; end;
/

