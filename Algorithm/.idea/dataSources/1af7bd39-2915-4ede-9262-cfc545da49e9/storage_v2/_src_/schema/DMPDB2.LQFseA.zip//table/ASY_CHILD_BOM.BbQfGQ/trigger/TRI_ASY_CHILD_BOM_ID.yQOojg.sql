create trigger TRI_ASY_CHILD_BOM_ID
    before insert
    on ASY_CHILD_BOM
    for each row
BEGIN  SELECT DMPDB2.S_Asy_Child_Bom_ID.nextval
 INTO :new.ID FROM dual; END;
/

