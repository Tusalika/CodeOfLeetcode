create trigger TRI_CODE_TEMP_ADD_ID
    before insert
    on CODE_TEMP
    for each row
BEGIN  SELECT seq_CODE_TEMP_id.nextval into :new.id from dual; end;
/

