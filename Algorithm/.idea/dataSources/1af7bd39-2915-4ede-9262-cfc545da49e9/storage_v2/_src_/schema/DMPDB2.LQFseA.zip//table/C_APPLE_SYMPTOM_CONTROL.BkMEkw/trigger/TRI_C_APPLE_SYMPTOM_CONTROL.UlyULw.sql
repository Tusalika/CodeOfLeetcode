create trigger TRI_C_APPLE_SYMPTOM_CONTROL
    before insert
    on C_APPLE_SYMPTOM_CONTROL
    for each row
BEGIN 
      SELECT DMPDB2.SEQ_C_Apple_Symptom_Control.nextval into :new.id from dual; 
end;
/

