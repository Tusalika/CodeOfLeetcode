create trigger C_AREA_DB_MAPPING_TRI
    before insert
    on C_AREA_DB_MAPPING
    for each row
BEGIN
   SELECT DMPDB2.C_Area_DB_Mapping_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

