create trigger C_AUTOLOCK_BYPREFIX_TRG
    before insert
    on C_AUTOLOCK_BYPREFIX
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select C_AUTOLOCK_BYPREFIX_SEQ.nextval into n from dual;
  :new.ID := N;
END C_AUTOLOCK_BYPREFIX_TRG;
/

