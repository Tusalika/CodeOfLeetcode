create trigger TRI_C_CGS_CHECK_RULE_ID
    before insert
    on C_CGS_CHECK_RULE
    for each row
BEGIN
SELECT DMPDB2.SEQ_C_CGS_CHECK_RULE_ID.nextval into :new.id from dual;
end;
/

