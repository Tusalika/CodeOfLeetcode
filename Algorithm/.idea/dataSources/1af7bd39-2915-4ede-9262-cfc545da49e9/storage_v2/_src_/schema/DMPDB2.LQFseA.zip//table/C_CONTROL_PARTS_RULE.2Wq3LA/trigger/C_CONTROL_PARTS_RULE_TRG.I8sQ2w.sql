create trigger C_CONTROL_PARTS_RULE_TRG
    before insert
    on C_CONTROL_PARTS_RULE
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select C_CONTROL_PARTS_RULE_SEQ.nextval into n from dual;
  :new.ID := N;
END C_CONTROL_PARTS_RULE_TRG;
/

