create trigger C_GBFLOOR_GROUP_ID_TRI
    before insert
    on C_GBFLOOR_GROUP
    for each row
BEGIN  SELECT  DMPDB2.SEQ_C_GBFLOOR_GROUP_ID.nextval into :new.id from dual; end;
/

