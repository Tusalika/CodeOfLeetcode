create trigger TRI_C_KX_SOP_ID
    before insert
    on C_KX_SOP
    for each row
BEGIN  SELECT  DMPDB2.SEQ_C_KX_SOP_ID.nextval into :new.id from dual; end;
/

