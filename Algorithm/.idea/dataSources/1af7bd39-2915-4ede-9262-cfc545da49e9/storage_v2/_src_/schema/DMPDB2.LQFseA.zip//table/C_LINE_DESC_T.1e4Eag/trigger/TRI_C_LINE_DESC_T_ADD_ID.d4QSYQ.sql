create trigger TRI_C_LINE_DESC_T_ADD_ID
    before insert
    on C_LINE_DESC_T
    for each row
BEGIN  SELECT seq_C_LINE_DESC_T_id.nextval into :new.id from dual; end;
/

