create trigger TRI_C_LOCK_APPEND_INFO_ADD_ID
    before insert
    on C_LOCK_APPEND_INFO
    for each row
BEGIN  SELECT DMPDB2.seq_C_LOCK_APPEND_INFO_id.nextval into :new.id from dual; end;
/

