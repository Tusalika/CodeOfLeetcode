create trigger C_LOT_DEFAULT_QTY_TRI
    before insert
    on C_LOT_DEFAULT_QTY
    for each row
BEGIN  SELECT  dmpdb2.C_LOT_DEFAULT_QTY_deq.nextval into :new.id from dual; end;
/

