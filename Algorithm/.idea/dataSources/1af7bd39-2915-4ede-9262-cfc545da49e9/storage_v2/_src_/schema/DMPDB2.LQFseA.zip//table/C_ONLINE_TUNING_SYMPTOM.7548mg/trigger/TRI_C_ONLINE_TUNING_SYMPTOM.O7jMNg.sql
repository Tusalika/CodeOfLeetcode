create trigger TRI_C_ONLINE_TUNING_SYMPTOM
    before insert
    on C_ONLINE_TUNING_SYMPTOM
    for each row
BEGIN  SELECT DMPDB2.SEQ_C_ONLINE_TUNING_SYMPTOM.nextval
 INTO :new.ID FROM dual; END;
/

