create trigger CR_C_OS_VERSION_ID_ADD
    before insert
    on C_OS_VERSION
    for each row
BEGIN
   SELECT dmpdb2.s_c_os_version_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

