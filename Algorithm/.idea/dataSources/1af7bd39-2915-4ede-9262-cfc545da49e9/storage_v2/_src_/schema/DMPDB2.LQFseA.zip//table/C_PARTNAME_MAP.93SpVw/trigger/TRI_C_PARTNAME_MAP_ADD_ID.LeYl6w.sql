create trigger TRI_C_PARTNAME_MAP_ADD_ID
    before insert
    on C_PARTNAME_MAP
    for each row
BEGIN  SELECT seq_C_PARTNAME_MAP_id.nextval into :new.id from dual; end;
/

