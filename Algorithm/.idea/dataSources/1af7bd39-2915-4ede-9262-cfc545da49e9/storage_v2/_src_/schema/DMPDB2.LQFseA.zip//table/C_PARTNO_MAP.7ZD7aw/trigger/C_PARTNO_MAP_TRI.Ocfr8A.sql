create trigger C_PARTNO_MAP_TRI
    before insert
    on C_PARTNO_MAP
    for each row
BEGIN
   SELECT DMPDB2.C_PARTNO_MAP_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

