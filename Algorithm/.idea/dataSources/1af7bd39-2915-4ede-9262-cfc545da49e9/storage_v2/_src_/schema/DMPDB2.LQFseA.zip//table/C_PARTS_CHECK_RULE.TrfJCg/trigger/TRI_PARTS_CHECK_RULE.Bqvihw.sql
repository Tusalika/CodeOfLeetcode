create trigger TRI_PARTS_CHECK_RULE
    before insert
    on C_PARTS_CHECK_RULE
    for each row
BEGIN  SELECT DMPDB2.SEQ_PARTS_CHECK_RULE.nextval
 INTO :new.ID FROM dual; END;
/

