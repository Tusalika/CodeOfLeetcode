create trigger TRI_C_PARTS_CONTROL_SYMPTOM
    before insert
    on C_PARTS_CONTROL_SYMPTOM
    for each row
BEGIN  
      SELECT DMPDB2.SEQ_C_Parts_Control_Symptom.nextval INTO :new.ID FROM dual; 
   END;
/

