create trigger TRI_C_PART_INFO_ID
    before insert
    on C_PART_INFO
    for each row
begin
    select dmpdb2.s_c_part_info_id.nextval into :new.id from dual ;
end ;
/

