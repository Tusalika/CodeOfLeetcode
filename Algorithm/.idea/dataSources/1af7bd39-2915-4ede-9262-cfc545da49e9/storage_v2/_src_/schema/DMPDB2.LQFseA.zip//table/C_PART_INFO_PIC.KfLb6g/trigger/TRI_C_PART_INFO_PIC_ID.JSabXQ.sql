create trigger TRI_C_PART_INFO_PIC_ID
    before insert
    on C_PART_INFO_PIC
    for each row
begin
    select dmpdb2.s_c_part_info_pic_id.nextval into :new.id from dual ;
end ;
/

