create trigger TRI_C_PROP_ID
    before insert
    on C_PROP
    for each row
BEGIN  SELECT  dmpdb2.seq_c_prop_id.nextval into :new.id from dual; end;
/

