create trigger C_PROP_D21_ID_TRI
    before insert
    on C_PROP_D21
    for each row
BEGIN  SELECT  DMPDB2.SEQ_C_PROP_D21_ID.nextval into :new.id from dual; end;
/

