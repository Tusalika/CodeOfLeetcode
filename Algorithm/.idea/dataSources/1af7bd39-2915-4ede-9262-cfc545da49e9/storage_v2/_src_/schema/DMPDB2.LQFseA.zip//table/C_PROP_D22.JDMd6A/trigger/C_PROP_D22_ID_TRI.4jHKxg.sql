create trigger C_PROP_D22_ID_TRI
    before insert
    on C_PROP_D22
    for each row
BEGIN  SELECT  DMPDB2.SEQ_C_PROP_D22_ID.nextval into :new.id from dual; end;
/

