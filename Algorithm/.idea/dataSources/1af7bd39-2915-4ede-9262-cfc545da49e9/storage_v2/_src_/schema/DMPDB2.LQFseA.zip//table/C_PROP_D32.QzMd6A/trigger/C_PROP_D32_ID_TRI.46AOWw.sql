create trigger C_PROP_D32_ID_TRI
    before insert
    on C_PROP_D32
    for each row
BEGIN  SELECT  DMPDB2.SEQ_C_PROP_D32_ID.nextval into :new.id from dual; end;
/

