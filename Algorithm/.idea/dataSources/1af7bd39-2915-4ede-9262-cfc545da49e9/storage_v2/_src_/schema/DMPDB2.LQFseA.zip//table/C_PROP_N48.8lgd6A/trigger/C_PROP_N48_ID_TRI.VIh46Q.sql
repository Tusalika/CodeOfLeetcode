create trigger C_PROP_N48_ID_TRI
    before insert
    on C_PROP_N48
    for each row
BEGIN  SELECT  DMPDB2.C_PROP_N48_id.nextval into :new.id from dual; end;
/

