create trigger C_PROP_N51_ID_TRI
    before insert
    on C_PROP_N51
    for each row
BEGIN  SELECT  DMPDB2.C_PROP_N51_id.nextval into :new.id from dual; end;
/

