create trigger C_PROP_N56_ID_TRI
    before insert
    on C_PROP_N56
    for each row
BEGIN
   SELECT DMPDB2.C_PROP_N56_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

