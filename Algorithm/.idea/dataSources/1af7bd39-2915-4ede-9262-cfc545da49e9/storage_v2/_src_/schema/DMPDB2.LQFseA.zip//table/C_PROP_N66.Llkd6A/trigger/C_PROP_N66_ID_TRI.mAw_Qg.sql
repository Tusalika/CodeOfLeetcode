create trigger C_PROP_N66_ID_TRI
    before insert
    on C_PROP_N66
    for each row
BEGIN
   SELECT DMPDB2.C_PROP_N66_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

