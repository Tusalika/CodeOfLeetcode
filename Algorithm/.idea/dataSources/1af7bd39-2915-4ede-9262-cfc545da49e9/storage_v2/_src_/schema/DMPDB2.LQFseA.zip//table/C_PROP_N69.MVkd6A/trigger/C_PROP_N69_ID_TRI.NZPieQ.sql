create trigger C_PROP_N69_ID_TRI
    before insert
    on C_PROP_N69
    for each row
BEGIN
   SELECT DMPDB2.C_PROP_N69_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

