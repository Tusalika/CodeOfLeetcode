create trigger C_PROP_N71_ID_TRI
    before insert
    on C_PROP_N71
    for each row
BEGIN
   SELECT DMPDB2.C_PROP_N71_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

