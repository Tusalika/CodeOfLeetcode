create trigger C_PRQ_PARTS_ID_TRI
    before insert
    on C_PRQ_PARTS
    for each row
BEGIN  SELECT  DMPDB2.C_PRQ_PARTS_ID.nextval into :new.id from dual; end;
/

