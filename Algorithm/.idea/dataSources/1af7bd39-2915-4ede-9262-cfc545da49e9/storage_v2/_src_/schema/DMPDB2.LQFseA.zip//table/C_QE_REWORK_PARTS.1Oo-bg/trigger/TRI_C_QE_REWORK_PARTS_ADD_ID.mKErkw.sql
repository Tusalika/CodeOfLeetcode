create trigger TRI_C_QE_REWORK_PARTS_ADD_ID
    before insert
    on C_QE_REWORK_PARTS
    for each row
BEGIN  SELECT DMPDB2.seq_C_QE_REWORK_PARTS_id.nextval into :new.id from dual; end;
/

