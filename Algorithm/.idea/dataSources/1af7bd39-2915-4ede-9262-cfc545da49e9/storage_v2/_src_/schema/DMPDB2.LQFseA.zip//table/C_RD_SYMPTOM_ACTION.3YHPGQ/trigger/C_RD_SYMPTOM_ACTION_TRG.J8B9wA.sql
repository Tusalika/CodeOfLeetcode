create trigger C_RD_SYMPTOM_ACTION_TRG
    before insert
    on C_RD_SYMPTOM_ACTION
    for each row
BEGIN
     select DMPDB2.SEQ_C_RD_SYMPTOM_ACTION.nextval  INTO :new.ID from dual;
END;
/

