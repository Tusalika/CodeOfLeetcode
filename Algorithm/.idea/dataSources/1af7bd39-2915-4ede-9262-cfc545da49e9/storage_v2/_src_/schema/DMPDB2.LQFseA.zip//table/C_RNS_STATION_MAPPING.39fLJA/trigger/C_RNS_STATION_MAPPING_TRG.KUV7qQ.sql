create trigger C_RNS_STATION_MAPPING_TRG
    before insert
    on C_RNS_STATION_MAPPING
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select C_RNS_STATION_MAPPING_SEQ.nextval into n from dual;
  :new.ID := N;
END C_RNS_STATION_MAPPING_TRG;
/

