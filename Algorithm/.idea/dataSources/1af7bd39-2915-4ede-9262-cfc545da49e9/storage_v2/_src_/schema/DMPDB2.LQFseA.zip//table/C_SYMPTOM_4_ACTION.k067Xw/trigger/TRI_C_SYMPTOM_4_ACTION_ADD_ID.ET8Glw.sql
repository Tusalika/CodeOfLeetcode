create trigger TRI_C_SYMPTOM_4_ACTION_ADD_ID
    before insert
    on C_SYMPTOM_4_ACTION
    for each row
BEGIN  SELECT DMPDB2.SEQ_C_SYMPTOM_4_ACTION_ID.nextval into :new.id from dual; end;
/

