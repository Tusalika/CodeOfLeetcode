create trigger C_SYMPTOM_PARTS_MAPPING_TRI
    before insert
    on C_SYMPTOM_PARTS_MAPPING
    for each row
BEGIN  SELECT  DMPDB2.C_SYMPTOM_PARTS_MAPPING_ID.nextval into :new.id from dual; end;
/

