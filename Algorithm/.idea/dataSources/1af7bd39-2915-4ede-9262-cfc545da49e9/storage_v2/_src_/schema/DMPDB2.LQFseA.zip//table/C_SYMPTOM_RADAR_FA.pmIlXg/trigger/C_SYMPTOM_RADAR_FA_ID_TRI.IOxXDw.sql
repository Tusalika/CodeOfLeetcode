create trigger C_SYMPTOM_RADAR_FA_ID_TRI
    before insert
    on C_SYMPTOM_RADAR_FA
    for each row
BEGIN  SELECT SEQ_C_SYMPTOM_RADAR_FA_ID.nextval into :new.id from dual; end;
/

