create trigger TRI_C_SYS_PROPERTY_CONTROL_ID
    before insert
    on C_SYS_PROPERTY_CONTROL
    for each row
BEGIN  SELECT  DMPDB2.SEQ_C_SYS_PROPERTY_CONTROL_ID.nextval into :new.id from dual; end;
/

