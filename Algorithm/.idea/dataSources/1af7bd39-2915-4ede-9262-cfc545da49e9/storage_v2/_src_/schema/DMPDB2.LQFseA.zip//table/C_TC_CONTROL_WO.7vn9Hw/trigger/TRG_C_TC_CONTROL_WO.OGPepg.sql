create trigger TRG_C_TC_CONTROL_WO
    before insert
    on C_TC_CONTROL_WO
    for each row
BEGIN  
      SELECT DMPDB2.SEQ_C_TC_CONTROL_WO.nextval INTO :new.ID FROM dual; 
   END;
/

