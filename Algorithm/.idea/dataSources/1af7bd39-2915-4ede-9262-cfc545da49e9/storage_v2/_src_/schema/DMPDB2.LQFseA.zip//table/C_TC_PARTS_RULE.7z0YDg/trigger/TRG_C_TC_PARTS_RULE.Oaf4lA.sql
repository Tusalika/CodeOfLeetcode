create trigger TRG_C_TC_PARTS_RULE
    before insert
    on C_TC_PARTS_RULE
    for each row
BEGIN  
      SELECT DMPDB2.SEQ_C_TC_PARTS_RULE.nextval INTO :new.ID FROM dual; 
   END;
/

