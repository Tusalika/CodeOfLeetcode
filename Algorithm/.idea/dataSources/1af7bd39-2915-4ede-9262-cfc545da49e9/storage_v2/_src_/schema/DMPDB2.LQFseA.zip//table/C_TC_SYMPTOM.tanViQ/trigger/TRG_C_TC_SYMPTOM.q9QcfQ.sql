create trigger TRG_C_TC_SYMPTOM
    before insert
    on C_TC_SYMPTOM
    for each row
BEGIN  
      SELECT DMPDB2.SEQ_C_TC_SYMPTOM.nextval INTO :new.ID FROM dual; 
   END;
/

