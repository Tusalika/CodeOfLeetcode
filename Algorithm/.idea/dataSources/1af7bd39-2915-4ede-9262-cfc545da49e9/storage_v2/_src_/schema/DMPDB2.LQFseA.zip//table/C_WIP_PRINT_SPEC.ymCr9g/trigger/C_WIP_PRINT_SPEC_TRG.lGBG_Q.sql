create trigger C_WIP_PRINT_SPEC_TRG
    before insert
    on C_WIP_PRINT_SPEC
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select C_WIP_PRINT_SPEC_SEQ.nextval into n from dual;
  :new.ID := N;
END C_WIP_PRINT_SPEC_TRG;
/

