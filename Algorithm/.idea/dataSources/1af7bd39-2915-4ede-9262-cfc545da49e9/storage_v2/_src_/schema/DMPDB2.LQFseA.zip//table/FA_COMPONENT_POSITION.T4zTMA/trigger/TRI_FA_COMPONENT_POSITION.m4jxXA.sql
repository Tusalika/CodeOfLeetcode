create trigger TRI_FA_COMPONENT_POSITION
    before insert
    on FA_COMPONENT_POSITION
    for each row
BEGIN
  SELECT DMPDB2.SEQ_FA_COMPONENT_POSITION.nextval into :new.id from dual;
end;
/

