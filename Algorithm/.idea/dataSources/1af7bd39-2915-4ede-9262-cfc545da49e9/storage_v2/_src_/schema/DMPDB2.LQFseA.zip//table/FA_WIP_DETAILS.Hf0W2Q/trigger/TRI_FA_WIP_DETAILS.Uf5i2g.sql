create trigger TRI_FA_WIP_DETAILS
    before insert
    on FA_WIP_DETAILS
    for each row
BEGIN
  SELECT DMPDB2.SEQ_FA_WIP_DETAILS.nextval into :new.id from dual;
end;
/

