create trigger FLOCK_LOG_ID
    before insert
    on FLOCK_LOG
    for each row
BEGIN  SELECT  DMPDB2.SEQ_FLOCK_LOG_id.nextval
 INTO :new.ID FROM dual; END;
/

