create trigger TRI_FLOCK_REASON
    before insert
    on FLOCK_REASON
    for each row
BEGIN
        SELECT SEQ_FLOCK_REASON.nextval into :new.id from dual; 
end;
/

