create trigger FLOOR_TRI
    before insert
    on FLOOR
    for each row
BEGIN
   SELECT DMPDB2.FLOOR_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

