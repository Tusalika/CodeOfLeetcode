create trigger LB_AIL_TRI
    before insert
    on LB_AIL
    for each row
BEGIN  SELECT   DMPDB2.LB_AIL_ID.nextval into :new.id from dual; end;
/

