create trigger TR2_LB_SCAN
    after update of IS_SFC
    on LB_SCAN
begin
  --將LB_SCAN表資料刪除------------------------
  delete from dmpdb2.lb_scan
   where rowid in (select rowid1 from dmpdb2.LB_T2_SCAN);
end TR2_lb_scan;
/

