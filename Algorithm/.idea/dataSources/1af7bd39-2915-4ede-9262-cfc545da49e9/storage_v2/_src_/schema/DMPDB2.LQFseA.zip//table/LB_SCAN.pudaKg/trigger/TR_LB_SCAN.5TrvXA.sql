create trigger TR_LB_SCAN
    after update of IS_SFC
    on LB_SCAN
    for each row
declare
  -- local variables here
begin
  if :new.is_sfc in ('Y','S') then
    begin
      insert into dmpdb2.lb_scan_end
        (SCAN_NO,
         FLOW_ID,
         FLOW_ITEM,
         PROJ_ID,
         FLOOR_ID,
         PROD_SN,
         NAL_SN,
         SCAN_TIME,
         STAGE_ID,
         USER_ID,
         LINE_CODE,
         IS_ACTI,
         NOTES,
         TO_FLOOR_ID,
         MOVE_TIME,
         is_sfc)
      values
        (:new.SCAN_NO,
         :new.FLOW_ID,
         :new.FLOW_ITEM,
         :new.PROJ_ID,
         :new.FLOOR_ID,
         :new.PROD_SN,
         :new.NAL_SN,
         :new.SCAN_TIME,
         :new.STAGE_ID,
         :new.USER_ID,
         :new.LINE_CODE,
         :new.IS_ACTI,
         :new.NOTES,
         :new.TO_FLOOR_ID,
         sysdate,
         :new.is_sfc);    
      delete from dmpdb2.lb_scan
       where nal_sn in (select nal_sn
                          from dmpdb2.lb_scan
                         where is_sfc in ('Y','S'));    
    end;
  end if;
end TR_lb_scan;
/

