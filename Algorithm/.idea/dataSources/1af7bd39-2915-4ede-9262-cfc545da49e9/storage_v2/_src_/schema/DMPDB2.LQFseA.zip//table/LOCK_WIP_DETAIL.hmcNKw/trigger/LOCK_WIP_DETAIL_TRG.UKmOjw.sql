create trigger LOCK_WIP_DETAIL_TRG
    before insert
    on LOCK_WIP_DETAIL
    for each row
BEGIN
 SELECT DMPDB2.lock_wip_detail_ID_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
END ;
/

