create trigger LOCK_WIP_2_DETAIL_TRG
    before insert
    on LOCK_WIP_DETAIL_2
    for each row
BEGIN
 SELECT DMPDB2.seq_lock_wip_detail_2_id.NEXTVAL INTO :NEW.ID FROM DUAL;
END ;
/

