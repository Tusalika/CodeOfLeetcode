create trigger LOCK_WIP_P_DETAIL_TRG
    before insert
    on LOCK_WIP_DETAIL_P
    for each row
BEGIN
 SELECT DMPDB2.seq_LOCK_WIP_DETAIL_P_id.NEXTVAL INTO :NEW.ID FROM DUAL;
END ;
/

