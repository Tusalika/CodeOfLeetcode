create trigger TRILOCK_WIP_DETAIL_PARTS_ID
    before insert
    on LOCK_WIP_DETAIL_PARTS
    for each row
BEGIN  SELECT  DMPDB2.LOCK_WIP_DETAIL_PARTS_ID.nextval
 INTO :new.ID FROM dual; END;
/

