create trigger TRI_LOCK_WIP_SQLLOAD_2_ADD_ID
    before insert
    on LOCK_WIP_SQLLOAD_2
    for each row
BEGIN
   SELECT DMPDB2.seq_LOCK_WIP_SQLLOAD_2_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

