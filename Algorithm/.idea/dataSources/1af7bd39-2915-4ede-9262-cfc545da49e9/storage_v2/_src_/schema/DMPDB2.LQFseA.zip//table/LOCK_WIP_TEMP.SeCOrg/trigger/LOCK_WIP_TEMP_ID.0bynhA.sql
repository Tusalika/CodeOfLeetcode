create trigger LOCK_WIP_TEMP_ID
    before insert
    on LOCK_WIP_TEMP
    for each row
begin
    select DMPDB2.LOCK_WIP_TEMP_ID_SEQ.NEXTVAL INTO :new.ID from dual;
end;
/

