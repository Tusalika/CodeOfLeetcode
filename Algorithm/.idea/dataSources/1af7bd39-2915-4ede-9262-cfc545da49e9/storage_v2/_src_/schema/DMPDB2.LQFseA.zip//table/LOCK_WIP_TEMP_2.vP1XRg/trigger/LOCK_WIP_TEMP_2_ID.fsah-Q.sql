create trigger LOCK_WIP_TEMP_2_ID
    before insert
    on LOCK_WIP_TEMP_2
    for each row
begin
    select DMPDB2.lock_wip_temp_2_ID_SEQ.NEXTVAL INTO :new.ID from dual;
end;
/

