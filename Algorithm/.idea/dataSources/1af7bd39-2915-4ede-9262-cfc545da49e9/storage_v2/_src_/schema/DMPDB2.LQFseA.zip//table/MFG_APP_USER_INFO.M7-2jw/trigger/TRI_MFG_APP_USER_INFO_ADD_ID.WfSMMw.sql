create trigger TRI_MFG_APP_USER_INFO_ADD_ID
    before insert
    on MFG_APP_USER_INFO
    for each row
BEGIN  SELECT DMPDB2.MFG_APP_USER_INFO_ID.nextval into :new.id from dual; end;
/

