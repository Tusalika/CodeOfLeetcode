create trigger MIYAGI_BLACKLIST_TRI
    before insert
    on MIYAGI_BLACKLIST
    for each row
BEGIN
   SELECT DMPDB2.MIYAGI_BLACKLIST_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

