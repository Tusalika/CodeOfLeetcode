create trigger OP_ACTIVE_CONFIG_TRG
    before insert
    on OP_ACTIVE_CONFIG
    for each row
BEGIN
 SELECT DMPDB2.SEQ_OP_active_config.NEXTVAL INTO :NEW.ID FROM DUAL;
END ;
/

