create trigger OP_CERTIFIED_INFO_TRG
    before insert
    on OP_CERTIFIED_INFO
    for each row
BEGIN
 SELECT DMPDB2.SEQ_OP_Certified_INFO.NEXTVAL INTO :NEW.ID FROM DUAL;
END ;
/

