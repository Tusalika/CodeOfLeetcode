create trigger TRI_PARTS_NO_RULE_ID
    before insert
    on PARTS_NO_RULE
    for each row
BEGIN  
  SELECT dmpdb2.S_PARTS_NO_RULE_ID.nextval      INTO :new.ID      FROM dual; 
END;
/

