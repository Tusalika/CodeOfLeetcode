create trigger TRI_PARTS_SN_RULE_ID
    before insert
    on PARTS_SN_RULE
    for each row
BEGIN  
  SELECT dmpdb2.s_Parts_SN_Rule_id.nextval  INTO :new.ID   FROM dual; 
END;
/

