create trigger TRI_PARTS_SN_RULE_TEMP_ID
    before insert
    on PARTS_SN_RULE_TEMP
    for each row
BEGIN  
  SELECT dmpdb2.s_Parts_Sn_Rule_Temp_id.nextval  INTO :new.ID   FROM dual; 
END;
/

