create trigger TRI_PART_PICTURE_DES_ID
    before insert
    on PART_PICTURE_DES
    for each row
BEGIN  SELECT DMPDB2.SEQ_PART_PICTURE_DES_ID.nextval into :new.id from dual; end;
/

