create trigger TRI_ROUTE_CHART_ADD_ID
    before insert
    on ROUTE_CHART
    for each row
BEGIN  SELECT dmpdb2.seq_ROUTE_CHART_ID.nextval into :new.id from dual; end;
/

