create trigger R_AUTO_UNLOCK_CHECK_ID_TRI
    before insert
    on R_AUTO_UNLOCK_CHECK_DETAIL
    for each row
BEGIN  SELECT  dmpdb2.R_AUTO_UNLOCK_CHECK_ID.nextval into :new.id from dual; end;
/

