create trigger TRI_R_BOB_FILTER_ID
    before insert
    on R_BOB_FILTER
    for each row
BEGIN  SELECT DMPDB2.seq_R_Bob_Filter_ID.nextval into :new.id from dual; end;
/

