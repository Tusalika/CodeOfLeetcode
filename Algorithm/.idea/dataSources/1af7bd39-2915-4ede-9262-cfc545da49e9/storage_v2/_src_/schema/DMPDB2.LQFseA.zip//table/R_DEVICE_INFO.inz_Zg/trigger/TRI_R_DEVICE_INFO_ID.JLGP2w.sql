create trigger TRI_R_DEVICE_INFO_ID
    before insert
    on R_DEVICE_INFO
    for each row
begin
   select dmpdb2.s_r_device_info_id.nextval into :new.id from dual;
end;
/

