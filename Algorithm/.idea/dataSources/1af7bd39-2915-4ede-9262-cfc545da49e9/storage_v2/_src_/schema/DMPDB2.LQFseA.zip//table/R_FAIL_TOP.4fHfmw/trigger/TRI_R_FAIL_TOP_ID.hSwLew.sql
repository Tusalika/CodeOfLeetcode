create trigger TRI_R_FAIL_TOP_ID
    before insert
    on R_FAIL_TOP
    for each row
begin
   select dmpdb2.s_r_fail_top_id.nextval into :new.id from dual;
end;
/

