create trigger R_GBFG_WO_MAPPING_TRI
    before insert
    on R_GBFG_WO_MAPPING
    for each row
BEGIN
   SELECT DMPDB2.R_GBFG_WO_MAPPING_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

