create trigger R_LOTS_QTY_USED_TRI
    before insert
    on R_LOTS_QTY_USED
    for each row
BEGIN  SELECT  dmpdb2.R_LOTS_QTY_USED_deq.nextval into :new.id from dual; end;
/

