create trigger R_MM_EXAMINE_TRG
    before insert
    on R_MM_EXAMINE
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select dmpdb2.R_MM_EXAMINE_SEQ.nextval into n from dual;
  :new.ID := N;
END R_MM_EXAMINE_TRG;
/

