create trigger R_MM_LOCK_TRG
    before insert
    on R_MM_LOCK
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select R_MM_LOCK_SEQ.nextval into n from dual;
  :new.ID := N;
END R_MM_LOCK_TRG;
/

