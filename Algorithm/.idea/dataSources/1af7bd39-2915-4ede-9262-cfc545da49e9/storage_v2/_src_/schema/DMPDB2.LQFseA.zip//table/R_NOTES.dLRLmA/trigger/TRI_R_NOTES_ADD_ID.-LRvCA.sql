create trigger TRI_R_NOTES_ADD_ID
    before insert
    on R_NOTES
    for each row
BEGIN  SELECT dmpdb2.seq_R_NOTES_id.nextval into :new.id from dual; end;
/

