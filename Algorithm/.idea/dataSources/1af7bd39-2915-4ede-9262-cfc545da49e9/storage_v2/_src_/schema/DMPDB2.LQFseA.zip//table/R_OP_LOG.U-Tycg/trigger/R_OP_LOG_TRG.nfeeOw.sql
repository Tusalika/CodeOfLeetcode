create trigger R_OP_LOG_TRG
    before insert
    on R_OP_LOG
    for each row
BEGIN
 SELECT DMPDB2.SEQ_R_OP_Log.NEXTVAL INTO :NEW.ID FROM DUAL;
END ;
/

