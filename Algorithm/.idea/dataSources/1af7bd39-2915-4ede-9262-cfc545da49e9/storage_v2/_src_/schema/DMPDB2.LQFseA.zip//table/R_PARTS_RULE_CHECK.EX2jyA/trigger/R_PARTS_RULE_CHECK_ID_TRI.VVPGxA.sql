create trigger R_PARTS_RULE_CHECK_ID_TRI
    before insert
    on R_PARTS_RULE_CHECK
    for each row
BEGIN
   SELECT DMPDB2.SEQ_R_PARTS_RULE_CHECK_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

