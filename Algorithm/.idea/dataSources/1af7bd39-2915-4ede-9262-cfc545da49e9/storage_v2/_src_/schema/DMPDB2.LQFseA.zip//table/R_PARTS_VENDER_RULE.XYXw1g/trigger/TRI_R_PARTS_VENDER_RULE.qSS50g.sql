create trigger TRI_R_PARTS_VENDER_RULE
    before insert
    on R_PARTS_VENDER_RULE
    for each row
BEGIN
        SELECT DMPDB2.SEQ_R_PARTS_VENDER_RULE.nextval INTO :new.ID FROM dual;
END;
/

