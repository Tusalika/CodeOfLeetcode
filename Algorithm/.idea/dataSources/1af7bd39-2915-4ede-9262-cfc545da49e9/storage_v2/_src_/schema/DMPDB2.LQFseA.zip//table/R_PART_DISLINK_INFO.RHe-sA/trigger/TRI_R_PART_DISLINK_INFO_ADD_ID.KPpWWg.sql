create trigger TRI_R_PART_DISLINK_INFO_ADD_ID
    before insert
    on R_PART_DISLINK_INFO
    for each row
BEGIN  SELECT DMPDB2. seq_R_PART_DISLINK_INFO_id.nextval into :new.id from dual; end;
/

