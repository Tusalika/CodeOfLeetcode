create trigger R_PDCA_NAME_TRG
    before insert
    on R_PDCA_NAME
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select R_PDCA_NAME_SEQ.nextval into n from dual;
  :new.ID := N;
END R_PDCA_NAME_TRG;
/

