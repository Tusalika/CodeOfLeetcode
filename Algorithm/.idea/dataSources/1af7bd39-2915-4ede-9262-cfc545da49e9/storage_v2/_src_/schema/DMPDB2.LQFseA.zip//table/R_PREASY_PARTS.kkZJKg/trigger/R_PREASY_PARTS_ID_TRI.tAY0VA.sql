create trigger R_PREASY_PARTS_ID_TRI
    before insert
    on R_PREASY_PARTS
    for each row
BEGIN
   SELECT DMPDB2.SEQ_R_PREASY_PARTS_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

