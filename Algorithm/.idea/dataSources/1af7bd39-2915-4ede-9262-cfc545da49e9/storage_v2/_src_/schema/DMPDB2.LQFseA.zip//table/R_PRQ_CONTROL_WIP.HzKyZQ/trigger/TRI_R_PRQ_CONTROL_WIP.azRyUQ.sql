create trigger TRI_R_PRQ_CONTROL_WIP
    before insert
    on R_PRQ_CONTROL_WIP
    for each row
BEGIN  SELECT DMPDB2.R_PRQ_CONTROL_WIP_SEQ.NEXTVAL INTO :NEW.ID
 FROM dual;
 END;
/

