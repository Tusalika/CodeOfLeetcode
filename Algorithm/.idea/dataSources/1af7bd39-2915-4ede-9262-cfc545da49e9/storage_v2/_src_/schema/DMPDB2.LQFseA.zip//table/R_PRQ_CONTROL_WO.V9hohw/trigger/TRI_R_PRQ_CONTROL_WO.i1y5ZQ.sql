create trigger TRI_R_PRQ_CONTROL_WO
    before insert
    on R_PRQ_CONTROL_WO
    for each row
BEGIN  SELECT DMPDB2.R_PRQ_CONTROL_SEQ.NEXTVAL INTO :NEW.ID
 FROM dual;
 END;
/

