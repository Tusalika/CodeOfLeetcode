create trigger R_REPLACE_PARTS_JUDGE_TRG
    before insert
    on R_REPLACE_PARTS_JUDGE
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select R_REPLACE_PARTS_JUDGE_SEQ.nextval into n from dual;
  :new.ID := N;
END R_REPLACE_PARTS_JUDGE_TRG;
/

