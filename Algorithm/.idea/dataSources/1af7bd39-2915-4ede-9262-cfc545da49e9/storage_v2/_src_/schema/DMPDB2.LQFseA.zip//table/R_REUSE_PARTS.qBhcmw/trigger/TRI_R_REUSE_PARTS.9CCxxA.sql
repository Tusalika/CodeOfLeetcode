create trigger TRI_R_REUSE_PARTS
    before insert
    on R_REUSE_PARTS
    for each row
BEGIN
 SELECT DMPDB2.SEQ_R_REUSE_PARTS.nextval INTO :new.ID FROM DUAL;
END ;
/

