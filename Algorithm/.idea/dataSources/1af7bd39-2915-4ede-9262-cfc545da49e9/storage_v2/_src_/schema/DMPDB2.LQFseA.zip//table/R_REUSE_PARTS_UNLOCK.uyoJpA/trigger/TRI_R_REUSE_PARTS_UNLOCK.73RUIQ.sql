create trigger TRI_R_REUSE_PARTS_UNLOCK
    before insert
    on R_REUSE_PARTS_UNLOCK
    for each row
BEGIN  SELECT DMPDB2.SEQ_R_REUSE_PARTS_UNLOCK.nextval
 INTO :new.ID FROM dual; END;
/

