create trigger TRI_R_REWORK_REQUEST
    before insert
    on R_REWORK_REQUEST
    for each row
DECLARE 
  N NUMBER; 
BEGIN 
  Select DMPDB2.SEQ_r_rework_request.nextval into :new.ID from dual; 
END ;
/

