create trigger TRI_REWORK_REQUEST_WIP_INFO
    before insert
    on R_REWORK_REQUEST_WIP_INFO
    for each row
DECLARE 
  N NUMBER; 
BEGIN 
  Select DMPDB2.SEQ_rework_request_wip_info.nextval into :new.ID from dual; 
END ;
/

