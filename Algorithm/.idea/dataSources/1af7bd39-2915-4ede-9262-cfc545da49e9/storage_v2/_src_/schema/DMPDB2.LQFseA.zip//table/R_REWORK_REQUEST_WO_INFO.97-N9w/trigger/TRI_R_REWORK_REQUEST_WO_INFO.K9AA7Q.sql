create trigger TRI_R_REWORK_REQUEST_WO_INFO
    before insert
    on R_REWORK_REQUEST_WO_INFO
    for each row
DECLARE 
  N NUMBER; 
BEGIN 
  Select DMPDB2.SEQ_r_rework_request_wo_info.nextval into :new.ID from dual; 
END ;
/

