create trigger TRI_R_SALE_PLANT_CODE_ADD_ID
    before insert
    on R_SALE_PLANT_CODE
    for each row
BEGIN  SELECT DMPDB2.seq_r_sale_plant_code_id.nextval into :new.id from dual; end;
/

