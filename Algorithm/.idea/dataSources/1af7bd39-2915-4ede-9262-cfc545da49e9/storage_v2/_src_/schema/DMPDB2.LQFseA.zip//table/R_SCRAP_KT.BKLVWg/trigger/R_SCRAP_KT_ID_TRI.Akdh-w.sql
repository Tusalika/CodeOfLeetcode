create trigger R_SCRAP_KT_ID_TRI
    before insert
    on R_SCRAP_KT
    for each row
BEGIN  SELECT  DMPDB2.SEQ_R_SCRAP_KT_ID.nextval into :new.id from dual; end;
/

