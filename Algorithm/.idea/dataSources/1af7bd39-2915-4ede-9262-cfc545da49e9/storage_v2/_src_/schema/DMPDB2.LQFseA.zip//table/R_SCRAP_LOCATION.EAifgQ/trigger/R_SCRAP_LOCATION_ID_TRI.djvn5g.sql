create trigger R_SCRAP_LOCATION_ID_TRI
    before insert
    on R_SCRAP_LOCATION
    for each row
BEGIN  SELECT  DMPDB2.SEQ_R_SCRAP_LOCATION_ID.nextval into :new.id from dual; end;
/

