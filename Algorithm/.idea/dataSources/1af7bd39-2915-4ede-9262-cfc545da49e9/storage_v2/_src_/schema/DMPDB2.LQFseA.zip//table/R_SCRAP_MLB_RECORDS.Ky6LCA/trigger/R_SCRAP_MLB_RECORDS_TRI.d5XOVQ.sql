create trigger R_SCRAP_MLB_RECORDS_TRI
    before insert
    on R_SCRAP_MLB_RECORDS
    for each row
BEGIN
   SELECT DMPDB2.R_SCRAP_MLB_RECORDS_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

