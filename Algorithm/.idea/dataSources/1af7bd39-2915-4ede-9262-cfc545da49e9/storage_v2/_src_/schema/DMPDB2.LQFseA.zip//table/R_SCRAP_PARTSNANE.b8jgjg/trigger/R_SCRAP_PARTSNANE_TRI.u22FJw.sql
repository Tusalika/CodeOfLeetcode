create trigger R_SCRAP_PARTSNANE_TRI
    before insert
    on R_SCRAP_PARTSNANE
    for each row
BEGIN
   SELECT DMPDB2.R_SCRAP_PARTSNANE_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

