create trigger R_SCRAP_PARTS_NOSN_TRI
    before insert
    on R_SCRAP_PARTS_NOSN
    for each row
BEGIN
   SELECT DMPDB2.R_SCRAP_PARTS_NOSN_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

