create trigger R_SCRAP_PICTURE_ID_TRI
    before insert
    on R_SCRAP_PARTS_PICTURE
    for each row
BEGIN  SELECT  dmpdb2.seq_R_SCRAP_PICTURE_ID.nextval into :new.id from dual; end;
/

