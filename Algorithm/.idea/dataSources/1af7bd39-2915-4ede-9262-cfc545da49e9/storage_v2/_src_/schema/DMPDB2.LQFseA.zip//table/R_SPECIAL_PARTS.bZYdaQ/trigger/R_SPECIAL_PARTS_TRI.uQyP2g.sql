create trigger R_SPECIAL_PARTS_TRI
    before insert
    on R_SPECIAL_PARTS
    for each row
BEGIN
   SELECT DMPDB2.R_SPECIAL_PARTS_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

