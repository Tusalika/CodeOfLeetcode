create trigger R_UNWO_PARTS_ID_TRI
    before insert
    on R_UNWO_PARTS
    for each row
BEGIN
   SELECT DMPDB2.R_UNWO_PARTS_id.NEXTVAL INTO :new.id FROM DUAL;
END;
/

