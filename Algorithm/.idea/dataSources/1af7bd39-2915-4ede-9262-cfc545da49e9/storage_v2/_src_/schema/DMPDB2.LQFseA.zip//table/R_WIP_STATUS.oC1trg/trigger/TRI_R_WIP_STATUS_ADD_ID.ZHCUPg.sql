create trigger TRI_R_WIP_STATUS_ADD_ID
    before insert
    on R_WIP_STATUS
    for each row
BEGIN  SELECT dmpdb2.seq_r_wip_status_id.nextval into :new.id from dual; end;
/

