create trigger TRI_R_WORK_TIME_ID
    before insert
    on R_WORK_TIME
    for each row
BEGIN
   SELECT dmpdb2.s_r_work_time_id.NEXTVAL
     INTO :NEW.ID
     FROM DUAL;
END
;
/

