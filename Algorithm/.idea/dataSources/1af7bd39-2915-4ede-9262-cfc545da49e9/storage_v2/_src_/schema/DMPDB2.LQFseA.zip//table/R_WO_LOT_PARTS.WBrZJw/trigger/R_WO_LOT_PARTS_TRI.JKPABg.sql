create trigger R_WO_LOT_PARTS_TRI
    before insert
    on R_WO_LOT_PARTS
    for each row
BEGIN  SELECT  dmpdb2.R_WO_LOT_PARTS_deq.nextval into :new.id from dual; end;
/

