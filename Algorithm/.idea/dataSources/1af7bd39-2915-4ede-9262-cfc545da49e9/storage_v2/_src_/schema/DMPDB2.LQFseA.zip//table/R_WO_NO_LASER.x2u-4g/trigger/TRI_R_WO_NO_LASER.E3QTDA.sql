create trigger TRI_R_WO_NO_LASER
    before insert
    on R_WO_NO_LASER
    for each row
BEGIN  SELECT  DMPDB2.R_WO_NO_LASER_ID.nextval into :new.id from dual; end;
/

