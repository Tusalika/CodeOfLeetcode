create trigger SORTING_ROUTE_CHART_TRI
    before insert
    on SORTING_ROUTE_CHART
    for each row
BEGIN
   SELECT DMPDB2.Sorting_Route_Chart_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

