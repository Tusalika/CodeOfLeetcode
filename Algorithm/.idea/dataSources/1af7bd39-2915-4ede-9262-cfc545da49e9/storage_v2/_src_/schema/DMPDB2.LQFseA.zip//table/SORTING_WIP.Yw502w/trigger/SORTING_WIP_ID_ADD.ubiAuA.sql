create trigger SORTING_WIP_ID_ADD
    before insert
    on SORTING_WIP
    for each row
BEGIN
   SELECT DMPDB2.Sorting_Wip_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

