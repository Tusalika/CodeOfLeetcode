create trigger SORTING_WIP_LOG_ID_ADD
    before insert
    on SORTING_WIP_LOG
    for each row
BEGIN
   SELECT DMPDB2.SORTING_WIP_LOG_ID.NEXTVAL INTO :new.id FROM DUAL;
END;
/

