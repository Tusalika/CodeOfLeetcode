create trigger TRI_STATION_TIME_INTERVAL_ID
    before insert
    on STATION_TIME_INTERVAL
    for each row
BEGIN  SELECT  DMPDB2.STATION_TIME_INTERVAL_ID.nextval into :new.id from dual; end;
/

