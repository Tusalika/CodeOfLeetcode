create trigger TRI_STOPLINE_REASON_ID
    before insert
    on STOPLINE_REASON
    for each row
BEGIN  
  SELECT dmpdb2.s_STOPLINE_REASON_id.nextval  INTO :new.ID   FROM dual; 
END;
/

