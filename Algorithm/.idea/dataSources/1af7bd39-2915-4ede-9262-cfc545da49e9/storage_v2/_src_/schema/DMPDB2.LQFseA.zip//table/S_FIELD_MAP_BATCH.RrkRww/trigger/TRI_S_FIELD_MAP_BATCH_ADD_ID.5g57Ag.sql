create trigger TRI_S_FIELD_MAP_BATCH_ADD_ID
    before insert
    on S_FIELD_MAP_BATCH
    for each row
BEGIN  SELECT DMPDB2.seq_S_FIELD_MAP_BATCH_id.nextval into :new.id from dual; end;
/

