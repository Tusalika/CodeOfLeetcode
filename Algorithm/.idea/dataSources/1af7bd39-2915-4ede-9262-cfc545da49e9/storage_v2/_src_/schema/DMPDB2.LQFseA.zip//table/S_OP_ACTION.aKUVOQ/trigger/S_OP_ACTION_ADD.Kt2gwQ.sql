create trigger S_OP_ACTION_ADD
    before insert
    on S_OP_ACTION
    for each row
BEGIN
     SELECT dmpdb2.SEQ_S_OP_ACTION_ID.NEXTVAL INTO :new.id FROM DUAL;
 END;
/

