create trigger S_OP_ACTION_MAPPING_ADD
    before insert
    on S_OP_ACTION_MAPPING
    for each row
BEGIN
     SELECT DMPDB2.SEQ_S_OP_Action_Mapping_ID.NEXTVAL INTO :new.id FROM DUAL;
 END;
/

