create trigger S_OP_SYS_MAPPING_ADD
    before insert
    on S_OP_SYS_MAPPING
    for each row
BEGIN
     SELECT dmpdb2.SEQ_S_OP_MAPPING_ID.NEXTVAL INTO :new.id FROM DUAL;
 END;
/

