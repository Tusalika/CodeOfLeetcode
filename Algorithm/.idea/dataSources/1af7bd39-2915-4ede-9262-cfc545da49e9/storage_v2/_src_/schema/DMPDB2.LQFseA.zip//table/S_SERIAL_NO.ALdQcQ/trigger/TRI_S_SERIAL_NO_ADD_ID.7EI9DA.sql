create trigger TRI_S_SERIAL_NO_ADD_ID
    before insert
    on S_SERIAL_NO
    for each row
BEGIN  SELECT dmpdb2.seq_S_SERIAL_NO_id.nextval into :new.id from dual; end;
/

