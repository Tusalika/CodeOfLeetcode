create trigger TRI_S_SFC_NO_ID
    before insert
    on S_SFC_NO
    for each row
BEGIN  SELECT DMPDB2.seq_S_SFC_NO_ID.nextval INTO :new.ID FROM dual; 
end;
/

