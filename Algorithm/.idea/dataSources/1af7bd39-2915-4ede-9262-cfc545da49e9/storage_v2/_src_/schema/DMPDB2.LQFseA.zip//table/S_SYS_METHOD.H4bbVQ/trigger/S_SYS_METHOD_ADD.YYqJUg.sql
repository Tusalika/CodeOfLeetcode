create trigger S_SYS_METHOD_ADD
    before insert
    on S_SYS_METHOD
    for each row
BEGIN
     SELECT dmpdb2.SEQ_S_SYS_METHOD_ID.NEXTVAL INTO :new.id FROM DUAL;
 END;
/

